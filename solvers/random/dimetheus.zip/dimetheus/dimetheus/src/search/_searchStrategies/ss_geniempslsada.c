/*	DIMETHEUS SAT SOLVER
 * 	Author:		Oliver Gableske	(oliver@gableske.net)
 *	Website:	http://www.gableske.net/dimetheus
 *  License:	See ./doc/license.txt
 */

#include "searchStrategies.h"

void search_strategy_geniempslsada_printHelp(){
	printf("c      %-3d: GENIEMPSLSADA\n", SEARCH_STRATEGY_GENIEMPSLSADA);
    printf("c           Behavior: Decimates based on free entropy estimation and performs SLS if necessary [MP, SLS].\n");
}

void search_strategy_geniempslsada_reset(){
	#ifdef VERBOSE_SEARCH
	printf("c   SEARCH: Strategy reset (GENIEMPSLSADA)...\n");
	#endif
	mp_resetModule();
	sls_resetModule();

	search_strategy_geniempslsada_midCheckSize = 1;
	search_strategy_geniempslsada_maxMagForSLS = ZERO;
	search_strategy_geniempslsada_minEntropyDensity = ZERO;
}

void search_strategy_geniempslsada_init(){
	#ifdef VERBOSE_SEARCH
	printf("c   SEARCH: Strategy init (GENIEMPSLSADA)...\n");
	#endif
	mp_initModule(); if (mp_returnCode != MP_UNKNOWN){ search_returnCode = SEARCH_ERROR; return; }
	sls_initModule(); if (sls_returnCode != SLS_UNKNOWN){ search_returnCode = SEARCH_ERROR; return; }

	//Search strategy settings.
	search_strategy_geniempslsada_midCheckSize = param_searchMIDCheckSize * f.n_vars_e_used;
	if (search_strategy_geniempslsada_midCheckSize == 0U) ++search_strategy_geniempslsada_midCheckSize;
	search_strategy_geniempslsada_maxMagForSLS = param_searchMaxMagForSLS;
	search_strategy_geniempslsada_minEntropyDensity = param_searchMIDMinEntropyDensity;
	#ifdef VERBOSE_SEARCH
	printf("c   SEARCH:   param_searchMIDCheckSize                    = %f\n", param_searchMIDCheckSize);
	printf("c   SEACRH:   param_searchMaxMagForSLS                    = %f\n", param_searchMaxMagForSLS);
	printf("c   SEACRH:   param_searchMIDMinEntropyDensity            = %f\n", param_searchMIDMinEntropyDensity);
	printf("c   SEARCH:   search_strategy_geniempslsada_midBlockSize  = %u\n", search_strategy_geniempslsada_midCheckSize);
	printf("c   SEARCH:   search_strategy_geniempslsada_maxMagForSLS  = %f\n", search_strategy_geniempslsada_maxMagForSLS);
	#endif
}

void search_strategy_geniempslsada_dispose(){
	#ifdef VERBOSE_SEARCH
	printf("c   SEARCH: Strategy dispose (GENIEMPSLSADA)...\n");
	#endif
	mp_disposeModule();
	sls_disposeModule();

	search_strategy_geniempslsada_midCheckSize = 1;
	search_strategy_geniempslsada_maxMagForSLS = ZERO;
	search_strategy_geniempslsada_minEntropyDensity = ZERO;
}


void search_strategy_geniempslsada_execute(){
	#ifdef VERBOSE_SEARCH
	printf("c   SEARCH: Strategy execute (GENIEMPSLSADA)...\n");
	#endif

	int32_t MID = 1, conflict = 0;

	#ifdef VERBOSE_SEARCH
	printf("c   SEARCH: Starting the decimation...\n");
	#endif

	do {
		#ifdef VERBOSE_SEARCH
		printf("c   SEARCH: Calling for MP. VARS: %6d...\n", f.n_vars_e_used);
		#endif
		//We perform MP on the global formula and check on its result.
		mp_extern_iterate(1);
		//If MP did converge, we can compute biases, otherwise we stick to the current ones.
		if (mp_returnCode == MP_CONVERGED) {
			//Yes, it did converge. Computing new biases is useful.
			mp_extern_computeBiases();

			#ifdef VERBOSE_SEARCH
			printf("c   SEARCH: MP_CONVERGED");
			if (mp_returnCode == MP_CONVERGED_PARAMAG){	printf("_PARAMAG");}
			else if (mp_returnCode == MP_CONVERGED_UNFROZEN_POSFERR){ printf("_UNFROZEN_POSFERR");}
			else if (mp_returnCode == MP_CONVERGED_UNFROZEN_NEGFERR){ printf("_UNFROZEN_NEGFERR");}
			else if (mp_returnCode == MP_CONVERGED_UNFROZEN_MIXED){ printf("_UNFROZEN_MIXED");}
			else if (mp_returnCode == MP_CONVERGED_FROZEN_POSFERR){ printf("_FROZEN_QUENDIS");}
			else if (mp_returnCode == MP_CONVERGED_FROZEN_NEGFERR){ printf("_FROZEN_QUENDIS");}
			else if (mp_returnCode == MP_CONVERGED_FROZEN_QUENDIS){ printf("_FROZEN_QUENDIS");}
			printf(" (global max. mag. %f, global frozenness %f, global bias %f).\n",
					mp_globalMaxMagnetization, mp_globalFrozenness, mp_globalBias);
			#endif

			//In case the magnetization of the formula is small, we call the SLS for a single try on the sub-formula with
			//limited number of flips allowed.
			if (mp_globalMaxMagnetization < search_strategy_geniempslsada_maxMagForSLS){
				#ifdef VERBOSE_SEARCH
				printf("c   SEARCH: Calling for SLS because of low magnetization.\n");
				#endif
				#ifdef COLLECTSTATS
				if (stats_search_firstParamagNumVar == -1) stats_search_firstParamagNumVar = f.n_vars_e_used;
				if (stats_search_firstParamagNumCls == -1) stats_search_firstParamagNumCls = f.m_eo_used + f.m_el_used;
				stats_search_lastParamagNumVar = f.n_vars_e_used;
				stats_search_lastParamagNumCls = f.m_eo_used + f.m_el_used;
				#endif
				sls_extern_tryRestartRules_switch(param_slsTryRestartRule);
				sls_extern_localSearch(1);
				if (sls_returnCode == SLS_SAT){
					break;
				} else if (sls_returnCode == SLS_ERROR){
					search_returnCode = SEARCH_ERROR;
					break;
				}
			}
		} else if (mp_returnCode == MP_UNCONVERGED) {
			#ifdef VERBOSE_SEARCH
			printf("c   SEARCH: UNCONVERGED.\n");
			#endif
		} else {
			//The return code is unexpected.
			#ifdef VERBOSE_SEARCH
			printf("c   SEARCH: ERROR. Unexpected return code %d of MP.\n", mp_returnCode);
			#endif
			printf("c ERROR. GENIEMPSLSADA asked for MP but this resulted in an error (A). GENIEMPSLSADA failed.\n");
			search_returnCode = SEARCH_ERROR; MID = 0; break;
		}

		//After computing biases, we will now fill the priority queue with all the unassigned variables for assignment.
		search_strategy_geniempslsada_sortVariables();

		//In case the queue is empty, we have no further assignments to make. The decimation is over and the search is
		//handed over to the SLS.
		if (vQ_leaf < 2){
			//Nothing was added to the queue. No further decimation is possible.
			MID = 0;
		} else {
			//Further variables have been added to the queue, so further decimation is possible. We then perform the
			//assignments. The result is either a conflict or no conflict.
			if (search_strategy_geniempslsada_assignOrdered()){
				//The decimation ended in a conflict. From here on, we hand over the search to SLS.
				MID = 0;
				conflict = 1;
			}
		}
	} while (MID);

	//The MID phase is now over.
	if (search_returnCode == SEARCH_ERROR) return;

	//We check if the solution was provided by SLS or whether the decimation ran into a conflict.
	if (sls_returnCode == SLS_SAT){
		#ifdef VERBOSE_SEARCH
		printf("c   SEARCH: Decimation ended prematurely (%d variables, %d clauses).\n", f.n_vars_e_used, f.m_eo_used + f.m_el_used);
		printf("c   SEARCH: SLS found a solution. GENIEMPSLSADA succeeded. Copying variable assignments.\n");
		#endif
		//The SLS did indeed find a solution.
		search_intern_transferSLSAss();
		search_returnCode = SEARCH_SAT;
	} else if (conflict) {
		#ifdef VERBOSE_SEARCH
		printf("c   SEARCH: Decimation ended (%d variables, %d clauses).\n", f.n_vars_e_used, f.m_eo_used + f.m_el_used);
		printf("c   SEARCH: Decimation ended in a CONFLICT. Storing phases and reverting temporary assignments.\n");
		#endif
		//We will now revert all the assignments that have been made so far. All assignments where only temporary. After that
		//the SLS will perform the search with all the phases the variables had last.
		search_strategy_geniempslsada_retainAllPhases();
		main_decStack_backJump(1,1,1);

		#ifdef VERBOSE_SEARCH
		printf("c   SEARCH: Calling for SLS.\n");
		#endif

		//We now call for the SLS module to perform the search using the phases that have been gathered so far.
		sls_extern_tryRestartRules_switch(SLS_TRYRESTARTRULE_SINGLEUNLIMITED);
		sls_extern_localSearch(1);
		if (sls_returnCode == SLS_UNKNOWN){
			#ifdef VERBOSE_SEARCH
			printf("c   SEARCH: SLS was unable to find a satisfying assignment. GENIEMPSLSADA failed.\n");
			#endif
			//The SLS did not find a satisfying assignment. This does not necessarily mean that there is none, but in
			//the current search strategy, this is considered a failure.
			search_returnCode = SEARCH_UNKNOWN;
		} else if (sls_returnCode == SLS_SAT){
			#ifdef VERBOSE_SEARCH
			printf("c   SEARCH: SLS found a solution. GENIEMPSLSADA succeeded. Copying variable assignments.\n");
			#endif
			//The SLS did indeed find a solution.
			search_intern_transferSLSAss();
			search_returnCode = SEARCH_SAT;
		} else {
			#ifdef VERBOSE_SEARCH
			printf("c   SEARCH: SLS return code unexpected after local search. We assume an error. GENIEMPSLSADA failed.\n");
			#endif
			//In case we get this far, the SLS returned an unexpected return code. The strategy failed.
			search_returnCode = SEARCH_ERROR;
		}
	} else {
		#ifdef VERBOSE_SEARCH
		printf("c   SEARCH: Decimation ended (%d variables, %d clauses).\n", f.n_vars_e_used, f.m_eo_used + f.m_el_used);
		printf("c   SEARCH: Decimation ended after assigning all variables. Calling the SLS is not necessary.\n");
		#endif
		search_returnCode = SEARCH_SAT;
	}
}

void search_strategy_geniempslsada_sortVariables(){
	//This method will fill the variable priority queue with all the variables, using the current bias absolute value as
	//the score (the stronger the bias, the more priority the variable has, and the sooner it will be assigned).
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	#endif

	variable *v;
	uint32_t count = 0;
	vQ_flush();

	while (count < f.n_vars_e_used){
		v = f.vars_e[count++];
		if (!IS_VAR_UNASSIGNED(v)) continue;
		//Recall, that the priority queue for variables uses an int32_t to keep the scores. Smaller values are better scores.
		//The larger the activity, the farther at the end the element will be. The first element will always be the one with
		//the worst activity.
		SET_VAR_Q_SCORE(v,-GET_VAR_Q_SCORE_FROM_VAR_ACTIVITY(v));
		vQ_enqueue(v);
	}


	#ifdef COLLECTSTATS
	stats_search_time_varSorting += STATS_GET_CURRENT_TIME_IN_SEC() - time_start;
	#endif
}

int32_t search_strategy_geniempslsada_assignOrdered(){
	//This method assigns the variables from the priority queue in their given order.

	variable *v;
	literal *l;
	clause *c;
	uint32_t numAssigned = 0, currentEnabled, numChecks = 0;

	#ifdef VERBOSE_SEARCH
	//We output the free entropy density for informative reasons now.
	mp_extern_computeFreeEntropy();
	printf("c   SEARCH: Free entropy density currently is %f, minimum allowed is %f.\n", mp_freeEntropyDensity,
			search_strategy_geniempslsada_minEntropyDensity);
	#endif

	while ((v = vQ_dequeueBest()) != NULL){
		//We ignore already assigned variables and just remove them from the queue.
		if (!IS_VAR_UNASSIGNED(v)){
			continue;
		}
		//We store the currently enabled variables in order to check how many UP assigned.
		currentEnabled = f.n_vars_e_used;
		//The variable has not yet been assigned. We will assign it according to its current phase.
		if (GET_VAR_PHASE(v)){
			l = main_litData + GET_VAR_ID(v);
		} else {
			l = main_litData - GET_VAR_ID(v);
		}
		MAIN_COMPLEXUP_ADD_DEC_PTR(l, v);
		//Unit propagate and check the result.
		c = main_complexup_propagate(1);
		//Check if this resulted in a conflict.
		if (c != NULL){
			//It did result in a conflict. We return this result. We also remove all the other elements from the queue.
			vQ_flush();
			return 1;
		}
		//Otherwise, we did not run into a conflict. We now check the difference between the formerly enabled variables and
		//the currently enabled variables. The difference is the number of variables that have been assigned. We then add
		//this onto the numAssigned.
		currentEnabled = currentEnabled - f.n_vars_e_used;
		numAssigned += currentEnabled;

		//We now check whether we have assigned the required amount of variables to re-compute the estimate for the free
		//entropy density. If this is the case, we recompute it and check whether it became too small (if so, MP will
		//be forced to compute new biases).
		if (numAssigned >= search_strategy_geniempslsada_midCheckSize){
			++numChecks;
			//Yes it is time to recompute the free entropy density.
			mp_extern_computeFreeEntropy();
			#ifdef VERBOSE_SEARCH
			printf("c   SEARCH: Checks: %d. New assignments: %d. New estimate for the free entropy density: %f",
					(int32_t)numChecks, (int32_t)numAssigned, mp_freeEntropyDensity);
			#endif
			if (mp_freeEntropyDensity < search_strategy_geniempslsada_minEntropyDensity){
				#ifdef VERBOSE_SEARCH
				printf(" < %f.\n", search_strategy_geniempslsada_minEntropyDensity);
				#endif
				//Ok, the free entropy density is estimated to be too small. We must stop decimating.
				break;
			}
			#ifdef VERBOSE_SEARCH
			else {
				printf(".\n");
			}
			#endif
			//We can now also reset the number of assigned variables.
			numAssigned = 0;
		}
	}

	//If it worked out without a conflict we return so.
	vQ_flush();
	return 0;
}

void search_strategy_geniempslsada_retainAllPhases(){
	//This method will simply override the phases of all currently assigned variables to whatever they are assigned now.
	variable *v;
	uint32_t i;

	for (i = 1; i < f.n_initial +1; ++i){
		v = main_varData + i;
		if (IS_VAR_UNASSIGNED(v)) continue;
		if (IS_VAR_TRUE(v)){
			SET_VAR_PHASE_1(v);
		} else {
			SET_VAR_PHASE_0(v);
		}
	}
}
