/*	DIMETHEUS SAT SOLVER
 * 	Author:		Oliver Gableske	(oliver@gableske.net)
 *	Website:	http://www.gableske.net/dimetheus
 *  License:	See ./doc/license.txt
 */

#ifndef SS_GENIEMPCDCL_H_
#define SS_GENIEMPCDCL_H_

#include "searchStrategies.h"

#include "../CDCL/_datastructures/cdclClauses.h"
#include "../CDCL/_datastructures/cdclLiterals.h"
#include "../CDCL/_datastructures/cdclVariables.h"

uint32_t search_strategy_geniempcdcl_midBlockSize;		//The number of variables that is to be assigned.
float_ty search_strategy_geniempcdcl_maxMPImpact;		//How much impact is allowed before we disable MP till next unit?
uint32_t search_strategy_geniempcdcl_assignmentMax;		//How many variables must the CDCL assign before it must return?

void search_strategy_geniempcdcl_printHelp();					//Show strategy help.

void search_strategy_geniempcdcl_reset();						//Reset everything for this strategy.
void search_strategy_geniempcdcl_init();						//Initialize everything for this strategy.
void search_strategy_geniempcdcl_dispose();						//Dispose everything for this strategy.

void search_strategy_geniempcdcl_execute();						//Execute the search.

uint32_t search_strategy_geniempcdcl_isCDCLClauseSubsumed(cdclClause*);//Checks if the CDCL clause is subsumed by main formula.
float_ty search_strategy_geniempcdcl_updateMessages(clause*);	//This method computes the omega warning messages for the clause.
float_ty search_strategy_geniempcdcl_retainNewEquivalences();	//This method retains new equivalences found by the CDCL.
float_ty search_strategy_geniempcdcl_convertImpactingClauses();	//This method retains MP impacting clauses learned by CDCL.
float_ty search_strategy_geniempcdcl_retainNewUnits();			//This method propagates new unit assignments found by the CDCL.
void search_strategy_geniempcdcl_assumeAndUpdate();				//Does MP under the given CDCL assignments as assumptions.

#endif /* SS_GENIEMPCDCL_H_ */
