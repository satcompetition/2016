/*	DIMETHEUS SAT SOLVER
 * 	Author:		Oliver Gableske	(oliver@gableske.net)
 *	Website:	http://www.gableske.net/dimetheus
 *  License:	See ./doc/license.txt
 */

#ifndef SS_GENIEMPSLSADA_H_
#define SS_GENIEMPSLSADA_H_

#include "searchStrategies.h"

uint32_t search_strategy_geniempslsada_midCheckSize;	//The number of variables that is to be assigned before MID computes
														//the internal entropy density in order to decide whether to continue.
float_ty search_strategy_geniempslsada_maxMagForSLS;	//If the magnetization of the formula drops below this value, do SLS.
float_ty search_strategy_geniempslsada_minEntropyDensity;//The minimum entropy we allow before we force MP into a new cycle.

void search_strategy_geniempslsada_printHelp();			//Show strategy help.

void search_strategy_geniempslsada_reset();				//Reset everything for this strategy.
void search_strategy_geniempslsada_init();				//Initialize everything for this strategy.
void search_strategy_geniempslsada_dispose();			//Dispose everything for this strategy.

void search_strategy_geniempslsada_sortVariables();		//Adds the highest biased variables into the queue.
int32_t search_strategy_geniempslsada_assignOrdered();	//Assigns the ordered variables on the main decision stack.
void search_strategy_geniempslsada_retainAllPhases();	//Overrides all the phases with current assignments.

void search_strategy_geniempslsada_execute();			//Execute the search.

#endif /* SS_GENIEMPSLSADA_H_ */
