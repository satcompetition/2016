/*	DIMETHEUS SAT SOLVER
 * 	Author:		Oliver Gableske	(oliver@gableske.net)
 *	Website:	http://www.gableske.net/dimetheus
 *  License:	See ./doc/license.txt
 */

#include "mp.h"

void mp_intern_retainMsgs(){
	//This method will walk through all the clauses of the global formula, check which of them was used in the iteration,
	//and copy all the messages locally known to the global messages array. This way we retain the last set of messages.
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	#endif
	#ifdef VERBOSE_MP
	printf("c     MP:   Retaining clause messages.\n");
	#endif
	mp_clauses_retainMsgs();
	#ifdef COLLECTSTATS
	stats_mp_time_retaining += (STATS_GET_CURRENT_TIME_IN_SEC() - time_start);
	#endif
}

void mp_intern_retainBiases(){
	//This method will walk through all the variables of the global formula, and update the variables activity to the bias of
	//the variable after MP converged.
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	#endif
	#ifdef VERBOSE_MP
	printf("c     MP:   Retaining variable biases.\n");
	#endif
	mp_variables_retainBiases();

	#ifdef COLLECTSTATS
	stats_mp_time_retaining += (STATS_GET_CURRENT_TIME_IN_SEC() - time_start);
	#endif
}

void mp_extern_printVersion(){
	printf("[Search          ] [Message Passing                ] :: %3d.%-4d :: %s",
			MP_VERSION_MA, MP_VERSION_MI, MP_VERSION_NAME);
}

void mp_extern_iterate(uint32_t prepareAnew){
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	++stats_mp_component_totalCalls;
	#endif
	float_ty minMessageDiff = 1.0;
	uint32_t numIterations = 0, numNonImpIterations = 0;
	mp_returnCode = MP_UNKNOWN;
	//First we prepare the call to the message passing component.
	if (prepareAnew){
		#ifdef VERBOSE_MP
		printf("c     MP: Preparing call...\n");
		printf("c     MP:   Data-structures...\n");
		#endif
		//Prepare the snapshot view of the formula for the MP module.
		mp_variables_prepareCall();
		mp_literals_prepareCall();
		mp_clauses_prepareCall();

		#ifdef VERBOSE_MP
		printf("c     MP:     Variables: %u, Clauses %u\n", mp_varNum, mp_clsUsed);
		printf("c     MP:   Plug-ins...\n");
		#endif
		//Prepare the call to all plug-ins.
		mp_updateRule_prepare();

		//Prepare local parameters.
		perm_LFSR_init(mp_clsUsed);
		#ifdef VERBOSE_MP
		printf("c     MP:   Message passing configuration:\n");
		printf("c     MP:     ");perm_LFSR_printConfig_inline();printf("\n");
		#endif
	}

	#ifdef COLLECTSTATS
	stats_mp_time_init += STATS_GET_CURRENT_TIME_IN_SEC() - time_start;
	float_ty time_start_iterations = STATS_GET_CURRENT_TIME_IN_SEC();
	#endif

	//Second, we perform the message passing.
	#ifdef VERBOSE_MP
	printf("c     MP: Iterating (mp_maxMessageDiff): ");
	#endif
	do {
		//A single message passing round (called an iteration) updates all messages and and checks whether the maximum number
		//of iterations is reached. If so, no convergence occurred. Non-convergence might also occur, if too many non-improving
		//iterations were performed. In case non of these situations occur, then the maximum difference between a new and an
		//old message we found during all updates was small enough such that we can assume our message passing converged
		//against a stable configuration of the messages (called an equilibrium).
		mp_maxMessageDiff = 0.0f;
		mp_updateRule_msgUpdate();
		if (mp_returnCode == MP_ERROR) {
			#ifdef COLLECTSTATS
			++stats_mp_return_ERROR;
			#endif
			return;
		}
		//After the iteration, we increase its value.
		++numIterations;
		//We now check if the maximum message difference encountered in the last round improved the situation.
		if (mp_maxMessageDiff < minMessageDiff){
			//Yes, the new message difference is even smaller than the smallest encountered so far. We make it the new
			//smallest value and reset the counter for non-improving iterations.
			minMessageDiff = mp_maxMessageDiff;
			numNonImpIterations = 0;
		} else {
			//No, the new message difference is not smaller than the smallest encountered so far. We increase the counter
			//for non-improving iterations.
			++numNonImpIterations;
		}
		#ifdef VERBOSE_MP
		printf("%1.3f", mp_maxMessageDiff);
		if (minMessageDiff == mp_maxMessageDiff){
			//The last iteration improved the situation.
			printf("+ ");
		} else {
			//The last iteration did not improve the situation.
			printf("- ");
		}
		if (numIterations % 10U == 0U)
			printf("  (%d iterations)\nc     MP:                                ", numIterations);
		fflush(stdout);
		#endif
	} while (//Continue, if...
			(mp_maxMessageDiff > param_mpMaxConvergenceDiff)		//... no equilibrium has been reached, and
			&& (numIterations < param_mpMaxNumIterations)			//... the maximum number of iterations is not reached, and
			&& (numNonImpIterations < param_mpMaxNonImpIterations)	//... not too many non-improving iterations were seen.
			);
	#ifdef VERBOSE_MP
	printf("%d iterations.\n", numIterations);
	#endif

	#ifdef COLLECTSTATS
	stats_mp_passing_numIterations += numIterations;
	stats_mp_time_iterating += STATS_GET_CURRENT_TIME_IN_SEC() - time_start_iterations;
	#endif

	//Third, we evaluate the result.
	if (mp_maxMessageDiff <= param_mpMaxConvergenceDiff){
		//Message passing did converge.
		#ifdef VERBOSE_MP
		printf("c     MP:   Converged (maximum message difference was %f < %f).\n",
				mp_maxMessageDiff, param_mpMaxConvergenceDiff);
		#endif
		mp_returnCode = MP_CONVERGED;
		#ifdef COLLECTSTATS
		++stats_mp_return_CONVERGED;
		#endif
	} else {
		//No convergence.
		#ifdef VERBOSE_MP
		printf("c     MP:   UNCONVERGED (maximum message difference %f, non-improving iterations %d).\n",
				mp_maxMessageDiff, numNonImpIterations);
		#endif
		mp_returnCode = MP_UNCONVERGED;
		#ifdef COLLECTSTATS
		++stats_mp_return_UNCONVERGED;
		if (stats_mp_iters_firstUnconverged == 0) stats_mp_iters_firstUnconverged = stats_mp_return_CONVERGED+1;
		#endif
	}
	#ifdef COLLECTSTATS
	stats_mp_time_total += (STATS_GET_CURRENT_TIME_IN_SEC() - time_start);
	#endif
}

void mp_extern_computeBiases(){
	//We compute the global magnetization and biases to detect if the state is paramagnetic or not.
	mpVariable* var;
	uint32_t i, numVarsUsed;
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	++stats_mp_component_totalCalls;
	#endif
	#ifdef VERBOSE_MP
	printf("c     MP: Computing variable magnetization, variable biases, global magnetization...\n");
	printf("c     MP:   param_mpMaxMagnetization = %f\n", param_mpMaxMagnetization);
	printf("c     MP:   param_mpMinFrozenness    = %f\n", param_mpMinFrozenness);
	printf("c     MP:   param_mpMinFerro         = %f\n", param_mpMinFerro);
	#endif
	//First, we call the MP algorithm to provide positive, negative and joker marginals as well as the bias.
	mp_updateRule_computeBias();

	//Second, we use the acquired information in order to determine the magnetization values.
	mp_globalMaxMagnetization	= ZERO;
	mp_globalBias				= ZERO;
	mp_globalFrozenness			= ZERO;

	numVarsUsed = 0;

	for (i = 0; i < f.n_vars_e_used; ++i){
		//We again ignore already assigned variables.
		if (!IS_VAR_UNASSIGNED(f.vars_e[i])) continue;

		var = mp_variables + f.vars_e[i]->id;
		++numVarsUsed;

		//We add the bias to the global bias value.
		mp_globalBias 		+= var->bias;
		mp_globalFrozenness += fabs(var->bias);

		//We add the larger marginal value to the global maximum magnetization value.
		if (var->muPlus > var->muMinus){
			mp_globalMaxMagnetization += var->muPlus;
		} else {
			mp_globalMaxMagnetization += var->muMinus;
		}
	}

	//Third, we calculate the respective quantities.
	if (numVarsUsed > 0U) {
		mp_globalMaxMagnetization 	= mp_globalMaxMagnetization/((float_ty)numVarsUsed);
		mp_globalBias				= mp_globalBias/((float_ty)numVarsUsed);
		mp_globalFrozenness			= mp_globalFrozenness/((float_ty)numVarsUsed);
	}

	#ifdef VERBOSE_MP
	printf("c     MP:   Magnetization density values:\n");
	printf("c     MP:     Global maximum magnetization density: %f\n", mp_globalMaxMagnetization);
	printf("c     MP:     Global bias density:                  %f\n", mp_globalBias);
	printf("c     MP:     Global frozenness density:            %f\n", mp_globalFrozenness);
	#endif

	#ifdef COLLECTSTATS
	stats_mp_time_biasCompute += STATS_GET_CURRENT_TIME_IN_SEC() - time_start;
	#endif
	if (mp_globalMaxMagnetization < param_mpMaxMagnetization){
		//The convergence of the message passing lead us to a paramagnetic state.
		#ifdef VERBOSE_MP
		printf("c     MP:     PARAMAGNETIC (global magnetization is %f < %f).\n",
				mp_globalMaxMagnetization, param_mpMaxMagnetization);
		#endif
		mp_returnCode = MP_CONVERGED_PARAMAG;
		#ifdef COLLECTSTATS
		++stats_mp_return_PARAMAG;
		if (stats_mp_iters_firstParamag == 0) stats_mp_iters_firstParamag = stats_mp_return_CONVERGED;
		#endif
	} else {
		//Let us determine in what state we exactly are.
		if (mp_globalFrozenness > param_mpMinFrozenness){
			//The biases are very strong, so we are in the frozen state.
			if (mp_globalBias > param_mpMinFerro){
				#ifdef VERBOSE_MP
				printf("c     MP:     FROZEN POSITIVE FERROMAGNET (frozenness is %f >= %f, bias is %f > %f).\n",
						mp_globalFrozenness, param_mpMinFrozenness,mp_globalBias, param_mpMinFerro);
				#endif
				mp_returnCode = MP_CONVERGED_FROZEN_POSFERR;
				#ifdef COLLECTSTATS
				++stats_mp_return_FROZEN_POSFERR;
				if (stats_mp_iters_firstFrozenPosFerr == 0) stats_mp_iters_firstFrozenPosFerr = stats_mp_return_CONVERGED;
				#endif
			} else if (mp_globalBias < -param_mpMinFerro){
				#ifdef VERBOSE_MP
				printf("c     MP:     FROZEN NEGATIVE FERROMAGNET (frozenness is %f >= %f, bias is %f < %f).\n",
						mp_globalFrozenness, param_mpMinFrozenness,mp_globalBias, -param_mpMinFerro);
				#endif
				mp_returnCode = MP_CONVERGED_FROZEN_NEGFERR;
				#ifdef COLLECTSTATS
				++stats_mp_return_FROZEN_NEGFERR;
				if (stats_mp_iters_firstFrozenNegFerr == 0) stats_mp_iters_firstFrozenNegFerr = stats_mp_return_CONVERGED;
				#endif
			} else {
				#ifdef VERBOSE_MP
				printf("c     MP:     QUENCHED DISORDER (frozenness is %f >= %f, bias is %f in [%f, %f]).\n",
						mp_globalFrozenness, param_mpMinFrozenness,mp_globalBias, -param_mpMinFerro, param_mpMinFerro);
				#endif
				mp_returnCode = MP_CONVERGED_FROZEN_QUENDIS;
				#ifdef COLLECTSTATS
				++stats_mp_return_FROZEN_QUENDIS;
				if (stats_mp_iters_firstFrozenQuenDis == 0) stats_mp_iters_firstFrozenQuenDis = stats_mp_return_CONVERGED;
				#endif
			}
		} else {
			//The biases are not very strong, so we are in the unfrozen state.
			if (mp_globalBias > param_mpMinFerro){
				#ifdef VERBOSE_MP
				printf("c     MP:     Unfrozen positive ferromagnet (frozenness is %f < %f, bias is %f > %f).\n",
						mp_globalFrozenness, param_mpMinFrozenness, mp_globalBias, param_mpMinFerro);
				#endif
				mp_returnCode = MP_CONVERGED_UNFROZEN_POSFERR;
				#ifdef COLLECTSTATS
				++stats_mp_return_UNFROZEN_POSFERR;
				if (stats_mp_iters_firstUnfrozenPosFerr == 0) stats_mp_iters_firstUnfrozenPosFerr = stats_mp_return_CONVERGED;
				#endif
			} else if (mp_globalBias < -param_mpMinFerro){
				#ifdef VERBOSE_MP
				printf("c     MP:     Unfrozen negative ferromagnet (frozenness is %f < %f, bias is %f < %f).\n",
						mp_globalFrozenness, param_mpMinFrozenness, mp_globalBias, -param_mpMinFerro);
				#endif
				mp_returnCode = MP_CONVERGED_UNFROZEN_NEGFERR;
				#ifdef COLLECTSTATS
				++stats_mp_return_UNFROZEN_NEGFERR;
				if (stats_mp_iters_firstUnfrozenNegFerr == 0) stats_mp_iters_firstUnfrozenNegFerr = stats_mp_return_CONVERGED;
				#endif
			} else {
				#ifdef VERBOSE_MP
				printf("c     MP:     Mixed (frozenness is %f < %f, bias is %f in [%f, %f]).\n",
						mp_globalFrozenness, param_mpMinFrozenness, mp_globalBias, -param_mpMinFerro, param_mpMinFerro);
				#endif
				mp_returnCode = MP_CONVERGED_UNFROZEN_MIXED;
				#ifdef COLLECTSTATS
				++stats_mp_return_UNFROZEN_MIXED;
				if (stats_mp_iters_firstUnfrozenMixed == 0) stats_mp_iters_firstUnfrozenMixed = stats_mp_return_CONVERGED;
				#endif
			}
		}
		//The convergence of the message passing lead us to a non-paramagnetic state we retain the messages and biases.
		mp_intern_retainMsgs();
		mp_intern_retainBiases();
	}
	#ifdef COLLECTSTATS
	stats_mp_time_total += (STATS_GET_CURRENT_TIME_IN_SEC() - time_start);
	#endif
}

void mp_extern_computeFreeEntropy(){
	//Given the current messages, this method computes the free entropy of the formula. This method only works correctly
	//in case the equilibrium messages where obtain with either BP, SP, or their interpolation iSP.
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	++stats_mp_component_totalCalls;
	#endif
	#ifdef VERBOSE_MP
	printf("c     MP: Computing free entropy...\n");
	#endif

	int32_t *litsC;
	float_ty *deltasC;
	float_ty F, T, tmp, cSize, varsUsed = 0;
	uint32_t i, isSat;

	#ifdef VERBOSE_MP
	printf("c     MP:   Resetting variable T and F values...\n");
	#endif

	//In an equilibrium situation, the free entropy is given as:
	//F^RSB,e = \sum_{c\in F} [(1-|c|)\log(1-\prod_{l\in c} \delta(l,c))] + \sum_{v\in V} log(T+F-mpIi*T*F)

	#ifdef VERBOSE_MP
	printf("c     MP:   Calculating...\n");
	#endif
	mp_freeEntropy = ZERO;
	mp_freeEntropyDensity = ZERO;
	for (i = 0; i < mp_clsUsed; ++i){
		tmp = ONE;
		litsC = mp_clauses[i].lits;
		deltasC = mp_clauses[i].deltas;
		isSat = 0;
		cSize = 0;
		while (*litsC != 0){
			if (IS_LIT_SAT(*litsC)){
				isSat = 1;
				break;
			} else if (!IS_LIT_UNSAT(*litsC)){
				tmp *= *deltasC;
				++cSize;
			}
			++litsC;
			++deltasC;
		}
		if (!isSat){
			//We must now ensure, that tmp < 1.0, because otherwise we cannot compute the logarithm correctly.
			if (tmp > ONE - param_mpEpsilon){
				//Too bad, we must enforce a slightly smaller value in order to net get -infinity as log-result.
				tmp = ONE - param_mpEpsilon;
			}
			mp_freeEntropy += (ONE-cSize) * log(ONE-tmp);
		}
	}

	//We now add the sum for all the variables.
	for (i = 0; i < f.n_vars_e_used; ++i){
		//We again ignore already assigned variables. We also ignore the variable corresponding to trueLit.
		if (!IS_VAR_UNASSIGNED(f.vars_e[i])) continue;

		//Grab the variables freedom to be assigned positively and negatively: T and F.
		F  = GET_MP_VAR_BIGF(f.vars_e[i]->id);
		T  = GET_MP_VAR_BIGT(f.vars_e[i]->id);

		if (F > 0 || T > 0){
			mp_freeEntropy += log(T+F-param_mpIi*T*F);
			++varsUsed;
		}
	}

	if (varsUsed > ZERO){
		mp_freeEntropyDensity = mp_freeEntropy/varsUsed;
	}

	#ifdef COLLECTSTATS
	++stats_mp_computation_numEntComp;
	stats_mp_time_entropyCompute += STATS_GET_CURRENT_TIME_IN_SEC() - time_start;
	#endif
	#ifdef VERBOSE_MP
	printf("c     MP:   Free entropy is %f. Free entropy density is %f.\n", mp_freeEntropy, mp_freeEntropyDensity);
	#endif
	#ifdef COLLECTSTATS
	stats_mp_time_total += (STATS_GET_CURRENT_TIME_IN_SEC() - time_start);
	#endif
}


void mp_resetModule(){
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	++stats_mp_component_totalCalls;
	#endif
	#ifdef VERBOSE_MP
	printf("c     MP: Component reset... \n");
	#endif
	mp_returnCode 					= MP_UNKNOWN;
	mp_maxMessageDiff				= ZERO;
	mp_globalMaxMagnetization		= ZERO;
	mp_globalBias					= ZERO;
	mp_globalFrozenness				= ZERO;
	mp_freeEntropy					= ZERO;
	mp_freeEntropyDensity			= ZERO;

	mp_variables_reset();
	mp_literals_reset();
	mp_clauses_reset();

	mp_updateRules_resetPlugin();
	#ifdef COLLECTSTATS
	stats_mp_time_total += (STATS_GET_CURRENT_TIME_IN_SEC() - time_start);
	#endif
}

void mp_initModule(){
	//We allocate an array to store all factors that participate in the creation of a message. In the worst case, this
	//array has size n (maximum size of a clause).
	#ifdef VERBOSE_MP
	printf("c     MP: Component initialize... \n");
	#endif
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	++stats_mp_component_totalCalls;
	stats_mp_iters_firstUnconverged = 0;
	stats_mp_iters_firstParamag = 0;
	#endif
	mp_returnCode = MP_UNKNOWN;

	//Initialize MP module data-structures.
	mp_variables_init(); if (mp_returnCode != MP_UNKNOWN) return;
	mp_literals_init(); if (mp_returnCode != MP_UNKNOWN) return;
	mp_clauses_init(); if (mp_returnCode != MP_UNKNOWN) return;

	//Initialize plug-ins.
	mp_updateRules_initPlugin(); if (mp_returnCode != MP_UNKNOWN) return;

	#ifdef COLLECTSTATS
	stats_mp_time_init += (STATS_GET_CURRENT_TIME_IN_SEC() - time_start);
	stats_mp_time_total += (STATS_GET_CURRENT_TIME_IN_SEC() - time_start);
	#endif
}

void mp_disposeModule(){
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	++stats_mp_component_totalCalls;
	#endif
	#ifdef VERBOSE_MP
	printf("c     MP: Component dispose... \n");
	#endif

	//Dispose MP module data-structures.
	mp_variables_dispose();
	mp_literals_dispose();
	mp_clauses_dispose();

	//Dispose plug-ins.
	mp_updateRules_disposePlugin();
	#ifdef COLLECTSTATS
	stats_mp_time_total += (STATS_GET_CURRENT_TIME_IN_SEC() - time_start);
	#endif
}

