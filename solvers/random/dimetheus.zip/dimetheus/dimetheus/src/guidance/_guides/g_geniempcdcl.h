/*	DIMETHEUS SAT SOLVER
 * 	Author:		Oliver Gableske	(oliver@gableske.net)
 *	Website:	http://www.gableske.net/dimetheus
 *  License:	See ./doc/license.txt
 */

#ifndef G_GENIEMPCDCL_H_
#define G_GENIEMPCDCL_H_

void guide_geniempcdcl_printHelp();
void guide_geniempcdcl_apply(int, char**);
void guide_geniempcdcl_enforceAfterAdaptation();

#endif /* G_GENIEMPCDCL_H_ */
