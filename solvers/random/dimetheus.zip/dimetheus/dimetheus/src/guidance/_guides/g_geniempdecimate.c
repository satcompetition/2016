/*	DIMETHEUS SAT SOLVER
 * 	Author:		Oliver Gableske	(oliver@gableske.net)
 *	Website:	http://www.gableske.net/dimetheus
 *  License:	See ./doc/license.txt
 */

#include "../guidance.h"

void guide_geniempdecimate_printHelp(){
	printf("c      %-3d: GENIEMPDECIMATE\n", GUIDE_GENIEMPDECIMATE);
    printf("c           Behavior: Performs ijMPP-based decimation (this resembles the ijMPPDecimate solver from the authors thesis).\n");
    printf("c           May use : CLASSIFY[ATTRIBUTOR RANDOMFOREST] ADAPT[ITEADAPTER] PREP[PRE] SEARCH[MP]\n");
    printf("c           Enforces: -searchStrategy %d, -adaptSearchStrategy 0,\n"
     	   "c                     -inpStrategy %d, -adaptInpStrategy 0, -adaptInpStrategyParams 0,\n"
    	   "c                     -mpUpdateRule %d, -adaptMpUR 0\n",
    	   	   	   	   	      	  SEARCH_STRATEGY_GENIEMPDECIMATE,
    	   	   	   	   	      	  INP_STRATEGY_NULL,
    	   	   	   	   	      	  MP_UPDATERULE_L2_4_IJMPP);
    printf("c           Forbids : Modification of the enforced parameters. Adaptation of the enforced parameters.\n");
}

void guide_geniempdecimate_apply(int argc, char** argv){
	//This guide will enforce the ijMPP-based decimation approach. No search takes place.
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	++stats_guidance_component_totalCalls;
	#endif

	//First, acquire all parameter settings and adaptation capabilities.
	guidance_intern_getAllParams(argc, argv);

	#ifdef VERBOSE_GUIDANCE
	printf("c   GUIDANCE: Enforcing and setting defaults...\n");
	#endif

	//Second, apply default values, if possible.
	//CLASSIFY
	GUIDANCE_APPLYDEFAULT(guidance_classifyStrategy, param_classifyStrategy, CLASSIFY_STRATEGY_RANDFOR);

	//ADAPT
	GUIDANCE_APPLYDEFAULT(guidance_adaptStrategy, param_adaptStrategy, ADAPT_STRATEGY_ITEGENERIC);

	//Third, check and enforce parameter settings for this guide.
	//INP
	GUIDANCE_CHECKANDSET(guidance_inpStrategy, param_inpStrategy, INP_STRATEGY_NULL);
	GUIDANCE_CHECKANDSET(guidance_adaptInpStrategy, param_adaptInpStrategy, 0);
	GUIDANCE_CHECKANDSET(guidance_adaptInpStrategyParams, param_adaptInpStrategyParams, 0);

	//SEARCH
	GUIDANCE_CHECKANDSET(guidance_searchStrategy, param_searchStrategy, SEARCH_STRATEGY_GENIEMPDECIMATE);
	GUIDANCE_CHECKANDSET(guidance_adaptSearchStrategy, param_adaptSearchStrategy, 0);

	//MP
	GUIDANCE_CHECKANDSET(guidance_mpUpdateRule, param_mpUpdateRule, MP_UPDATERULE_L2_4_IJMPP);
	GUIDANCE_CHECKANDSET(guidance_adaptMpUR, param_adaptMpUR, 0);

	guidance_intern_printGuidanceResult();
	#ifdef COLLECTSTATS
	stats_guidance_time_total += STATS_GET_CURRENT_TIME_IN_SEC() - time_start;
	#endif
}

void guide_geniempdecimate_enforceAfterAdaptation(){
	param_inpStrategy = INP_STRATEGY_NULL;
	param_searchStrategy = SEARCH_STRATEGY_GENIEMPDECIMATE;
	param_mpUpdateRule = MP_UPDATERULE_L2_4_IJMPP;
	#ifdef VERBOSE_GUIDANCE
	printf("c     GUIDANCE:   inpStrategy = INP_STRATEGY_NULL\n");
	printf("c     GUIDANCE:   searchStrategy = SEARCH_STRATEGY_GENIEMPDECIMATE\n");
	printf("c     GUIDANCE:   mpUpdateRule = MP_UPDATERULE_L2_4_IJMPP\n");
	#endif
}

