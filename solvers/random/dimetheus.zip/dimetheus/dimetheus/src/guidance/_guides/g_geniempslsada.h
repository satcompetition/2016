/*	DIMETHEUS SAT SOLVER
 * 	Author:		Oliver Gableske	(oliver@gableske.net)
 *	Website:	http://www.gableske.net/dimetheus
 *  License:	See ./doc/license.txt
 */

#ifndef G_GENIEMPSLSADA_H_
#define G_GENIEMPSLSADA_H_

#include "../guidance.h"

void guide_geniempslsada_printHelp();
void guide_geniempslsada_apply(int, char**);
void guide_geniempslsada_enforceAfterAdaptation();


#endif /* G_GENIEMPSLSADA_H_ */
