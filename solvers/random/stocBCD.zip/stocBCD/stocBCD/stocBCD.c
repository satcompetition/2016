/**
 * stocBCD by Jingchao Chen, 2016
*/

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include <sys/time.h>
#include <sys/times.h>
#include <string.h>
#include <limits.h>
#include <float.h>
#include <getopt.h>
#include <signal.h>

#define LLONG_MAX  9223372036854775807
#define LLONG long long int
#define ABS(x) ((x)>0?(x):(-x))

int try;	
char *tabuVar;
int  *saveValue;
int  tabuState=0;
int  blocksize;
int  (*best_bno)[101];
int bestNo[12];
int bestcnt=0;
int usedcnt=0;                      
unsigned int stamp=0; 

char *fileName;
int coeff_No=0;

int nVars;          // numbers of variables. 
int doubleVars;     // number of literals. 
int nClauses;       // number of clauses.
LLONG prv_flip=0;
int *value;         //  value of variables : 0=false  1=true 
int *prv_value;
int copyNum=0;
int copyLimit=-1;
int nBlocked2;      // number of the first blocked clauses
int *label,*clauseScore;
void flipClause(int *clause);

int maxCsize;       // max clause size
int Csize3=0;          // # clause size=3
int **clauses;      // CNF formula: clauses[0..n-1][last] -> clauses[1..n][last],each clause ends at 0
int sumLit;         // the total number of literals
int *clauseMem;
int *lookup_mem;

int **lookup;       //  clause No. where each literal occurs, lookup[lit][j]:  the j'th clause of literal lit or -lit  
int *occurrences;   // number each literal occurs
float *blockingf;     
int *clauseSize;
int *clauseFlag;

int maxOccurences;  // maximum number of occurences for a literal

int nfalse;         // number of false clauses
int *falseCls;      // list for  all false clauses
int *where_false;   // where_false[i]=j means clause i is listed in falseCls at position j.
int *nTrueLit;      // number of true literals in each clause. 

int minfalses;     // min false clauses so far

int *breaks;

int *critVar;
int bestVar;


double *probsBreak;
double *probs;
int *candiVar;
double cb; //for break
double eps = 1.0;

LLONG seed;
LLONG maxFlips = LLONG_MAX;
LLONG flip=0;
     
double tryTime;
long ticks_per_second;

void printModel() {
	int i;
	printf("v ");
	for (i = 1; i <= nVars; i++) {
		if ((i-1) % 20 == 0 && i>1) printf("\nv ");
                if (value[i] == 1) printf("%d ", i);
		else  if(value[i] == 0)	printf("%d ", -i);
                     // else printf("* ");
	}
	printf("\n");
}

void flipUpdate();

void computeUnfixed()
{    int i;

    int *value2 = (int*) malloc(sizeof(int) * (nVars + 1));
    for (i = 1; i <= nVars; ++i) value2[i] = 2;
    for(i=1; i<=nClauses; i++){
        int *clause=clauses[i];
        while (*clause) {
           int var=ABS(*clause);
           if (value2[var] == (*clause > 0)) break;
           if (value[var] == (*clause > 0)){
                value2[var]=value[var];
                break;
           }
           clause++;
        }
   }
//
   for (i = 1; i <= nVars; ++i){
           if(value2[i] == 2 || (minfalses==1 && breaks[i] == 0)){
                 int klit= value[i] ? i : -i;
                 int *clsNo=lookup[klit];
                 int lit,cNo;
        	 while ((cNo = *clsNo)) {
                     int *clause=clauses[cNo];
                     while((lit=*clause)){
                          bestVar=ABS(lit);
                          if(i != bestVar){
                            if ( value[bestVar] == (lit > 0) ) flipUpdate();
                          }
                          clause++;
                     }
                     clsNo++;
                }
           }
   }
   free(value2);
}

inline void convertbit(int n,char *bit)
{  int i;
   for(i=0; i< blocksize; i++){
        bit[i]=n%2;
        n=n/2;
   }
}

// 000010000, 0000001010,000000,0000001000
//no: base  max,shiftValue
//pos:start max,nowPos

int state[16][3]=
{{0, 1,0},{0,  20,14}, //0, 14
 {0, 1,0},{10, 30,26}, //0,26
 {1, 5,4},{5, 15,9},  //16, 9
 {32,5,1},{30,40,34} //64,34
};

void clearTabu()
{  int i,m;
   for(i=7; i>=1; i=i-2){
       int pos=state[i][2]*blocksize+1;
       for(m=0; m < blocksize; m++) tabuVar[pos+m]=0;
    }
}

void nextPos()
{  int i;
   for(i=7; i>=1; i=i-2){
       int pos=state[i][2];
       pos++;
       if(pos>=nVars/blocksize) pos=0;
       state[i][2]=pos;
    }
}

void firstPos()
{  int i,j=0;
   for(i=7; i>=1; i=i-2){
       int pos=state[i][2];
       if(pos<4) pos=j++;
       else{
           if(pos>=nVars/blocksize) pos=j++;
       }
       state[i][2]=pos;
    }
}

inline void vecFlip(int n,int start,int tabumark)
{   char bit[32];
    int  m; 
    convertbit(n,bit);
    for(m=0; m < blocksize; m++){
        bestVar=start+m;
        if(tabumark){
             if(saveValue[bestVar]!=value[bestVar]) bit[m] = 1-bit[m];
        }
        if(bit[m]) flipUpdate();
        tabuVar[bestVar]=tabumark;
    }
}

void twoVecFlip()
{  int i;
   for(i=4; i<=6; i+=2){
         int base=state[i][0];
         int shift=state[i][2];
         int bno= base << shift;
         int pos=state[i+1][2];
         vecFlip(bno,pos*blocksize+1,0);
   }
}

int min_F,max_F;
int *falseVec;
int nowIdx=0;
int blockfsum=0;
void blockFlip()
{   int i;
    if(nVars<=40) return;
    for(i=6; i>=0; i=i-2){
          int base=state[i][0];
          int shift=state[i][2];
          int bno= base << shift;

          int pos=state[i+1][2];
          vecFlip(bno,pos*blocksize+1,1);
    }
}

void Init_FixBlock()
{  int i;
   if(nVars<=40) return;
   min_F=100000;
   max_F=0;
   blockfsum=nowIdx=0;
   firstPos();
   for(i=0; i<nVars/blocksize; i++){
          twoVecFlip();
          if(min_F > nfalse) min_F = nfalse;
          if(max_F < nfalse) max_F = nfalse;
          falseVec[i]=nfalse;
          twoVecFlip();
          nextPos();
    }
    if(max_F - min_F >= 4){
            int mid=(max_F + min_F)/2;
            max_F=mid+1;
            min_F=mid-1;
           if(nVars <= 800){ max_F++;min_F--;} 
    }
  //  printf("c <min_F=%d max_F=%d>\n",min_F,max_F);
    blockFlip();
    return;
}
void restorePrevBlock(int startVar);
inline int oneblockFlip(int n,int startVar);
void rebuild_lookup();
void initialize(int);
                   
inline void updateMinNoFalse() 
{
       if (nfalse < 2 && (clauseFlag[falseCls[0]]==0)){ 
              printf("c %-9lli unsatCls#=%d \n", flip, falseCls[0]);
              clauseFlag[falseCls[0]]=1;
        }   
       
	 if (nfalse < minfalses){
               minfalses = nfalse;
               if(nfalse == 0) return;
               if(try==0 || minfalses<5 || (maxCsize<5 && minfalses<40)) 
                    printf("c #flips:%-9lli #unsat:%d\n", flip,nfalse);
               if(minfalses == 25 || minfalses == 16 || minfalses == 1) computeUnfixed();
               return;
         }    
         if(nVars < 600 && usedcnt < 15 ) {
         	 if (flip - prv_flip > 30000000){ 
                       prv_flip = flip;
                       if(bestcnt){
                              int i;
                              if(bestcnt>6) bestcnt=6;
                              for(i=1; i <= nVars-11; i += 12) restorePrevBlock(i);
                              int k=bestNo[usedcnt%bestcnt];
                              usedcnt++;
                              printf("c usedcnt=%d bestcnt=%d\n",usedcnt,bestcnt);
                              for(i=1; i <= nVars-11; i += 12){
                                  if(usedcnt > bestcnt && i>=nVars-14) oneblockFlip(stamp++,i);
                                  else oneblockFlip(best_bno[i/12][k],i);
                             }
                       }
                       return;
                 }
         }          

	 if (flip - prv_flip > 25000000 && tabuState>0 && tabuState < 5){
                prv_flip=flip;
                clearTabu();
                if(tabuState==2) { tabuState++; return;}
                while(nowIdx < nVars/blocksize && blockfsum < 110){
                      nowIdx++; 
                      nextPos();
                      if(falseVec[nowIdx] >= min_F && falseVec[nowIdx] <= max_F) break;
                }
                if(nowIdx < nVars/blocksize && blockfsum < 110){
                      printf("c cur_nfalse=%d #blockflip=%d \n",nfalse,blockfsum);
                      int i;
                      if(nfalse!=1){
                           for (i = 1; i <= nVars; i++) 
                                  if(prv_value[i]!=value[i]){
                                         bestVar=i;
                                         flipUpdate();
                                   }
                      }
                      blockFlip();
                      blockfsum++;
                      tabuState=2;
                }
                else {
                     clearTabu();
                     tabuState=5;
                }
                return;
         }

 	 if (flip - prv_flip > 90000000 && nfalse<2 && copyNum>copyLimit && usedcnt < 17){
 	        prv_flip=flip;
                copyLimit=copyNum+5;
                printf("c restart --------%-9lli unsatCls#=%d #unsat=%d----------\n", flip, falseCls[0],nfalse);
                int i;
                if(tabuState == 0){
                  for (i = 1; i <= nVars; i++) saveValue[i]=prv_value[i]=value[i];
                  Init_FixBlock();
                  tabuState=1;
               }
               else{
                  static int sd=1;
                  srand(sd++);
                  for(i=sd%8; i <= nVars; i+=8){
                       if(i==0) continue;
                       bestVar=i;
                       flipUpdate();
                  }
              }
              return;
         }
}  

void readCNFfile() 
{	int i, j;
	FILE *fp = fopen(fileName, "r");
	if (fp == NULL) {
		fprintf(stderr, "c Error: cannot open the file: %s\n", fileName);
		exit(-1);
	}
	while(1) {
		char c = fgetc(fp);
		if (c == 'c') //skip comment line
			do {
				c = fgetc(fp); //read the complete comment line
			} while ((c != '\n') && (c != EOF));
		else if (c == 'p') { //paser p-line 
			if ((fscanf(fp, "%*s %d %d", &nVars, &nClauses))) //%*s = "cnf"
			break;
		} else {
			printf("c line <p cnf #vars #clauses> has not found! \n");
            		exit(-1);
		}
	}

	doubleVars = nVars * 2;
	maxCsize = sumLit=0;
        int  memsize = 2 * nClauses;
	int *cp= (int*) malloc(sizeof(int) * memsize);
        int *tmpClause = (int*) malloc(sizeof(int) *(nVars+1));
	for (i = 0; i < nClauses; i++) {
		int cSize=0;
                int lit;
		do {	fscanf(fp, "%i", &lit);
			tmpClause[cSize++] = lit;
		} while (lit);
                if(sumLit + cSize > memsize){
                    memsize = sumLit + cSize + sumLit/2;
                    cp=(int *)realloc (cp, sizeof(int) * memsize);
        	}
                for (j = 0; j < cSize; j++) cp[sumLit++]=tmpClause[j];
           	if (cSize > maxCsize) maxCsize = cSize;
                if (cSize <= 4) Csize3++;
        }
	fclose(fp);
        clauseMem=cp;
        maxCsize--;
        free(tmpClause);
        clauses = (int**) malloc(sizeof(int*) * (nClauses+1));
        for (i = 0; i < nClauses; i++) {
                 clauses[i] = cp;
                 while(*cp) cp++;
                 cp++;
        }
        nBlocked2=0;
}

void setupBreaks()
{       int i;
        nfalse = 0;
        for (i = 1; i <= nVars; i++) breaks[i] = 0;
        for (i = 1; i <= nClauses; i++) {
		nTrueLit[i] = 0;
		where_false[i] = -1;
	}

        for (i = 1; i <= nClauses ; i++){
            int lit, crLit=0; 
            int *cp=clauses[i];
	    while ((lit = *cp)) {
		   if (value[ABS(lit)] == (lit > 0)) {
				nTrueLit[i]++;
				crLit = lit;
		   }
		   cp++;
	    }
	    if (nTrueLit[i] == 1) {
                   int vc=ABS(crLit);
		   critVar[i] = vc;
		   breaks[vc]++;
                   continue;
	     } 
             if (nTrueLit[i] == 0) { //add it to the unsat list
		   falseCls[nfalse] = i;
		   where_false[i] = nfalse;
		   nfalse++;
	     }
       }
}

void initialize(int try) 
{	int i;
        printf("c initialize\n");
	for (i = 1; i <= nVars; i++) {
	        if(try && (i%2)) value[i] = rand() % 2; // from second
                else{
                      if(value[i] ==2) value[i]=1;
                }
        }
        setupBreaks((int *)0);
        for (i = 0; i <= nClauses;i++) clauseFlag[i]=0;
        bestcnt=usedcnt=0;
}

int verifyAssignment() 
{
	int i, lit;
	for (i = 1; i <= nClauses; i++) {
                int *cp=clauses[i];
 		while ((lit = *cp)) {
			if (value[ABS(lit)] == (lit > 0)) break;
                        cp++;
		}
		if (lit == 0) return 0;
	}
	return 1;
}

inline void flipUpdate() 
{
        if(tabuVar) if(tabuVar[bestVar]) return;
//   
	int i,var;
	int clauseNo; 
	int trueLit; //trueLit makes the clauses where it appears sat.
	if (value[bestVar] == 1)
		trueLit = -bestVar; //if x=1 then all clauses containing -x will be made sat after fliping x
	else    trueLit = bestVar; 

        value[bestVar] = 1 - value[bestVar];
	i = 0;
	while ((clauseNo = lookup[trueLit][i])) {//true lit
		if (nTrueLit[clauseNo] == 0) {	
			falseCls[where_false[clauseNo]] = falseCls[--nfalse]; 
			where_false[falseCls[nfalse]] = where_false[clauseNo]; //remove from unsat list
			where_false[clauseNo] = -1;

         		critVar[clauseNo] = bestVar; 
	                breaks[bestVar]++;
                       
         	} else {
			if (nTrueLit[clauseNo] == 1){
                                   breaks[critVar[clauseNo]]--;
                        }
		}
		nTrueLit[clauseNo]++; //the number of true Lit is increased.
		i++;
	}
	i = 0;
	while ((clauseNo = lookup[-trueLit][i])) {//false lit
		if (nTrueLit[clauseNo] == 1) { //then trueLit=1 was the satisfying literal. => unsat
			falseCls[nfalse] = clauseNo;
			where_false[clauseNo] = nfalse;
			nfalse++;
			breaks[bestVar]--;
      		} else if (nTrueLit[clauseNo] == 2) { //find true literal, make it critical,decrease its score
			int *cp=clauses[clauseNo];
			while ((var = ABS(*cp))) {
				if (((*cp > 0) == value[var])) {
					critVar[clauseNo] = var;
					breaks[var]++;
                         		break;
				}
				cp++;
			}
		}
		nTrueLit[clauseNo]--;
		i++;
	}
}

void CDCL()
{   int stack[300][3];
    int fcnt=0;
    printf("c CDCL search \n");
    fflush(stdout);
start:;   
    int pos,sp=0;
    int *fixed_var = (int* ) calloc (nVars+1, sizeof(int));
    while(1){
       int flipCls = falseCls[0];
       stack[sp][0]=flipCls;
       stack[sp][1]=pos=0;
       while(1){
           bestVar=ABS(clauses[flipCls][pos]);
           if(bestVar==0){//
               sp--;
               if(sp<0) goto end;
   next:       
               flipCls=stack[sp][0];
               pos=stack[sp][1];
               bestVar=ABS(clauses[flipCls][pos]);
               flipUpdate();
               fixed_var[bestVar]=0;
               stack[sp][1]=pos=pos+1;
               continue;
          }
          if(fixed_var[bestVar]){
              stack[sp][1]=pos=pos+1;
              continue;
          }
          fixed_var[bestVar]=1;
          fcnt++;
          flipUpdate();
          stack[sp][2]=nfalse;
          if(nfalse > minfalses+1) goto next;
          if(nfalse==0){
                  printf("c find a solution by CDCL\n");
                  goto end;
          }
          if(nfalse < minfalses) {
                  minfalses=nfalse;
                  goto start;
          }                    
          if(sp < 100){ sp++;break;}
          goto next;
      } 
   }
end:
   free(fixed_var);
}            

//go trough the unsat clauses with the flip counter and DO NOT pick RANDOM unsat clauses!!
void restorePrevBlock(int startVar)
{  
    int  m; 
    for(m=0; m < 12; m++){
        bestVar=m+startVar;
        if(prv_value[bestVar] !=value[bestVar]) flipUpdate();
    }
}

inline int oneblockFlip(int n,int startVar)
{   int  m,diff=0; 
    for(m=0; m < 12; m++){
        bestVar=m+startVar;
        if( n%2 !=value[bestVar]) flipUpdate();
        n = n/2;
    }
    return diff;
}

int blockFlip4096(int startVar)
{   int n;
    int falseDis[4096][2];
    int maxFF=0;
    for(n=0; n<4096; n++) {
        int dis=oneblockFlip(n,startVar);
        falseDis[n][0]=dis;
        falseDis[n][1]=nfalse;
        if(maxFF < nfalse) maxFF=nfalse;
    }
    int midf1=(maxFF+4)/5;
    int k=startVar/12;
    int m=0;
    for(n=0; n<4096; n++) {
        int nf=falseDis[n][1];
        if((nf >= midf1 && nf <= midf1+1)){
            best_bno[k][m++]=n;
            if(m>=100) break;
        }
    }
    return m; 
}

inline void pickVarB() 
{	int i,flipCls;
   
       flipCls = falseCls[flip % nfalse];
       if(nfalse==1){
           if(clauseFlag[flipCls]<=1) {
                 clauseFlag[flipCls]=2;
                 if(prv_value){
                      copyNum++;
                      printf("c pattern %d \n",copyNum);
     
                      for (i = 1; i <= nVars; i++) prv_value[i]=value[i];
                     
                      if(bestcnt<=usedcnt && nVars < 600){
                          bestcnt=0;
                          int minsz=10000;
                          for(i=1; i <= nVars-11; i += 12){
                               int sz=blockFlip4096(i);
                               if(minsz > sz) minsz = sz;
                               restorePrevBlock(i);
                          }
                          int k,nf[15];
                          for(k=0; k < minsz; k++){
                               for(i=1; i <= nVars-11; i += 12) oneblockFlip(best_bno[i/12][k],i);
                               for(i=bestcnt-1; i >= 0; i--){
                                 if(nfalse > nf[i]) break;
                                 nf[i+1]    =nf[i];
                                 bestNo[i+1]=bestNo[i];
                               }
                               nf[i+1]    =nfalse;
                               bestNo[i+1]=k;
                               if(bestcnt < 10) bestcnt++;
                          }
                          for(i=1; i <= nVars-11; i += 12) restorePrevBlock(i);
                          usedcnt=0;
                          if(bestcnt){
                               prv_flip = flip;
                               k=bestNo[usedcnt++];
                               stamp++;
                               for(i=1; i <= nVars-11; i += 12) oneblockFlip(best_bno[i/12][k],i);
                          }
                          printf("c building best block NO is done \n");
                      }
                 }
/*
                 if(flip > 500000000) {
                     static int cflag=0;
                     if(cflag==0) CDCL();
                     cflag=1;
                     if(nfalse==0) return;
                 }
*/
          }
      }       
//
       if( minfalses > 2 && nfalse < 50){
              for(i=flipCls; i<nfalse; i++){
                    int k = falseCls[i];
                    if(clauseSize[k]<4){
                      flipCls=k; break;
                    }
              }  
        }
//
        double sumProb = 0.0;
	double randPosition;
        int k,lit;
        i = 0;
        for(k=0; k < 10 && k < nfalse; k++){ 
            if(nfalse < 13) flipCls = falseCls[(flip+k) % nfalse];
            int *cp=clauses[flipCls];
            while ( (lit = *cp) ) {cp++; candiVar[i++]=lit;}
            if(nfalse >=13 || maxCsize >= 6) break;
        }

   	for(k=0; k<i; k++){
                lit=candiVar[k];
                int var=ABS(lit);        
		probs[k] = probsBreak[breaks[var]];
                if(maxCsize <= 8 && (nVars <= 200000)){
                     if(flipCls < nBlocked2 &&  nfalse < 20 ){//18 20 22 30 //
                        probs[k] *= blockingf[lit];
                     }
                }

        	sumProb += probs[k];
	}

	randPosition = (double) (rand()) / RAND_MAX * sumProb;
	for (i = i - 1; i != 0; i--) {
		sumProb -= probs[i];
		if (sumProb <= randPosition) break;
        }
        bestVar=candiVar[i];
        bestVar = ABS(bestVar);
        return;
}


double elapsed_time(void) 
{
	double seconds;
	static struct tms now_tms;
	static long prev_times = 0;
	(void) times(&now_tms);
	seconds = ((double) (((long) now_tms.tms_utime) - prev_times)) / ((double) ticks_per_second);
	prev_times = (long) now_tms.tms_utime;
	return seconds;
}

inline void displayStatistics() {
	printf("c %-30s: %-9lli\n", "numFlips", flip);
	printf("c %-30s: %-8.2f\n", "avg. flips/variable", (double) flip / (double) nVars);
	printf("c %-30s: %-8.2f\n", "avg. flips/clause", (double) flip / (double) nClauses);
	printf("c %-30s: %-8.0f\n", "flips/sec", (double) flip / tryTime);
	printf("c %-30s: %-8.4f\n", "CPU Time", tryTime);
}

void initPoly() {
	int i;
	probsBreak = (double*) malloc(sizeof(double) * (maxOccurences + 1));
	for (i = 0; i <= maxOccurences; i++) probsBreak[i] = pow((eps + i), -cb);
}

void initExp() {
	int i;
	probsBreak = (double*) malloc(sizeof(double) * (maxOccurences + 1));
	for (i = 0; i <= maxOccurences; i++) probsBreak[i] = pow(cb, -i);
}

void reset_prob_cb_eps()
{       int mainsz3=0;
        if(coeff_No>3) coeff_No=0;
        if(5*Csize3 > 4*nClauses) mainsz3=1;
	if (maxCsize <= 3 || mainsz3) {
	        eps = 0.9;
                double delta=(2.30-1.96)/4;
                cb = 2.30-coeff_No*delta;
	} else if (maxCsize <= 4){
            	//	cb = 2.95;//cb = 2.85;
                        double delta=(3.05-2.8)/4;
                        if(coeff_No) cb = 3.05-coeff_No*delta;
                        else cb = 2.95;
	        }
		else if (maxCsize <= 5){
                        //cb = 3.88;//cb = 3.7
		        double delta=(3.95-3.65)/4;
                        if(coeff_No) cb = 3.95-coeff_No*delta;
                        else cb = 3.88;
	       }
                else if (maxCsize <= 6){
                        //cb = 4.831870; //cb = 5.1
                        double init=4.831870;
		        double delta=(5.2-init)/4;
                        cb = init+coeff_No*delta;
                }
                else  if(maxCsize <= 7) {  //cb = 6.169701;  //cb = 5.4
                        double delta=(6.169701-5.35)/4;
                        if(coeff_No) cb = 6.2-coeff_No*delta;
                        else cb = 5.825;//6.169701;
               }
               else{
                       double delta=(5.8-5.2)/4;
                        if(coeff_No) cb = 5.8-coeff_No*delta;
                        else cb = 5.4;//6.5
               }
   	if (maxCsize < 4 || mainsz3) initPoly();
 	else	 	  initExp();
        coeff_No++;
        printf("c %d: cb=%f eps=%f max=%d Csize3=%d mainsz3=%d \n",coeff_No,cb,eps,maxCsize,Csize3,mainsz3);
}

void parseParameters(int argc, char *argv[]) 
{
	if (argc < 2) {
         	printf("./stocbcd <DIMACS CNF instance> [<seed>]\n");
		exit(0);
	}
	fileName = *(argv + 1);

	if (argc == 3) seed = atoi(*(argv + 2));
	else  seed = time(0);
}

void handle_interrupt() 
{
	printf("s UNKNOWN, Min false cluase:%d (%-15.5fsec)\n", minfalses, elapsed_time());
	displayStatistics();
	fflush(stdout);
	exit(-1);
}

void buildSignalHandler() 
{
	signal(SIGTERM, handle_interrupt);
	signal(SIGINT,  handle_interrupt);
	signal(SIGQUIT, handle_interrupt);
	signal(SIGABRT, handle_interrupt);
	signal(SIGKILL, handle_interrupt);
}

void lookup_Mem()
{
     occurrences = (int*) malloc(sizeof(int) * (doubleVars + 1));
     lookup = (int**) malloc(sizeof(int*) * (doubleVars + 1));

     occurrences += nVars;
     lookup  +=  nVars;
 
     int i;
     for (i = -nVars; i <= nVars; i++) occurrences[i] =0;
     int *litp = clauses[0];
     for (i = 0; i <  sumLit; i++) occurrences[*litp++]++;	
     
     occurrences[0]=0;
     for (i = -nVars; i <= nVars; i++) {
		if (occurrences[i] > maxOccurences) maxOccurences = occurrences[i];
     }

     maxOccurences += 10;
	
     lookup_mem   = (int*) malloc (sizeof(int) * (sumLit+doubleVars+1));
     int loc= 0;
     for (i = -nVars; i <= nVars; ++i) { 
         lookup[ i ] = lookup_mem + loc;
         loc += occurrences[ i ]+1; // end at 0
     }
}

void alloc_mem_SLS()
{   
	critVar = (int*) malloc(sizeof(int) * (nClauses + 1));

	falseCls = (int*) malloc(sizeof(int) * (nClauses + 1));
	where_false = (int*) malloc(sizeof(int) * (nClauses + 1));
	nTrueLit = (int*) malloc(sizeof(int) * (nClauses + 1));
        
        probs    = (double*) malloc(sizeof(double) * (nVars + nVars + 1));
	candiVar = (int *) malloc(sizeof(int) * (nVars + nVars + 1));
	
        breaks = (int*) malloc(sizeof(int) * (nVars + 1));
}
//BCD ------------------------------------------------------------------------
int *marks,*next, last, start, *touched,*stack;
int nBlocked1,nBlocked,nMoved, nRemoved, nRank;
   
inline void addClauseIdx (int index) {
  int *clause = clauses[ index ];
  while (*clause) { int lit = *(clause++); lookup[ lit ][ occurrences[ lit ]++ ] = index; }
}

struct clauserank {
    int score;
    int clsNo;
} clsRank[40];


void removeBlocked_addcandidate (int index)
{
    int* clause = clauses[index];
    while (*clause) {
           int j,lit  = *(clause++);
           for (j = 0; j < occurrences[ lit ]; ++j)
	     if (lookup[ lit ][ j ] == index)
	        lookup[ lit ][ j-- ] = lookup[ lit ][ --occurrences[ lit ] ];

           for (j = 0; j < occurrences[ -lit ]; ++j){
              int cls = lookup[ -lit ][ j ];
	      if (touched[cls]== 0) {
                 touched[ cls ] = 1;
                 if (last == -1) start = cls;
                 else            next[ last ] = cls;
                 last = cls;
                 next[ last ] = last;
             }
          }
    }
}

void LessInterfere_BCD()
{   int i,j,bce=0;
BCE:
  i = start;
  while (1) {
      if (touched[ i ] == 0) goto next_i;
      int *clause = clauses[ i ];
      touched[ i ] = 0;
      while (*clause) { int lit = *(clause++); marks[ -lit ] = i; }

      clause = clauses[ i ];
      int first = *clause;
      while (*clause) {
        int lit  = *(clause++);
        int flag = 1;
        for (j = 0; j < occurrences[ -lit ]; ++j) {
          int count  = 0;
	  int *check = clauses[ lookup[ -lit ][ j ] ];
	  while (*check) {
	    if (marks[ *(check++) ] == i) count++;
            if (count == 2) goto next_check;
          }
          flag = 0; break;
          next_check:;
        }
        if (flag) { // found a blocked clause, update data-structures
	  label   [ i ]      = 1;
          clauses  [ i ][ 0 ] = lit;
          clause   [-1 ]      = first;
          stack[ nBlocked++ ] = i;
          nRemoved++;
          if (nClauses <= nRemoved) return;
          removeBlocked_addcandidate (i);
          break;
        }
      }
    next_i:;
    if (next[ i ] == i) break;
    i = next[ i ];
  }
  bce++;
  if (nClauses <= nRemoved) return;

//DECOMPOSITION

    int decision = -1;
    for(i=0; i<nRank; i++){
      if (label[clsRank[i].clsNo]) continue; 
      decision=clsRank[i].clsNo;
      goto REMOVE;
    }
    nRank=0;

    int min_taut = 1000000;
    for (i = 0; i < nClauses; ++i) {
      if (label[ i ]) continue; // clause is already in one of the sets;
      clauseScore[ i ] = 0;
      int *clause = clauses[ i ];
      while (*clause) {
          int lit=*clause;
          marks[ -lit ] = i;
          if (occurrences[ -lit ] < min_taut) min_taut = occurrences[ -lit ];
         clause++; 
       }
    }

    for (i = 0; i < nClauses; ++i) {
      if (label[ i ]) continue; // clause is already in one of the sets;
      int *clause = clauses[ i ];
      while (*clause) {
          int lit = *clause;   
          int m = occurrences[ -lit ];
          if (m == min_taut) {
             for (j = 0; j < m; ++j) {
                 int count = 0;
                 int cls = lookup[ -lit ][ j ];
                 if(m>20){
                      int *check = clauses[ cls ];
	              while (*check)
	              if (marks[ *(check++) ] == i) count++;
	              if (count == 1) clauseScore[ cls ]++;
                 }
                 else clauseScore[ cls ]++;
                 int k;
                 for(k=nRank-1; k >= 0; k--){
           	      if(clauseScore[ cls ] < clsRank[k].score) break; 
                      clsRank[k+1]=clsRank[k];
                 }
                 k++;
                 clsRank[k].score=clauseScore[ cls ];
                 clsRank[k].clsNo=cls;
                 if(nClauses < 6*nVars){
                      if(nRank < 14) nRank++;
                 }
                else{
                    if(nRank < 18) nRank++;
                }
              }
           }
           clause++;
      }
    }
    if(nRank==0){
         for (i = 0; i < nClauses; ++i) if (label[i]==0) break;
         if(i>=nClauses) return;
         decision = i;   
    }
    else decision = clsRank[0].clsNo;
REMOVE:;
      last = -1;
      if (decision >= 0) {
          label[ decision ] = 2;
          nRemoved++;  nMoved++;
          removeBlocked_addcandidate (decision);
          goto BCE;
      }
}

void flipClause(int *clause)
{
    int *first=clause;
    while (*clause) {
      int var=ABS(*clause);
      if (value[var] == (*clause > 0)) return;
      clause++;
    }
    clause--;
    while (clause >= first) {
      int lit=*clause--;
      if (value[ABS(lit) ] == 2){// any
                 value[ABS(lit)] = (lit > 0);
                 return;
      }
    }
    value[ ABS(*first) ] = (*first > 0);
}

void bcd_init()
{  int i;
  for (i = -nVars; i <= nVars; ++i) { 
        occurrences[ i ] = 0; 
        marks[i] = -1; 
  }

  for (i = 0; i < nClauses; ++i) {
    next    [ i ] = i + 1;
    label   [ i ] = 0;  // 1: blocked 2:moved 0:any 
    addClauseIdx(i);
    touched[ i ] = 1; 
  }
  last = nClauses - 1;
  next[last] = last;
  nMoved = nRemoved = nRank = start = nBlocked = 0;
}
    
void MixBcd() 
{ int i;
  printf("c MixBcd #var=%d  #clause=%d \n", nVars, nClauses);
 
  stack       = (int* ) malloc (sizeof(int ) * ( nClauses ));
  touched     = (int* ) malloc (sizeof(int ) * ( nClauses ));
  next        = (int* ) malloc (sizeof(int ) * ( nClauses ));
  clauseScore = (int* ) malloc (sizeof(int ) * ( nClauses ));
  label       = (int* ) malloc (sizeof(int ) * ( nClauses ));
  marks       = (int* ) malloc (sizeof(int ) * (2*nVars+1)); 
  marks       += nVars;
  
  bcd_init();
  LessInterfere_BCD();
  nBlocked1=nBlocked;

  double percent = (nBlocked * 100.0) / nClauses;
  printf("c [MixBcd] BLOCKED %i OUT OF %i CLAUSES %i%%, %i REMAIN %i%%\n",
          nBlocked, nClauses, (int) percent, nClauses - nBlocked, 100 - (int) percent );

  int **newclauses = (int**) malloc(sizeof(int*) * (nClauses + 1));
  nBlocked2=1;

//large part
  for (i = nBlocked1 - 1; i >= 0; --i) newclauses[nBlocked2++]=clauses[stack[i]];
//small part
  for (i = nBlocked1; i < nBlocked ; i++) newclauses[nBlocked2++]=clauses[stack[i]];
 
  for (i = 1; i <= nVars; ++i) value[i] = 2;//any
  for (i = 1; i < nBlocked2; i++) flipClause(newclauses[i]);

  printf("c check assignment nBlocked2=%d \n",nBlocked2);
 
  for (i = 1; i < nBlocked2; i++){
    int *clause = newclauses[i];
    int  blocking_literal = *clause;
    while (*clause) {
    if (value[ABS(*clause)] == ( *clause >0 ) ) goto next_check;
         clause++; 
    }
    printf("c ERROR forcing %i=%d to true (stack_pos %i)\n", blocking_literal, value[ ABS(blocking_literal) ], i);
    break;
    next_check:;
  }

// second blocked set -------------------------------------------------------------
  for (i = -nVars; i <= nVars; ++i) { 
        occurrences[ i ] = 0; 
        marks[ i ] = -1; 
  }
 
  last = -1;
  for (i = 0; i < nClauses; ++i) {
     if(label[ i ] == 2){
         if (last == -1) start = i;
         else            next[last]= i;
         last = i;
         label[ i ] = 0;
         addClauseIdx(i);
         touched[ i ] = 1; 
     }
     else  touched[ i ]= 0; 
  }

  if(last == -1) {
         clauses--; //use old one
         goto free_mem; 
  }

  next[ last ] = last;
  nRemoved = nBlocked;
  nMoved = nRank = 0;
//
  LessInterfere_BCD();
  
  percent = (nBlocked * 100.0) / nClauses;
  printf("c small part: BLOCKED %i out of %i clauses %i%%, %i REMAIN %i%%\n",
          nBlocked, nClauses, (int) percent, nClauses - nBlocked, 100 - (int) percent );

  int k = nBlocked2; 
  for (i = nBlocked - 1; i >= nBlocked2-1; --i) newclauses[k++]=clauses[stack[i]];
  if(k <= nClauses){
         for (i = 0; i < nClauses; ++i) 
              if(label[ i ] == 2) newclauses[k++]=clauses[i];
  } 
 
  if( k != nClauses+1){
         clauses--; // use old one
         goto free_mem; 
  }
 
   for (i = 0; i < nClauses; i++) label[stack[i]]=-2;
   for (i = 0; i < nClauses; i++){
         if(label[i]!=-2) {
            clauses--;
            goto free_mem; 
         }
    }
          
   free(clauses);
   clauses = newclauses;

free_mem:
  free(stack);
  free(touched);
  free(next);
  free(clauseScore);
  free(label);
  marks -= nVars;
  free(marks);
  return;
}

//BCD end--------------------------------------------------------------------------

void rebuild_lookup()
{
        int i,lit;

        int * blocking = (int*) malloc(sizeof(int) * (doubleVars + 1));
        blocking += nVars;

        for (i = -nVars; i <= nVars; i++) blocking[i]=occurrences[i] =0;
      
        for (i = 1; i <= nClauses; i++) {
		int *cp = clauses[i];
                if( i < nBlocked2 ) blocking[*cp] = 1;
		else  blocking[*cp] |= 2;
       
                while ((lit = *cp)){
			lookup[lit][occurrences[lit]++] = i;
                        cp++;
		}
                clauseSize[i]=cp-clauses[i];
        }
        for (lit = -nVars; lit <= nVars; lit++) lookup[lit][occurrences[lit]] = 0; //end at 0 
     
        if(maxCsize <= 8){
             double alp=1.2, bet=0.92;
             for (lit = 1; lit <= nVars; lit++){
                blockingf[-lit]=blockingf[lit]=1;
                if(blocking[-lit]!=2 && blocking[lit]!=2){
                     if(blocking[-lit]==0 && blocking[lit]){
                         blockingf[lit]=alp; //8
                         if(blocking[lit]==3) blockingf[-lit]=bet;//0.5
                     }
                     if(blocking[lit]==0 && blocking[-lit]){
                          blockingf[-lit]=alp; //8
                          if(blocking[-lit]==3) blockingf[lit]=bet;//0.5
                     }
                }
             }
        }
        for (i = 1; i <= nVars; i++){
              value[i] = 2;
              if(maxCsize > 7){
                  if(occurrences[i] >occurrences[-i]+10) value[i]=0;
                  if(occurrences[-i]>occurrences[i]+10) value[i]=1;
              }
        }     
        for (i = 1; i<=nClauses; i++) flipClause(clauses[i]);
    
        blocking -= nVars;
        free(blocking);
}      

int main(int argc, char *argv[]) 
{
	tryTime = 0.;
	double totalTime = 0.;
	ticks_per_second = sysconf(_SC_CLK_TCK);

        printf("c stocbcd by Jingchao Chen\n");

        parseParameters(argc, argv);
	readCNFfile();

        blocksize=10;
        bestcnt=0;
        if(nVars > 10000) tabuState=6; 
        else tabuState=0;

//---------------------
	value = (int*) malloc(sizeof(int) * (nVars + 1));
        lookup_Mem();
	candiVar = (int *) malloc(sizeof(int) * (30*maxCsize + 1));        

        MixBcd();

        if(tabuState==0){
               tabuVar=(char *) calloc (nVars+1, sizeof(char));
               saveValue= (int*) malloc(sizeof(int) * (nVars + 1));
               falseVec = (int*) malloc(sizeof(int) * (nVars/blocksize + 10));
        }
        else {
            prv_value = saveValue = falseVec =0;
            tabuVar=0;
        }
        if(nVars < 600 || tabuState ==0) prv_value = (int*) malloc(sizeof(int) * (nVars + 1));
        if(nVars < 600) best_bno=(int (*)[101])malloc(sizeof(int)*101*(nVars/12 + 2));
        else  best_bno=0;

        blockingf = (float *) malloc(sizeof(float) * (doubleVars + 1));
        blockingf += nVars;

        clauseSize =(int*) malloc(sizeof(int) * (nClauses + 1));
        clauseFlag= (int* ) calloc (nClauses+1, sizeof(int));
     
        rebuild_lookup();
     
        alloc_mem_SLS();
    
//----------------------
        reset_prob_cb_eps();

	buildSignalHandler();

        seed=1409844053;
	srand(seed);
        for (try = 0; try < 10000000; try++) {
                if(try){
                       reset_prob_cb_eps();
                       rebuild_lookup();
		}
                initialize(try);
        	minfalses = nClauses;
                maxFlips = 200000000ll;
                if (maxCsize <= 4) maxFlips=2*maxFlips;
		for (flip = 0; flip < maxFlips; flip++) {//
			if (nfalse) pickVarB();
          		if (nfalse == 0)  break;
                        flipUpdate();
                        if (nfalse==1 && nfalse < minfalses){
                             maxFlips = 2*flip;
                             if(maxFlips < 200000000ll) maxFlips = 200000000ll;
		        }
                        updateMinNoFalse();
                //        if(usedcnt > 10) continue;
                //        if(flip > 500000000ll) {
                //             if( (flip % 200000000ll) == 0 ) reset_prob_cb_eps();//new idea
                //        }
                }
		tryTime = elapsed_time();
		totalTime += tryTime;
		if (nfalse == 0) {
                      if (!verifyAssignment()) {
                              //  rebuild_lookup();
                            //	initialize(try);
                                continue;
			} else {
                        	displayStatistics();
				printf("s SATISFIABLE\n");
                        	printModel();
	                      	return 10;
			}
		} 
                else printf("c try=%d best(%4d) current(%4d) (%-15.5fsec)\n", try,minfalses, nfalse, tryTime);
	}
	displayStatistics();
	return 0;
}

