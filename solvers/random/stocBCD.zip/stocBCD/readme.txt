----------------------------------------------------------
stocbcd 
Authors: Jingchao Chen
Donghua University 
2016
----------------------------------------------------------

Usage of stocbcd
./stocbcd [options] <DIMACS CNF instance> 


