#ifndef _FRWCB2014_HELP_H
#define _FRWCB2014_HELP_H

#include "basic.h"

inline void unsat_FrwCB2014(int clause)
{
	index_in_unsat_stack[clause] = unsat_stack_fill_pointer;
	push(clause,unsat_stack);
}


inline void sat_FrwCB2014(int clause)
{
	int index,last_unsat_clause;

	//since the clause is satisfied, its position can be reused to store the last_unsat_clause
	last_unsat_clause = pop(unsat_stack);
	index = index_in_unsat_stack[clause];
	unsat_stack[index] = last_unsat_clause;
	index_in_unsat_stack[last_unsat_clause] = index;
}

void init_huge_FrwCB2014()
{
	int 		v,c;
	int			j;
	
	//init unsat_stack
	unsat_stack_fill_pointer = 0;

	//init solution
	for (v = 1; v <= num_vars; v++) {

		if(rand()%2==1) cur_soln[v] = 1;
		else cur_soln[v] = 0;

		time_stamp[v] = 0;
		conf_change[v] = 1;
	}

	/* figure out sat_count, and init unsat_stack */
	for (c=0; c<num_clauses; ++c) 
	{
		sat_count[c] = 0;
		
		for(j=0; j<clause_lit_count[c]; ++j)
		{
			if (cur_soln[clause_lit[c][j].var_num] == clause_lit[c][j].sense)
			{
				sat_count[c]++;
				sat_var[c] = clause_lit[c][j].var_num;	
			}
		}

		if (sat_count[c] == 0) 
			unsat_FrwCB2014(c);
	}
	
	//setting for the virtual var 0
	time_stamp[0]=0;
	conf_change[0]=0;
	bscore[0]=0;
	mscore[0]=0;
}

 
//flip a var, and do the neccessary updating
void flip_huge_FrwCB2014(int flipvar)
{
	int v,c;
	struct lit* clause_c;
	struct lit* p;
	struct lit* q;

	cur_soln[flipvar] = 1 - cur_soln[flipvar];
	
	//update related clauses and neighbor vars
	for(q=var_lit[flipvar]; (c=q->clause_num)!=-1; q++)
	{
		clause_c = clause_lit[c];
		if(cur_soln[flipvar] == q->sense)
		{
			++sat_count[c];
			
			if (sat_count[c] == 1) // sat_count from 0 to 1
			{
				sat_var[c] = flipvar;//record the only true lit's var
				
				for(p=clause_c; (v=p->var_num)!=0; p++)
				{
					conf_change[v]++;
				}

				sat_FrwCB2014(c);
			}
		}
		else // cur_soln[flipvar] != cur_lit.sense
		{
			--sat_count[c];
			if (sat_count[c] == 0) //sat_count from 1 to 0
			{
				for(p=clause_c; (v=p->var_num)!=0; p++)
				{
					conf_change[v]++;
				}
				unsat_FrwCB2014(c);
			}//end else if
			
		}//end else
	}

	//update information of flipvar
	conf_change[flipvar] = 0;
}


//initiation of the algorithm
void init_normal_FrwCB2014()
{
	int 		v,c;
	int			i,j;
	
	//init unsat_stack
	unsat_stack_fill_pointer = 0;

	//init solution
	for (v = 1; v <= num_vars; v++) {

		if(rand()%2==1) cur_soln[v] = 1;
		else cur_soln[v] = 0;
		
		time_stamp[v] = 0;
		conf_change[v] = 1;
	}

	/* figure out sat_count, and init unsat_stack */
	for (c=0; c<num_clauses; ++c) 
	{
		sat_count[c] = 0;
		
		for(j=0; j<clause_lit_count[c]; ++j)
		{
			if (cur_soln[clause_lit[c][j].var_num] == clause_lit[c][j].sense)
			{
				sat_count[c]++;
				sat_var[c] = clause_lit[c][j].var_num;	
			}
		}

		if (sat_count[c] == 0) 
			unsat_FrwCB2014(c);
	}

	/*figure out var dscore*/
	int lit_count;
	for (v=1; v<=num_vars; v++) 
	{
		bscore[v] = mscore[v] = 0;
		
		lit_count = var_lit_count[v];
		
		for(i=0; i<lit_count; ++i)
		{
			c = var_lit[v][i].clause_num;
			if (sat_count[c]==0) mscore[v]++;
			else if (sat_count[c]==1 && var_lit[v][i].sense==cur_soln[v]) bscore[v]++;
		}
	}
	
	//setting for the virtual var 0
	time_stamp[0]=0;
	conf_change[0]=0;
	bscore[0]=0;
	mscore[0]=0;
}

 
//flip a var, and do the neccessary updating
void flip_normal_FrwCB2014(int flipvar)
{
	int v,c;
	struct lit* clause_c;
	struct lit* p;
	struct lit* q;

	cur_soln[flipvar] = 1 - cur_soln[flipvar];
	
	//update related clauses and neighbor vars
	for(q=var_lit[flipvar]; (c=q->clause_num)!=-1; q++)
	{
		clause_c = clause_lit[c];
		if(cur_soln[flipvar] == q->sense)
		{
			++sat_count[c];
			
			if (sat_count[c] == 2) //sat_count from 1 to 2
				bscore[sat_var[c]] --;
			else if (sat_count[c] == 1) // sat_count from 0 to 1
			{
				sat_var[c] = flipvar;//record the only true lit's var
				bscore[flipvar]++;
				
				for(p=clause_c; (v=p->var_num)!=0; p++)
				{
					mscore[v] --;
					conf_change[v]++;
				}

				sat_FrwCB2014(c);
			}
		}
		else // cur_soln[flipvar] != cur_lit.sense
		{
			--sat_count[c];
			if (sat_count[c] == 1) //sat_count from 2 to 1
			{
				for(p=clause_c; (v=p->var_num)!=0; p++)
				{
					if(p->sense == cur_soln[v] )
					{
						bscore[v] ++;
						sat_var[c] = v;
						break;
					}
				}
			}
			else if (sat_count[c] == 0) //sat_count from 1 to 0
			{
				for(p=clause_c; (v=p->var_num)!=0; p++)
				{
					mscore[v] ++;
					conf_change[v]++;
				}
				bscore[flipvar]--;
				unsat_FrwCB2014(c);
			}//end else if
			
		}//end else
	}

	//update information of flipvar
	conf_change[flipvar] = 0;
}

//initiation of the algorithm
void init_lm_FrwCB2014()
{
	int 		v,c;
	int			i,j;
	
	//init unsat_stack
	unsat_stack_fill_pointer = 0;

	//init solution
	for (v = 1; v <= num_vars; v++) {

		if(rand()%2==1) cur_soln[v] = 1;
		else cur_soln[v] = 0;

		time_stamp[v] = 0;
		conf_change[v] = 1;
	}

	/* figure out sat_count, and init unsat_stack */
	for (c=0; c<num_clauses; ++c) 
	{
		sat_count[c] = 0;
		
		for(j=0; j<clause_lit_count[c]; ++j)
		{
			if (cur_soln[clause_lit[c][j].var_num] == clause_lit[c][j].sense)
			{
				sat_count[c]++;
				sat_var[c] = clause_lit[c][j].var_num;	
			}
		}

		if (sat_count[c] == 0) 
			unsat_FrwCB2014(c);
	}

	/*figure out var dscore*/
	int lit_count;
	for (v=1; v<=num_vars; v++) 
	{
		bscore[v] = mscore[v] = mscore_2[v] = 0;
		
		lit_count = var_lit_count[v];
		
		for(i=0; i<lit_count; ++i)
		{
			c = var_lit[v][i].clause_num;
			if (sat_count[c]==0) mscore[v]++;
			else if(sat_count[c]==1)
			{
				if(var_lit[v][i].sense==cur_soln[v]) bscore[v]++;
				if(var_lit[v][i].var_num!=sat_var[c]) mscore_2[v]++;
			}
		}
	}
	
	//setting for the virtual var 0
	time_stamp[0]=0;
	conf_change[0]=0;
	bscore[0]=0;
	mscore[0]=0;
}

//flip a var, and do the neccessary updating
void flip_lm_FrwCB2014(int flipvar)
{
	int v,c;
	int index;
	lit* clause_c;
	lit* p;
	lit* q;
	int* var_neighbor_ptr;

	cur_soln[flipvar] = 1 - cur_soln[flipvar];
	
	//update related clauses and neighbor vars
	for(q=var_lit[flipvar]; (c=q->clause_num)!=-1; q++)
	{
		clause_c = clause_lit[c];
		if(cur_soln[flipvar] == q->sense)
		{
			++sat_count[c];
			
			if (sat_count[c] == 2) //sat_count from 1 to 2
			{
				bscore[sat_var[c]] --;

				for(p=clause_c; (v=p->var_num)!=0; p++)
					mscore_2[v]--;
				mscore_2[sat_var[c]]++;
			}
			else if (sat_count[c] == 1) // sat_count from 0 to 1
			{
				sat_var[c] = flipvar;//record the only true lit's var
				bscore[flipvar]++;
				
				for(p=clause_c; (v=p->var_num)!=0; p++)
				{
					mscore[v] --;
					conf_change[v]++;
					mscore_2[v]++;
				}
				mscore_2[flipvar]--;

				sat_FrwCB2014(c);
			}
		}
		else // cur_soln[flipvar] != cur_lit.sense
		{
			--sat_count[c];
			if (sat_count[c] == 1) //sat_count from 2 to 1
			{
				for(p=clause_c; (v=p->var_num)!=0; p++)
				{
					if(p->sense == cur_soln[v] )
					{
						bscore[v] ++;
						sat_var[c] = v;
						break;
					}
				}
				for(p=clause_c; (v=p->var_num)!=0; p++)
					mscore_2[v]++;
				mscore_2[sat_var[c]]--;
			}
			else if (sat_count[c] == 0) //sat_count from 1 to 0
			{
				for(p=clause_c; (v=p->var_num)!=0; p++)
				{
					mscore[v] ++;
					conf_change[v]++;
				}
				bscore[flipvar]--;
				
				for(p=clause_c; (v=p->var_num)!=0; p++)
					mscore_2[v]--;
				mscore_2[sat_var[c]]++;
				unsat_FrwCB2014(c);
			}//end else if
			
		}//end else
	}

	//update information of flipvar
	conf_change[flipvar] = 0;
}



#endif

