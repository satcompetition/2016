#ifndef _MAIN_CPP
#define _MAIN_CPP

#include "basic.h"
#include "DCCASat2014_help.h"
#include "DCCASat2014.h"
#include "FrwCB2014_help.h"
#include "FrwCB2014.h"

#include <sys/times.h> //these two h files are for linux
#include <unistd.h>

int solve_mode; // 1 stands for FrwCB2014; 2 stands for DCCASat2014

void choose_normal_FrwCB2014()
{
	init = init_normal_FrwCB2014;
	flip = flip_normal_FrwCB2014;
	pick_var = pick_var_normal_FrwCB2014;
	max_flips = max_flips_FrwCB2014;
	solve_mode = 1;
}

void choose_huge_FrwCB2014()
{
	init = init_huge_FrwCB2014;
	flip = flip_huge_FrwCB2014;
	pick_var = pick_var_huge_FrwCB2014;
	max_flips = max_flips_FrwCB2014;
	solve_mode = 1;
}

void choose_lm_FrwCB2014()
{
	init = init_lm_FrwCB2014;
	flip = flip_lm_FrwCB2014;
	pick_var = pick_var_lm_FrwCB2014;
	max_flips = max_flips_FrwCB2014;
	solve_mode = 1;
}

void choose_3SAT_DCCASat2014()
{
	set_clause_weighting();
	
	init = init_DCCASat2014;
	flip = flip_3SAT_DCCASat2014;
	pick_var = pick_var_3SAT_DCCASat2014;
	max_flips = max_flips_DCCASat2014;
	solve_mode = 2;
}

void choose_large_DCCASat2014()
{
	set_clause_weighting();
	
	init = init_DCCASat2014;
	flip = flip_large_DCCASat2014;
	pick_var = pick_var_large_DCCASat2014;
	max_flips = max_flips_DCCASat2014;
	
	para_d = 13-max_clause_len;
	if(para_d<6) para_d = 6;
	
	solve_mode = 2;
}

void set_functions()
{
	double r;
	r = (double)num_clauses/num_vars;
	
	if(probtype==SAT3)
	{
		if(r<=4.24)
		{
			//employ FrwCB2014
			if(num_vars>20000)
			{
				choose_huge_FrwCB2014();
				prob = 0.6*MY_RAND_MAX_INT;
			}
			else
			{
				choose_normal_FrwCB2014();
				prob = 0.6*MY_RAND_MAX_INT;
			}
		}
		else
		{
			//employ DCCASat2014
			choose_3SAT_DCCASat2014();
		}
	}
	else if(probtype==SAT4)
	{
		if(r<=9.35)
		{
			//employ FrwCB2014
			choose_normal_FrwCB2014();
			prob = 0.65*MY_RAND_MAX_INT;
		}
		else
		{
			//employ DCCASat2014
			choose_large_DCCASat2014();
		}
	}
	else if(probtype==SAT5)
	{
		if(r<=20.1)
		{
			//employ FrwCB2014
			choose_lm_FrwCB2014();
			prob = 0.58*MY_RAND_MAX_INT;
		}
		else
		{
			//employ DCCASat2014
			choose_large_DCCASat2014();
		}
	}
	else if(probtype==SAT6)
	{
		if(r<=41.2)
		{
			//employ FrwCB2014
			choose_lm_FrwCB2014();
			prob = 0.69*MY_RAND_MAX_INT;
		}
		else
		{
			//employ DCCASat2014
			choose_large_DCCASat2014();
		}
	}
	else if(probtype==SAT7)
	{
		if(r<=80)
		{
			//employ FrwCB2014
			choose_lm_FrwCB2014();
			prob = 0.76*MY_RAND_MAX_INT;
		}
		else
		{
			//employ DCCASat2014
			choose_large_DCCASat2014();
		}
	}
	else
	{
		//employ DCCASat2014
		choose_3SAT_DCCASat2014();
	}
}

void local_search()
{
	int flipvar;
	for (step = 0; step<max_flips; step++)
	{
		if(unsat_stack_fill_pointer==0) return;
		
		flipvar = pick_var();
		flip(flipvar);
		time_stamp[flipvar] = step;
	}
}

void print_information(char *instance, int seed)
{
	if(solve_mode==1)
	{
		cout<<"c Using FrwCB2014"<<endl;
	}
	else
	{
		cout<<"c Using DCCASat2014"<<endl;
	}
	cout<<"c instance = "<<instance<<endl;
	cout<<"c seed = "<<seed<<endl;
	cout<<"c num_vars = "<<num_vars<<endl;
	cout<<"c num_clauses = "<<num_clauses<<endl;
	cout<<"c max_clause_len = "<<max_clause_len<<endl;
	cout<<"c min_clause_len = "<<min_clause_len<<endl;
	cout<<"c ratio = "<<(double)num_clauses/num_vars<<endl;
	cout<<"c max_tries = "<<max_tries<<endl;
	cout<<"c max_flips = "<<max_flips<<endl;
}

int main(int argc, char* argv[])
{
	int     seed;
	long long i;
	struct tms start, stop;
	times(&start);
	
	cout<<"c this is CSCCSat [Version: SC2016]" <<endl;
    
    if(argc!=3)
    {
    	cout<<"c Usage: "<<argv[0] << " <instance> <seed>" <<endl;
    	return -1;
    }

	if (build_instance(argv[1])==0)
	{
		cout<<"c Invalid filename: "<< argv[1]<<endl;
		return -1;
	}
     
    sscanf(argv[2],"%d",&seed);
    
    srand(seed);
    
	set_functions();
	
	print_information(argv[1], seed);
	
	cout<<"c start searching"<<endl;
	
	for (i = 0; i <= max_tries; i++) 
	{
		 init();
		 
		 times(&stop);
	 
		 local_search();

		 if (unsat_stack_fill_pointer==0) break;
	}

	times(&stop);
	double comp_time = double(stop.tms_utime - start.tms_utime +stop.tms_stime - start.tms_stime) / sysconf(_SC_CLK_TCK);

	if(unsat_stack_fill_pointer==0)
	{
		if(verify_sol()==1)
		{
			cout<<"s SATISFIABLE"<<endl;
			print_solution();
			
			cout<<"c solveSteps = "<<i<<" tries + "<<step<<" steps (each try has " << max_flips << " steps)."<<endl;
            cout<<"c solveTime = "<<comp_time<<endl;
        }
        else 
        {
        	cout<<"s UNKNOWN"<<endl;
        	cout<<"c Sorry, something is wrong."<<endl;
        }
    }
    else
    {
    	cout<<"s UNKNOWN"<<endl;
    }
	 
    free_memory();

    return 0;
}

#endif

