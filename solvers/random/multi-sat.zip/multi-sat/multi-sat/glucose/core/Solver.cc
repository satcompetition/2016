/***************************************************************************************[Solver.cc]
 Glucose -- Copyright (c) 2009-2011, Gilles Audemard, Laurent Simon
						CRIL - Univ. Artois, France
						LRI  - Univ. Paris Sud, France
 
Glucose sources are based on MiniSat (see below MiniSat copyrights). Permissions and copyrights of
Glucose are exactly the same as Minisat on which it is based on. (see below).

---------------

Copyright (c) 2003-2006, Niklas Een, Niklas Sorensson
Copyright (c) 2007-2010, Niklas Sorensson

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and
associated documentation files (the "Software"), to deal in the Software without restriction,
including without limitation the rights to use, copy, modify, merge, publish, distribute,
sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or
substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT
OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
**************************************************************************************************/

#include <math.h>

#include "mtl/Sort.h"
#include "Solver.h"
#include "core/Constants.h"

using namespace Minisat;

//=================================================================================================
// Options:

std::string Minisat::Solver :: activities[NUM_ACTIVITIES] = {"0", "0", "0", "0", "0", "0", "0", "0", "0", "0"};
// std::string Minisat::Solver :: activities[NUM_ACTIVITIES] = {"0", "1", "3", "9", "d", "0", "1", "3", "9", "d"};

unsigned Minisat::Solver :: activity_index = 0;

int Minisat::Solver :: sample_frequency = 16;
int Minisat::Solver :: sample_size = 64;


bool width = false; int width_c = 1;
bool diff = false; int diff_c = 0;
bool lbd = false; int lbd_c = 1;
bool dec = false; int dec_c = 1;
bool alevel = false; int alevel_c = 1;
bool bjump = false; int bjump_c = 0;
bool usage = false; int usage_c = 0;
bool reslits = false; int reslits_c = 0;
bool implic = false; int implic_c = 1;
bool agility = false; int agility_c = 1;
bool confvars = false; int confvars_c = 1;
bool reswidth = false; int reswidth_c = 1;
bool reswidth_r = false; int reswidth_r_c = 1;
bool freq = false; int freq_c = 1;
bool fdiff = false; int fdiff_c = 1;
bool sat = true; int sat_c = 1;
bool runs = true; int runs_c = 1;
bool sum_lbd = false; int sum_lbd_c = 1;

unsigned activity_order[NUM_ACTIVITIES][NUM_CRITERIA];


double& Minisat::activity_array :: operator [] (Var i)
{
	return array[Minisat::Solver::activity_index][i];
}

vec<double>& Minisat::activity_array :: get_array(unsigned i)
{
	return array[i];
}

const vec<double>& Minisat::activity_array :: get_array(unsigned i) const
{
	return array[i];
}

//void Minisat::activity_array :: push(void)
//{
//    array[Minisat::Solver::activity_index].push();
//}

void Minisat::activity_array :: push(const double& elem)
{
	for (unsigned i = 0; i < NUM_ACTIVITIES; ++i)
	{
		array[i].push(elem);
	}
}

//void Minisat::activity_array :: push_(const double& elem)
//{
//	array[Minisat::Solver::activity_index].push(elem);
//}

//void Minisat::activity_array :: pop(void)
//{
//	array[Minisat::Solver::activity_index].pop();
//}


int Minisat::activity_heap :: operator[] (unsigned i)
{
	return heap[Minisat::Solver::activity_index]->operator[](i);
}

bool Minisat::activity_heap :: inHeap (int n) const
{
	return heap[Minisat::Solver::activity_index]->inHeap(n);
}

void Minisat::activity_heap :: decrease(int n)
{
	heap[Minisat::Solver::activity_index]->decrease(n);
}

void Minisat::activity_heap :: inccrease (int n)
{
	heap[Minisat::Solver::activity_index]->increase(n);
}

void Minisat::activity_heap :: insert(int n)
{
	heap[Minisat::Solver::activity_index]->insert(n);
}

int Minisat::activity_heap :: size()
{
	return heap[Minisat::Solver::activity_index]->size();
}

bool Minisat::activity_heap :: empty()
{
	return heap[Minisat::Solver::activity_index]->empty();
}

int Minisat::activity_heap :: removeMin()
{
	return heap[Minisat::Solver::activity_index]->removeMin();
}

void Minisat::activity_heap :: build(vec<int>& ns)
{
	for (unsigned i = 0; i < NUM_ACTIVITIES; ++i)
	{
		heap[i]->build(ns);
	}
}

void Minisat::activity_heap :: build(vec<int>& ns, unsigned activity)
{
	heap[activity]->build(ns);
}



static const char* _cat = "CORE";

static DoubleOption  opt_var_decay         (_cat, "var-decay",   "The variable activity decay factor",            0.95,     DoubleRange(0, false, 1, false));
static DoubleOption  opt_clause_decay      (_cat, "cla-decay",   "The clause activity decay factor",              0.999,    DoubleRange(0, false, 1, false));
static DoubleOption  opt_random_var_freq   (_cat, "rnd-freq",    "The frequency with which the decision heuristic tries to choose a random variable", 0, DoubleRange(0, true, 1, true));
static DoubleOption  opt_random_seed       (_cat, "rnd-seed",    "Used by the random variable selection",         91648253, DoubleRange(0, false, HUGE_VAL, false));
static IntOption     opt_ccmin_mode        (_cat, "ccmin-mode",  "Controls conflict clause minimization (0=none, 1=basic, 2=deep)", 2, IntRange(0, 2));
static IntOption     opt_phase_saving      (_cat, "phase-saving", "Controls the level of phase saving (0=none, 1=limited, 2=full)", 2, IntRange(0, 2));
static BoolOption    opt_rnd_init_act      (_cat, "rnd-init",    "Randomize the initial activity", false);
static BoolOption    opt_luby_restart      (_cat, "luby",        "Use the Luby restart sequence", true);
static IntOption     opt_restart_first     (_cat, "rfirst",      "The base restart interval", 100, IntRange(1, INT32_MAX));
static DoubleOption  opt_restart_inc       (_cat, "rinc",        "Restart interval increase factor", 2, DoubleRange(1, false, HUGE_VAL, false));
static DoubleOption  opt_garbage_frac      (_cat, "gc-frac",     "The fraction of wasted memory allowed before a garbage collection is triggered",  0.20, DoubleRange(0, false, HUGE_VAL, false));


//=================================================================================================
// Constructor/Destructor:


Solver::Solver() :

    // Parameters (user settable):
    //
    verbosity        (0)
//  , var_decay        (opt_var_decay)
  , clause_decay     (opt_clause_decay)
  , random_var_freq  (opt_random_var_freq)
  , random_seed      (opt_random_seed)
  , luby_restart     (opt_luby_restart)
  , ccmin_mode       (opt_ccmin_mode)
  , phase_saving     (opt_phase_saving)
  , rnd_pol          (false)
  , rnd_init_act     (opt_rnd_init_act)
  , garbage_frac     (opt_garbage_frac)
  , restart_first    (opt_restart_first)
  , restart_inc      (opt_restart_inc)

, decisions_at_last_conflict(0)
, num_lrnt_clauses_in_res(0)
, assessment_mode(false)
, assessment_disabled(false)
, num_assessments(0)
, num_selections(0)

    // Parameters (the rest):
    //
  , learntsize_factor((double)1/(double)3), learntsize_inc(1.1)

    // Parameters (experimental):
    //
  , learntsize_adjust_start_confl (100)
  , learntsize_adjust_inc         (1.5)

    // Statistics: (formerly in 'SolverStats')
    //
  ,  nbRemovedClauses(0),nbReducedClauses(0), nbDL2(0),nbBin(0),nbUn(0) , nbReduceDB(0)
  , solves(0), starts(0), decisions(0), rnd_decisions(0), propagations(0), conflicts(0)
  , dec_vars(0), clauses_literals(0), learnts_literals(0), max_literals(0), tot_literals(0)

  , ok                 (true)
  , cla_inc            (1)
  // , var_inc            (1)
  , watches            (WatcherDeleted(ca))
  , watchesBin            (WatcherDeleted(ca))
  , qhead              (0)
  , simpDB_assigns     (-1)
  , simpDB_props       (0)
  , order_heap         (activity)
  , progress_estimate  (0)
  , remove_satisfied   (true)

    // Resource constraints:
    //
  , conflict_budget    (-1)
  , propagation_budget (-1)
  , asynch_interrupt   (false)
{
	MYFLAG=0;
	for (unsigned i = 0; i < NUM_ACTIVITIES; ++i)
	{
		nbclausesbeforereduce[i]=NBCLAUSESBEFOREREDUCE;

		var_inc[i] = 1;
		var_decay[i] = opt_var_decay;

		activity_implic[i] = 0;
	    activity_lits_cc[i] = 0;
		activity_alevels[i] = 0;
		activity_res_lits[i] = 0;
		activity_res_clauses[i] = 0;
		activity_backjumps[i] = 0;
		activity_conflict_decisions[i] = 0;
		activity_flips[i] = 0;
		activity_reswidth[i] = 0;
		act_prev_reswidth[i] = 0;
		act_reswidth_rate[i] = 0;
		activity_freq_diff[i] = 0;
		activity_satisfaction[i] = 0;

	    activity_lrnt_usage[i] = 1;
	    activity_usage[i] = 0;
	    activity_selections[i] = 0;
	    activity_conflicts[i] = 0;

	    activity_frequency[i] = 0;
	    activity_learnt_vars[i] = 0;

	    activity_lbd_size[i] = 0;
	    activity_albd[i] = 0;
	    conf4stats[i] = 0;
	    cons[i] = 0;
	    curRestart[i] = 1;
	    sumLBD_act[i] = 0;
	}
	nextClause = -1;
    next_sampling = 0;
    sampling_inc = 8;
    assessment_dirty = true;
	best_criterion = -1;
	best_selection = 0;
	solver_ready = false;

}


Solver::~Solver()
{
}


//=================================================================================================
// Minor methods:


// Creates a new SAT variable in the solver. If 'decision' is cleared, variable will not be
// used as a decision variable (NOTE! This has effects on the meaning of a SATISFIABLE result).
//
Var Solver::newVar(bool sign, bool dvar)
{
    int v = nVars();
    watches  .init(mkLit(v, false));
    watches  .init(mkLit(v, true ));
    watchesBin  .init(mkLit(v, false));
    watchesBin  .init(mkLit(v, true ));
    assigns  .push(l_Undef);
    vardata  .push(mkVarData(CRef_Undef, 0));
    //activity .push(0);
    activity .push(rnd_init_act ? drand(random_seed) * 0.00001 : 0);

    frequency.push(0);
    t_frequency.push(0);
    f_frequency.push(0);
    clsize_score.push(0);
    var_weights.push(0);


    seen     .push(0);
    permDiff  .push(0);
    // polarity .push(sign);
    decision .push();
    trail    .capacity(v+1);
    // setDecisionVar(v, dvar);
    unsigned temp = Minisat::Solver::activity_index;
    for (Minisat::Solver::activity_index = 0; Minisat::Solver::activity_index < NUM_ACTIVITIES; Minisat::Solver::activity_index++)
    {
        polarity[Minisat::Solver::activity_index].push(sign);
    	setDecisionVar(v, dvar);
        var_assigned[Minisat::Solver::activity_index].push(false);
    }
    Minisat::Solver::activity_index = temp;


    return v;
}


bool Solver::addClause_(vec<Lit>& ps)
{
    assert(decisionLevel() == 0);
    if (!ok) return false;

    // Check if clause is satisfied and remove false/duplicate literals:
    sort(ps);
    Lit p; int i, j;
    for (i = j = 0, p = lit_Undef; i < ps.size(); i++)
        if (value(ps[i]) == l_True || ps[i] == ~p)
            return true;
        else if (value(ps[i]) != l_False && ps[i] != p)
            ps[j++] = p = ps[i];
    ps.shrink(i - j);

    if (ps.size() == 0)
        return ok = false;
    else if (ps.size() == 1){
        uncheckedEnqueue(ps[0]);
        return ok = (propagate() == CRef_Undef);
    }else{
        CRef cr = ca.alloc(ps, false);
        clauses.push(cr);

        for (unsigned l =0; l < ps.size(); ++l )
        {
        	Var v = var(ps[l]);
        	frequency[v]++;
        	if (sign(ps[l]))
        	{
        		f_frequency[v]++;
        	}
        	else
        	{
        		t_frequency[v]++;
        	}
        	clsize_score[v] += (ps.size() < 50) ? 50 - ps.size() : 1;
        }

        attachClause(cr);
    }

    return true;
}


void Solver::attachClause(CRef cr) {
    const Clause& c = ca[cr];
    assert(c.size() > 1);
    if(c.size()==2) {
      watchesBin[~c[0]].push(Watcher(cr, c[1]));
      watchesBin[~c[1]].push(Watcher(cr, c[0]));
    } else {
      watches[~c[0]].push(Watcher(cr, c[1]));
      watches[~c[1]].push(Watcher(cr, c[0]));
    }
    if (c.learnt()) learnts_literals += c.size();
    else            clauses_literals += c.size(); }




void Solver::detachClause(CRef cr, bool strict) {
    const Clause& c = ca[cr];
    
    assert(c.size() > 1);
    if(c.size()==2) {
      if (strict){
        remove(watchesBin[~c[0]], Watcher(cr, c[1]));
        remove(watchesBin[~c[1]], Watcher(cr, c[0]));
      }else{
        // Lazy detaching: (NOTE! Must clean all watcher lists before garbage collecting this clause)
        watchesBin.smudge(~c[0]);
        watchesBin.smudge(~c[1]);
      }
    } else {
      if (strict){
        remove(watches[~c[0]], Watcher(cr, c[1]));
        remove(watches[~c[1]], Watcher(cr, c[0]));
      }else{
        // Lazy detaching: (NOTE! Must clean all watcher lists before garbage collecting this clause)
        watches.smudge(~c[0]);
        watches.smudge(~c[1]);
      }
    }
    if (c.learnt()) learnts_literals -= c.size();
    else            clauses_literals -= c.size(); }


void Solver::removeClause(CRef cr) {
  
  Clause& c = ca[cr];
  detachClause(cr);
  // Don't leave pointers to free'd memory!
  if (locked(c)) vardata[var(c[0])].reason = CRef_Undef;
  c.mark(1); 
   ca.free(cr);
}


bool Solver::satisfied(const Clause& c) const {
    for (int i = 0; i < c.size(); i++)
        if (value(c[i]) == l_True)
            return true;
    return false; }


// Revert to the state at given level (keeping all assignment at 'level' but not beyond).
//
void Solver::cancelUntil(int level) {
    if (decisionLevel() > level){
        for (int c = trail.size()-1; c >= trail_lim[level]; c--){
            Var      x  = var(trail[c]);
            assigns [x] = l_Undef;
            if (phase_saving > 1 || (phase_saving == 1) && c > trail_lim.last())
                polarity[Minisat::Solver::activity_index][x] = sign(trail[c]);
            insertVarOrder(x); }
        qhead = trail_lim[level];
        trail.shrink(trail.size() - trail_lim[level]);
        trail_lim.shrink(trail_lim.size() - level);
    } }


//=================================================================================================
// Major methods:


Lit Solver::pickBranchLit()
{
    Var next = var_Undef;

    // Random decision:
    if (drand(random_seed) < random_var_freq && !order_heap.empty()){
        next = order_heap[irand(random_seed,order_heap.size())];
        if (value(next) == l_Undef && decision[next])
            rnd_decisions++; }

    // Activity based decision:
    while (next == var_Undef || value(next) != l_Undef || !decision[next])
        if (order_heap.empty())
        {
            next = var_Undef;
            break;
        }else
        {
            next = order_heap.removeMin();
        }

    if (::confvars)
	{
		activity_conflict_vars[activity_index].insert(next);
	}

    // return next == var_Undef ? lit_Undef : mkLit(next, rnd_pol ? drand(random_seed) < 0.5 : polarity[next]);
    return next == var_Undef ? lit_Undef : mkLit(next, rnd_pol ? drand(random_seed) < 0.5 : polarity[Minisat::Solver::activity_index][next]);
}

void Solver :: varBumpActivity(std::vector<Var>& bump_vars)
{
	double s = 1;
	std::string activity = Minisat::Solver::activities[Minisat::Solver::activity_index];
	for (unsigned c = 0; c < activity.size(); ++c)
	{
		switch(activity[c])
		{
		case '0':
			s *= 1;
			break;
		case '1':
			s *= bump_vars.size();
			break;
		case '2':
			s *= 1.0 / (double)bump_vars.size();
			break;
		case '3':
			s *= 1.0/(double)learnt_clause.size();
			break;
		case '4':
			s *= (1.0/(double)backtrack_level);
			break;
		case '9':
			s *= num_clauses_in_res;
			break;
		case 'b':
			s *= backtrack_level;
			break;
		case 'c':
			s *= learnt_clause.size();
			break;
		case 'd':
			if (decisions - decisions_at_last_conflict)
				s *= (1.0 / (double)(decisions - decisions_at_last_conflict));
			else
				s *= 1;
			break;
		case 'e':
			if (decisions - decisions_at_last_conflict)
				s *= ((decisions - decisions_at_last_conflict));
			else
				s *= 1;
			break;
//		case 'h':
//			s *= (double)(num_clauses_in_res) / (double)(num_lrnt_clauses_in_res);
//			break;
		case 'i':
			if (decisionLevel()-backtrack_level)
			{
				s *= (double)(decisionLevel()-backtrack_level)/(double)(backtrack_level);
			}
			else
			{
				s *= 1;
			}
			break;
		case 'j':
			if (decisionLevel()-backtrack_level)
			{
				s *= (double)(backtrack_level)/(double)(decisionLevel()-backtrack_level);
			}
			else
			{
				s *= 1;
			}
			break;
		default:
			s *= 1;
			break;
		}
	}
	for (unsigned i = 0; i < bump_vars.size(); ++i)
	{
		Var v = bump_vars[i];
		varBumpActivity(v,s);
	}

	if (false)
	// if (num_assessments < MAX_ASSESS || MAX_ASSESS < 0)
	// if (!assessment_disabled)
	{
		unsigned current_act = Minisat::Solver::activity_index;

		for (unsigned i = 0; i < NUM_ACTIVITIES; i++)
		{
			if (i != current_act)
			{
				Minisat::Solver::activity_index = i;
				for (unsigned vi = 0; vi < learnt_clause.size(); ++vi)
				{
					Var v = var(learnt_clause[vi]);
					varBumpActivity(v,1);
				}
			}
		}

		Minisat::Solver::activity_index = current_act;
	}
}


/*_________________________________________________________________________________________________
|
|  analyze : (confl : Clause*) (out_learnt : vec<Lit>&) (out_btlevel : int&)  ->  [void]
|  
|  Description:
|    Analyze conflict and produce a reason clause.
|  
|    Pre-conditions:
|      * 'out_learnt' is assumed to be cleared.
|      * Current decision level must be greater than root level.
|  
|    Post-conditions:
|      * 'out_learnt[0]' is the asserting literal at level 'out_btlevel'.
|      * If out_learnt.size() > 1 then 'out_learnt[1]' has the greatest decision level of the 
|        rest of literals. There may be others from the same level though.
|  
|________________________________________________________________________________________________@*/
void Solver::analyze(CRef confl, vec<Lit>& out_learnt, int& out_btlevel,unsigned int &lbd)
{
	num_lrnt_clauses_in_res = 0;
	num_clauses_in_res = 0;
	std::vector<Var> bump_vars;

	int pathC = 0;
    Lit p     = lit_Undef;

    // Generate conflict clause:
    //
    out_learnt.push();      // (leave room for the asserting literal)
    int index   = trail.size() - 1;

    double res_width = 0;
    do{
        assert(confl != CRef_Undef); // (otherwise should be UIP)
        Clause& c = ca[confl];

        num_clauses_in_res++;
        res_width += c.size();

        // Special case for binary clauses
	// The first one has to be SAT
	if( p != lit_Undef && c.size()==2 && value(c[0])==l_False) {
	  
	  assert(value(c[1])==l_True);
	  Lit tmp = c[0];
	  c[0] =  c[1], c[1] = tmp;
	}
	
       if (c.learnt())
       {
    	   	num_lrnt_clauses_in_res++;
            claBumpActivity(c);
       }

        for (int j = (p == lit_Undef) ? 0 : 1; j < c.size(); j++){
            Lit q = c[j];

            if (!seen[var(q)] && level(var(q)) > 0){
//                varBumpActivity(var(q));
//            	if (Minisat::Solver::activities[Minisat::Solver::activity_index] != "f")
				{
					bump_vars.push_back(var(q));
				}
                seen[var(q)] = 1;
                if (level(var(q)) >= decisionLevel()) {
                    pathC++;
#ifdef UPDATEVARACTIVITY
		    // UPDATEVARACTIVITY trick (see competition'09 companion paper)
		    if((reason(var(q))!= CRef_Undef)  && ca[reason(var(q))].learnt()) 
		      lastDecisionLevel.push(q);
#endif

		} else {
                    out_learnt.push(q);
		}
	    }
        }
        
        // Select next clause to look at:
        while (!seen[var(trail[index--])]);
        p     = trail[index+1];
        confl = reason(var(p));
        seen[var(p)] = 0;
        pathC--;

    }while (pathC > 0);
    out_learnt[0] = ~p;

    res_width /= num_clauses_in_res;

    // Simplify conflict clause:
    //
    int i, j;
    out_learnt.copyTo(analyze_toclear);
    if (ccmin_mode == 2){
        uint32_t abstract_level = 0;
        for (i = 1; i < out_learnt.size(); i++)
            abstract_level |= abstractLevel(var(out_learnt[i])); // (maintain an abstraction of levels involved in conflict)

        for (i = j = 1; i < out_learnt.size(); i++)
            if (reason(var(out_learnt[i])) == CRef_Undef || !litRedundant(out_learnt[i], abstract_level))
                out_learnt[j++] = out_learnt[i];
        
    }else if (ccmin_mode == 1){
        for (i = j = 1; i < out_learnt.size(); i++){
            Var x = var(out_learnt[i]);

            if (reason(x) == CRef_Undef)
                out_learnt[j++] = out_learnt[i];
            else{
                Clause& c = ca[reason(var(out_learnt[i]))];
                for (int k = 1; k < c.size(); k++)
                    if (!seen[var(c[k])] && level(var(c[k])) > 0){
                        out_learnt[j++] = out_learnt[i];
                        break; }
            }
        }
    }else
        i = j = out_learnt.size();

    max_literals += out_learnt.size();
    out_learnt.shrink(i - j);
    tot_literals += out_learnt.size();

    /* ***************************************
      Minimisation with binary clauses of the asserting clause
      First of all : we look for small clauses
      Then, we reduce clauses with small LBD.
      Otherwise, this can be useless
     */
    if(out_learnt.size()<=30) {
      // Find the LBD measure                                                                                                         
      lbd = 0;
      MYFLAG++;
      for(int i=0;i<out_learnt.size();i++) {

	int l = level(var(out_learnt[i]));
	if (permDiff[l] != MYFLAG) {
	  permDiff[l] = MYFLAG;
	  lbd++;
	}
      }


      if(lbd<=6){
      MYFLAG++;
      
      for(int i = 1;i<out_learnt.size();i++) {
	permDiff[var(out_learnt[i])] = MYFLAG;
      }

      vec<Watcher>&  wbin  = watchesBin[p];
      int nb = 0;
      for(int k = 0;k<wbin.size();k++) {
	Lit imp = wbin[k].blocker;
	if(permDiff[var(imp)]==MYFLAG && value(imp)==l_True) {
	  /*      printf("---\n");
		  printClause(out_learnt);
		  printf("\n");
		  
		  printClause(*(wbin[k].clause));printf("\n");
	  */
	  nb++;
	  permDiff[var(imp)]= MYFLAG-1;
	}
      }
      int l = out_learnt.size()-1;
      if(nb>0) {
	nbReducedClauses++;
	for(int i = 1;i<out_learnt.size()-nb;i++) {
	  if(permDiff[var(out_learnt[i])]!=MYFLAG) {
	    Lit p = out_learnt[l];
	    out_learnt[l] = out_learnt[i];
	    out_learnt[i] = p;
	    l--;i--;
	  }
	}
	
	//    printClause(out_learnt);
	//printf("\n");
	out_learnt.shrink(nb);


	/*printf("nb=%d\n",nb);
	  printClause(out_learnt);
	  printf("\n");
	*/
      }
    }
    }
    // Find correct backtrack level:
    //
    if (out_learnt.size() == 1)
        out_btlevel = 0;
    else{
        int max_i = 1;
        // Find the first literal assigned at the next-highest level:
        for (int i = 2; i < out_learnt.size(); i++)
            if (level(var(out_learnt[i])) > level(var(out_learnt[max_i])))
                max_i = i;
        // Swap-in this literal at index 1:
        Lit p             = out_learnt[max_i];
        out_learnt[max_i] = out_learnt[1];
        out_learnt[1]     = p;
        out_btlevel       = level(var(p));
    }

	for (unsigned l = 0; l < out_learnt.size(); ++l)
	{
		++frequency[var(out_learnt[l])];
		if (sign(out_learnt[l]))
		{
			++f_frequency[var(out_learnt[l])];
		}
		else
		{
			++t_frequency[var(out_learnt[l])];
		}
	}

  // Find the LBD measure 
  lbd = 0;
  MYFLAG++;
  for(int i=0;i<out_learnt.size();i++) {
    
    int l = level(var(out_learnt[i]));
    if (permDiff[l] != MYFLAG) {
      permDiff[l] = MYFLAG;
      lbd++;
    }
  }

  if (::lbd)
  // if (assessment_mode)
  {
	  activity_lbd_size[Minisat::Solver::activity_index] += lbd;
  }

	if (::width)
	{
		activity_lits_cc[Minisat::Solver::activity_index] += out_learnt.size();
	}

  varBumpActivity(bump_vars);

  
#ifdef UPDATEVARACTIVITY
  // UPDATEVARACTIVITY trick (see competition'09 companion paper)
  if(lastDecisionLevel.size()>0) {
    for(int i = 0;i<lastDecisionLevel.size();i++) {
      if(ca[reason(var(lastDecisionLevel[i]))].lbd()<lbd)
	varBumpActivity(var(lastDecisionLevel[i]),1);
    }
    lastDecisionLevel.clear();
  } 
#endif	    

  if (!assessment_mode)
	++activity_usage[Minisat::Solver::activity_index];

  if (assessment_mode)
  {
  	// activity_usage[Minisat::Solver::activity_index] += decisionLevel();

		// if (decisionLevel()-backtrack_level)
		{
			if (::reswidth)
			{
				activity_reswidth[Minisat::Solver::activity_index] += res_width;

				double newvalue = backtrack_level;//learnt_clause.size(); //decisionLevel();

				double change = abs(newvalue - act_prev_reswidth[Minisat::Solver::activity_index]);

				if (false && change > 0)
				{
					change = 1.0 / change;
				}

				double reswidth_rate = change;
				act_prev_reswidth[Minisat::Solver::activity_index] = newvalue;
				act_reswidth_rate[Minisat::Solver::activity_index] += reswidth_rate;
			}

			if (::freq)
			{
				activity_learnt_vars[activity_index] += ((double)out_learnt.size() / (double)frequency.size());

				for (unsigned l = 0; l < out_learnt.size(); ++l)
				// for (unsigned l = 0; l < bump_vars.size(); ++l)
				{
					activity_frequency[activity_index] += (frequency[var(out_learnt[l])] / out_learnt.size()) / frequency.size();
				}
			}

			if (::implic)
			{
				double implications = nAssigns() - decisionLevel();
				// if (decisionLevel())
				// {
					// implications /= (double)decisionLevel();
				// }
				// implications /= learnt_clause.size();
				// printf("%f ", (float)implications); fflush(stdout);
				activity_implic[Minisat::Solver::activity_index] += implications;
			}

			if (::alevel)
			{
				activity_alevels[Minisat::Solver::activity_index] += backtrack_level;
			}

			if (::reslits)
			{
				activity_res_lits[Minisat::Solver::activity_index] += bump_vars.size();
			}
			activity_res_clauses[Minisat::Solver::activity_index] += num_clauses_in_res;

			if (::bjump)
			// if (decisionLevel()-backtrack_level)
			{
				activity_backjumps[Minisat::Solver::activity_index] += (double)(decisionLevel()-backtrack_level);///(double)(backtrack_level);
			}

			if (::dec)
			{
				activity_conflict_decisions[Minisat::Solver::activity_index] += decisionLevel();//decisions - decisions_at_last_conflict;
			}

			if (::usage)
			{
				activity_lrnt_usage[Minisat::Solver::activity_index] += num_lrnt_clauses_in_res;
			}

			if (::fdiff)
			{
				double smallest = 0;
				double largest = 0;
				for (unsigned l = 0; l < out_learnt.size(); ++l)
				{
					if (frequency[var(out_learnt[l])] < smallest || l == 0)
					{
						smallest = frequency[var(out_learnt[l])];
					}
					if (frequency[var(out_learnt[l])] > largest || l == 0)
					{
						largest = frequency[var(out_learnt[l])];
					}
				}
				activity_freq_diff[Minisat::Solver::activity_index] += (largest - smallest) / out_learnt.size();
			}
//		activity_lits_cc[Minisat::Solver::activity_index] += t_dec;
//		activity_lrnt_usage[Minisat::Solver::activity_index] += bump_vars.size();
		    if (::lbd)
		    {
		    	// activity_lbd_size[Minisat::Solver::activity_index] += lbd;

//				std::set<unsigned> lbd;
//
//				for(unsigned l = 0; l < out_learnt.size(); ++l)
//				{
//					// bump_vars.push_back(var(out_learnt[l]));
//					lbd.insert(level(var(out_learnt[l])));
//				}
//				// printf("%d: %d\n", (int)out_learnt.size(), (int)lbd.size());fflush(stdout);
//				activity_lbd_size[Minisat::Solver::activity_index] += (lbd.size() <= 2 ? 1 : 0);
//
//
//				std::vector<unsigned> lbds;
//				for (std::set<unsigned>::iterator it = lbd.begin(); it != lbd.end(); ++it)
//				{
//					lbds.push_back(*it);
//				}
//				for (unsigned i = 0; i < lbds.size(); ++i)
//				{
//					for (unsigned j = i+1; j < lbds.size(); ++j)
//					{
//						if (lbds[i] < lbds[j])
//						{
//							unsigned temp = lbds[i];
//							lbds[i] = lbds[j];
//							lbds[j] = temp;
//						}
//					}
//				}
//				double albd = decisionLevel();
//				/*
//				for (unsigned i = 0; i < lbds.size()-1; ++i)
//				{
//					albd += (lbds[i] - lbds[i+1]);
//				}
//				if (lbds.size() == 1)
//				{
//					albd = decisionLevel();
//				}
//				albd /= out_learnt.size();
//				*/
//				if (lbds.size() > 1)
//				{
//					albd = abs(lbds[0] - lbds[lbds.size()-1]);
//				}
//	//			if (lbd.size() < out_learnt.size())
//	//			{
//	//				printf("HIT %f ",(float)out_learnt.size() / lbd.size()); fflush(stdout);
//	//			}
//	//			activity_albd[Minisat::Solver::activity_index] +=  (decisionLevel() - backtrack_level +
//	//															   1.0/out_learnt.size() /*+ (double)out_learnt.size() / lbd.size()*/ +
//	//					                                           // (double)out_learnt.size() / lbd.size() +
//	//					                                           (double)albd);
//				activity_albd[Minisat::Solver::activity_index] +=  albd; // / out_learnt.size();
//				// printf("%f\n", (float)lbd.size());
		    }
		}

  }
  decisions_at_last_conflict = decisions;

    for (int j = 0; j < analyze_toclear.size(); j++) seen[var(analyze_toclear[j])] = 0;    // ('seen[]' is now cleared)
}


// Check if 'p' can be removed. 'abstract_levels' is used to abort early if the algorithm is
// visiting literals at levels that cannot be removed later.
bool Solver::litRedundant(Lit p, uint32_t abstract_levels)
{
    analyze_stack.clear(); analyze_stack.push(p);
    int top = analyze_toclear.size();
    while (analyze_stack.size() > 0){
        assert(reason(var(analyze_stack.last())) != CRef_Undef);
        Clause& c = ca[reason(var(analyze_stack.last()))]; analyze_stack.pop();
	if(c.size()==2 && value(c[0])==l_False) {
	  assert(value(c[1])==l_True);
	  Lit tmp = c[0];
	  c[0] =  c[1], c[1] = tmp;
	}

        for (int i = 1; i < c.size(); i++){
            Lit p  = c[i];
            if (!seen[var(p)] && level(var(p)) > 0){
                if (reason(var(p)) != CRef_Undef && (abstractLevel(var(p)) & abstract_levels) != 0){
                    seen[var(p)] = 1;
                    analyze_stack.push(p);
                    analyze_toclear.push(p);
                }else{
                    for (int j = top; j < analyze_toclear.size(); j++)
                        seen[var(analyze_toclear[j])] = 0;
                    analyze_toclear.shrink(analyze_toclear.size() - top);
                    return false;
                }
            }
        }
    }

    return true;
}


/*_________________________________________________________________________________________________
|
|  analyzeFinal : (p : Lit)  ->  [void]
|  
|  Description:
|    Specialized analysis procedure to express the final conflict in terms of assumptions.
|    Calculates the (possibly empty) set of assumptions that led to the assignment of 'p', and
|    stores the result in 'out_conflict'.
|________________________________________________________________________________________________@*/
void Solver::analyzeFinal(Lit p, vec<Lit>& out_conflict)
{
    out_conflict.clear();
    out_conflict.push(p);

    if (decisionLevel() == 0)
        return;

    seen[var(p)] = 1;

    for (int i = trail.size()-1; i >= trail_lim[0]; i--){
        Var x = var(trail[i]);
        if (seen[x]){
            if (reason(x) == CRef_Undef){
                assert(level(x) > 0);
                out_conflict.push(~trail[i]);
            }else{
                Clause& c = ca[reason(x)];
                for (int j = 1; j < c.size(); j++)
                    if (level(var(c[j])) > 0)
                        seen[var(c[j])] = 1;
            }

            seen[x] = 0;
        }
    }

    seen[var(p)] = 0;
}


void Solver::uncheckedEnqueue(Lit p, CRef from)
{
    assert(value(p) == l_Undef);
    assigns[var(p)] = lbool(!sign(p));

    // SAS
    if (solver_ready & from != CRef_Undef)
    {
    	if (sign(p) != polarity[Minisat::Solver::activity_index][var(p)] && var_assigned[activity_index][var(p)])
    	{
    		double g = 0.9999;
    		activity_flips[activity_index] *= g;
    		activity_flips[activity_index] += 1 - g;
    	}
    }

    var_assigned[activity_index][var(p)] = true;

    vardata[var(p)] = mkVarData(from, decisionLevel());
    trail.push_(p);
}


/*_________________________________________________________________________________________________
|
|  propagate : [void]  ->  [Clause*]
|  
|  Description:
|    Propagates all enqueued facts. If a conflict arises, the conflicting clause is returned,
|    otherwise CRef_Undef.
|  
|    Post-conditions:
|      * the propagation queue is empty, even if there was a conflict.
|________________________________________________________________________________________________@*/
CRef Solver::propagate()
{
    CRef    confl     = CRef_Undef;
    int     num_props = 0;
    watches.cleanAll();
    watchesBin.cleanAll();
    while (qhead < trail.size()){
        Lit            p   = trail[qhead++];     // 'p' is enqueued fact to propagate.
        vec<Watcher>&  ws  = watches[p];
        Watcher        *i, *j, *end;
        num_props++;

        if (false)
        if (assessment_mode)
        {
        	if (::sat)
        	{
				if (sign(p))
				{
					activity_satisfaction[activity_index] += f_frequency[var(p)] / frequency.size();
				}
				else
				{
					activity_satisfaction[activity_index] += t_frequency[var(p)] / frequency.size();
				}
        	}
        }
	
	    // First, Propagate binary clauses 
	vec<Watcher>&  wbin  = watchesBin[p];
	
	for(int k = 0;k<wbin.size();k++) {
	  
	  Lit imp = wbin[k].blocker;
	  
	  if(value(imp) == l_False) {
	    return wbin[k].cref;
	  }
	  
	  if(value(imp) == l_Undef) {
	    //printLit(p);printf(" ");printClause(wbin[k].cref);printf("->  ");printLit(imp);printf("\n");
	    uncheckedEnqueue(imp,wbin[k].cref);
	  }
	}
    


        for (i = j = (Watcher*)ws, end = i + ws.size();  i != end;){
            // Try to avoid inspecting the clause:
            Lit blocker = i->blocker;
            if (value(blocker) == l_True){
                *j++ = *i++; continue; }

            // Make sure the false literal is data[1]:
            CRef     cr        = i->cref;
            Clause&  c         = ca[cr];
            Lit      false_lit = ~p;
            if (c[0] == false_lit)
                c[0] = c[1], c[1] = false_lit;
            assert(c[1] == false_lit);
            i++;

            // If 0th watch is true, then clause is already satisfied.
            Lit     first = c[0];
            Watcher w     = Watcher(cr, first);
            if (first != blocker && value(first) == l_True)
            {
                // activity_satisfaction[activity_index]+= 1.0 / (learnts.size()+1);
            	*j++ = w; continue;
            }

            // Look for new watch:
            for (int k = 2; k < c.size(); k++)
                if (value(c[k]) != l_False){
                    c[1] = c[k]; c[k] = false_lit;
                    watches[~c[1]].push(w);
                    goto NextClause; }

            // Did not find watch -- clause is unit under assignment:
            *j++ = w;
            if (value(first) == l_False){
                confl = cr;
                qhead = trail.size();
                // Copy the remaining watches:
                while (i < end)
                    *j++ = *i++;
            }else {
                uncheckedEnqueue(first, cr);
	  
#ifdef DYNAMICNBLEVEL		    
		// DYNAMIC NBLEVEL trick (see competition'09 companion paper)
		if(c.learnt()  && c.lbd()>2) { 
		  MYFLAG++;
		  unsigned  int nblevels =0;
		  for(int i=0;i<c.size();i++) {
		    int l = level(var(c[i]));
		    if (permDiff[l] != MYFLAG) {
		      permDiff[l] = MYFLAG;
		      nblevels++;
		    }
		    
		    
		  }
		  if(nblevels+1<c.lbd() ) { // improve the LBD
		    if(c.lbd()<=30) {
		      c.setCanBeDel(false); 
		    }
		      // seems to be interesting : keep it for the next round
		    c.setLBD(nblevels); // Update it
		  }
		}
#endif
		
	    }
        NextClause:;
        }
        ws.shrink(i - j);
    }
    propagations += num_props;
    simpDB_props -= num_props;
    
    return confl;
}


/*_________________________________________________________________________________________________
|
|  reduceDB : ()  ->  [void]
|  
|  Description:
|    Remove half of the learnt clauses, minus the clauses locked by the current assignment. Locked
|    clauses are clauses that are reason to some assignment. Binary clauses are never removed.
|________________________________________________________________________________________________@*/
struct reduceDB_lt { 
    ClauseAllocator& ca;
    reduceDB_lt(ClauseAllocator& ca_) : ca(ca_) {}
    bool operator () (CRef x, CRef y) { 
 
    // Main criteria... Like in MiniSat we keep all binary clauses
    if(ca[x].size()> 2 && ca[y].size()==2) return 1;
    
    if(ca[y].size()>2 && ca[x].size()==2) return 0;
    if(ca[x].size()==2 && ca[y].size()==2) return 0;
    
    // Second one  based on literal block distance
    if(ca[x].lbd()> ca[y].lbd()) return 1;
    if(ca[x].lbd()< ca[y].lbd()) return 0;    
    
    
    // Finally we can use old activity or size, we choose the last one
        return ca[x].activity() < ca[y].activity();
	//return x->size() < y->size();

        //return ca[x].size() > 2 && (ca[y].size() == 2 || ca[x].activity() < ca[y].activity()); } 
    }    
};

void Solver::reduceDB()
{
 
  int     i, j;
  nbReduceDB++;
  sort(learnts, reduceDB_lt(ca));

  // We have a lot of "good" clauses, it is difficult to compare them. Keep more !
  if(ca[learnts[learnts.size() / RATIOREMOVECLAUSES]].lbd()<=3) nbclausesbeforereduce[activity_index] +=1000;
  // Useless :-)
  if(ca[learnts.last()].lbd()<=5)  nbclausesbeforereduce[activity_index] +=1000;
  
  
  // Don't delete binary or locked clauses. From the rest, delete clauses from the first half
  // Keep clauses which seem to be usefull (their lbd was reduce during this sequence)

  int limit = learnts.size() / 2;

  for (i = j = 0; i < learnts.size(); i++){
    Clause& c = ca[learnts[i]];
    if (c.lbd()>2 && c.size() > 2 && c.canBeDel() &&  !locked(c) && (i < limit))
    {
    	for (unsigned vi = 0; vi < c.size(); ++vi)
    	{
    		Var v = var(c[vi]);

    		--frequency[v];
        	if (sign(c[vi]))
        	{
        		--f_frequency[v];
        	}
        	else
        	{
        		--t_frequency[v];
        	}
    	}

      removeClause(learnts[i]);
      nbRemovedClauses++;
    }
    else {
      if(!c.canBeDel()) limit++; //we keep c, so we can delete an other clause
      c.setCanBeDel(true);       // At the next step, c can be delete
      learnts[j++] = learnts[i];
    }
  }
  learnts.shrink(i - j);
  checkGarbage();
}


void Solver::removeSatisfied(vec<CRef>& cs)
{
  
    int i, j;
    for (i = j = 0; i < cs.size(); i++){
        Clause& c = ca[cs[i]];


        if (c.size()>2 && satisfied(c)) // A bug if we remove size ==2, We need to correct it, but later.
        {
            Clause& c = ca[cs[i]];
        	for (unsigned vi = 0; vi < c.size(); ++vi)
        	{
        		Var v = var(c[vi]);

        		--frequency[v];
            	if (sign(c[vi]))
            	{
            		--f_frequency[v];
            	}
            	else
            	{
            		--t_frequency[v];
            	}
        	}

            removeClause(cs[i]);
        }
        else
            cs[j++] = cs[i];
    }
    cs.shrink(i - j);
}

void Solver::rebuildOrderHeap()
{
	vs.clear();
    for (Var v = 0; v < nVars(); v++)
        if (decision[v] && value(v) == l_Undef)
            vs.push(v);
    order_heap.build(vs);
}


/*_________________________________________________________________________________________________
|
|  simplify : [void]  ->  [bool]
|  
|  Description:
|    Simplify the clause database according to the current top-level assigment. Currently, the only
|    thing done here is the removal of satisfied clauses, but more things can be put here.
|________________________________________________________________________________________________@*/
bool Solver::simplify()
{
    assert(decisionLevel() == 0);

    if (!ok || propagate() != CRef_Undef)
        return ok = false;

    if (nAssigns() == simpDB_assigns || (simpDB_props > 0))
        return true;

    // Remove satisfied clauses:
    removeSatisfied(learnts);
    if (remove_satisfied)        // Can be turned off.
        removeSatisfied(clauses);
    checkGarbage();
    rebuildOrderHeap();

    simpDB_assigns = nAssigns();
    simpDB_props   = clauses_literals + learnts_literals;   // (shouldn't depend on stats really, but it will do for now)

    return true;
}


/*_________________________________________________________________________________________________
|
|  search : (nof_conflicts : int) (params : const SearchParams&)  ->  [lbool]
|  
|  Description:
|    Search for a model the specified number of conflicts. 
|    NOTE! Use negative value for 'nof_conflicts' indicate infinity.
|  
|  Output:
|    'l_True' if a partial assigment that is consistent with respect to the clauseset is found. If
|    all variables are decision variables, this means that the clause set is satisfiable. 'l_False'
|    if the clause set is unsatisfiable. 'l_Undef' if the bound on number of conflicts is reached.
|________________________________________________________________________________________________@*/
// static  long conf4stats = 0,cons = 0,curRestart=1;
int curr_restarts = 0;

lbool Solver::search(int nof_conflicts)
{

    assert(ok);
//    int         backtrack_level;
    int         conflictC = 0;
//    vec<Lit>    learnt_clause;
    unsigned int nblevels;
    if (!assessment_mode)
    {
    	starts++;
    }
    for (;;){
        CRef confl = propagate();
        if (confl != CRef_Undef){
            // CONFLICT
     // if (!assessment_mode)
    	  conflicts++;

	  conflictC++;
	  if (decisionLevel() == 0) return l_False;

      activity_conflicts[Minisat::Solver::activity_index]++;

      if (assessment_mode)
	  if (::sat)
	  {
		  double satisfaction = 0;
		  for (unsigned qhead =0; qhead < trail.size(); qhead++)
		  {
			  Lit            p   = trail[qhead++];     // 'p' is enqueued fact to propagate.
			  //if (assessment_mode)
			  {
				  if (sign(p))
				  {
					  // activity_satisfaction[activity_index] += f_frequency[var(p)] / (clauses.size()+learnts.size()); //frequency.size();
					  satisfaction += f_frequency[var(p)] / frequency.size();//(clauses.size()+learnts.size());
				  }
				  else
				  {
					  // activity_satisfaction[activity_index] += t_frequency[var(p)] / (clauses.size()+learnts.size()); //frequency.size();
					  satisfaction += t_frequency[var(p)] / frequency.size();//(clauses.size()+learnts.size());
				  }
			  }
		  }

		  // satisfaction /= trail.size();
		  // satisfaction /= (clauses.size()+conflicts);
		  activity_satisfaction[activity_index] += (double)satisfaction;
	  }
            learnt_clause.clear();
            analyze(confl, learnt_clause, backtrack_level, nblevels);

	    if (assessment_mode)
	    {
	      if (::sum_lbd)
	      {
		    sumLBD_act[activity_index] +=  (float)learnt_clause.size() * (float)nblevels*1e-10;
	      }
	    }
	    
            if (!assessment_mode)
            {
                cons[activity_index]++;
				conf4stats[activity_index]++;
				nbDecisionLevelHistory[activity_index].push(nblevels);
				totalSumOfDecisionLevel[activity_index] += nblevels;
            }
 

           cancelUntil(backtrack_level);

            if (learnt_clause.size() == 1){
	      uncheckedEnqueue(learnt_clause[0]);nbUn++;
            }else{
                CRef cr = ca.alloc(learnt_clause, true);
		ca[cr].setLBD(nblevels); 
		if(nblevels<=2) nbDL2++; // stats
		if(ca[cr].size()==2) nbBin++; // stats

                learnts.push(cr);
                attachClause(cr);

                claBumpActivity(ca[cr]);
                uncheckedEnqueue(learnt_clause[0], cr);
            }

            varDecayActivity();
            claDecayActivity();

            if (--learntsize_adjust_cnt == 0){
                learntsize_adjust_confl *= learntsize_adjust_inc;
                learntsize_adjust_cnt    = (int)learntsize_adjust_confl;
                max_learnts             *= learntsize_inc;}

            nextClause = learnts.size() - 1;
           
        }else{
        	if (!assessment_mode)
        	{
        		// Our dynamic restart, see the SAT09 competition companion paper
        		if ( ( nbDecisionLevelHistory[activity_index].isvalid() &&
        				((nbDecisionLevelHistory[activity_index].getavg()*0.7) > (totalSumOfDecisionLevel[activity_index] / conf4stats[activity_index]))))
        		{
        			nbDecisionLevelHistory[activity_index].fastclear();
        			progress_estimate = progressEstimate();
        			cancelUntil(0);
        			return l_Undef;
        		}
        	}
        	else
        	{
	              // NO CONFLICT
        		//if (nof_conflicts >= 0 && conflictC >= nof_conflicts || !withinBudget())
        		if (nof_conflicts >= 0 && conflictC >= nof_conflicts)
        		{
        			// Reached bound on number of conflicts:
        			// nbDecisionLevelHistory[activity_index].fastclear();
        			progress_estimate = progressEstimate();
        			cancelUntil(0);
        			return l_Undef;
        		}
//	              // NO CONFLICT
//        		//if (nof_conflicts >= 0 && conflictC >= nof_conflicts || !withinBudget())
//        		if (nof_conflicts >= 0 && conflictC >= nof_conflicts || (!withinBudget() && !assessment_mode))
//        		{
//        			// Reached bound on number of conflicts:
//        			progress_estimate = progressEstimate();
//        			cancelUntil(0);
//        			return l_Undef;
//        		}
        	}

            // Simplify the set of problem clauses:
            if (decisionLevel() == 0 && !simplify())
                return l_False;
	    // Perform clause database reduction !
            if(cons[activity_index]-curRestart[activity_index]* nbclausesbeforereduce[activity_index]>=0 && !assessment_mode)
            {
            	assert(learnts.size()>0);
            	curRestart[activity_index] = (activity_usage[activity_index] / nbclausesbeforereduce[activity_index])+1;
            	unsigned tmp = learnts.size();
            	reduceDB();
            	tmp = tmp - learnts.size();

            	nbclausesbeforereduce[activity_index] += 300;

            	if (tmp > 0)  // enforce a restart if clause database was modified
            	{
            		next_sampling = curr_restarts+1;
            		cancelUntil(0);
            		return l_Undef;
            	}
            }
	    
            Lit next = lit_Undef;
            while (decisionLevel() < assumptions.size()){
                // Perform user provided assumption:
                Lit p = assumptions[decisionLevel()];
                if (value(p) == l_True){
                    // Dummy decision level:
                    newDecisionLevel();
                }else if (value(p) == l_False){
                    analyzeFinal(~p, conflict);
                    return l_False;
                }else{
                    next = p;
                    break;
                }
            }

            if (next == lit_Undef){
                // New variable decision:
                decisions++;
                next = pickBranchLit();

                if (next == lit_Undef)
                {
                    // Model found:
                    return l_True;
                }
            }

            // Increase decision level and enqueue 'next'
            newDecisionLevel();
            uncheckedEnqueue(next);
        }
    }
}


double Solver::progressEstimate() const
{
    double  progress = 0;
    double  F = 1.0 / nVars();

    for (int i = 0; i <= decisionLevel(); i++){
        int beg = i == 0 ? 0 : trail_lim[i - 1];
        int end = i == decisionLevel() ? trail.size() : trail_lim[i];
        progress += pow(F, i) * (end - beg);
    }

    return progress / nVars();
}

/*
  Finite subsequences of the Luby-sequence:

  0: 1
  1: 1 1 2
  2: 1 1 2 1 1 2 4
  3: 1 1 2 1 1 2 4 1 1 2 1 1 2 4 8
  ...


 */

static double luby(double y, int x){

    // Find the finite subsequence that contains index 'x', and the
    // size of that subsequence:
    int size, seq;
    for (size = 1, seq = 0; size < x+1; seq++, size = 2*size+1);

    while (size-1 != x){
        size = (size-1)>>1;
        seq--;
        x = x % size;
    }

    return pow(y, seq);
}

unsigned Solver :: select_best_activity3()
{
	width = true; diff = true; lbd = true; dec = true; alevel = true; bjump = true; usage = true;

	// Update selections according to each heuristic
	select_best_activity2();

	// Compute entropies of each criterion
	double selections[NUM_ACTIVITIES][NUM_CRITERIA];
	double entropies[NUM_CRITERIA];
	for (int i = 0; i < NUM_CRITERIA; ++i)
	{
		entropies[i] = 0;
		if (num_selections)
		{
			int highest_selection = 0;
			for (int j =0; j < NUM_ACTIVITIES; ++j)
			{
				// selections[i][j] = (double)activity_selections2[i][j] / (double)num_selections;
//				double selection = (double)activity_selections2[j][i] / (double)num_selections;
//				if (selection > 0)
//				{
//					entropies[i] += selection * log(selection)  / log(10);
//				}
				if (activity_selections2[j][i] > entropies[i])
				{
					entropies[i] = activity_selections2[j][i];
				}
			}
//			entropies[i] *= -1;
		}
		// printf("%f ", (float)entropies[i]);
	}
	// printf("\n"); fflush(stdout);

	// Use the criterion that has the highest certainty

	best_selection = entropies[best_criterion];

	for (int i = 0; i < NUM_CRITERIA; ++i)
	{
		if (entropies[i] > best_selection || best_criterion < 0)
		{
			best_criterion = i;
			best_selection = entropies[i];
		}
	}

	return activity_order[NUM_ACTIVITIES-1][best_criterion];
}

unsigned Solver :: select_best_activity2()
{
//double activity_lits_cc[NUM_ACTIVITIES];
//double activity_alevels[NUM_ACTIVITIES];
//double activity_res_lits[NUM_ACTIVITIES];
//double activity_res_clauses[NUM_ACTIVITIES];
//double activity_backjumps[NUM_ACTIVITIES];
//double activity_conflict_decisions[NUM_ACTIVITIES];

	unsigned best_activity = 0;

	unsigned activity_scores[NUM_ACTIVITIES];

	for(unsigned i = 0; i < NUM_ACTIVITIES; ++i)
	{
		activity_scores[i] = 0;
	}

	// TO MAXIMIZE A CRITERIA USE > SYMBOL AND TO MINIMIZE USE < SYMBOL



	if (width)
	{
		for(unsigned i = 0; i < NUM_ACTIVITIES; ++i)
		{
			activity_order[i][Width] = i;
		}
		for (unsigned i = 0; i < NUM_ACTIVITIES; ++i)
		{
			for (unsigned j = i+1; j < NUM_ACTIVITIES; ++j)
			{
				if (activity_lits_cc[activity_order[i][Width]] / activity_conflicts[activity_index] < activity_lits_cc[activity_order[j][Width]] / activity_conflicts[activity_index])
				{
					unsigned t = activity_order[i][Width];
					activity_order[i][Width] = activity_order[j][Width];
					activity_order[j][Width] = t;
				}
			}
		}
		for (unsigned i = 0; i < NUM_ACTIVITIES; ++i)
		{
			activity_scores[activity_order[i][Width]] += width_c * i;
		}
		activity_selections2[activity_order[NUM_ACTIVITIES-1][Width]][Width]++;
	}


	if (diff)
	{
		for(unsigned i = 0; i < NUM_ACTIVITIES; ++i)
		{
			activity_order[i][Diff] = i;
		}
		for (unsigned i = 0; i < NUM_ACTIVITIES; ++i)
		{
			for (unsigned j = i+1; j < NUM_ACTIVITIES; ++j)
			{
				if (activity_albd[activity_order[i][Diff]] > activity_albd[activity_order[j][Diff]])
				{
					unsigned t = activity_order[i][Diff];
					activity_order[i][Diff] = activity_order[j][Diff];
					activity_order[j][Diff] = t;
				}
			}
		}
		for (unsigned i = 0; i < NUM_ACTIVITIES; ++i)
		{
			activity_scores[activity_order[i][Diff]] += diff_c * i;
		}
		activity_selections2[activity_order[NUM_ACTIVITIES-1][Diff]][Diff]++;
	}


	if (bjump)
	{
		for(unsigned i = 0; i < NUM_ACTIVITIES; ++i)
		{
			activity_order[i][Bjump] = i;
		}
		for (unsigned i = 0; i < NUM_ACTIVITIES; ++i)
		{
			for (unsigned j = i+1; j < NUM_ACTIVITIES; ++j)
			{
				if (activity_backjumps[activity_order[i][Bjump]] > activity_backjumps[activity_order[j][Bjump]])
				{
					unsigned t = activity_order[i][Bjump];
					activity_order[i][Bjump] = activity_order[j][Bjump];
					activity_order[j][Bjump] = t;
				}
			}
		}
		for (unsigned i = 0; i < NUM_ACTIVITIES; ++i)
		{
			activity_scores[activity_order[i][Bjump]] += bjump_c * i;
		}
		activity_selections2[activity_order[NUM_ACTIVITIES-1][Bjump]][Bjump]++;
	}


//	if (false)
//	{
//	for(unsigned i = 0; i < NUM_ACTIVITIES; ++i)
//	{
//		activity_order[i] = i;
//	}
//	for (unsigned i = 0; i < NUM_ACTIVITIES; ++i)
//	{
//		for (unsigned j = i+1; j < NUM_ACTIVITIES; ++j)
//		{
//			if (activity_lits_cc[activity_order[i]] / activity_lbd_size[activity_order[i]] > activity_lits_cc[activity_order[j]] / activity_lbd_size[activity_order[j]])
//			{
//				unsigned t = activity_order[i];
//				activity_order[i] = activity_order[j];
//				activity_order[j] = t;
//			}
//		}
//	}
//	for (unsigned i = 0; i < NUM_ACTIVITIES; ++i)
//	{
//		activity_scores[activity_order[i]] += i;
//	}
//	}


	if (::lbd)
	{
		for(unsigned i = 0; i < NUM_ACTIVITIES; ++i)
		{
			activity_order[i][Lbd] = i;
		}
		for (unsigned i = 0; i < NUM_ACTIVITIES; ++i)
		{
			for (unsigned j = i+1; j < NUM_ACTIVITIES; ++j)
			{
				if (activity_lbd_size[activity_order[i][Lbd]] < activity_lbd_size[activity_order[j][Lbd]])
				{
					unsigned t = activity_order[i][Lbd];
					activity_order[i][Lbd] = activity_order[j][Lbd];
					activity_order[j][Lbd] = t;
				}
			}
		}
		for (unsigned i = 0; i < NUM_ACTIVITIES; ++i)
		{
			activity_scores[activity_order[i][Lbd]] += lbd_c * i;
		}
		activity_selections2[activity_order[NUM_ACTIVITIES-1][Lbd]][Lbd]++;
	}


	if (dec)
	{
		for(unsigned i = 0; i < NUM_ACTIVITIES; ++i)
		{
			activity_order[i][Dec] = i;
		}
		for (unsigned i = 0; i < NUM_ACTIVITIES; ++i)
		{
			for (unsigned j = i+1; j < NUM_ACTIVITIES; ++j)
			{
				if (activity_conflict_decisions[activity_order[i][Dec]] < activity_conflict_decisions[activity_order[j][Dec]])
				{
					unsigned t = activity_order[i][Dec];
					activity_order[i][Dec] = activity_order[j][Dec];
					activity_order[j][Dec] = t;
				}
			}
		}
		for (unsigned i = 0; i < NUM_ACTIVITIES; ++i)
		{
			activity_scores[activity_order[i][Dec]] += dec_c * i;
		}
		activity_selections2[activity_order[NUM_ACTIVITIES-1][Dec]][Dec]++;
	}


	if (alevel)
	{
		for(unsigned i = 0; i < NUM_ACTIVITIES; ++i)
		{
			activity_order[i][Alevel] = i;
		}
		for (unsigned i = 0; i < NUM_ACTIVITIES; ++i)
		{
			for (unsigned j = i+1; j < NUM_ACTIVITIES; ++j)
			{
				if (activity_alevels[activity_order[i][Alevel]] < activity_alevels[activity_order[j][Alevel]])
				{
					unsigned t = activity_order[i][Alevel];
					activity_order[i][Alevel] = activity_order[j][Alevel];
					activity_order[j][Alevel] = t;
				}
			}
		}
		for (unsigned i = 0; i < NUM_ACTIVITIES; ++i)
		{
			activity_scores[activity_order[i][Alevel]] += alevel_c * i;
		}
		activity_selections2[activity_order[NUM_ACTIVITIES-1][Alevel]][Alevel]++;
	}


	if (reslits)
	{
		for(unsigned i = 0; i < NUM_ACTIVITIES; ++i)
		{
			activity_order[i][ResLits] = i;
		}
		for (unsigned i = 0; i < NUM_ACTIVITIES; ++i)
		{
			for (unsigned j = i+1; j < NUM_ACTIVITIES; ++j)
			{
				if (activity_res_lits[activity_order[i][ResLits]] > activity_res_lits[activity_order[j][ResLits]])
				{
					unsigned t = activity_order[i][ResLits];
					activity_order[i][ResLits] = activity_order[j][ResLits];
					activity_order[j][ResLits] = t;
				}
			}
		}
		for (unsigned i = 0; i < NUM_ACTIVITIES; ++i)
		{
			activity_scores[activity_order[i][ResLits]] += reslits_c * i;
		}
		activity_selections2[activity_order[NUM_ACTIVITIES-1][ResLits]][ResLits]++;
	}


//	if (false)
//	{
//	for(unsigned i = 0; i < NUM_ACTIVITIES; ++i)
//	{
//		activity_order[i] = i;
//	}
//	for (unsigned i = 0; i < NUM_ACTIVITIES; ++i)
//	{
//		for (unsigned j = i+1; j < NUM_ACTIVITIES; ++j)
//		{
//			if (activity_res_clauses[activity_order[i]] > activity_res_clauses[activity_order[j]])
//			{
//				unsigned t = activity_order[i];
//				activity_order[i] = activity_order[j];
//				activity_order[j] = t;
//			}
//		}
//	}
//	for (unsigned i = 0; i < NUM_ACTIVITIES; ++i)
//	{
//		activity_scores[activity_order[i]] += i;
//	}
//	}


	if (usage)
	{
		for(unsigned i = 0; i < NUM_ACTIVITIES; ++i)
		{
			activity_order[i][Usage] = i;
		}
		for (unsigned i = 0; i < NUM_ACTIVITIES; ++i)
		{
			for (unsigned j = i+1; j < NUM_ACTIVITIES; ++j)
			{
				if (activity_lrnt_usage[activity_order[i][Usage]] > activity_lrnt_usage[activity_order[j][Usage]])
				{
					unsigned t = activity_order[i][Usage];
					activity_order[i][Usage] = activity_order[j][Usage];
					activity_order[j][Usage] = t;
				}
			}
		}
		for (unsigned i = 0; i < NUM_ACTIVITIES; ++i)
		{
			activity_scores[activity_order[i][Usage]] += usage_c * i;
		}
		activity_selections2[activity_order[NUM_ACTIVITIES-1][Usage]][Usage]++;
	}

	unsigned best_score = 0;

	for (unsigned i = 0; i < NUM_ACTIVITIES; ++i)
	{
		if (activity_scores[i] > best_score)
		{
			best_score = activity_scores[i];
			best_activity = i;
		}
	}

	return best_activity;
}

unsigned Solver :: select_best_activity2_2()
{
//double activity_lits_cc[NUM_ACTIVITIES];
//double activity_alevels[NUM_ACTIVITIES];
//double activity_res_lits[NUM_ACTIVITIES];
//double activity_res_clauses[NUM_ACTIVITIES];
//double activity_backjumps[NUM_ACTIVITIES];
//double activity_conflict_decisions[NUM_ACTIVITIES];

	unsigned best_activity = 0;

	unsigned activity_scores[NUM_ACTIVITIES];

	for(unsigned i = 0; i < NUM_ACTIVITIES; ++i)
	{
		activity_scores[i] = 0;
	}

	// TO MAXIMIZE A CRITERIA USE > SYMBOL AND TO MINIMIZE USE < SYMBOL



	if (width)
	{
		// printf("\n");
		for(unsigned i = 0; i < NUM_ACTIVITIES; ++i)
		{
			// printf(" %f ", (float)activity_lits_cc[activity_order[i][Width]]);
			activity_order[i][Width] = i;
		}
		// printf("\n");
		for (unsigned i = 0; i < NUM_ACTIVITIES; ++i)
		{
			for (unsigned j = i+1; j < NUM_ACTIVITIES; ++j)
			{
				if (activity_lits_cc[activity_order[i][Width]] / activity_conflicts[activity_order[i][Width]] < activity_lits_cc[activity_order[j][Width]] / activity_conflicts[activity_order[j][Width]])
				{
					unsigned t = activity_order[i][Width];
					activity_order[i][Width] = activity_order[j][Width];
					activity_order[j][Width] = t;
				}
			}
		}
		// printf("\n");
		for (unsigned i = 0; i < NUM_ACTIVITIES; ++i)
		{
			activity_scores[activity_order[i][Width]] += width_c * i;
		}
		activity_selections2[activity_order[NUM_ACTIVITIES-1][Width]][Width]++;
	}


	if (diff)
	{
		for(unsigned i = 0; i < NUM_ACTIVITIES; ++i)
		{
			activity_order[i][Diff] = i;
		}
		for (unsigned i = 0; i < NUM_ACTIVITIES; ++i)
		{
			for (unsigned j = i+1; j < NUM_ACTIVITIES; ++j)
			{
				if (activity_albd[activity_order[i][Diff]] / activity_usage[activity_index] > activity_albd[activity_order[j][Diff]] / activity_usage[activity_index])
				{
					unsigned t = activity_order[i][Diff];
					activity_order[i][Diff] = activity_order[j][Diff];
					activity_order[j][Diff] = t;
				}
			}
		}
		for (unsigned i = 0; i < NUM_ACTIVITIES; ++i)
		{
			activity_scores[activity_order[i][Diff]] += diff_c * i;
		}
		activity_selections2[activity_order[NUM_ACTIVITIES-1][Diff]][Diff]++;
	}


	if (bjump)
	{
		for(unsigned i = 0; i < NUM_ACTIVITIES; ++i)
		{
			activity_order[i][Bjump] = i;
		}
		for (unsigned i = 0; i < NUM_ACTIVITIES; ++i)
		{
			for (unsigned j = i+1; j < NUM_ACTIVITIES; ++j)
			{
				if (activity_backjumps[activity_order[i][Bjump]] / activity_usage[activity_index] > activity_backjumps[activity_order[j][Bjump]] / activity_usage[activity_index])
				{
					unsigned t = activity_order[i][Bjump];
					activity_order[i][Bjump] = activity_order[j][Bjump];
					activity_order[j][Bjump] = t;
				}
			}
		}
		for (unsigned i = 0; i < NUM_ACTIVITIES; ++i)
		{
			activity_scores[activity_order[i][Bjump]] += bjump_c * i;
		}
		activity_selections2[activity_order[NUM_ACTIVITIES-1][Bjump]][Bjump]++;
	}


//	if (false)
//	{
//	for(unsigned i = 0; i < NUM_ACTIVITIES; ++i)
//	{
//		activity_order[i] = i;
//	}
//	for (unsigned i = 0; i < NUM_ACTIVITIES; ++i)
//	{
//		for (unsigned j = i+1; j < NUM_ACTIVITIES; ++j)
//		{
//			if (activity_lits_cc[activity_order[i]] / activity_lbd_size[activity_order[i]] > activity_lits_cc[activity_order[j]] / activity_lbd_size[activity_order[j]])
//			{
//				unsigned t = activity_order[i];
//				activity_order[i] = activity_order[j];
//				activity_order[j] = t;
//			}
//		}
//	}
//	for (unsigned i = 0; i < NUM_ACTIVITIES; ++i)
//	{
//		activity_scores[activity_order[i]] += i;
//	}
//	}


	if (lbd)
	{
		for(unsigned i = 0; i < NUM_ACTIVITIES; ++i)
		{
			activity_order[i][Lbd] = i;
		}
		for (unsigned i = 0; i < NUM_ACTIVITIES; ++i)
		{
			for (unsigned j = i+1; j < NUM_ACTIVITIES; ++j)
			{
				if (activity_lbd_size[activity_order[i][Lbd]] / activity_conflicts[activity_order[i][Lbd]] < activity_lbd_size[activity_order[j][Lbd]] / activity_conflicts[activity_order[j][Lbd]])
				{
					unsigned t = activity_order[i][Lbd];
					activity_order[i][Lbd] = activity_order[j][Lbd];
					activity_order[j][Lbd] = t;
				}
			}
		}
		for (unsigned i = 0; i < NUM_ACTIVITIES; ++i)
		{
			activity_scores[activity_order[i][Lbd]] += lbd_c * i;
		}
		activity_selections2[activity_order[NUM_ACTIVITIES-1][Lbd]][Lbd]++;
	}


	if (dec)
	{
		for(unsigned i = 0; i < NUM_ACTIVITIES; ++i)
		{
			activity_order[i][Dec] = i;
		}
		for (unsigned i = 0; i < NUM_ACTIVITIES; ++i)
		{
			for (unsigned j = i+1; j < NUM_ACTIVITIES; ++j)
			{
				if (activity_conflict_decisions[activity_order[i][Dec]] / activity_usage[activity_index] < activity_conflict_decisions[activity_order[j][Dec]] / activity_usage[activity_index])
				{
					unsigned t = activity_order[i][Dec];
					activity_order[i][Dec] = activity_order[j][Dec];
					activity_order[j][Dec] = t;
				}
			}
		}
		for (unsigned i = 0; i < NUM_ACTIVITIES; ++i)
		{
			activity_scores[activity_order[i][Dec]] += dec_c * i;
		}
		activity_selections2[activity_order[NUM_ACTIVITIES-1][Dec]][Dec]++;
	}


	if (alevel)
	{
		for(unsigned i = 0; i < NUM_ACTIVITIES; ++i)
		{
			activity_order[i][Alevel] = i;
		}
		for (unsigned i = 0; i < NUM_ACTIVITIES; ++i)
		{
			for (unsigned j = i+1; j < NUM_ACTIVITIES; ++j)
			{
				if (activity_alevels[activity_order[i][Alevel]] / activity_usage[activity_index] < activity_alevels[activity_order[j][Alevel]] / activity_usage[activity_index])
				{
					unsigned t = activity_order[i][Alevel];
					activity_order[i][Alevel] = activity_order[j][Alevel];
					activity_order[j][Alevel] = t;
				}
			}
		}
		for (unsigned i = 0; i < NUM_ACTIVITIES; ++i)
		{
			activity_scores[activity_order[i][Alevel]] += alevel_c * i;
		}
		activity_selections2[activity_order[NUM_ACTIVITIES-1][Alevel]][Alevel]++;
	}


	if (reslits)
	{
		for(unsigned i = 0; i < NUM_ACTIVITIES; ++i)
		{
			activity_order[i][ResLits] = i;
		}
		for (unsigned i = 0; i < NUM_ACTIVITIES; ++i)
		{
			for (unsigned j = i+1; j < NUM_ACTIVITIES; ++j)
			{
				if (activity_res_lits[activity_order[i][ResLits]] / activity_usage[activity_index] > activity_res_lits[activity_order[j][ResLits]] / activity_usage[activity_index])
				{
					unsigned t = activity_order[i][ResLits];
					activity_order[i][ResLits] = activity_order[j][ResLits];
					activity_order[j][ResLits] = t;
				}
			}
		}
		for (unsigned i = 0; i < NUM_ACTIVITIES; ++i)
		{
			activity_scores[activity_order[i][ResLits]] += reslits_c * i;
		}
		activity_selections2[activity_order[NUM_ACTIVITIES-1][ResLits]][ResLits]++;
	}


//	if (false)
//	{
//	for(unsigned i = 0; i < NUM_ACTIVITIES; ++i)
//	{
//		activity_order[i] = i;
//	}
//	for (unsigned i = 0; i < NUM_ACTIVITIES; ++i)
//	{
//		for (unsigned j = i+1; j < NUM_ACTIVITIES; ++j)
//		{
//			if (activity_res_clauses[activity_order[i]] > activity_res_clauses[activity_order[j]])
//			{
//				unsigned t = activity_order[i];
//				activity_order[i] = activity_order[j];
//				activity_order[j] = t;
//			}
//		}
//	}
//	for (unsigned i = 0; i < NUM_ACTIVITIES; ++i)
//	{
//		activity_scores[activity_order[i]] += i;
//	}
//	}


	if (usage)
	{
		for(unsigned i = 0; i < NUM_ACTIVITIES; ++i)
		{
			activity_order[i][Usage] = i;
		}
		for (unsigned i = 0; i < NUM_ACTIVITIES; ++i)
		{
			for (unsigned j = i+1; j < NUM_ACTIVITIES; ++j)
			{
				if (activity_lrnt_usage[activity_order[i][Usage]] / activity_usage[activity_index] > activity_lrnt_usage[activity_order[j][Usage]] / activity_usage[activity_index])
				{
					unsigned t = activity_order[i][Usage];
					activity_order[i][Usage] = activity_order[j][Usage];
					activity_order[j][Usage] = t;
				}
			}
		}
		for (unsigned i = 0; i < NUM_ACTIVITIES; ++i)
		{
			activity_scores[activity_order[i][Usage]] += usage_c * i;
		}
		activity_selections2[activity_order[NUM_ACTIVITIES-1][Usage]][Usage]++;
	}

	if (implic)
	{
		for(unsigned i = 0; i < NUM_ACTIVITIES; ++i)
		{
			activity_order[i][Implic] = i;
		}
		for (unsigned i = 0; i < NUM_ACTIVITIES; ++i)
		{
			for (unsigned j = i+1; j < NUM_ACTIVITIES; ++j)
			{
				if (activity_implic[activity_order[i][Implic]] / activity_conflict_decisions[activity_index] > activity_implic[activity_order[j][Implic]] / activity_conflict_decisions[activity_index])
				{
					unsigned t = activity_order[i][Implic];
					activity_order[i][Implic] = activity_order[j][Implic];
					activity_order[j][Implic] = t;
				}
			}
		}
		for (unsigned i = 0; i < NUM_ACTIVITIES; ++i)
		{
			activity_scores[activity_order[i][Implic]] += implic_c * i;
		}
		activity_selections2[activity_order[NUM_ACTIVITIES-1][Implic]][Implic]++;
	}

	if (agility)
	{
		for(unsigned i = 0; i < NUM_ACTIVITIES; ++i)
		{
			activity_order[i][Agility] = i;
		}
		for (unsigned i = 0; i < NUM_ACTIVITIES; ++i)
		{
			for (unsigned j = i+1; j < NUM_ACTIVITIES; ++j)
			{
				if (activity_flips[activity_order[i][Agility]] / activity_conflict_decisions[activity_index] > activity_flips[activity_order[j][Agility]] / activity_conflict_decisions[activity_index])
				{
					unsigned t = activity_order[i][Agility];
					activity_order[i][Agility] = activity_order[j][Agility];
					activity_order[j][Agility] = t;
				}
			}
		}
		for (unsigned i = 0; i < NUM_ACTIVITIES; ++i)
		{
			activity_scores[activity_order[i][Agility]] += agility_c * i;
		}
		activity_selections2[activity_order[NUM_ACTIVITIES-1][Agility]][Agility]++;
	}

	if (confvars)
	{
		for(unsigned i = 0; i < NUM_ACTIVITIES; ++i)
		{
			activity_order[i][ConfVars] = i;
		}
		for (unsigned i = 0; i < NUM_ACTIVITIES; ++i)
		{
			for (unsigned j = i+1; j < NUM_ACTIVITIES; ++j)
			{
				if (activity_conflict_vars[activity_order[i][ConfVars]].size() / activity_usage[activity_index] > activity_conflict_vars[activity_order[j][ConfVars]].size() / activity_usage[activity_index])
				{
					unsigned t = activity_order[i][ConfVars];
					activity_order[i][ConfVars] = activity_order[j][ConfVars];
					activity_order[j][ConfVars] = t;
				}
			}
		}
		for (unsigned i = 0; i < NUM_ACTIVITIES; ++i)
		{
			activity_scores[activity_order[i][ConfVars]] += confvars_c * i;
		}
		activity_selections2[activity_order[NUM_ACTIVITIES-1][ConfVars]][ConfVars]++;
	}

	if (reswidth)
	{
		for(unsigned i = 0; i < NUM_ACTIVITIES; ++i)
		{
			activity_order[i][ResWidth] = i;
		}
		for (unsigned i = 0; i < NUM_ACTIVITIES; ++i)
		{
			for (unsigned j = i+1; j < NUM_ACTIVITIES; ++j)
			{
				if (activity_reswidth[activity_order[i][ResWidth]] / activity_usage[activity_index] < activity_reswidth[activity_order[j][ResWidth]] / activity_usage[activity_index])
				{
					unsigned t = activity_order[i][ResWidth];
					activity_order[i][ResWidth] = activity_order[j][ResWidth];
					activity_order[j][ResWidth] = t;
				}
			}
		}
		for (unsigned i = 0; i < NUM_ACTIVITIES; ++i)
		{
			activity_scores[activity_order[i][ResWidth]] += reswidth_c * i;
		}
		activity_selections2[activity_order[NUM_ACTIVITIES-1][ResWidth]][ResWidth]++;
	}

	if (::reswidth_r)
	{
		for(unsigned i = 0; i < NUM_ACTIVITIES; ++i)
		{
			activity_order[i][ResWidthRate] = i;
		}
		for (unsigned i = 0; i < NUM_ACTIVITIES; ++i)
		{
			for (unsigned j = i+1; j < NUM_ACTIVITIES; ++j)
			{
				if (act_reswidth_rate[activity_order[i][ResWidthRate]] / activity_usage[activity_index] > act_reswidth_rate[activity_order[j][ResWidthRate]] / activity_usage[activity_index])
				{
					unsigned t = activity_order[i][ResWidthRate];
					activity_order[i][ResWidthRate] = activity_order[j][ResWidthRate];
					activity_order[j][ResWidthRate] = t;
				}
			}
		}
		for (unsigned i = 0; i < NUM_ACTIVITIES; ++i)
		{
			activity_scores[activity_order[i][ResWidthRate]] += reswidth_r_c * i;
		}
		activity_selections2[activity_order[NUM_ACTIVITIES-1][ResWidthRate]][ResWidthRate]++;
	}


	if (::freq)
	{
		for(unsigned i = 0; i < NUM_ACTIVITIES; ++i)
		{
			activity_order[i][Frequency] = i;
			// printf("%f ", (float)activity_frequency[i]/ activity_usage[activity_index]);
		}
		// printf("\n");
		for (unsigned i = 0; i < NUM_ACTIVITIES; ++i)
		{
			for (unsigned j = i+1; j < NUM_ACTIVITIES; ++j)
			{
				if ((activity_frequency[activity_order[i][Frequency]] /*/ activity_learnt_vars[activity_index]*/) / activity_usage[activity_index] > (activity_frequency[activity_order[j][Frequency]] /*/ activity_learnt_vars[activity_index]*/) / activity_usage[activity_index])
				{
					unsigned t = activity_order[i][Frequency];
					activity_order[i][Frequency] = activity_order[j][Frequency];
					activity_order[j][Frequency] = t;
				}
			}
		}
		for (unsigned i = 0; i < NUM_ACTIVITIES; ++i)
		{
			activity_scores[activity_order[i][Frequency]] += freq_c * i;
		}
		activity_selections2[activity_order[NUM_ACTIVITIES-1][Frequency]][Frequency]++;
	}

	if (::fdiff)
	{
		for(unsigned i = 0; i < NUM_ACTIVITIES; ++i)
		{
			activity_order[i][FreqDiff] = i;
			// printf("%f ", (float)activity_frequency[i]/ activity_usage[activity_index]);
		}
		// printf("\n");
		for (unsigned i = 0; i < NUM_ACTIVITIES; ++i)
		{
			for (unsigned j = i+1; j < NUM_ACTIVITIES; ++j)
			{
				if ((activity_freq_diff[activity_order[i][FreqDiff]]) / activity_usage[activity_index] > (activity_freq_diff[activity_order[j][FreqDiff]]) / activity_usage[activity_index])
				{
					unsigned t = activity_order[i][FreqDiff];
					activity_order[i][FreqDiff] = activity_order[j][FreqDiff];
					activity_order[j][FreqDiff] = t;
				}
			}
		}
		for (unsigned i = 0; i < NUM_ACTIVITIES; ++i)
		{
			activity_scores[activity_order[i][FreqDiff]] += ::fdiff_c * i;
		}
		activity_selections2[activity_order[NUM_ACTIVITIES-1][FreqDiff]][FreqDiff]++;
	}

	if (::sat)
	{
		// printf("%\n");
		for(unsigned i = 0; i < NUM_ACTIVITIES; ++i)
		{
			// printf(" %f ", (float)activity_satisfaction[i]);
			activity_order[i][Satisfaction] = i;
			// printf("%f ", (float)activity_frequency[i]/ activity_usage[activity_index]);
		}
		// printf("\n");
		for (unsigned i = 0; i < NUM_ACTIVITIES; ++i)
		{
			for (unsigned j = i+1; j < NUM_ACTIVITIES; ++j)
			{
				if ((activity_satisfaction[activity_order[i][Satisfaction]]) /*/ activity_conflicts[activity_order[i][Satisfaction]]*/ > (activity_satisfaction[activity_order[j][Satisfaction]]) /*/ activity_conflicts[activity_order[j][Satisfaction]]*/ )
				{
					unsigned t = activity_order[i][Satisfaction];
					activity_order[i][Satisfaction] = activity_order[j][Satisfaction];
					activity_order[j][Satisfaction] = t;
				}
			}
		}
		for (unsigned i = 0; i < NUM_ACTIVITIES; ++i)
		{
			activity_scores[activity_order[i][Satisfaction]] += ::sat_c * i;
		}
		activity_selections2[activity_order[NUM_ACTIVITIES-1][Satisfaction]][Satisfaction]++;
	}

	if (::sum_lbd)
	{
		// printf("%\n");
		for(unsigned i = 0; i < NUM_ACTIVITIES; ++i)
		{
			// printf(" %f ", (float)activity_satisfaction[i]);
			activity_order[i][SumLBD] = i;
			// printf("%f ", (float)activity_frequency[i]/ activity_usage[activity_index]);
		}
		// printf("\n");
		for (unsigned i = 0; i < NUM_ACTIVITIES; ++i)
		{
			for (unsigned j = i+1; j < NUM_ACTIVITIES; ++j)
			{
				if ((sumLBD_act[activity_order[i][SumLBD]])  < (sumLBD_act[activity_order[j][SumLBD]])  )
				{
					unsigned t = activity_order[i][SumLBD];
					activity_order[i][SumLBD] = activity_order[j][SumLBD];
					activity_order[j][SumLBD] = t;
				}
			}
		}
		for (unsigned i = 0; i < NUM_ACTIVITIES; ++i)
		{
			activity_scores[activity_order[i][SumLBD]] += ::sum_lbd_c * i;
		}
		activity_selections2[activity_order[NUM_ACTIVITIES-1][SumLBD]][SumLBD]++;
	}

	if (::runs)
	{
		// printf("%\n");
		for(unsigned i = 0; i < NUM_ACTIVITIES; ++i)
		{
			// printf(" %f ", (float)activity_satisfaction[i]);
			activity_order[i][Runs] = i;
			// printf("%f ", (float)activity_frequency[i]/ activity_usage[activity_index]);
		}
		// printf("\n");
		for (unsigned i = 0; i < NUM_ACTIVITIES; ++i)
		{
			for (unsigned j = i+1; j < NUM_ACTIVITIES; ++j)
			{
				if ((activity_usage[activity_order[i][Runs]]) / (activity_restarts[activity_order[i][Runs]]+1) < (activity_usage[activity_order[j][Runs]]) / (activity_restarts[activity_order[j][Runs]]+1))
				{
					unsigned t = activity_order[i][Runs];
					activity_order[i][Runs] = activity_order[j][Runs];
					activity_order[j][Runs] = t;
				}
			}
		}
		for (unsigned i = 0; i < NUM_ACTIVITIES; ++i)
		{
			activity_scores[activity_order[i][Runs]] += ::runs_c * i;
		}
		activity_selections2[activity_order[NUM_ACTIVITIES-1][Runs]][Runs]++;
	}


	unsigned best_score = 0;

	for (unsigned i = 0; i < NUM_ACTIVITIES; ++i)
	{
		if (activity_scores[i] > best_score)
		{
			best_score = activity_scores[i];
			best_activity = i;
		}
	}

	return best_activity;
}


unsigned Solver :: select_best_activity()
{
	double best_cost = 0;
	int best_activity  = -1;
	for (unsigned i = 0; i < NUM_ACTIVITIES; ++i)
	{
		double cost = 0;
		cost = (activity_implic[i] / activity_conflicts[i]);// / activity_lrnt_usage[i]);// / activity_usage[i];
		if (cost > best_cost || best_activity < 0)
		{
			best_cost = cost;
			best_activity = i;
		}
	}
	return best_activity;
}

unsigned Solver :: select_best_activity_lbd()
{
	double best_cost = 0;
	int best_activity  = -1;
	for (unsigned i = 0; i < NUM_ACTIVITIES; ++i)
	{
		double cost = 0;
		cost = (activity_lbd_size[i] / activity_usage[i]);// / activity_lrnt_usage[i]);// / activity_usage[i];
		if (cost < best_cost || best_activity < 0)
		{
			best_cost = cost;
			best_activity = i;
		}
	}
	return best_activity;
}

unsigned Solver :: select_best_activity_ilbd()
{
	double best_cost = 0;
	int best_activity  = -1;
	for (unsigned i = 0; i < NUM_ACTIVITIES; ++i)
	{
		double cost = 0;
		cost = (activity_lbd_size[i] / activity_usage[i]);// / activity_lrnt_usage[i]);// / activity_usage[i];
		if (cost > best_cost || best_activity < 0)
		{
			best_cost = cost;
			best_activity = i;
		}
	}
	return best_activity;
}

unsigned Solver :: select_best_activity_wlbd()
{
	double best_cost = 0;
	int best_activity  = -1;
	for (unsigned i = 0; i < NUM_ACTIVITIES; ++i)
	{
		double cost = 0;
		//cost = (activity_lbd_size[i] / activity_usage[i]) * (activity_lits_cc[i] / activity_usage[i]);// / activity_lrnt_usage[i]);// / activity_usage[i];

		cost = activity_lits_cc[i] / activity_lbd_size[i];// / activity_lrnt_usage[i]);// / activity_usage[i];
		if (cost < best_cost || best_activity < 0)
		{
			best_cost = cost;
			best_activity = i;
		}
	}
	return best_activity;
}

unsigned Solver :: select_best_activity_albd()
{
	double best_cost = 0;
	int best_activity  = -1;
	for (unsigned i = 0; i < NUM_ACTIVITIES; ++i)
	{
		double cost = 0;
		cost = (activity_albd[i] / activity_usage[i]);// / activity_lrnt_usage[i]);// / activity_usage[i];
		if (cost > best_cost || best_activity < 0)
		{
			best_cost = cost;
			best_activity = i;
		}
	}
	return best_activity;
}

int deep = 0;
void Solver :: traverse_preorder_depth_first(unsigned root,
											 std::vector<unsigned>& df_queue,
											 std::vector<unsigned>* clause_map,
											 bool* flags)
{
	if (flags[root])
	{
		return;
	}
	deep++;
	printf("%d ", (int)deep); fflush(stdout);
	flags[root] = true;
	// printf("%d ", (int)root); fflush(stdout);

	df_queue.push_back(root);

	for (unsigned i = 0; i < clause_map[root].size(); ++i)
	{
		unsigned clause = clause_map[root][i];
		CRef cr = clauses[clause];
		const Clause& cl = ca[cr];
		for (unsigned l = 0; l < cl.size(); ++l)
		{
			unsigned v = var(cl[l]);
			traverse_preorder_depth_first(v,
										  df_queue,
										  clause_map,
										  flags);
		}
	}
	deep--;
}


// NOTE: assumptions passed in member-variable 'assumptions'.
lbool Solver::solve_()
{
	bool static_heuristics = true;

	unsigned act = 1;

	if (static_heuristics)
	{
		std::vector<unsigned>* clause_map = new std::vector<unsigned>[frequency.size()];
		for (unsigned i = 0; i < clauses.size(); ++i)
		{
			CRef cr = clauses[i];
			const Clause& cl = ca[cr];
			for (unsigned l = 0; l < cl.size(); ++l)
			{
				unsigned v = var(cl[l]);
				clause_map[v].push_back(i);
			}
		}
	//	int heaviest = -1;
	//	unsigned highest_weight = 0;
	//	for (unsigned vi = 0; vi < clause_weights.size(); ++vi)
	//	{
	//		if (clause_weights[vi] > highest_weight || heaviest == -1)
	//		{
	//			heaviest = vi;
	//			highest_weight = clause_weights[vi];
	//		}
	//	}
	//
	//	CRef cr = clauses[heaviest];
	//	const Clause& cl = ca[cr];

		bool* flags = new bool[frequency.size()];
		std::vector<unsigned > var_order, df_stack;
		var_order.reserve(frequency.size());
		df_stack.reserve(frequency.size());

		// ACTIVITY 0 - 9

		std::set<int> tried;
		for (act = 0; act < NUM_ACTIVITIES; ++act)
		{
			int most_frequent = -1;
			unsigned highest_frequency = 0;
			for (int v=0; v<frequency.size(); ++v)
			{
				if ((frequency[v] > highest_frequency || most_frequent == -1) && tried.find(v) == tried.end())
				{
					most_frequent = v;
					highest_frequency = frequency[v];
				}
			}

			// printf("%d\n", most_frequent); fflush(stdout);
			if (most_frequent == -1)
			{
				tried.clear();
			}
			else
			{
				tried.insert(most_frequent);
			}

			var_order.clear(); df_stack.clear();
			for (unsigned i = 0; i < frequency.size(); ++i)
			{
				flags[i] = false;
				if (!clause_map[i].size())
				{
					var_order.push_back(i);
				}
			}

			df_stack.push_back(most_frequent);


//			if (false)
			{
				unsigned index = 0;
				while (true)
				{
					int root = 0;
					if (true)
					{
						if (!df_stack.size())
							break;
						root = df_stack[df_stack.size()-1];
						df_stack.pop_back();
					}
					else
					{
						if (index >= df_stack.size())
						{
							break;
						}
						root = df_stack[index++];
					}

					var_order.push_back(root);

					for (unsigned i = 0; i < clause_map[root].size(); ++i)
					{
						unsigned clause = clause_map[root][i];
						CRef cr = clauses[clause];
						const Clause& cl = ca[cr];
						for (unsigned l = 0; l < cl.size(); ++l)
						{
							unsigned v = var(cl[l]);
							if (!flags[v])
							{
								flags[v] = true;
								df_stack.push_back(v);
							}
						}
					}
				}
			}
//			else
//			{
//				unsigned index = 0;
//				while (index < df_stack.size())
//				{
//					int root = df_stack[index++];
//					var_order.push_back(root);
//
//					for (unsigned i = 0; i < clause_map[root].size(); ++i)
//					{
//						unsigned clause = clause_map[root][i];
//						CRef cr = clauses[clause];
//						const Clause& cl = ca[cr];
//						for (unsigned l = 0; l < cl.size(); ++l)
//						{
//							unsigned v = var(cl[l]);
//							if (!flags[v])
//							{
//								flags[v] = true;
//								df_stack.push_back(v);
//							}
//						}
//					}
//				}
//			}


			for (unsigned i = 0; i < activity.get_array(act).size(); ++i)
			{
				activity.get_array(act)[var_order[i]] = var_order.size() - i;
				// printf("%d ", (int)var_order[i]);
			}

			// printf("\n\n\n");

			order_heap.build(vs, act);

			for (unsigned i = 0; i < activity.get_array(act).size(); ++i)
			{
				activity.get_array(act)[i] /= frequency.size();//1e10;
			}
		}

		delete[] flags;
		delete[] clause_map;
	}

    model.clear();
    conflict.clear();
    if (!ok) return l_False;

    for (unsigned i = 0; i < NUM_ACTIVITIES; ++i)
    {
    	nbDecisionLevelHistory[i].initSize(100);
    	totalSumOfDecisionLevel[i] = 0;
        nbclausesbeforereduce[i] = 4000;
    }
    
    solves++;
    double nof_learnts = max_learnts = nClauses() * learntsize_factor;
    learntsize_adjust_confl   = learntsize_adjust_start_confl;
    learntsize_adjust_cnt     = (int)learntsize_adjust_confl;

    
    // Compute the first call to database clause reduction
//    if(nof_learnts <nbclausesbeforereduce) {
//      nbclausesbeforereduce = (nof_learnts/2 < 5000) ? 5000 : nof_learnts/2;
//    }
    lbool   status        = l_Undef;
//    nbclausesbeforereduce = 4000;
    
//    int tempt = luby(2, 8467);
//    printf("%d\n", tempt);
//    exit(0);
 
    if (verbosity >= 1){
        printf("c ============================[ Search Statistics ]==============================\n");
        printf("c | Conflicts |          ORIGINAL         |          LEARNT          | Progress |\n");
        printf("c |           |    Vars  Clauses Literals |    Limit  Clauses Lit/Cl |          |\n");
        printf("c ===============================================================================\n");
    }

    // Search:
	double diff = 0; //32-sample_frequency;
    // int curr_restarts = 0;
    for (unsigned p = 0; p < NUM_ACTIVITIES; ++p)
    {
    	activity_restarts[p] = 0;
    }
    while (status == l_Undef){
//        double rest_base = luby_restart ? luby(restart_inc, curr_restarts) : pow(restart_inc, curr_restarts);
//        status = search(rest_base * restart_first);

    	unsigned best_activity = Minisat::Solver::activity_index;

//		if (!assessment_mode && (num_assessments < MAX_ASSESS || MAX_ASSESS < 0))
		if (!assessment_mode && (next_sampling) == (curr_restarts) && !assessment_disabled)
		{
				if (false)
				if (this->num_assessments % 4 == 0)
				{
					for (unsigned i = 0; i < NUM_ACTIVITIES; ++i)
					{
//						activity_lits_cc[i] *= diff;
//						activity_lbd_size[i] *= diff;
//						activity_albd[i] *= diff;
//						activity_backjumps[i] *= diff;
//						activity_alevels[i] *= diff;
//						activity_conflict_decisions[i] *= diff;
						for (unsigned i = 0; i < NUM_ACTIVITIES; ++i)
						{
							activity_satisfaction[i] *= 0.5;
						}
					}
				}
				else if (false)
				{
					for (unsigned i = 0; i < NUM_ACTIVITIES; ++i)
					{
						//activity_frequency[i] *= 0;
						activity_lits_cc[i] *= 0;
						activity_lbd_size[i] *= 0;
						activity_albd[i] *= 0;
						activity_backjumps[i] *= 0;
						activity_alevels[i] *= 0;
						activity_conflict_decisions[i] = 0;
						activity_lrnt_usage[i] = 0;
					}
				}
				assessment_mode = true;
				++this->num_assessments;
				best_activity = 0;
		}
		else if (assessment_mode)
		{
			best_activity = (Minisat::Solver::activity_index + 1) % (NUM_ACTIVITIES);
			if (best_activity == 0)
			{
				assessment_mode = false;
				if (num_assessments == MAX_ASSESS)
				{
					assessment_disabled = true;
				}
				// this->next_sampling = luby(2,this->num_assessments) * sample_frequency + curr_restarts;
				// if (sample_frequency < 100)
				{
					//sample_frequency+=4;
				}
//				if (sample_size > 32)
//				{
//					sample_size-=4;
//				}
				this->next_sampling = sample_frequency + curr_restarts;
				// printf("<*%d*>", (int)next_sampling); fflush(stdout);
				assessment_dirty = true;
			}
		}

		if (!assessment_mode)
		{
			// if (num_assessments < MAX_ASSESS || MAX_ASSESS < 0)
			if (assessment_dirty)
			{
//				best_activity = 0;
				best_activity = select_best_activity2_2();
				assessment_dirty = false;
				num_selections++;

				activity_selections[best_activity]++;
	            if (false && verbosity >= 1 && this->num_assessments % 8 == 0)
	                printf("c | %9d | %7d %8d %8d | %8d %8d %6.0f | %6.3f %% |\n",
	                       (int)conflicts,
	                       (int)dec_vars - (trail_lim.size() == 0 ? trail.size() : trail_lim[0]), nClauses(), (int)clauses_literals,
	                       (int)max_learnts, nLearnts(), (double)learnts_literals/nLearnts(), progressEstimate()*100);
			}

			// best_activity = (Minisat::Solver::activity_index+1) % NUM_ACTIVITIES;
			// printf("%d\n", activity_selections[best_activity]);
		}

		Minisat::Solver::activity_index = best_activity;

    	if (assessment_mode)
    	{
    		// printf("\n**%d**\n", (int)curr_restarts);fflush(stdout);
    		// assessment_learnts.clear();
    		status = search(sample_size);
    	}
    	else
    	{
//			double rest_base = luby_restart ? luby(restart_inc, curr_restarts) : pow(restart_inc, curr_restarts);
    		double rest_base = true ? luby(restart_inc, (int)activity_restarts[Minisat::Solver::activity_index])
    				                        : pow(restart_inc, activity_restarts[Minisat::Solver::activity_index]);

    		// printf("<*%d*>", (int)(rest_base));
    		//long temp = conflicts;
    		// printf("**%d--%d**\n", (int)Minisat::Solver::activity_index, (int)rest_base * restart_first);fflush(stdout);
			status = search((int)(rest_base * restart_first));
			//temp = conflicts - temp;
			// printf("**%d**\n", (int)temp);
	        curr_restarts++;
	        // printf("**%d**\n", (int)curr_restarts);
			activity_restarts[Minisat::Solver::activity_index]++;
            printf("c %1d | %9d | %7d %8d %8d | %8d %8d %6.0f | %6.3f %% |\n", (int)activity_index,
                   (int)conflicts,
                   (int)dec_vars - (trail_lim.size() == 0 ? trail.size() : trail_lim[0]), nClauses(), (int)clauses_literals,
                   (int)max_learnts, nLearnts(), (double)learnts_literals/nLearnts(), progressEstimate()*100);

//			if (false)
    	}


        if (!withinBudget()) break;
        // curr_restarts++;
    }

    if (verbosity >= 1)
        printf("c ===============================================================================\n");


    if (status == l_True){
        // Extend & copy model:
        model.growTo(nVars());
        for (int i = 0; i < nVars(); i++) model[i] = value(i);
    }else if (status == l_False && conflict.size() == 0)
        ok = false;

    cancelUntil(0);
    return status;
}

//=================================================================================================
// Writing CNF to DIMACS:
// 
// FIXME: this needs to be rewritten completely.

static Var mapVar(Var x, vec<Var>& map, Var& max)
{
    if (map.size() <= x || map[x] == -1){
        map.growTo(x+1, -1);
        map[x] = max++;
    }
    return map[x];
}


void Solver::toDimacs(FILE* f, Clause& c, vec<Var>& map, Var& max)
{
    if (satisfied(c)) return;

    for (int i = 0; i < c.size(); i++)
        if (value(c[i]) != l_False)
            fprintf(f, "%s%d ", sign(c[i]) ? "-" : "", mapVar(var(c[i]), map, max)+1);
    fprintf(f, "0\n");
}


void Solver::toDimacs(const char *file, const vec<Lit>& assumps)
{
    FILE* f = fopen(file, "wr");
    if (f == NULL)
        fprintf(stderr, "could not open file %s\n", file), exit(1);
    toDimacs(f, assumps);
    fclose(f);
}


void Solver::toDimacs(FILE* f, const vec<Lit>& assumps)
{
    // Handle case when solver is in contradictory state:
    if (!ok){
        fprintf(f, "p cnf 1 2\n1 0\n-1 0\n");
        return; }

    vec<Var> map; Var max = 0;

    // Cannot use removeClauses here because it is not safe
    // to deallocate them at this point. Could be improved.
    int cnt = 0;
    for (int i = 0; i < clauses.size(); i++)
        if (!satisfied(ca[clauses[i]]))
            cnt++;
        
    for (int i = 0; i < clauses.size(); i++)
        if (!satisfied(ca[clauses[i]])){
            Clause& c = ca[clauses[i]];
            for (int j = 0; j < c.size(); j++)
                if (value(c[j]) != l_False)
                    mapVar(var(c[j]), map, max);
        }

    // Assumptions are added as unit clauses:
    cnt += assumptions.size();

    fprintf(f, "p cnf %d %d\n", max, cnt);

    for (int i = 0; i < assumptions.size(); i++){
        assert(value(assumptions[i]) != l_False);
        fprintf(f, "%s%d 0\n", sign(assumptions[i]) ? "-" : "", mapVar(var(assumptions[i]), map, max)+1);
    }

    for (int i = 0; i < clauses.size(); i++)
        toDimacs(f, ca[clauses[i]], map, max);

    if (verbosity > 0)
        printf("Wrote %d clauses with %d variables.\n", cnt, max);
}


//=================================================================================================
// Garbage Collection methods:

void Solver::relocAll(ClauseAllocator& to)
{
    // All watchers:
    //
    // for (int i = 0; i < watches.size(); i++)
    watches.cleanAll();
    watchesBin.cleanAll();
    for (int v = 0; v < nVars(); v++)
        for (int s = 0; s < 2; s++){
            Lit p = mkLit(v, s);
            // printf(" >>> RELOCING: %s%d\n", sign(p)?"-":"", var(p)+1);
            vec<Watcher>& ws = watches[p];
            for (int j = 0; j < ws.size(); j++)
                ca.reloc(ws[j].cref, to);
            vec<Watcher>& ws2 = watchesBin[p];
            for (int j = 0; j < ws2.size(); j++)
                ca.reloc(ws2[j].cref, to);
        }

    // All reasons:
    //
    for (int i = 0; i < trail.size(); i++){
        Var v = var(trail[i]);

        if (reason(v) != CRef_Undef && (ca[reason(v)].reloced() || locked(ca[reason(v)])))
            ca.reloc(vardata[v].reason, to);
    }

    // All learnt:
    //
    for (int i = 0; i < learnts.size(); i++)
        ca.reloc(learnts[i], to);

    // All original:
    //
    for (int i = 0; i < clauses.size(); i++)
        ca.reloc(clauses[i], to);
}


void Solver::garbageCollect()
{
    // Initialize the next region to a size corresponding to the estimated utilization degree. This
    // is not precise but should avoid some unnecessary reallocations for the new region:
    ClauseAllocator to(ca.size() - ca.wasted()); 

    relocAll(to);
    if (verbosity >= 2)
        printf("|  Garbage collection:   %12d bytes => %12d bytes             |\n", 
               ca.size()*ClauseAllocator::Unit_Size, to.size()*ClauseAllocator::Unit_Size);
    to.moveTo(ca);
}
