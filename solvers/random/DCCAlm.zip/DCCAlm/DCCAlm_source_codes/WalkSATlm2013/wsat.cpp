#include "wsat.h"

#include <sys/times.h> //these two h files are for linux
#include <unistd.h>

int a,b;

//compute break values and pick a var. (SKC)
int cpick_bbreak()
{
	int		k,c,v,ci;
	int 	bestvar_array[1000];
	int		bestvar_count;
	int		best_bbreak;
	int		bbreakv;
	int		*truep;
	
	c = unsat_stack[rand()%unsat_stack_fill_pointer];
	
	//the first var
	v = clause_lit[c][0].var_num;
	truep = (cur_soln[v])? var_poslit[v]:var_neglit[v];
	
	bbreakv=0;
	for(; (ci=*truep)!=-1; ++truep)
	{
		if (sat_count[ci]==1) ++bbreakv;
	}
	
	best_bbreak = bbreakv;
	bestvar_array[0] = v;
	bestvar_count = 1;	
	
	//the remaining vars
	for(k=1; k<clause_lit_count[c]; ++k)
	{
		v = clause_lit[c][k].var_num;
		
		truep = (cur_soln[v])? var_poslit[v]:var_neglit[v];
	
		bbreakv=0;
		for(; (ci=*truep)!=-1; ++truep)
		{
			if (sat_count[ci]==1) 
			{
				if (bbreakv == best_bbreak) break;
				++bbreakv;					
			}
		}
		
		if(ci!=-1) continue;//implies bbreakv>best_bbreak
		
		if (bbreakv < best_bbreak)
		{
			best_bbreak = bbreakv;
			bestvar_array[0] = v;
			bestvar_count = 1;
		}
		else// if (bbreakv == best_bbreak)
		{
			bestvar_array[bestvar_count]=v;
			++bestvar_count;
		}
	}
	
	if(best_bbreak == 0) return bestvar_array[rand()%bestvar_count];

	if( (rand()%MY_RAND_MAX_INT)*BASIC_SCALE < wp) return clause_lit[c][rand()%clause_lit_count[c]].var_num;
	else	return bestvar_array[rand()%bestvar_count];
	
}


//cpick means computing break values and pick, this function is adopted for random 4-SAT
int cpick_bbreak_gmake()
{
	int		i,k,c,v,ci;
	int 	bestvar_array[100];
	int		bestvar_count;
	int		best_bbreak;
	int		best_gmake;
	int		bbreakv,gmakev;

	int		*truep, *falsep;
	
	c = unsat_stack[rand()%unsat_stack_fill_pointer];
	
	//the first var
	v = clause_lit[c][0].var_num;
	truep = (cur_soln[v])? var_poslit[v]:var_neglit[v];
	
	bbreakv=0;
	for(; (ci=*truep)!=-1; ++truep)
	{
		if (sat_count[ci]==1) ++bbreakv;
	}
	
	best_bbreak = bbreakv;
	bestvar_array[0] = v;
	bestvar_count = 1;	
	
	//the remaining vars
	for(k=1; k<clause_lit_count[c]; ++k)
	{
		v = clause_lit[c][k].var_num;
		
		truep = (cur_soln[v])? var_poslit[v]:var_neglit[v];
		
		bbreakv=0;
		for(; (ci=*truep)!=-1; ++truep)
		{
			if (sat_count[ci]==1) 
			{
				if (bbreakv == best_bbreak) break;
				++bbreakv;					
			}
		}
		
		if(ci!=-1) continue;
		
		if (bbreakv < best_bbreak)
		{
			best_bbreak = bbreakv;
			bestvar_array[0] = v;
			bestvar_count = 1;
		}
		else// if (bbreakv == best_bbreak)
		{
			bestvar_array[bestvar_count]=v;
			++bestvar_count;
		}
	}

	if(best_bbreak!=0 && (rand()%MY_RAND_MAX_INT)*BASIC_SCALE < wp) return clause_lit[c][rand()%clause_lit_count[c]].var_num;

	if(bestvar_count>1)
	{	
		int org_bestvar_count = bestvar_count;
		
		v = bestvar_array[0];
		
		falsep = cur_soln[v]?var_neglit[v]:var_poslit[v];
		
		gmakev=0;
		for(; (ci=*falsep)!=-1; ++falsep)
		{
			if (sat_count[ci]==1) gmakev+=b;
			else if (sat_count[ci]==0) gmakev+=a;
		}
		best_gmake = gmakev;
		//bestvar_array[0] = v;
		bestvar_count = 1;	
		
		for(i=1; i<org_bestvar_count; ++i)
		{
			v = bestvar_array[i];
			falsep = cur_soln[v]?var_neglit[v]:var_poslit[v];
			
			gmakev=0;
			for(; (ci=*falsep)!=-1; ++falsep)
			{
				if (sat_count[ci]>1) continue;
				if (sat_count[ci]==1) gmakev+=b; 
				else //if (sat_count[ci]==0) 
					gmakev+=a;
			}
			
			if (gmakev > best_gmake)
			{
				best_gmake = gmakev;
				bestvar_array[0] = v;
				bestvar_count = 1;
			}
			else if (gmakev == best_gmake)
			{
				bestvar_array[bestvar_count]=v;
				++bestvar_count;
			}
		}
	}
	
	return bestvar_array[rand()%bestvar_count];
	
	/*if(best_bbreak == 0) return bestvar_array[rand()%bestvar_count];

	if(rand()%MY_RAND_MAX_INT < scaledwp) return clause_lit[c][rand()%clause_lit_count[c]].var_num;
	else	return bestvar_array[rand()%bestvar_count];*/
	
}


int pick_bbreak_gmake()
{
	int		i,k,c,v,ci;
	int 	bestvar_array[1000];
	int		bestvar_count;
	int		best_bbreak;
	int		best_gmake;
	int		gmakev;
	int		*falsep;
	
	c = unsat_stack[rand()%unsat_stack_fill_pointer];
	
	v = clause_lit[c][0].var_num; 
	best_bbreak = bbreak[v];
	bestvar_array[0] = v;
	bestvar_count = 1;	
	
    //idenfify the variables with min break.
	for(k=1; k<clause_lit_count[c]; ++k)
	{
		v = clause_lit[c][k].var_num;
		
		if (bbreak[v] < best_bbreak)
		{
			best_bbreak = bbreak[v];
			bestvar_array[0] = v;
			bestvar_count = 1;
		}
		else if (bbreak[v] == best_bbreak)
		{
			bestvar_array[bestvar_count]=v;
			++bestvar_count;
		}
	}

	
	if(best_bbreak!=0 && (rand()%MY_RAND_MAX_INT)*BASIC_SCALE < wp) return clause_lit[c][rand()%clause_lit_count[c]].var_num;

	
	if(bestvar_count>1)
	{	
		int org_bestvar_count = bestvar_count;
		
		v = bestvar_array[0];
		falsep = cur_soln[v]?var_neglit[v]:var_poslit[v];
		gmakev=0;
		for(; (ci=*falsep)!=-1; ++falsep)
		{
			if (sat_count[ci]>1) continue;
			if (sat_count[ci]==1) gmakev+=b; 
			else gmakev+=a;
		}
		best_gmake = gmakev;
		bestvar_count = 1;	
		
		for(i=1; i<org_bestvar_count; ++i)
		{
			v = bestvar_array[i];
			falsep = cur_soln[v]?var_neglit[v]:var_poslit[v];
			
			gmakev=0;
			for(; (ci=*falsep)!=-1; ++falsep)
			{
				if (sat_count[ci]>1) continue;
				if (sat_count[ci]==1) gmakev+=b; 
				else gmakev+=a;
			}
			
			if (gmakev > best_gmake)
			{
				best_gmake = gmakev;
				bestvar_array[0] = v;
				bestvar_count = 1;
			}
			else if (gmakev == best_gmake)
			{
				bestvar_array[bestvar_count]=v;
				++bestvar_count;
			}
		}
	}
	
	return bestvar_array[rand()%bestvar_count];
	
	/*if(best_bbreak == 0) return bestvar_array[rand()%bestvar_count];

	if(rand()%MY_RAND_MAX_INT < scaledwp) return clause_lit[c][rand()%clause_lit_count[c]].var_num;
	else	return bestvar_array[rand()%bestvar_count];*/
	
}

int (*pick) ();

void set_fun_par()
{
	//set wp
	if(max_clause_len <= 3) 
	{
		flip = flip_simp;
		pick = cpick_bbreak;
		if(ratio<=4.22) wp = 0.567;
		else if(ratio<=4.23) wp = 0.567-(ratio-4.2)/20;
		else if (ratio<4.26) wp = 0.561-(ratio-4.252)*7/30;
		else wp = 0.554-(ratio-4.267)*2/5;
		
		cout<<"c Algorithmic: WalkSAT"<<endl;
		cout<<"c Algorithmic: Noise = "<<wp<<endl;
	}
	else
	{
		flip = flip_simp;
		pick = cpick_bbreak_gmake;
		if(max_clause_len==4) 
		{
			if(ratio<=9) wp = 0.6;
			else if (ratio<=9.5) wp = 1.4921-0.1*ratio;
			else if (ratio<=9.75) wp = 1.5026-0.1*ratio;
			else wp = 1.9895-0.15*ratio;
			
			a=3; b=1;
		}
		else if(max_clause_len==5) 
		{	
			if(ratio<=20) wp = 0.39;
			else if(ratio<20.6) wp = 1.22-ratio/24;
			else if(ratio<=20.8)wp = 0.707-ratio/60;
			else wp = 1.231-ratio/24;
			
			a=3; b=2;
		}
		else if (max_clause_len==6) 
		{
			if(ratio<42) {
				wp = 1.05-0.02*ratio;
				if(wp>0.3) wp = 0.3;
			}
			else wp = 0.2;
			
			a=4; b=3;
		}
		else
		{
			flip = flip_update;
			pick = pick_bbreak_gmake;
			
			if(ratio<=85) wp = 0.12;
			else if (ratio<=87) wp = 0.232-ratio/750;
			else wp = 0.115;
			
			a=1; b=1;
		}
		
		cout<<"c Algorithmic: WalkSATlm"<<endl;
		cout<<"c Algorithmic: Noise = "<<wp<<endl;
		cout<<"c Algorithmic: Linear make = f1*make+f2*make_2, f1 = "<<a<<", f2 = "<<b<<endl;
	}
}


void local_search(int max_flips)
{
	int flipvar;
  
	for (step = 0; step<max_flips; step++)
	{
		if(unsat_stack_fill_pointer==0) return;
		
		flipvar = pick();
		flip(flipvar);
	}
}


int main(int argc, char* argv[])
{
	int     seed, tries; 
	int		satisfy_flag=0;
	struct 	tms start, stop;
	
	cout<<"c This is WalkSATlm2013 [Version: 2013.4.8] [Author: Shaowei Cai]."<<endl;
	
	times(&start);

	if (build_instance(argv[1])==0) return -1;
	
	sscanf(argv[2],"%d",&seed);
    
    //sscanf(argv[3],"%lf",&wp);
    
	srand(seed);
	//cout<<seed<<' ';

	cout<<"c Instance: Max clause length = "<<max_clause_len<<endl;
    cout<<"c Instance: Min clause length = "<<min_clause_len<<endl;
	cout<<"c Instance: Number of variables = "<<num_vars<<endl;
	cout<<"c Instance: Number of clauses = "<<num_clauses<<endl;
	cout<<"c Instance: Ratio = "<<ratio<<endl;
	cout<<"c Algorithmic: Random seed = "<<seed<<endl;
	
	set_fun_par();

	init();
	
	for (tries = 0; tries < max_tries; tries++) 
	{
		 local_search(max_flips);
		 
		 if (unsat_stack_fill_pointer==0) 
		 {
		 	if(verify_sol()==1) {satisfy_flag = 1; break;}
		    else cout<<"c Sorry, something is wrong."<<endl;/////
		 }
	}

	if(satisfy_flag==1)
    {
    	cout<<"s SATISFIABLE"<<endl;
		print_solution();
    }
    else  cout<<"s UNKNOWN"<<endl;
    
    times(&stop);
	double comp_time = double(stop.tms_utime - start.tms_utime +stop.tms_stime - start.tms_stime) / sysconf(_SC_CLK_TCK);
    
    cout<<"c solveSteps = "<<tries<<" tries + "<<step<<" steps (each try has "<<max_flips<<" steps)."<<endl;
    cout<<"c solveTime = "<<comp_time<<endl;
	
	free_memory();

    return 0;
}
