#include "polypower.h"
#include <sys/times.h>
//#include <unistd.h>
struct 	tms start, stop;
int	lsx_cutoff_time = 1000;
int	lsx = 0;
int	dwp1 = 0.567 * RAND_MAX;

//for probsat
double	probs0, probs1, probs2, probs3, probs4, probs5, probs6;
double	sumProb;
double	randPosition;

inline int tbfs4()
{
	//move the first t to the end and choose the t+1 one
	while (unsat_stack[first] == 0) ++first;
	unsat_stack[last] = unsat_stack[first++];
	index_in_unsat_stack[unsat_stack[last]] = last;
	++last;
	while (unsat_stack[first] == 0) ++first;
	unsat_stack[last] = unsat_stack[first++];
	index_in_unsat_stack[unsat_stack[last]] = last;
	++last;
	while (unsat_stack[first] == 0) ++first;
	unsat_stack[last] = unsat_stack[first++];
	index_in_unsat_stack[unsat_stack[last]] = last;
	++last;
	while (unsat_stack[first] == 0) ++first;
	unsat_stack[last] = unsat_stack[first++];
	index_in_unsat_stack[unsat_stack[last]] = last;
	++last;

	if (last > MM) { // Defragmentation
		int i = 0;
		while (first < last) {
			if (unsat_stack[first] != 0) {
				unsat_stack[i] = unsat_stack[first];
				index_in_unsat_stack[unsat_stack[i]] = i;
				++i;
			}
			++first;
		}
		first = 1; //because unsat_stack[0] will be satisfied
		last = unsat_stack_fill_pointer;
		return unsat_stack[0];
	}
	while (unsat_stack[first] == 0) ++first;
	return unsat_stack[first++];
}
inline int tbfsi()
{
	//move the first t to the end and choose the t+1 one
	for (int i = 0; i < _t; ++i) {
		while (unsat_stack[first] == 0) ++first;
		unsat_stack[last] = unsat_stack[first++];
		index_in_unsat_stack[unsat_stack[last]] = last;
		++last;
	}
	if (last > MM) { // Defragmentation
		int i = 0;
		while (first < last) {
			if (unsat_stack[first] != 0) {
				unsat_stack[i] = unsat_stack[first];
				index_in_unsat_stack[unsat_stack[i]] = i;
				++i;
			}
			++first;
		}
		first = 1; //because unsat_stack[0] will be satisfied
		last = unsat_stack_fill_pointer;
		return unsat_stack[0];
	}
	while (unsat_stack[first] == 0) ++first;
	return unsat_stack[first++];
}
void cpick_7sat()
{
	int	c = unsat_stack[rand()%unsat_stack_fill_pointer];
	int	oi = rand() % 5040;
	int	v0,v1,v2,v3,v4,v5,v6;
	
	v0 = clause_lit[c][order_7sat[oi][0]].var_num;
	if (bbreak[v0] == 0) {
		flip0_7sat(v0);
		return;
	}
	probs0 = probsBreak[bbreak[v0]];
	sumProb = probs0;
	
	v1 = clause_lit[c][order_7sat[oi][1]].var_num;
	if (bbreak[v1] == 0) {
		flip0_7sat(v1);
		return;
	}
	probs1 = probsBreak[bbreak[v1]];
	sumProb += probs1;
	
	v2 = clause_lit[c][order_7sat[oi][2]].var_num;
	if (bbreak[v2] == 0) {
		flip0_7sat(v2);
		return;
	}
	probs2 = probsBreak[bbreak[v2]];
	sumProb += probs2;
	
	v3 = clause_lit[c][order_7sat[oi][3]].var_num;
	if (bbreak[v3] == 0) {
		flip0_7sat(v3);
		return;
	}
	probs3 = probsBreak[bbreak[v3]];
	sumProb += probs3;
	
	v4 = clause_lit[c][order_7sat[oi][4]].var_num;
	if (bbreak[v4] == 0) {
		flip0_7sat(v4);
		return;
	}
	probs4 = probsBreak[bbreak[v4]];
	sumProb += probs4;
	
	v5 = clause_lit[c][order_7sat[oi][5]].var_num;
	if (bbreak[v5] == 0) {
		flip0_7sat(v5);
		return;
	}
	probs5 = probsBreak[bbreak[v5]];
	sumProb += probs5;

	v6 = clause_lit[c][order_7sat[oi][6]].var_num;
	if (bbreak[v6] == 0) {
		flip0_7sat(v6);
		return;
	}
	probs6 = probsBreak[bbreak[v6]];
	sumProb += probs6;

	randPosition = (double) (rand()) / (RAND_MAX + 1.0) * sumProb;
	// var 0
	sumProb -= probs0;
	if (sumProb <= randPosition) {
		flip2_7sat(v0);
		return;
	}
	// var 1
	sumProb -= probs1;
	if (sumProb <= randPosition) {
		flip2_7sat(v1);
		return;
	}
	// var 2
	sumProb -= probs2;
	if (sumProb <= randPosition) {
		flip2_7sat(v2);
		return;
	}
	// var 3
	sumProb -= probs3;
	if (sumProb <= randPosition) {
		flip2_7sat(v3);
		return;
	}
	// var 4
	sumProb -= probs4;
	if (sumProb <= randPosition) {
		flip2_7sat(v4);
		return;
	}
	// var 5
	sumProb -= probs5;
	if (sumProb <= randPosition) {
		flip2_7sat(v5);
		return;
	}
	// var 6
	flip2_7sat(v6);
}

void cpick_6sat()
{
	int	c = unsat_stack[rand()%unsat_stack_fill_pointer];
	int	oi = rand() % 720;
	int	v0,v1,v2,v3,v4,v5;
	
	v0 = clause_lit[c][order_6sat[oi][0]].var_num;
	if (bbreak[v0] == 0) {
		flip0_update(v0);
		return;
	}
	probs0 = probsBreak[bbreak[v0]];
	sumProb = probs0;
	
	v1 = clause_lit[c][order_6sat[oi][1]].var_num;
	if (bbreak[v1] == 0) {
		flip0_update(v1);
		return;
	}
	probs1 = probsBreak[bbreak[v1]];
	sumProb += probs1;
	
	v2 = clause_lit[c][order_6sat[oi][2]].var_num;
	if (bbreak[v2] == 0) {
		flip0_update(v2);
		return;
	}
	probs2 = probsBreak[bbreak[v2]];
	sumProb += probs2;
	
	v3 = clause_lit[c][order_6sat[oi][3]].var_num;
	if (bbreak[v3] == 0) {
		flip0_update(v3);
		return;
	}
	probs3 = probsBreak[bbreak[v3]];
	sumProb += probs3;
	
	v4 = clause_lit[c][order_6sat[oi][4]].var_num;
	if (bbreak[v4] == 0) {
		flip0_update(v4);
		return;
	}
	probs4 = probsBreak[bbreak[v4]];
	sumProb += probs4;
	
	v5 = clause_lit[c][order_6sat[oi][5]].var_num;
	if (bbreak[v5] == 0) {
		flip0_update(v5);
		return;
	}
	probs5 = probsBreak[bbreak[v5]];
	sumProb += probs5;

	randPosition = (double) (rand()) / (RAND_MAX + 1.0) * sumProb;
	// var 0
	sumProb -= probs0;
	if (sumProb <= randPosition) {
		flip2_update(v0);
		return;
	}
	// var 1
	sumProb -= probs1;
	if (sumProb <= randPosition) {
		flip2_update(v1);
		return;
	}
	// var 2
	sumProb -= probs2;
	if (sumProb <= randPosition) {
		flip2_update(v2);
		return;
	}
	// var 3
	sumProb -= probs3;
	if (sumProb <= randPosition) {
		flip2_update(v3);
		return;
	}
	// var 4
	sumProb -= probs4;
	if (sumProb <= randPosition) {
		flip2_update(v4);
		return;
	}
	// var 5
	flip2_update(v5);
}

void cpick_5sat_c_tbfs()
{
	int	c = tbfsi();
	int	oi = rand() % 120;
	int	v0,v1,v2,v3,v4;
	
	v0 = clause_lit[c][order_5sat[oi][0]].var_num;
	if (bbreak[v0] == 0) {
		flip0_update_tbfs(v0);
		return;
	}
	probs0 = probsBreak[bbreak[v0]];
	sumProb = probs0;
	
	v1 = clause_lit[c][order_5sat[oi][1]].var_num;
	if (bbreak[v1] == 0) {
		flip0_update_tbfs(v1);
		return;
	}
	probs1 = probsBreak[bbreak[v1]];
	sumProb += probs1;
	
	v2 = clause_lit[c][order_5sat[oi][2]].var_num;
	if (bbreak[v2] == 0) {
		flip0_update_tbfs(v2);
		return;
	}
	probs2 = probsBreak[bbreak[v2]];
	sumProb += probs2;
	
	v3 = clause_lit[c][order_5sat[oi][3]].var_num;
	if (bbreak[v3] == 0) {
		flip0_update_tbfs(v3);
		return;
	}
	probs3 = probsBreak[bbreak[v3]];
	sumProb += probs3;
	
	v4 = clause_lit[c][order_5sat[oi][4]].var_num;
	if (bbreak[v4] == 0) {
		flip0_update_tbfs(v4);
		return;
	}
	probs4 = probsBreak[bbreak[v4]];
	sumProb += probs4;

	randPosition = (double) (rand()) / (RAND_MAX + 1.0) * sumProb;
	// var 0
	sumProb -= probs0;
	if (sumProb <= randPosition) {
		flip2_update_tbfs(v0);
		return;
	}
	// var 1
	sumProb -= probs1;
	if (sumProb <= randPosition) {
		flip2_update_tbfs(v1);
		return;
	}
	// var 2
	sumProb -= probs2;
	if (sumProb <= randPosition) {
		flip2_update_tbfs(v2);
		return;
	}
	// var 3
	sumProb -= probs3;
	if (sumProb <= randPosition) {
		flip2_update_tbfs(v3);
		return;
	}
	// var 4
	flip2_update_tbfs(v4);
}
void cpick_5sat_c()
{
	int	c = unsat_stack[rand()%unsat_stack_fill_pointer];
	int	oi = rand() % 120;
	int	v0,v1,v2,v3,v4;
	
	v0 = clause_lit[c][order_5sat[oi][0]].var_num;
	if (bbreak[v0] == 0) {
		flip0_update(v0);
		return;
	}
	probs0 = probsBreak[bbreak[v0]];
	sumProb = probs0;
	
	v1 = clause_lit[c][order_5sat[oi][1]].var_num;
	if (bbreak[v1] == 0) {
		flip0_update(v1);
		return;
	}
	probs1 = probsBreak[bbreak[v1]];
	sumProb += probs1;
	
	v2 = clause_lit[c][order_5sat[oi][2]].var_num;
	if (bbreak[v2] == 0) {
		flip0_update(v2);
		return;
	}
	probs2 = probsBreak[bbreak[v2]];
	sumProb += probs2;
	
	v3 = clause_lit[c][order_5sat[oi][3]].var_num;
	if (bbreak[v3] == 0) {
		flip0_update(v3);
		return;
	}
	probs3 = probsBreak[bbreak[v3]];
	sumProb += probs3;
	
	v4 = clause_lit[c][order_5sat[oi][4]].var_num;
	if (bbreak[v4] == 0) {
		flip0_update(v4);
		return;
	}
	probs4 = probsBreak[bbreak[v4]];
	sumProb += probs4;

	randPosition = (double) (rand()) / (RAND_MAX + 1.0) * sumProb;
	// var 0
	sumProb -= probs0;
	if (sumProb <= randPosition) {
		flip2_update(v0);
		return;
	}
	// var 1
	sumProb -= probs1;
	if (sumProb <= randPosition) {
		flip2_update(v1);
		return;
	}
	// var 2
	sumProb -= probs2;
	if (sumProb <= randPosition) {
		flip2_update(v2);
		return;
	}
	// var 3
	sumProb -= probs3;
	if (sumProb <= randPosition) {
		flip2_update(v3);
		return;
	}
	// var 4
	flip2_update(v4);
}

void cpick_5sat_nc()
{
	int		c = unsat_stack[rand()%unsat_stack_fill_pointer];
	int		v0,v1,v2,v3,v4;
	int		oi = rand() % 120;
	int		*truep0, *truep1, *truep2, *truep3, *truep4;
	//find 0
	// var 0
	v0 = clause_lit[c][order_5sat[oi][0]].var_num;
	truep0 = (cur_soln[v0])? var_poslit[v0]:var_neglit[v0];
	for(; sat_count[*truep0]!=1; ++truep0);
	if (*truep0 == 0) {
		flip0(v0);
		return;
	}
	// var 1
	v1 = clause_lit[c][order_5sat[oi][1]].var_num;
	truep1 = (cur_soln[v1])? var_poslit[v1]:var_neglit[v1];
	for(; sat_count[*truep1]!=1; ++truep1);
	if (*truep1 == 0) {
		flip0(v1);
		return;
	}
	// var 2
	v2 = clause_lit[c][order_5sat[oi][2]].var_num;
	truep2 = (cur_soln[v2])? var_poslit[v2]:var_neglit[v2];
	for(; sat_count[*truep2]!=1; ++truep2);
	if (*truep2 == 0) {
		flip0(v2);
		return;
	}
	// var 3
	v3 = clause_lit[c][order_5sat[oi][3]].var_num;
	truep3 = (cur_soln[v3])? var_poslit[v3]:var_neglit[v3];
	for(; sat_count[*truep3]!=1; ++truep3);
	if (*truep3 == 0) {
		flip0(v3);
		return;
	}
	// var 4
	v4 = clause_lit[c][order_5sat[oi][4]].var_num;
	truep4 = (cur_soln[v4])? var_poslit[v4]:var_neglit[v4];
	for(; sat_count[*truep4]!=1; ++truep4);
	if (*truep4 == 0) {
		flip0(v4);
		return;
	}

	// the break values are at least 1
	//prob
	// var 0
	int	bb = 0;
	for (++truep0; (*truep0)!=0; ++truep0) {
		if (sat_count[*truep0] == 1)
			++bb;
	}
	probs0 = probsBreak[bb];
	sumProb = probs0;

	// var 1
	bb = 0;
	for (++truep1; (*truep1)!=0; ++truep1) {
		if (sat_count[*truep1] == 1)
			++bb;
	}
	probs1 = probsBreak[bb];
	sumProb += probs1;

	// var 2
	bb = 0;
	for (++truep2; (*truep2)!=0; ++truep2) {
		if (sat_count[*truep2] == 1)
			++bb;
	}
	probs2 = probsBreak[bb];
	sumProb += probs2;

	// var 3
	bb = 0;
	for (++truep3; (*truep3)!=0; ++truep3) {
		if (sat_count[*truep3] == 1)
			++bb;
	}
	probs3 = probsBreak[bb];
	sumProb += probs3;

	// var 4
	bb = 0;
	for (++truep4; (*truep4)!=0; ++truep4) {
		if (sat_count[*truep4] == 1)
			++bb;
	}
	probs4 = probsBreak[bb];
	sumProb += probs4;

	randPosition = (double) (rand()) / (RAND_MAX + 1.0) * sumProb;
	// var 0
	sumProb -= probs0;
	if (sumProb <= randPosition) {
		flip2(v0);
		return;
	}
	// var 1
	sumProb -= probs1;
	if (sumProb <= randPosition) {
		flip2(v1);
		return;
	}
	// var 2
	sumProb -= probs2;
	if (sumProb <= randPosition) {
		flip2(v2);
		return;
	}
	// var 3
	sumProb -= probs3;
	if (sumProb <= randPosition) {
		flip2(v3);
		return;
	}
	// var 4
	flip2(v4);
}

void cpick_4sat_c_tbfs4()
{
	int	c = tbfs4();
	int	oi = rand() % 24;
	int	v0,v1,v2,v3;
	
	v0 = clause_lit[c][order_4sat[oi][0]].var_num;
	if (bbreak[v0] == 0) {
		flip0_update_tbfs(v0);
		return;
	}
	probs0 = probsBreak[bbreak[v0]];
	sumProb = probs0;
	
	v1 = clause_lit[c][order_4sat[oi][1]].var_num;
	if (bbreak[v1] == 0) {
		flip0_update_tbfs(v1);
		return;
	}
	probs1 = probsBreak[bbreak[v1]];
	sumProb += probs1;
	
	v2 = clause_lit[c][order_4sat[oi][2]].var_num;
	if (bbreak[v2] == 0) {
		flip0_update_tbfs(v2);
		return;
	}
	probs2 = probsBreak[bbreak[v2]];
	sumProb += probs2;
	
	v3 = clause_lit[c][order_4sat[oi][3]].var_num;
	if (bbreak[v3] == 0) {
		flip0_update_tbfs(v3);
		return;
	}
	probs3 = probsBreak[bbreak[v3]];
	sumProb += probs3;
	
	randPosition = (double) (rand()) / (RAND_MAX + 1.0) * sumProb;
	// var 0
	sumProb -= probs0;
	if (sumProb <= randPosition) {
		flip2_update_tbfs(v0);
		return;
	}
	// var 1
	sumProb -= probs1;
	if (sumProb <= randPosition) {
		flip2_update_tbfs(v1);
		return;
	}
	// var 2
	sumProb -= probs2;
	if (sumProb <= randPosition) {
		flip2_update_tbfs(v2);
		return;
	}
	// var 3
	flip2_update_tbfs(v3);
}
void cpick_4sat_c()
{
	int	c = unsat_stack[rand()%unsat_stack_fill_pointer];
	int	oi = rand() % 24;
	int	v0,v1,v2,v3;
	
	v0 = clause_lit[c][order_4sat[oi][0]].var_num;
	if (bbreak[v0] == 0) {
		flip0_update(v0);
		return;
	}
	probs0 = probsBreak[bbreak[v0]];
	sumProb = probs0;
	
	v1 = clause_lit[c][order_4sat[oi][1]].var_num;
	if (bbreak[v1] == 0) {
		flip0_update(v1);
		return;
	}
	probs1 = probsBreak[bbreak[v1]];
	sumProb += probs1;
	
	v2 = clause_lit[c][order_4sat[oi][2]].var_num;
	if (bbreak[v2] == 0) {
		flip0_update(v2);
		return;
	}
	probs2 = probsBreak[bbreak[v2]];
	sumProb += probs2;
	
	v3 = clause_lit[c][order_4sat[oi][3]].var_num;
	if (bbreak[v3] == 0) {
		flip0_update(v3);
		return;
	}
	probs3 = probsBreak[bbreak[v3]];
	sumProb += probs3;
	
	randPosition = (double) (rand()) / (RAND_MAX + 1.0) * sumProb;
	// var 0
	sumProb -= probs0;
	if (sumProb <= randPosition) {
		flip2_update(v0);
		return;
	}
	// var 1
	sumProb -= probs1;
	if (sumProb <= randPosition) {
		flip2_update(v1);
		return;
	}
	// var 2
	sumProb -= probs2;
	if (sumProb <= randPosition) {
		flip2_update(v2);
		return;
	}
	// var 3
	flip2_update(v3);
}

void cpick_4sat()
{
	int		c = unsat_stack[rand()%unsat_stack_fill_pointer];
	int		v0,v1,v2,v3;
	int		oi = rand() % 24;
	int		*truep0, *truep1, *truep2, *truep3;
	//find 0
	// var 0
	v0 = clause_lit[c][order_4sat[oi][0]].var_num;
	truep0 = (cur_soln[v0])? var_poslit[v0]:var_neglit[v0];
	for(; sat_count[*truep0]!=1; ++truep0);
	if (*truep0 == 0) {
		flip0(v0);
		return;
	}
	// var 1
	v1 = clause_lit[c][order_4sat[oi][1]].var_num;
	truep1 = (cur_soln[v1])? var_poslit[v1]:var_neglit[v1];
	for(; sat_count[*truep1]!=1; ++truep1);
	if (*truep1 == 0) {
		flip0(v1);
		return;
	}
	// var 2
	v2 = clause_lit[c][order_4sat[oi][2]].var_num;
	truep2 = (cur_soln[v2])? var_poslit[v2]:var_neglit[v2];
	for(; sat_count[*truep2]!=1; ++truep2);
	if (*truep2 == 0) {
		flip0(v2);
		return;
	}
	// var 3
	v3 = clause_lit[c][order_4sat[oi][3]].var_num;
	truep3 = (cur_soln[v3])? var_poslit[v3]:var_neglit[v3];
	for(; sat_count[*truep3]!=1; ++truep3);
	if (*truep3 == 0) {
		flip0(v3);
		return;
	}

	//prob
	// var 0
	int	bb = 1;
	for (++truep0; (*truep0)!=0; ++truep0) {
		if (sat_count[*truep0] == 1)
			++bb;
	}
	probs0 = probsBreak[bb];
	sumProb = probs0;

	// var 1
	bb = 1;
	for (++truep1; (*truep1)!=0; ++truep1) {
		if (sat_count[*truep1] == 1)
			++bb;
	}
	probs1 = probsBreak[bb];
	sumProb += probs1;

	// var 2
	bb = 1;
	for (++truep2; (*truep2)!=0; ++truep2) {
		if (sat_count[*truep2] == 1)
			++bb;
	}
	probs2 = probsBreak[bb];
	sumProb += probs2;

	// var 3
	bb = 1;
	for (++truep3; (*truep3)!=0; ++truep3) {
		if (sat_count[*truep3] == 1)
			++bb;
	}
	probs3 = probsBreak[bb];
	sumProb += probs3;

	randPosition = (double) (rand()) / (RAND_MAX + 1.0) * sumProb;
	// var 0
	sumProb -= probs0;
	if (sumProb <= randPosition) {
		flip2(v0);
		return;
	}
	// var 1
	sumProb -= probs1;
	if (sumProb <= randPosition) {
		flip2(v1);
		return;
	}
	// var 2
	sumProb -= probs2;
	if (sumProb <= randPosition) {
		flip2(v2);
		return;
	}
	// var 3
	flip2(v3);
}
inline int tbfs1()
{
	while (unsat_stack[first] == 0) ++first;
	unsat_stack[last] = unsat_stack[first++];
	index_in_unsat_stack[unsat_stack[last]] = last;
	++last;
	if (last > MM) { // Defragmentation
		int i = 0;
		while (first < last) {
			if (unsat_stack[first] != 0) {
				unsat_stack[i] = unsat_stack[first];
				index_in_unsat_stack[unsat_stack[i]] = i;
				++i;
			}
			++first;
		}
		first = 1; //because unsat_stack[0] will be satisfied
		last = unsat_stack_fill_pointer;
		return unsat_stack[0];
	}
	while (unsat_stack[first] == 0) ++first;
	return unsat_stack[first++];
}
inline int tbfs2()
{
	while (unsat_stack[first] == 0) ++first;
	unsat_stack[last] = unsat_stack[first++];
	index_in_unsat_stack[unsat_stack[last]] = last;
	++last;
	//move the first two to the end and choose the third one
	while (unsat_stack[first] == 0) ++first;
	unsat_stack[last] = unsat_stack[first++];
	index_in_unsat_stack[unsat_stack[last]] = last;
	++last;
	if (last > MM) { // Defragmentation
		int i = 0;
		while (first < last) {
			if (unsat_stack[first] != 0) {
				unsat_stack[i] = unsat_stack[first];
				index_in_unsat_stack[unsat_stack[i]] = i;
				++i;
			}
			++first;
		}
		first = 1; //because unsat_stack[0] will be satisfied
		last = unsat_stack_fill_pointer;
		return unsat_stack[0];
	}
	while (unsat_stack[first] == 0) ++first;
	return unsat_stack[first++];
}
void cpick_3sat_tbfs4()
{
	int	c = tbfs4();
	int	oi = rand() % 6;
	int	v0,v1,v2;
	v0 = clause_lit[c][order_3sat[oi][0]].var_num;
	if (bbreak[v0] == 0) {
		flip0_update_3sat_tbfs(v0);
		return;
	}
	v1 = clause_lit[c][order_3sat[oi][1]].var_num;
	if (bbreak[v1] == 0) {
		flip0_update_3sat_tbfs(v1);
		return;
	}
	v2 = clause_lit[c][order_3sat[oi][2]].var_num;
	if (bbreak[v2] == 0) {
		flip0_update_3sat_tbfs(v2);
		return;
	}
	int	rd = rand();
	PPP3	ppp = pb3[bbreak[v0]][bbreak[v1]][bbreak[v2]];
	if (rd < ppp.a)
		flip2_update_3sat_tbfs(v0);
	else if (rd < ppp.b)
		flip2_update_3sat_tbfs(v1);
	else
		flip2_update_3sat_tbfs(v2);
}
void cpick_3sat_tbfs()
{
	int	c = clauseselection();
	int	oi = rand() % 6;
	int	v0,v1,v2;
	v0 = clause_lit[c][order_3sat[oi][0]].var_num;
	if (bbreak[v0] == 0) {
		flip0_update_3sat_tbfs(v0);
		return;
	}
	v1 = clause_lit[c][order_3sat[oi][1]].var_num;
	if (bbreak[v1] == 0) {
		flip0_update_3sat_tbfs(v1);
		return;
	}
	v2 = clause_lit[c][order_3sat[oi][2]].var_num;
	if (bbreak[v2] == 0) {
		flip0_update_3sat_tbfs(v2);
		return;
	}
	int	rd = rand();
	PPP3	ppp = pb3[bbreak[v0]][bbreak[v1]][bbreak[v2]];
	if (rd < ppp.a)
		flip2_update_3sat_tbfs(v0);
	else if (rd < ppp.b)
		flip2_update_3sat_tbfs(v1);
	else
		flip2_update_3sat_tbfs(v2);
}
void cpick_3sat_rs()
{
	int	c = unsat_stack[rand() % unsat_stack_fill_pointer];
	int	oi = rand() % 6;
	int	v0,v1,v2;
	v0 = clause_lit[c][order_3sat[oi][0]].var_num;
	if (bbreak[v0] == 0) {
		flip0_update_3sat(v0);
		return;
	}
	v1 = clause_lit[c][order_3sat[oi][1]].var_num;
	if (bbreak[v1] == 0) {
		flip0_update_3sat(v1);
		return;
	}
	v2 = clause_lit[c][order_3sat[oi][2]].var_num;
	if (bbreak[v2] == 0) {
		flip0_update_3sat(v2);
		return;
	}
	int	rd = rand();
	PPP3	ppp = pb3[bbreak[v0]][bbreak[v1]][bbreak[v2]];
	if (rd < ppp.a)
		flip2_update_3sat(v0);
	else if (rd < ppp.b)
		flip2_update_3sat(v1);
	else
		flip2_update_3sat(v2);
}
void cpick_3sat_c()
{
	int	c = unsat_stack[rand()%unsat_stack_fill_pointer];
	int	oi = rand() % 6;
	int	v0,v1,v2;
	
	v0 = clause_lit[c][order_3sat[oi][0]].var_num;
	if (bbreak[v0] == 0) {
		flip0_update(v0);
		return;
	}
	probs0 = probsBreak[bbreak[v0]];
	sumProb = probs0;
	
	v1 = clause_lit[c][order_3sat[oi][1]].var_num;
	if (bbreak[v1] == 0) {
		flip0_update(v1);
		return;
	}
	probs1 = probsBreak[bbreak[v1]];
	sumProb += probs1;
	
	v2 = clause_lit[c][order_3sat[oi][2]].var_num;
	if (bbreak[v2] == 0) {
		flip0_update(v2);
		return;
	}
	probs2 = probsBreak[bbreak[v2]];
	sumProb += probs2;
	
	randPosition = (double) (rand()) / (RAND_MAX + 1.0) * sumProb;
	// var 0
	sumProb -= probs0;
	if (sumProb <= randPosition) {
		flip2_update(v0);
		return;
	}
	// var 1
	sumProb -= probs1;
	if (sumProb <= randPosition) {
		flip2_update(v1);
		return;
	}
	// var 2
	flip2_update(v2);
}
void cpick_3sat_snc_tbfs4()
{
	int		c = tbfs4();
	int		v0,v1,v2;
	int		oi = rand() % 6;
	int		*truep0, *truep1, *truep2;
	//find 0
	// var 0
	v0 = clause_lit[c][order_3sat[oi][0]].var_num;
	truep0 = (cur_soln[v0])? var_poslit[v0]:var_neglit[v0];
	for(; sat_count[*truep0]!=1; ++truep0);
	if (*truep0 == 0) {
		flip0_tbfs(v0);
		return;
	}
	// var 1
	v1 = clause_lit[c][order_3sat[oi][1]].var_num;
	truep1 = (cur_soln[v1])? var_poslit[v1]:var_neglit[v1];
	for(; sat_count[*truep1]!=1; ++truep1);
	if (*truep1 == 0) {
		flip0_tbfs(v1);
		return;
	}
	// var 2
	v2 = clause_lit[c][order_3sat[oi][2]].var_num;
	truep2 = (cur_soln[v2])? var_poslit[v2]:var_neglit[v2];
	for(; sat_count[*truep2]!=1; ++truep2);
	if (*truep2 == 0) {
		flip0_tbfs(v2);
		return;
	}

	//prob
	// var 0
	int	b0 = 1, b1 = 1, b2 = 1;
	for (++truep0; (*truep0)!=0; ++truep0) {
		if (sat_count[*truep0] == 1)
			++b0;
	}

	// var 1
	for (++truep1; (*truep1)!=0; ++truep1) {
		if (sat_count[*truep1] == 1)
			++b1;
	}

	// var 2
	for (++truep2; (*truep2)!=0; ++truep2) {
		if (sat_count[*truep2] == 1)
			++b2;
	}
	int	rd = rand();
	PPP3	ppp = pb3[b0][b1][b2];
	if (rd < ppp.a)
		flip2_tbfs(v0);
	else if (rd < ppp.b)
		flip2_tbfs(v1);
	else
		flip2_tbfs(v2);
}
void cpick_3sat_snc_tbfs()
{
	int		c = tbfsi();
	int		v0,v1,v2;
	int		oi = rand() % 6;
	int		*truep0, *truep1, *truep2;
	//find 0
	// var 0
	v0 = clause_lit[c][order_3sat[oi][0]].var_num;
	truep0 = (cur_soln[v0])? var_poslit[v0]:var_neglit[v0];
	for(; sat_count[*truep0]!=1; ++truep0);
	if (*truep0 == 0) {
		flip0_tbfs(v0);
		return;
	}
	// var 1
	v1 = clause_lit[c][order_3sat[oi][1]].var_num;
	truep1 = (cur_soln[v1])? var_poslit[v1]:var_neglit[v1];
	for(; sat_count[*truep1]!=1; ++truep1);
	if (*truep1 == 0) {
		flip0_tbfs(v1);
		return;
	}
	// var 2
	v2 = clause_lit[c][order_3sat[oi][2]].var_num;
	truep2 = (cur_soln[v2])? var_poslit[v2]:var_neglit[v2];
	for(; sat_count[*truep2]!=1; ++truep2);
	if (*truep2 == 0) {
		flip0_tbfs(v2);
		return;
	}

	//prob
	// var 0
	int	b0 = 1, b1 = 1, b2 = 1;
	for (++truep0; (*truep0)!=0; ++truep0) {
		if (sat_count[*truep0] == 1)
			++b0;
	}

	// var 1
	for (++truep1; (*truep1)!=0; ++truep1) {
		if (sat_count[*truep1] == 1)
			++b1;
	}

	// var 2
	for (++truep2; (*truep2)!=0; ++truep2) {
		if (sat_count[*truep2] == 1)
			++b2;
	}
	int	rd = rand();
	PPP3	ppp = pb3[b0][b1][b2];
	if (rd < ppp.a)
		flip2_tbfs(v0);
	else if (rd < ppp.b)
		flip2_tbfs(v1);
	else
		flip2_tbfs(v2);
}
void cpick_3sat_snc()
{
	int		c = unsat_stack[rand()%unsat_stack_fill_pointer];
	int		v0,v1,v2;
	int		oi = rand() % 6;
	int		*truep0, *truep1, *truep2;
	//find 0
	// var 0
	v0 = clause_lit[c][order_3sat[oi][0]].var_num;
	truep0 = (cur_soln[v0])? var_poslit[v0]:var_neglit[v0];
	for(; sat_count[*truep0]!=1; ++truep0);
	if (*truep0 == 0) {
		flip0(v0);
		return;
	}
	// var 1
	v1 = clause_lit[c][order_3sat[oi][1]].var_num;
	truep1 = (cur_soln[v1])? var_poslit[v1]:var_neglit[v1];
	for(; sat_count[*truep1]!=1; ++truep1);
	if (*truep1 == 0) {
		flip0(v1);
		return;
	}
	// var 2
	v2 = clause_lit[c][order_3sat[oi][2]].var_num;
	truep2 = (cur_soln[v2])? var_poslit[v2]:var_neglit[v2];
	for(; sat_count[*truep2]!=1; ++truep2);
	if (*truep2 == 0) {
		flip0(v2);
		return;
	}

	//prob
	// var 0
	int	b0 = 1, b1 = 1, b2 = 1;
	for (++truep0; (*truep0)!=0; ++truep0) {
		if (sat_count[*truep0] == 1)
			++b0;
	}

	// var 1
	for (++truep1; (*truep1)!=0; ++truep1) {
		if (sat_count[*truep1] == 1)
			++b1;
	}

	// var 2
	for (++truep2; (*truep2)!=0; ++truep2) {
		if (sat_count[*truep2] == 1)
			++b2;
	}
	int	rd = rand();
	PPP3	ppp = pb3[b0][b1][b2];
	if (rd < ppp.a)
		flip2(v0);
	else if (rd < ppp.b)
		flip2(v1);
	else
		flip2(v2);
}

void cpick_new_for_org()
{
	int		c = unsat_stack[rand()%unsat_stack_fill_pointer];
	int		v0,v1,v2;
	int		oi = rand() % 6;
	int		*truep0, *truep1, *truep2;
	//find 0
	// var 0
	v0 = clause_lit[c][order_3sat[oi][0]].var_num;
	truep0 = (cur_soln[v0])? var_poslit[v0]:var_neglit[v0];
	for(; sat_count[*truep0]!=1; ++truep0);
	if (*truep0 == 0) {
		flip0(v0);
		return;
	}
	// var 1
	v1 = clause_lit[c][order_3sat[oi][1]].var_num;
	truep1 = (cur_soln[v1])? var_poslit[v1]:var_neglit[v1];
	for(; sat_count[*truep1]!=1; ++truep1);
	if (*truep1 == 0) {
		flip0(v1);
		return;
	}
	// var 2
	v2 = clause_lit[c][order_3sat[oi][2]].var_num;
	truep2 = (cur_soln[v2])? var_poslit[v2]:var_neglit[v2];
	for(; sat_count[*truep2]!=1; ++truep2);
	if (*truep2 == 0) {
		flip0(v2);
		return;
	}

	//random
	if (rand() < dwp1) {
		flip2(clause_lit[c][rand() % 3].var_num);
		return;
	}

	// the break values are at least 1
	int		c0, c1, c2;
	int		bestvar;
	int		best_bbreak = 0;
	int		bbreakv = 0;
	// var 0
	for(c0 = *(truep0++); (*truep0)!=0; ++truep0) {
		if (sat_count[*truep0]==1) ++best_bbreak;
	}
	if (best_bbreak == 0) {
		flip0(v0);
		//only c0 will be unsat
		unsat_stack[unsat_stack_fill_pointer] = c0;
		index_in_unsat_stack[c0] = unsat_stack_fill_pointer++;
		return;
	}
	bestvar = v0;
	// var 1
	for(c1 = *(truep1++); (*truep1)!=0; ++truep1) {
		if (sat_count[*truep1]==1) {
			if (bbreakv == best_bbreak - 1) break;
			++bbreakv;					
		}
	}
	if(*truep1 == 0) {// implies bbreakv < best_bbreak
		if (bbreakv == 0) {
			flip0(v1);
			//only c1 will be unsat
			unsat_stack[unsat_stack_fill_pointer] = c1;
			index_in_unsat_stack[c1] = unsat_stack_fill_pointer++;
			return;
		}
		best_bbreak = bbreakv;
		bestvar = v1;
	}
	// var 2
	bbreakv = 0;
	for(c2 = *(truep2++); (*truep2)!=0; ++truep2) {
		if (sat_count[*truep2]==1) {
			if (bbreakv == best_bbreak - 1) break;
			++bbreakv;					
		}
	}
	if(*truep2 == 0) {// implies bbreakv < best_bbreak
		if (bbreakv == 0) {
			flip0(v2);
			//only c2 will be unsat
			unsat_stack[unsat_stack_fill_pointer] = c2;
			index_in_unsat_stack[c2] = unsat_stack_fill_pointer++;
			return;
		}
		else {
			flip2(v2);
			return;
		}
	}
	flip2(bestvar);
}
void set_fun_par()
{
	double eps, kapa, wp;
	double	sss;
	int i, j, k;
	if (clause_lit_count[1] == 3) {
		if (ratio > 4.21) {
			pickandflip = cpick_3sat_rs;
			kapa = 1;
			eps = -0.08;
		}
		else if (ratio > 4.1) { // test 4.2
			// based on result in /liusixue/sc16/result0419_3sat4.2_OrgTheBest
			pickandflip = cpick_3sat_snc_tbfs4;
			kapa = 1;
			eps = -0.08;
			/*if (lsx == 15) {
				pickandflip = cpick_3sat_rs;
				kapa = 1;
				eps = -0.08;
			}
			else if (lsx == 14) {
				pickandflip = cpick_3sat_snc_tbfs4;
				kapa = 1;
				eps = -0.08;
			}
			else { // 0-13
				pickandflip = cpick_3sat_snc_tbfs4;
				//kapa = 1.05 - 0.1 + (lsx % 4) * 0.05;
				//eps = -0.1 + (lsx / 4) * 0.05;
				// 10 > 0 = 5
				kapa = 1.05 - 0.04 + (lsx % 4) * 0.02;
				eps = -0.06 + (lsx / 4) * 0.03;
			}*/
		}
		else { // for 3.7, 4.0 and any others
			//kapa = 1.1 - 0.1 + (lsx % 4) * 0.05;
			//eps = -0.1 + (lsx / 4) * 0.05;
			// for both 3.7 and 4.0, 3>7>>others
			pickandflip = cpick_3sat_snc_tbfs4;
			kapa = 1.15;
			eps = -0.1;
		}
		//MM = 4 * _t * num_clauses;
		MM = min(16 * num_clauses, MAX_STACK_SIZE - 10);
		/*if (MM > MAX_STACK_SIZE - 100) {
			cout << "Error! Please enlarge the MAX_STACK_SIZE!" << endl;
			exit(1);
		}*/

		for (i = 0; i < max_break; ++i)
			probsBreak[i + 1] = 1.0 / (pow(pow(i, kapa) + 2, 2) + eps);
		for (i = 0; i <= max_break; ++i) {
			for (j = 0; j <= max_break; ++j) {
				for (k = 0; k <= max_break; ++k) {
					sss = probsBreak[i] + probsBreak[j] + probsBreak[k];
					pb3[i][j][k].a = probsBreak[i] / sss * RAND_MAX + 1;
					pb3[i][j][k].b = (probsBreak[i] + probsBreak[j]) / sss * RAND_MAX + 1;
				}
			}
		}
	}
	else if (clause_lit_count[1] == 4) {
		pickandflip = cpick_4sat_c_tbfs4;
		//MM = 36 * num_clauses;
		MM = min(36 * num_clauses, MAX_STACK_SIZE - 100);
		/*if (MM > MAX_STACK_SIZE - 1000) {
			cout << "Error! Please enlarge the MAX_STACK_SIZE!" << endl;
			exit(1);
		}*/

		if (ratio > 9.71) {
			kapa = 2;
			eps = 0.06; // for threshold
		}
		else if (ratio < 8.85) {
			kapa = 2.1;
			eps = -0.1;
		}
		else {
			kapa = 2.0;
			eps = -0.1;
		}


		/*
			if (lsx == 17) {
				pickandflip = cpick_4sat_c_tbfs4;
				kapa = 2;
				eps = 0.06; // for threshold
			}
			else {
				pickandflip = cpick_4sat_c_tbfs4;
				kapa = 2 - 0.2 + (lsx % 4) * 0.1;
				eps = -0.1 + (lsx / 4) * 0.05;
			}
		}*/
		for (i = 0; i < max_break; ++i)
			probsBreak[i + 1] = 1.0 / (pow(pow(i, kapa) + 2, 2) + eps);
	}
	else if (clause_lit_count[1] == 5) {
		pickandflip = cpick_5sat_c;
		
		if (ratio > 20.5) {
			kapa = 2.5;
			//eps = 0.03 - 0.7 + lsx * 0.1;
			eps = -0.17;
		}
		else if (ratio < 18) {
			kapa = 2.5;
			eps = -1.1;
		}
		else {
			//based on results in result0420_5sat/
			kapa = 2.3;
			//eps = -0.3 + lsx * 0.05;
			eps = -0.2;
		}
		for (i = 0; i < max_break; ++i)
			probsBreak[i + 1] = 1.0 / (pow(pow(i, kapa) + 2, 2) + eps);
	}
	else if (clause_lit_count[1] == 6) {
		pickandflip = cpick_6sat;
		
		if (ratio > 40.18) {
			kapa = 3;
			eps = 0.2;
		}
		else if (ratio < 34) {
			kapa = 3.2;
			eps = -0.4;
		}
		else {
			kapa = 3.2;
			eps = -0.2;
		}
		/*double kapa = 3.0;
		if (lsx == 0)
			//eps = 0.08 - 0.7 + 0.1 * lsx;
			eps = -0.22;
		else if (lsx == 1) {
			kapa = 3;
			eps = 1;
		}
		else {
			kapa = 3;
			eps = 0.4 - 0.05 * lsx;
		}*/
		for (i = 0; i < max_break; ++i)
			probsBreak[i + 1] = 1.0 / (pow(pow(i, kapa) + 2, 2) + eps);
	}
	else if (clause_lit_count[1] == 7) {
		pickandflip = cpick_7sat;
		//eps = 0.35 - 0.06 + 0.02 * lsx;
		/*if (lsx == 0) {
			kapa = 3.5;
			eps = 0.35;
		}
		else { // 1 - 15
			kapa = 3;
			// previous 0.1 * 4 is the best
			eps = 0.4;
			//eps = 0.05 * lsx;
		}
		for (i = 0; i < max_break; ++i)
			probsBreak[i + 1] = 1.0 / (pow(pow(i, kapa) + 2, 2) + eps);
		*/
		if (ratio > 80.4) {
			kapa = 3.5;
			eps =  0.35;
		}
		else if (ratio < 66.5) {
			kapa = 3.5;
			eps = -1.8;
		}
		else {
			/*if (lsx == 17) {
				kapa = 3.5;
				eps = 0.35;
			}
			else if (lsx == 16) {
				kapa = 3;
				eps = 0.4;
			}
			else {
				kapa = 3.5;
				eps = -0.9 + 0.3 * lsx;
			}*/
			kapa = 3.5;
			//eps = - 0.3 * lsx;
			eps = -1.5;
		}
		for (i = 0; i < max_break; ++i)
			probsBreak[i + 1] = 1.0 / (pow(pow(i, kapa) + 2, 2) + eps);
	}
	/*cout << "variables number:\t" << num_vars << endl;
	cout << "clauses number:\t" << num_clauses << endl;
	cout << "ratio:\t" << ratio << endl;
	cout << "kapa:\t" << kapa << endl;
	cout << "eps:\t" << eps << endl;
	cout << "MM:\t" << MM << endl;
	cout << "cutoff time:\t" << lsx_cutoff_time << endl;*/
}

int main(int argc, char* argv[])
{
	int     seed = time(0), i; 
	//double	comp_time;	
	
	//times(&start);

	if (build_instance(argv[1])==0) return -1;
	
	//if (argc > 2)	
	//	sscanf(argv[2],"%d",&lsx_cutoff_time);
	if (argc > 2)	
		sscanf(argv[3],"%d",&seed);
	//if (argc > 4)	
	//	sscanf(argv[4],"%d",&lsx);
    	//cout << "seed:\t" << seed << endl;
	srand(seed);

	set_fun_par();

	init();
	while(1) {
		pickandflip();
		if (unsat_stack_fill_pointer == 0) { //solution found!
			cout<<"s SATISFIABLE"<<endl;
			print_solution();
			
			free_memory();
			return 0;
		}
	}	
}
