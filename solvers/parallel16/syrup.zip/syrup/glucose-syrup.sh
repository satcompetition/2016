#!/bin/sh

    ./bin/glucose-syrup -nthreads=24 -model -maxmemory=50000 $1
