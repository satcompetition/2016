#!/bin/sh

export MROOT=$PWD


make -C core clean 
make -C simp clean 
 
rm ParaGlueminisat
