/*****************************************************************************************[Main.cc]
Copyright (c) 2003-2006, Niklas Een, Niklas Sorensson
Copyright (c) 2007,      Niklas Sorensson

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and
associated documentation files (the "Software"), to deal in the Software without restriction,
including without limitation the rights to use, copy, modify, merge, publish, distribute,
sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or
substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT
OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
**************************************************************************************************/
#include <omp.h>
#include <errno.h>

#include <signal.h>
#include <zlib.h>
#include <sys/resource.h>
#include <sys/time.h>

#include "utils/System.h"
#include "utils/ParseUtils.h"
#include "utils/Options.h"
#include "core/Dimacs.h"
#include "simp/SimpSolver.h"

#include <iostream>
#include <fstream>
#include <string>
#include <sstream>

using namespace Glueminisat;

void printStats(Solver& solver)
{
    double cpu_time = cpuTime();
    double mem_used = memUsedPeak();
    printf("c  ----------------------------------------         \n");
    printf("c   winner:  more statistics           \n");
    printf("c  ----------------------------------------         \n");
    printf("c  restarts              : %"PRIu64"\n", solver.starts);
    printf("c  conflicts             : %-12"PRIu64"   (%.0f /sec)\n", solver.conflicts   , solver.conflicts   /cpu_time);
    printf("c  decisions             : %-12"PRIu64"   (%4.2f %% random) (%.0f /sec)\n", solver.decisions, (float)solver.rnd_decisions*100 / (float)solver.decisions, solver.decisions   /cpu_time);
    printf("c  propagations          : %-12"PRIu64"   (%.0f /sec)\n", solver.propagations, solver.propagations/cpu_time);
    printf("c  conflict literals     : %-12"PRIu64"   (%4.2f %% deleted)\n", solver.tot_literals, (solver.max_literals - solver.tot_literals)*100 / (double)solver.max_literals);
    if (mem_used != 0) printf("c  Memory used           : %.2f MB\n", mem_used);
    printf("c  CPU time              : %g s\n", cpu_time);
}

//=================================================================================================


// modified by nabesima
//void printStats(Solver& solver)
//{
//    double cpu_time = cpuTime();
//    double mem_used = memUsedPeak();
//    printf("restarts              : %"PRIu64"\n", solver.starts);
//    printf("conflicts             : %-12"PRIu64"   (%.0f /sec)\n", solver.conflicts   , solver.conflicts   /cpu_time);
//    printf("decisions             : %-12"PRIu64"   (%4.2f %% random) (%.0f /sec)\n", solver.decisions, (float)solver.rnd_decisions*100 / (float)solver.decisions, solver.decisions   /cpu_time);
//    printf("propagations          : %-12"PRIu64"   (%.0f /sec)\n", solver.propagations, solver.propagations/cpu_time);
//    printf("conflict literals     : %-12"PRIu64"   (%4.2f %% deleted)\n", solver.tot_literals, (solver.max_literals - solver.tot_literals)*100 / (double)solver.max_literals);
//    if (mem_used != 0) printf("Memory used           : %.2f MB\n", mem_used);
//    printf("CPU time              : %g s\n", cpu_time);
//}

static Cooperation* cooperation;
int nbThreads;
int winner;
int use_minisat_param;
// Terminate by notifying the solver and back out gracefully. This is mainly to have a test-case
// for this feature of the Solver as it may take longer than an immediate call to '_exit()'.
static void SIGINT_interrupt(int signum) { 
	printf("s UNKNOWN\n");
	for(int t = 0; t < nbThreads; t++){
	  cooperation->solvers[t].interrupt();
	}
}

// Note that '_exit()' rather than 'exit()' has to be used. The reason is that 'exit()' calls
// destructors and may cause deadlocks if a malloc/free function happens to be running (these
// functions are guarded by locks for multithreaded use).
static void SIGINT_exit(int signum) {
    printf("c\n"); printf("s UNKNOWN *** INTERRUPTED (%d) ***\n", signum);

	for(int t = 0; t < nbThreads; t++){
	  if(cooperation->solvers[t].verbosity > 0) 
		printf("c *** INTERRUPTED (%d) ***\n", signum);
	}
	_exit(1);}

//    if (solver->verbosity > 0){
 //       solver->printStats();
//        printf("c\n"); printf("c *** INTERRUPTED (%d) ***\n", signum); }
//    _exit(1); }


double processRealTime(double initTime) {
	double endTime = omp_get_wtime();
	return endTime - initTime;

//	struct rusage u;
//	double res;
//	if(getrusage(RUSAGE_SELF, &u)) return 0;
//	res = u.ru_utime.tv_sec + 1e-6 * u.ru_utime.tv_usec;
//	res += u.ru_stime.tv_sec + 1e-6 * u.ru_stime.tv_usec;
//	res = u.ru_rtime.tv_sec + 1e-6 * u.ru_rtime.tv_usec;
//	return res;
}

#define TR	3600
#define NTR	30
#define M	100
#define CHB_LIM 15000
//=================================================================================================
// Main:

int main(int argc, char** argv)
{
    try {
	clock_t clock_all, clock_Import = 0, clock_Export = 0;
	int64_t comm_cnt_all = 0;
	clock_all = clock();

        setUsageHelp("USAGE: %s [options] <input-file> <result-output-file>\n\n  where input may be either in plain or gzipped DIMACS.\n");
        // printf("This is MiniSat 2.0 beta\n");

#if defined(__linux__)
        fpu_control_t oldcw, newcw;
        _FPU_GETCW(oldcw); newcw = (oldcw & ~_FPU_EXTENDED) | _FPU_DOUBLE; _FPU_SETCW(newcw);
//        printf("c WARNING: for repeatability, setting FPU to use double precision\n");
#endif
        // Extra options:
        //
        IntOption    verb   ("MAIN", "verb",   "Verbosity level (0=silent, 1=some, 2=more).", 1, IntRange(0, 2));
        BoolOption   pre    ("MAIN", "pre",    "Completely turn on/off any preprocessing.", true);
        StringOption dimacs ("MAIN", "dimacs", "If given, stop after preprocessing and write the result to this file.");
       	IntOption    cpu_lim("MAIN", "cpu-lim","Limit on CPU time allowed in seconds.\n", INT32_MAX, IntRange(0, INT32_MAX));
		IntOption    mem_lim("MAIN", "mem-lim","Limit on memory usage in megabytes.\n", INT32_MAX, IntRange(0, INT32_MAX));

		IntOption    ncores ("MAIN", "ncores","# threads.\n", 4, IntRange(1, 1000)); // omp_get_num_procs()));
		IntOption    limitEx("MAIN", "limitEx","Limit size clause exchange.\n", 10, IntRange(0, INT32_MAX));
        IntOption    det    ("MAIN", "det","determenistic mode (0=non deterministic, 1=deterministic static, 2=deterministic dynamic.\n", 0, IntRange(0, 2));
		IntOption    ctrl   ("MAIN", "ctrl","Dynamic control clause sharing with 2 modes.\n", 0, IntRange(0, 2));
	
		if (argc < 2) 
            fprintf(stderr, "c ERROR! allocate <input-file>\n"), exit(1);

		nbThreads = 24;	
//		nbThreads = atoi(argv[2]);

//		if(nbThreads > omp_get_num_procs() * 5) 
//			fprintf(stderr, "c ERROR! allocated core number exceeded the number of (5 * physical cores)\n"), exit(1);
	
        parseOptions(argc, argv, true);

	double initial_time = cpuTime();
	double start_time = omp_get_wtime();

//	bool use_recursive = (nbThreads >= 32)? true : false; 
	bool use_recursive = false;
		
//	nbThreads   = ncores;
	int limitExport = limitEx;	
	Cooperation coop(nbThreads, limitExport);
	cooperation = &coop;
	
	coop.ctrl = ctrl;
	coop.deterministic_mode = det;

	int tr[NTR];
	if(use_recursive) {
		for(int i = 2; i < NTR + 2; i++) {
			tr[i - 2] = (TR - i * M) / i;
		}
	}  
	
	int p = nbThreads / 4;
	int q = p % NTR;
	int idx = 1;
	for(int t = 0; t < nbThreads; t++){
		int q1 = t % 4;
		
		if(use_recursive) {
			if(q1 == 2 || q1 == 3) {
				int idx1;
				if(idx <= q) {
					idx1 = ((NTR - 1) * idx) / (q + 1);
//					printf("t: %d, idx1: %d, tr: %d\n",t, idx1, tr[idx1]);
				}
				else {
					idx1 = idx % NTR;
//					printf("t: %d, idx11: %d\n",t, idx1, tr[idx1]);
				}
				coop.solvers[t].timeLimitRecursive = tr[idx1];
//				coop.solvers[t].timeLimitRecursive = 1;
				if(q1 == 3) idx++;
			}
			else coop.solvers[t].timeLimitRecursive = -1;
//			else coop.solvers[t].timeLimitRecursive = 1;
//			printf("time %d: %d\n", t, coop.solvers[t].timeLimitRecursive);
		}
		else coop.solvers[t].timeLimitRecursive = -1; 
//	coop.solvers[t].timeLimitRecursive = t * 1 + 10;
	
		coop.solvers[t].startTime = omp_get_wtime();
		coop.solvers[t].threadId = t;
		coop.solvers[t].verbosity = verb;
		coop.solvers[t].deterministic_mode = det;
		
		coop.solvers[t].directionChangeInterval = coop.directionChangeInterval;
	}

	
        // Use signal handlers that forcibly quit until the solver will be able to respond to
        // interrupts:
        signal(SIGINT, SIGINT_exit);
        signal(SIGXCPU,SIGINT_exit);

        // Set limit on CPU-time:
        if (cpu_lim != INT32_MAX){
            rlimit rl;
            getrlimit(RLIMIT_CPU, &rl);
            if (rl.rlim_max == RLIM_INFINITY || (rlim_t)cpu_lim < rl.rlim_max){
                rl.rlim_cur = cpu_lim;
                if (setrlimit(RLIMIT_CPU, &rl) == -1)
                    printf("c WARNING! Could not set resource limit: CPU-time.\n");
            } }

        // Set limit on virtual memory:
        if (mem_lim != INT32_MAX){
            rlim_t new_mem_lim = (rlim_t)mem_lim * 1024*1024;
            rlimit rl;
            getrlimit(RLIMIT_AS, &rl);
            if (rl.rlim_max == RLIM_INFINITY || new_mem_lim < rl.rlim_max){
                rl.rlim_cur = new_mem_lim;
            } }
        
        
        gzFile in = (argc == 1) ? gzdopen(0, "rb") : gzopen(argv[1], "rb");
        if (in == NULL)
            fprintf(stderr, "ERROR! Could not open file: %s\n", argc == 1 ? "<stdin>" : argv[1]), exit(1);
	

		// Change to signal-handlers that will only notify the solver and allow it to terminate
        // voluntarily:
        signal(SIGINT, SIGINT_interrupt);
        signal(SIGXCPU,SIGINT_interrupt);
	
		winner = -1;
	use_minisat_param = -1;
	lbool ret;
	lbool result = l_Undef;

//	parse_DIMACS_Parallel(in, &coop);
//	gzclose(in);

// launch threads in Parallel 	
omp_set_num_threads(nbThreads);
#pragma omp parallel
{
		int t = omp_get_thread_num();
		gzFile in[t];
        vec<Lit> dummy;
	  	coop.start = true;

		in[t] = (argc == 1) ? gzdopen(0, "rb") : gzopen(argv[1], "rb");
		parse_DIMACS(in[t], coop.solvers[t]);
		gzclose(in[t]);
	
//		#pragma omp barrier
//		if(t == 0) coop.setDimension(coop.solvers[t].nVars());
		#pragma omp barrier

		int nVar = coop.solvers[t].nVars();
		if(nVar > CHB_LIM) coop.solvers[t].chb = 0;


		while(1) {
			if(coop.interrupt) break;
			ret = coop.solvers[t].solveLimited(&coop, dummy);
			if(ret == l_True || ret == l_False) coop.answers[t] = ret;
	
		  	if(toInt(ret) == toInt(l_Recur)) {

				coop.resetSolver(t);
				coop.solvers[t].reset();

				in[t] = (argc == 1) ? gzdopen(0, "rb") : gzopen(argv[1], "rb");
				parse_DIMACS(in[t], coop.solvers[t]);
				gzclose(in[t]);
		  	}
		  	else break;
	  	} 
	}
	
	// select winner threads with respect to deterministic mode 
	for(int t = 0; t < coop.nThreads(); t++){ 
//	printf("c %d: %d\n", t, coop.answer(t));
	  if(coop.answer(t) != l_Undef && winner == -1){ 
	    winner = t;
		use_minisat_param = coop.solvers[t].use_minisat_param;
	    result = coop.answer(t);
//	    break;
	  }
	  clock_Import += coop.solvers[t].tImport;
	  clock_Export += coop.solvers[t].tExport;
	  comm_cnt_all += coop.solvers[t].commCnt;
	}
	
	bool correctAnswer = true;
	if(winner != -1) {
		coop.printStats(coop.solvers[winner].threadId);
		printStats(coop.solvers[winner]);
		
		if (coop.solvers[winner].verbosity > 0){
		  //printStats(coop.solvers[winner]);
				printf("\n"); }
		printf(result == l_True ? "s SATISFIABLE\n" : result == l_False ? "s UNSATISFIABLE\n" : "s UNKNOWN\n");
		if (result == l_True){
		  printf("v ");
				in = (argc == 1) ? gzdopen(0, "rb") : gzopen(argv[1], "rb");
//				printf("winner: %d\n", winner);
//				if(!check_DIMACS(in, coop.solvers[winner])) {
//					fprintf(stderr, "wrong answer!"); correctAnswer = false;
//				}
				gzclose(in);

				for (int i = 0; i < coop.solvers[winner].nVars(); i++)
					if(coop.solvers[winner].model[coop.solvers[winner].shuffleTable[i]] != l_Undef)
						printf("%s%s%d", (i==0)?"":" ", (coop.solvers[winner].model[coop.solvers[winner].shuffleTable[i]]==l_True)?"":"-", i+1);
				printf(" 0\n");
		} 
	}


#ifdef NDEBUG
		int finalResult = result == l_True ? 10 : result == l_False ? 20 : 0;
        exit(finalResult);     // (faster than "return", which will invoke the destructor for 'Solver')
#else
		int finalResult = result == l_True ? 10 : result == l_False ? 20 : 0;
        return (finalResult);
#endif
    } catch (OutOfMemoryException&){
        printf("c ===============================================================================\n");
        printf("s UNKNOWN\n");
        exit(0);
    }
}
