 
#!/bin/sh

#$1 Type de machine : CLUSTER || PC
#$2 Type de solveur : GLUCOSE_MINISAT || GLUCOSE || MINISAT
#$3 Mode de fonctionnement : CONCURENTS || SCOUTS
#$4 Nom du dossier de LOG contenue dans le dossier "Log" 
#$5 Chemin relatif de la CNF
#$6 H_POL
#$7 TREE_HEIGHT
#$8 TYPE_COM : type des communications
#$9 NB_CONFLICT_SCOUT
#$10 NB_CONFLICT_WORKERS
#$11 TYPE_EXTEND_WORKER 
#$12 TYPE_EXTEND_SCOUT

#TYPE_EXTEND_WORKER : DIRECTIVE FOR THE WORKERS EXPAND
# -1 : NO_DIRECTIVE
# 0 : NO_EXPAND (Workers takle a cube for infinity conflict (until UNSAT))
# 1 ... n : if (nb_cubes < n) NB_CONFLICT_WORKERS else 0 (0 to infinity)  

#TYPE_EXTEND_SCOUT : DIRECTIVE FOR THE SCOUT EXPAND
# -1 : NO_DIRECTIVE
# 1 ... n : if (nb_cubes < n) EXTEND else NO_EXTEND  


#H_POL : 0 : P
#H_POL : 1 : R
#H_POL : 2 : 0
#H_POL : 3 : 1
#H_POL : 4 : PU
#H_POL : 5 : PR
#H_POL : 6 : ALL
#H_POL : 7 : nb_cubes and nb_workers for each node


CNF="$PWD/$5"
RACINE="$PWD/.."

if [ "$1" = "PC" ]; then
    HOST=""
    HOST_MASTERMIND=""
    HOST_MASTERS=""
    HOST_WORKER_GLUCOSE1=""
    HOST_WORKER_GLUCOSE2=""
    NB_WORKERS="6"
    NB_WORKER_MINISAT_1="1"
    NB_WORKER_MINISAT_2="1"
    NB_WORKER_GLUCOSE_1="1"
    NB_WORKER_GLUCOSE_2="1"
    NB_WORKER_MINISAT_PSM_1="1"
    NB_WORKER_MINISAT_PSM_2="1"
elif [ "$1" = "CLUSTER" ]; then

    HOST="--map-by core"
    HOST3="--map-by node:pe=32 --oversubscribe --bind-to core"
    HOST2="--map-by node:pe=1 --oversubscribe --bind-to core"
   
    HOST_NODE_200="--host node200"
    HOST_NODE_201="--host node201"
    NB_WORKERS="126"
    NB_WORKER_MINISAT_32_1="11"
    NB_WORKER_MINISAT_32_2="11"
    NB_WORKER_GLUCOSE_32_1="11"
    NB_WORKER_GLUCOSE_32_2="11"
    NB_WORKER_MINISATPSM_32_1="9"
    NB_WORKER_MINISATPSM_32_2="9"
    NB_WORKER_8="8"
    
else
    echo "Paramétre 1 : PC || CLUSTER"
    exit
fi


if [ "$3" = "CONCURENTS" ]; then
    MODE=0
    RND_INIT="-rnd-init"
    H_POL=""
    TREE_HEIGHT=""
    MPI_SCOUT_1=""
    MPI_SCOUT_2=""
    MPI_SCOUT_3="" 
    NB_SCOUTS="0"
elif [ "$3" = "SCOUTS" ]; then
    MODE=1
    RND_INIT="-rnd-init"
    H_POL="-hpol=$6"
    TREE_HEIGHT="-tree=$7"
    TYPE_COM="-type_com=$8"
    TYPE_EXTEND="-type_extend=${11}"
    TYPE_EXTEND_SCOUT="-type_extend=${12}"
    OPT_EXP=""
    MPI_SCOUT_1=": -np 1 $HOST_NODE_201 $RACINE/Scouts/minisatScout1/Worker/SMinisat1 $CNF -type=1 $TYPE_EXTEND_SCOUT $TREE_HEIGHT $OPT_EXP $RND_INIT -verb=0"
    MPI_SCOUT_2=": -np 1 $HOST_NODE_201 $RACINE/Scouts/minisatScout1/Worker/SMinisat1 $CNF -type=1 $TYPE_EXTEND_SCOUT $TREE_HEIGHT $RND_INIT -verb=0"
    MPI_SCOUT_3=": -np 1 $HOST_NODE_201 $RACINE/Scouts/minisatScout1/Worker/SMinisat1 $CNF -type=1 $TYPE_EXTEND_SCOUT $TREE_HEIGHT $RND_INIT -verb=0"
    NB_SCOUTS="1"
else
    echo "Paramétre 3 : CONCURENTS || SCOUTS"
    exit
fi

PROG_GLUCOSE="$RACINE/Workers/glucose-syrup-adapt/syrup/Worker/WGlucoseSyrup"
PROG_MINISAT="$RACINE/Workers/minisat/Worker/WMinisat"
PROG_MINISATPSM="$RACINE/Workers/minisatPsmDyn/Worker/WMinisatPsmDyn"
PROG_OPT="$CNF $H_POL $TYPE_EXTEND $TYPE_COM $RND_INIT -verb=0"

MPI_MASTER="-np 1 $HOST_NODE_200 $RACINE/Master/master $MODE $NB_WORKERS $NB_SCOUTS $9 ${10}"

MPI_WORKER_GLUCOSE_32_1=": -np $NB_WORKER_GLUCOSE_32_1 $HOST_NODE_200 $PROG_GLUCOSE  $PROG_OPT -type=1"
MPI_WORKER_GLUCOSE_32_2=": -np $NB_WORKER_GLUCOSE_32_2 $HOST_NODE_201 $PROG_GLUCOSE $PROG_OPT -type=1"

MPI_WORKER_MINISAT_32_1=": -np $NB_WORKER_MINISAT_32_1 $HOST_NODE_200 $PROG_MINISAT $PROG_OPT -type=2"
MPI_WORKER_MINISAT_32_2=": -np $NB_WORKER_MINISAT_32_2 $HOST_NODE_201 $PROG_MINISAT $PROG_OPT -type=2"

MPI_WORKER_MINISATPSM_32_1=": -np $NB_WORKER_MINISATPSM_32_1 $HOST_NODE_200 $PROG_MINISATPSM $PROG_OPT -type=3"
MPI_WORKER_MINISATPSM_32_2=": -np $NB_WORKER_MINISATPSM_32_2 $HOST_NODE_201 $PROG_MINISATPSM $PROG_OPT -type=3"

MPI_WORKER_32="$MPI_WORKER_GLUCOSE_32_1 $MPI_WORKER_GLUCOSE_32_2 $MPI_WORKER_MINISAT_32_1 $MPI_WORKER_MINISAT_32_2 $MPI_WORKER_MINISATPSM_32_1 $MPI_WORKER_MINISATPSM_32_2"

MPI_WORKER_GLUCOSE_8_1=": -np 8 --host node143 $PROG_GLUCOSE  $PROG_OPT -type=1"
MPI_WORKER_GLUCOSE_8_2=": -np 8 --host node144 $PROG_GLUCOSE  $PROG_OPT -type=1"
MPI_WORKER_GLUCOSE_8_3=": -np 8 --host node145 $PROG_GLUCOSE  $PROG_OPT -type=1"

MPI_WORKER_MINISAT_8_1=": -np 8 --host node146 $PROG_MINISAT $PROG_OPT -type=2"
MPI_WORKER_MINISAT_8_2=": -np 8 --host node147 $PROG_MINISAT $PROG_OPT -type=2"
MPI_WORKER_MINISAT_8_3=": -np 8 --host node148 $PROG_MINISAT $PROG_OPT -type=2"

MPI_WORKER_MINISATPSM_8_1=": -np 8 --host node149 $PROG_MINISATPSM $PROG_OPT -type=3"
MPI_WORKER_MINISATPSM_8_2=": -np 8 --host node150 $PROG_MINISATPSM $PROG_OPT -type=3"

MPI_WORKER_GLUCOSE_8="$MPI_WORKER_GLUCOSE_8_1 $MPI_WORKER_GLUCOSE_8_2 $MPI_WORKER_GLUCOSE_8_3"
MPI_WORKER_MINISAT_8="$MPI_WORKER_MINISAT_8_1 $MPI_WORKER_MINISAT_8_2 $MPI_WORKER_MINISAT_8_3"
MPI_WORKER_MINISATPSM_8="$MPI_WORKER_MINISATPSM_8_1 $MPI_WORKER_MINISATPSM_8_2"

#MPI_WORKER_8="$MPI_WORKER_GLUCOSE_8_1"
MPI_WORKER_8="$MPI_WORKER_GLUCOSE_8 $MPI_WORKER_MINISAT_8 $MPI_WORKER_MINISATPSM_8"

if [ "$2" = "GLUCOSE" ]; then
    echo "NO WORK"
    exit
elif [ "$2" = "MINISAT" ]; then
   echo "NO WORK"
     exit
elif [ "$2" = "GLUCOSE_MINISAT" ]; then
    echo "NO WORK"
     exit
elif [ "$2" = "MINISATPSM" ]; then
     echo "NO WORK"
     exit
elif [ "$2" = "GLUCOSE_MINISAT_MINISATPSM" ]; then

    PROG="$MPI_MASTER $MPI_WORKER_32 $MPI_WORKER_8 $MPI_SCOUT_1"
else
    echo "Paramétre 3 : GLUCOSE || MINISAT || GLUCOSE_MINISAT || GLUCOSE_MINISAT_MINISATPSM"
    exit
fi

echo $PROG
MPIRUN="time -p /usr/local/bin/mpirun $HOST --report-bindings --display-allocation "
#CLUSTER="shortparallele8 -l nodes=5:ppn=8 -l cput=40:00:00 -l walltime=80:00:00"
#CLUSTER="parallelempi-2 -l nodes=node201:ppn=32+node200:ppn=32+node143:ppn=8 -l walltime=00:20:00"
CLUSTER="parallelempi-2 -l nodes=node201:ppn=32+node200:ppn=32+node143:ppn=8+node144:ppn=8+node145:ppn=8+node146:ppn=8+node147:ppn=8+node148:ppn=8+node149:ppn=8+node150:ppn=8 -l walltime=00:20:00"
LOG="$RACINE/Log/$4/$(basename $5 | sed 's/.cnf//g')"


if [ "$1" = "PC" ]; then
    echo "[PC]CNF: $(basename $5 | sed 's/.cnf//g').cnf"
    echo "[PC]PATH CNF: $CNF"
    echo "[PC]MPI: $MPIRUN"
    $MPIRUN $PROG
    echo
elif [ "$1" = "CLUSTER" ]; then
    echo "[CLUSTER]CNF: $(basename $5 | sed 's/.cnf//g').cnf"
    echo "[CLUSTER]PATH CNF: $CNF"
    echo "[CLUSTER]LOG: $LOG.log"
    echo "[CLUSTER]CONFIG: $CLUSTER"
    echo "[CLUSTER]MPI: $MPIRUN"
    qadd -e "$LOG.err" -o "$LOG.log" -q $CLUSTER -- $MPIRUN $PROG
    echo
fi
