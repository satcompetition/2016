#!/bin/sh

#$1 Lancement sur le CLUSTER ou un PC
#$2 NORMAL FULLGLUCOSE FULLPENELOPE UNIQUEGLUCOSE
#$3 Mode de fonctionnement CONCURENTS CUBES

#$4 Nom du dossier de LOG contenue dans le dossier "Log" 
#$5 Chemin relatif de la CNF

CONFLICT="0 0"

if [ "$3" = "CONCURENTS" ]; then
    MODE=0
    RND_INIT="-rnd-init"
elif [ "$3" = "CUBES" ]; then
    MODE=1
    RND_INIT=""
else
    echo "Paramétre 3 : CONCURENTS || CUBES"
    exit
fi


if [ "$2" = "NORMAL" ]; then
    NB_MASTERS=3
elif [ "$2" = "FULLGLUCOSE" ]; then
    NB_MASTERS=1
elif [ "$2" = "FULLMINISAT" ]; then
    NB_MASTERS=1
elif [ "$2" = "FULLPENELOPE" ]; then
    NB_MASTERS=1
elif [ "$2" = "UNIQUEGLUCOSE" ]; then
    NB_MASTERS=1
else
    echo "Paramétre 2 : NORMAL || FULLGLUCOSE || FULLPENELOPE || UNIQUEGLUCOSE"
    exit
fi
NB_SCOUTCUBES=1
NB_TYPES=3

CNF="$PWD/$5"
RACINE="$PWD/.."


if [ "$1" = "PC" ]; then
    HOST=""
    HOST_MASTERMIND=""
    HOST_MASTERS=""
    HOST_WORKER_GLUCOSE1=""
    HOST_WORKER_PENELOPE1=""
    HOST_WORKER_PENELOPE2=""
    HOST_WORKER_PENELOPE3=""
elif [ "$1" = "CLUSTER" ]; then
    HOST="--hostfile $RACINE/hostfile --map-by node:pe=8 --oversubscribe --bind-to core"

    HOST_MASTERMIND="--host node106"
    HOST_MASTERS="--host node106"

    HOST_WORKER_GLUCOSE1="--host node102"
    HOST_WORKER_GLUCOSE2="--host node103"
    HOST_WORKER_GLUCOSE3="--host node104"
    HOST_WORKER_GLUCOSE4="--host node105"

   HOST_WORKER_GLUCOSE5="--host node107"
    HOST_WORKER_GLUCOSE6="--host node108"
    HOST_WORKER_GLUCOSE7="--host node109"
    HOST_WORKER_GLUCOSE8="--host node111"
    HOST_WORKER_GLUCOSE9="--host node112"

    HOST_WORKER_PENELOPE1="--host node102"
    HOST_WORKER_PENELOPE2="--host node103"
    HOST_WORKER_PENELOPE3="--host node104"
    HOST_WORKER_PENELOPE4="--host node105"
else
    echo "Paramétre 1 : PC || CLUSTER"
    exit
fi


MPI_MASTERMIND="-np 1 $HOST_MASTERMIND $RACINE/MasterMind/MasterMind $MODE $NB_MASTERS 32 $NB_TYPES $NB_SCOUTCUBES"
MPI_MASTERS="-np $NB_MASTERS $HOST_MASTERS $RACINE/Masters/Master $NB_MASTERS 32 $NB_SCOUTCUBES $CONFLICT"

MPI_SCOUTCUBES1="-np $NB_SCOUTCUBES $HOST_MASTERS $RACINE/ScoutCubes/march_cc/march_cc $CNF"

#MPI_WORKER_UNIQUE_GLUCOSE="-np 1 $HOST_WORKER_GLUCOSE1 $RACINE/Workers/glucose/Worker/WGlucose $CNF"
MPI_WORKER_UNIQUE_GLUCOSE="-np 1 $HOST_WORKER_GLUCOSE1 $RACINE/Workers/glucose/Worker/WGlucose $CNF -nbMasters=$NB_MASTERS -type=0 $RND_INIT -verb=0"

MPI_WORKER_GLUCOSE1="-np 8 $HOST_WORKER_GLUCOSE1 $RACINE/Workers/glucose/Worker/WGlucose $CNF -nbMasters=$NB_MASTERS -type=0 $RND_INIT -verb=0"
MPI_WORKER_GLUCOSE2="-np 8 $HOST_WORKER_GLUCOSE2 $RACINE/Workers/glucose/Worker/WGlucose $CNF -nbMasters=$NB_MASTERS -type=0 $RND_INIT -verb=0"
MPI_WORKER_GLUCOSE3="-np 8 $HOST_WORKER_GLUCOSE3 $RACINE/Workers/glucose/Worker/WGlucose $CNF -nbMasters=$NB_MASTERS -type=0 $RND_INIT -verb=0"
MPI_WORKER_GLUCOSE4="-np 8 $HOST_WORKER_GLUCOSE4 $RACINE/Workers/glucose/Worker/WGlucose $CNF -nbMasters=$NB_MASTERS -type=0 $RND_INIT -verb=0"
MPI_WORKER_GLUCOSE5="-np 8 $HOST_WORKER_GLUCOSE5 $RACINE/Workers/glucose/Worker/WGlucose $CNF -nbMasters=$NB_MASTERS -type=0 $RND_INIT -verb=0"
MPI_WORKER_GLUCOSE6="-np 8 $HOST_WORKER_GLUCOSE6 $RACINE/Workers/glucose/Worker/WGlucose $CNF -nbMasters=$NB_MASTERS -type=0 $RND_INIT -verb=0"
MPI_WORKER_GLUCOSE7="-np 8 $HOST_WORKER_GLUCOSE7 $RACINE/Workers/glucose/Worker/WGlucose $CNF -nbMasters=$NB_MASTERS -type=0 $RND_INIT -verb=0"
MPI_WORKER_GLUCOSE8="-np 8 $HOST_WORKER_GLUCOSE8 $RACINE/Workers/glucose/Worker/WGlucose $CNF -nbMasters=$NB_MASTERS -type=0 $RND_INIT -verb=0"
MPI_WORKER_GLUCOSE9="-np 8 $HOST_WORKER_GLUCOSE9 $RACINE/Workers/glucose/Worker/WGlucose $CNF -nbMasters=$NB_MASTERS -type=0 $RND_INIT -verb=0"


export OMP_NUM_THREADS=8
CONFIGFILE="$RACINE/Workers/penelope/configuration.ini"
MPI_WORKER_PENELOPE1="-np 1 $HOST_WORKER_PENELOPE1 $RACINE/Workers/penelope/penelope $CNF -config=$CONFIGFILE -nbMasters=$NB_MASTERS -type=1 -verb=0"
MPI_WORKER_PENELOPE2="-np 1 $HOST_WORKER_PENELOPE2 $RACINE/Workers/penelope/penelope $CNF -config=$CONFIGFILE -nbMasters=$NB_MASTERS -type=1 -verb=0"
MPI_WORKER_PENELOPE3="-np 1 $HOST_WORKER_PENELOPE3 $RACINE/Workers/penelope/penelope $CNF -config=$CONFIGFILE -nbMasters=$NB_MASTERS -type=1 -verb=0"
MPI_WORKER_PENELOPE4="-np 1 $HOST_WORKER_PENELOPE3 $RACINE/Workers/penelope/penelope $CNF -config=$CONFIGFILE -nbMasters=$NB_MASTERS -type=1 -verb=0"


if [ "$2" = "NORMAL" ]; then
    PROG="$MPI_MASTERMIND : $MPI_MASTERS : $MPI_SCOUTCUBES1 : $MPI_WORKER_GLUCOSE1 : $MPI_WORKER_PENELOPE2 : $MPI_WORKER_PENELOPE3 : $MPI_WORKER_PENELOPE4"
elif [ "$2" = "FULLGLUCOSE" ]; then
    PROG="$MPI_MASTERMIND : $MPI_MASTERS : $MPI_SCOUTCUBES1 : $MPI_WORKER_GLUCOSE1 : $MPI_WORKER_GLUCOSE2 : $MPI_WORKER_GLUCOSE3 : $MPI_WORKER_GLUCOSE4 : $MPI_WORKER_GLUCOSE5 : $MPI_WORKER_GLUCOSE6 : $MPI_WORKER_GLUCOSE7 : $MPI_WORKER_GLUCOSE8 : $MPI_WORKER_GLUCOSE9"
elif [ "$2" = "FULLPENELOPE" ]; then
    PROG="$MPI_MASTERMIND : $MPI_MASTERS : $MPI_SCOUTCUBES1 : $MPI_WORKER_PENELOPE1 : $MPI_WORKER_PENELOPE2 : $MPI_WORKER_PENELOPE3 : $MPI_WORKER_PENELOPE4"
elif [ "$2" = "UNIQUEGLUCOSE" ]; then
    PROG="$MPI_MASTERMIND : $MPI_MASTERS : $MPI_SCOUTCUBES1 : $MPI_WORKER_UNIQUE_GLUCOSE"
else
    echo "Paramétre 4 : NORMAL || FULLGLUCOSE || FULLPENELOPE || UNIQUEGLUCOSE"
    exit
fi

echo $PROG
MPIRUN="time -p /usr/local/bin/mpirun $HOST --report-bindings --display-allocation "
#CLUSTER="shortparallele8 -l nodes=5:ppn=8 -l cput=40:00:00 -l walltime=80:00:00"
CLUSTER="shortparallele8 -l nodes=10:ppn=8 -l walltime=00:30:00"
LOG="$RACINE/Log/$4/$(basename $5 | sed 's/.cnf//g')"


if [ "$1" = "PC" ]; then
    echo "[PC]CNF: $(basename $5 | sed 's/.cnf//g').cnf"
    echo "[PC]PATH CNF: $CNF"
    echo "[PC]MPI: $MPIRUN"
    $MPIRUN $PROG
    echo
elif [ "$1" = "CLUSTER" ]; then
    echo "[CLUSTER]CNF: $(basename $5 | sed 's/.cnf//g').cnf"
    echo "[CLUSTER]PATH CNF: $CNF"
    echo "[CLUSTER]LOG: $LOG.log"
    echo "[CLUSTER]CONFIG: $CLUSTER"
    echo "[CLUSTER]MPI: $MPIRUN"
    qadd -e "$LOG.err" -o "$LOG.log" -q $CLUSTER -- $MPIRUN $PROG
    echo
fi




