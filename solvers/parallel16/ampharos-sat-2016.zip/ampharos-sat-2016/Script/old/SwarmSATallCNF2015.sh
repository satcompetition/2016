#!/bin/bash

# $1 Type de machine : CLUSTER || PC
# $2 Type de solveur : GLUCOSE_MINISAT || GLUCOSE || MINISAT
# $3 Mode de fonctionnement : CONCURENTS || SCOUTS
# $4 Dossier de log
# $5 H_POL
# $6 TREE_HEIGHT

#H_POL : 0 : P
#H_POL : 1 : R
#H_POL : 2 : 0
#H_POL : 3 : 1
#H_POL : 4 : PU
#H_POL : 5 : PR


rm -rf ../Log/$4
mkdir ../Log/$4

(( CPT=0 ))

for i in `cat ord2015.res`
do
    echo $i
    #CNF="../../dimacs_satElite_jfpc/$i.cnf"
    ./SwarmSAT64.sh $1 $2 $3 $4 $i $5 $6 $7 $8 $9 ${10}
done
