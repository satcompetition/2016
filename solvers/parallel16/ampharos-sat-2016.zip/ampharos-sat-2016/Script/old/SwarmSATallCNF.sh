#!/bin/bash

#1 Lancement sur un PC ou CLUSTER (torque)
#2 NORMAL FULLGLUCOSE FULLPENELOPE UNIQUEGLUCOSE
#3 CONCURENTS CUBES
#4 Dossier de log
rm -rf ../Log/$4
mkdir ../Log/$4

for i in `ls ../../dimacs_satElite/*.cnf`
do
    ./SwarmSAT.sh $1 $2 $3 $4 $i
done
