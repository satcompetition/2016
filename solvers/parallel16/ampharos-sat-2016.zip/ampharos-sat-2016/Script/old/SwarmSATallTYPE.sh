#!/bin/bash

./make.sh clean

./SwarmSAT.sh CLUSTER logNormal NORMAL
./SwarmSAT.sh CLUSTER logGlucose FULLGLUCOSE
./SwarmSAT.sh CLUSTER logPenelope FULLPENELOPE
