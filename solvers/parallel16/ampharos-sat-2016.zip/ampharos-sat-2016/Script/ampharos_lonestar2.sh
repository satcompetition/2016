echo $PWD
echo $1

ibrun -np 33 /home1/02055/marijn/SC16/ampharos-sat-2016/Master/master $1 1 31 1 10000 1000


