#!/bin/bash
#SBATCH -J ampharosMPI            # job name
#SBATCH -o ampharos_$1.o%j        # output and error file name (%j expands to jobID)
#SBATCH -N 1                # number of nodes requested
#SBATCH -n 24               # total number of mpi tasks requested
#SBATCH -p normal      # queue (partition) -- normal, development, etc.
#SBATCH -t 01:23:20         # run time (hh:mm:ss) 

PATH="/home1/02055/marijn/ampharos-sat-2016/Script"
echo $PATH
CNF="$PATH/$1"
echo $CNF
#LAUNCH="mpirun" 
LAUNCH="ibrun" 
OPT_MASTER="1 22 1 10000 1000 lala"
OPT_WORKER="-hpol=7 -type_extend=1 -type_com=3 -rnd-init -verb=0"
OPT_MANAGER="-type=1 -type_com=3 -type_extend=1 -tree=1 -rnd-init -verb=0"



$LAUNCH -np 1 $PATH/../Master/master $OPT_MASTER : -np 11 $PATH/../Workers/glucose-syrup-adapt/syrup/Worker/WGlucoseSyrup $CNF $OPT_WORKER -type=1 : -np 11 $PATH/../Workers/minisat/Worker/WMinisat $CNF $OPT_WORKER -type=2 : -np 1 $PATH/../Scouts/minisatScout1/Worker/SMinisat1 $CNF $OPT_MANAGER

#$LAUNCH $PATH/../Master/master $OPT_MASTER
