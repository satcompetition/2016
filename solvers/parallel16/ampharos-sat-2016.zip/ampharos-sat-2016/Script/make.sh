#!/bin/sh



CLEAN="OFF"
MAKE="OFF"

if [ "$1" = "clean" ]; then
    CLEAN="ON"
fi
if [ "$1" = "all" ]; then
    CLEAN="ON"
    MAKE="ON"
fi
if [ "$1" = "" ]; then
    MAKE="ON"
fi


if [ "$CLEAN" = "ON" ]; then
    cd ..
    
    echo
    echo "[Cleaning *~ *# *.o]"
    set -x
    find . -name "*~" -exec rm -rf "{}" \;
    find . -name "*#" -exec rm -rf "{}" \;
    find . -name "*.o" -exec rm -rf "{}" \;
    set +x
    cd $PWD/Script

    cd ..
    echo "PATH SCRIPT : $PWD"
    #ScoutLib
    cd $PWD/Scouts/minisatScout1/Worker/
    echo
    echo "[Cleaning ScoutLib]"
    rm -rf *.a
    ./make.sh clean
    cd $PWD/../../../
    echo "PATH SCRIPT : $PWD"

    #Glucose/Minisat Lib
    cd $PWD/Workers/glucose-syrup-adapt/syrup/Worker
    echo
    echo "[Compiling Glucose/Minisat Lib]"
    ./make.sh clean
    cd $PWD/../../../../

    echo "PATH SCRIPT : $PWD"
    #Master
    cd $PWD/Master
    echo
    echo "[Cleaning Masters]"
    make clean
    cd $PWD/..    

    #GlucoseSyrup
    #cd $PWD/Workers/glucose-syrup-adapt/syrup/Worker
    #echo
    #echo "[Cleaning Glucose Syrup]"
    #./make.sh clean
    #cd $PWD/../../../..

    cd $PWD/Script
    echo "PATH SCRIPT : $PWD"
    echo
    echo "[Size]"

    du -smk ../* | sort    
fi

if [ "$MAKE" = "ON" ]; then
    cd ..

     #ScoutLib
    cd $PWD/Scouts/minisatScout1/Worker/
    echo
    echo "[Compiling ScoutLib]"
    ./make.sh 
    cd $PWD/../../..

    #Glucose/Minisat Lib
    cd $PWD/Workers/glucose-syrup-adapt/syrup/Worker
    echo
    echo "[Compiling Glucose/Minisat Lib]"
    ./make.sh 
    cd $PWD/../../../../


    #Master
    cd $PWD/Master
    echo
    echo "[Cleaning Masters]"
    make 
    cd $PWD/..    
    cd $PWD/Script
fi

echo
echo "PATH SCRIPT : $PWD"



