#!/bin/sh

#Execution
emacs *.sh ../define.h &

cd $PWD/..

#MasterMind Et Master
emacs Master/*.cc &
emacs Master/*.h &

#ScoutLib
emacs Scouts/ScoutLib/*.h Scouts/ScoutLib/Scout.cc &

#WorkerLib
emacs Workers/WorkerLib/*.h Workers/WorkerLib/*.cc &

#Penelope
#emacs Workers/penelope/Worker/Solver.cpp Workers/penelope/Worker/Cooperation.cpp Workers/penelope/include/penelope/core/Solver.h Workers/penelope/Worker/bin/*.cpp &

#Glucose
#emacs Workers/glucose/core/Solver.cc Workers/glucose/core/Solver.h Workers/glucose/Worker/Main.cc Workers/glucose/Worker/VirtualSolver.cc &

#minisat
emacs Workers/minisat/core/Solver.cc Workers/minisat/core/Solver.h Workers/minisat/Worker/Main.cc Workers/minisat/Worker/VirtualSolver.cc &

#minisatPsmDyn
emacs Workers/minisatPsmDyn/core/Solver.cc Workers/minisatPsmDyn/core/Solver.h Workers/minisatPsmDyn/Worker/Main.cc Workers/minisatPsmDyn/Worker/VirtualSolver.cc &

#ScoutMinisat1
emacs Scouts/minisatScout1/core/Solver.cc Scouts/minisatScout1/core/Solver.h Scouts/minisatScout1/Worker/Main.cc Scouts/minisatScout1/Worker/VirtualScout.cc &

#Glucose-syrup
emacs Workers/glucose-syrup-adapt/syrup/core/Solver.cc Workers/glucose-syrup-adapt/syrup/core/Solver.h Workers/glucose-syrup-adapt/syrup/Worker/Main.cc Workers/glucose-syrup-adapt/syrup/Worker/VirtualSolver.cc &

cd $PWD/Script
