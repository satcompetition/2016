 #!/bin/sh

#$1 Type de machine : CLUSTER || PC
#$2 Type de solveur :  GLUCOSE || MINISAT || GLUCOSE_MINISAT || GLUCOSE_MINISAT_MINISATPSM
#$3 Mode de fonctionnement : CONCURENTS || MANAGER
#$4 Nom du dossier de LOG contenue dans le dossier "Log" 
#$5 Chemin relatif de la CNF
#$6 H_POL
#$7 TREE_HEIGHT
#$8 TYPE_COM
#$9 NB_CONFLICT_SCOUT
#$10 NB_CONFLICT_WORKERS
#$11 TYPE_EXTEND

#H_POL : 0 : P
#H_POL : 1 : R
#H_POL : 2 : 0
#H_POL : 3 : 1
#H_POL : 4 : PU
#H_POL : 5 : PR
#H_POL : 6 : ALL
#H_POL : 7 : following nb_cubes and nb_workers for each node

#./ampharos.sh PC GLUCOSE_MINISAT_MINISATPSM MANAGER logEss $1 7 1 SHARE_ALL 10000 1000 1

CNF="$5"
RACINE="$PWD/.."

if [ "$1" = "PC" ]; then
    NB_WORKERS="31"
    NB_WORKER_MINISAT="0"
    NB_WORKER_GLUCOSE="31" 
elif [ "$1" = "CLUSTER" ]; then 
    HOST="--map-by core --oversubscribe"
    NAME_NODE="node201"
    HOST_NODE="--host $NAME_NODE"
    NB_WORKERS="31"
    NB_WORKER_MINISAT="11"
    NB_WORKER_GLUCOSE="31" 
else
    echo "Paramétre 1 : PC || CLUSTER"
    exit
fi

if [ "$3" = "CONCURENTS" ]; then
    MODE=0
    RND_INIT="-rnd-init"
    H_POL=""
    TREE_HEIGHT=""
    MPI_SCOUT_1=""
    MPI_SCOUT_2=""
    MPI_SCOUT_3="" 
    NB_SCOUTS="0"
elif [ "$3" = "MANAGER" ]; then
    MODE=1
    RND_INIT="-rnd-init"
    H_POL="-hpol=$6"
    TREE_HEIGHT="-tree=$7"
    if [ "$8" = "SHARE_ALL" ]; then
        TYPE_COM="-type_com=3"
    elif [ "$8" = "NO_SHARE" ]; then
        TYPE_COM="-type_com=0"
    elif [ "$8" = "SHARE_ALL_NO_ULN" ]; then
        TYPE_COM="-type_com=4"
    elif [ "$8" = "SHARE_UNITS_LITERALS" ]; then
        TYPE_COM="-type_com=1"
    elif [ "$8" = "SHARE_CLAUSES" ]; then
        TYPE_COM="-type_com=2"
    else
        echo "Paramétre 8 : SHARE_ALL || NO_SHARE || SHARE_UNITS_LITERALS || SHARE_CLAUSES || SHARE_ALL_NO_ULN"
        exit
    fi
    TYPE_EXTEND="-type_extend=${11}"
    TYPE_EXTEND_SCOUT="-type_extend=${11}"
    OPT_EXP=""
    MPI_SCOUT_1=": -np 1 $HOST_NODE $RACINE/Scouts/minisatScout1/Worker/SMinisat1 $CNF -type=1 $TYPE_COM $TYPE_EXTEND_SCOUT $TREE_HEIGHT $OPT_EXP $RND_INIT -verb=0"
    NB_SCOUTS="1"
else
    echo "Paramétre 3 : CONCURENTS || MANAGER"
    exit
fi
 
#/usr/local/valgrind/bin/valgrind 

PROG_GLUCOSE="$RACINE/Workers/glucose-syrup-adapt/syrup/Worker/WGlucoseSyrup"
PROG_MINISAT="$RACINE/Workers/minisat/Worker/WMinisat"
PROG_OPT="$CNF $H_POL $TYPE_EXTEND $TYPE_COM $RND_INIT -verb=0"

MPI_MASTER="-np 33 $HOST_NODE $RACINE/Master/master $CNF $MODE $NB_WORKERS $NB_SCOUTS $9 ${10}"

MPI_WORKER_GLUCOSE=": -np $NB_WORKER_GLUCOSE $HOST_NODE $PROG_GLUCOSE  $PROG_OPT -type=1"
MPI_WORKER_MINISAT=": -np $NB_WORKER_MINISAT $HOST_NODE $PROG_MINISAT $PROG_OPT -type=2"

MPI_WORKER="$MPI_WORKER_GLUCOSE $MPI_WORKER_MINISAT"

if [ "$2" = "GLUCOSE" ]; then
    echo "NO WORK"
    exit
elif [ "$2" = "MINISAT" ]; then
    echo "NO WORK"
    exit
elif [ "$2" = "GLUCOSE_MINISAT" ]; then
    PROG="$MPI_MASTER"
elif [ "$2" = "MINISATPSM" ]; then
    exit
elif [ "$2" = "GLUCOSE_MINISAT_MINISATPSM" ]; then
    echo "NO WORK"
    exit
else
    echo "Paramétre 3 : GLUCOSE || MINISAT || GLUCOSE_MINISAT || GLUCOSE_MINISAT_MINISATPSM"
    exit
fi

echo $PROG
MPIRUN="/usr/local/bin/mpirun --oversubscribe --report-bindings --display-allocation "
CLUSTER="parallelempi -l nodes=$NAME_NODE:ppn=32 -l walltime=01:23:20"
LOG="$RACINE/Log/$4/$(basename $5 | sed 's/.cnf//g')"
if [ "$1" = "PC" ]; then
    echo "[PC]CNF: $(basename $5 | sed 's/.cnf//g').cnf"
    echo "[PC]PATH CNF: $CNF"
    echo "[PC]MPI: $MPIRUN"
    $MPIRUN $PROG
    echo
elif [ "$1" = "CLUSTER" ]; then
    echo "[CLUSTER]CNF: $(basename $5 | sed 's/.cnf//g').cnf"
    echo "[CLUSTER]PATH CNF: $CNF"
    echo "[CLUSTER]LOG: $LOG.log"
    echo "[CLUSTER]CONFIG: $CLUSTER"
    echo "[CLUSTER]MPI: $MPIRUN"
    qadd -e "$LOG.err" -o "$LOG.log" -q $CLUSTER -- $MPIRUN $PROG
    echo
fi








