//
// Copyright (c) 2004-2006 The Trustees of Indiana University and Indiana
//                         University Research and Technology
//                         Corporation.  All rights reserved.
// Copyright (c) 2006      Cisco Systems, Inc.  All rights reserved.
//
// Sample MPI "hello world" application in C++
//

#include "mpi.h"

#include "Swarm.h"

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <assert.h>
#include <signal.h>
#include "../define.h"

#include "GlucoseMain.h"
// #include "LocalMain.h"
#include "ScoutMain.h"

int main(int argc, char **argv){
  /*if(argc != 7){
    std::cerr << "Il faut exactement 6 parametre :\n" 
              << "\t1 : le mode de fonctionnement : CONCURENTS:0 vs SCOUTS:1\n"
              << "\t2 : le nombre de workers\n" 
              << "\t3 : le nombre de scouts\n"
              << "\t4 : le nombre de conflit pour la creation de l'arbre (scout)\n"
              << "\t5 : le nombre de conflit pour les workers\n";
    exit(0);
    }*/
  MPI::Init();
  Swarm::init_wall_time();
 
  int rank;
  MPI_Comm_rank(MPI_COMM_WORLD, &rank);

  if(rank == 0){
    
    printf("[RANK %d]It's the MASTER\n",rank);
    
    Swarm::init(MPI::COMM_WORLD.Get_size(), atoi(*(argv + 2)) 
                ,atoi(*(argv + 3))
                ,atoi(*(argv + 4))
                ,atoi(*(argv + 5))
                ,atoi(*(argv + 6)));  
    
    //printf("Model into %s\n",*(argv + 6));

    if(!Swarm::get_mode() && atoi(*(argv + 3))){
      std::cerr << "Le mode est CONCURENTS alors qu'il y a des scouts";
      exit(0);
    }
    Swarm::send_workers(MSG_START);
  
    if(Swarm::get_mode()){
      Swarm::send_scouts(MSG_CONFLICTS);
      Swarm::send_scouts(Swarm::nb_conflict_scout); //Number of conflict for the build of the tree
      Swarm::send_scouts(MSG_START);
    }
    Swarm::listen_send_all();   
    MPI::Finalize();
  }else if (rank < 32){
    printf("[RANK %d]Here will be a solver\n", rank);    
    glucoseMain(argc, argv, rank%2);
  }else if (rank == 32){
    printf("[RANK %d]Here will be the manager\n",rank);
    ScoutMain(argc,argv);
  }else{
    
    printf("[RANK %d]It's the MANAGER\n",rank);
  }
  
  return 0;
}
