
#include <vector>

#include "mpi.h"
#include <time.h>
#include <sys/time.h>
#include <stdio.h>
#include <stdlib.h>

#include "../define.h"

class Swarm {
 public:
   
  //Main informations
  inline static int get_nb_process(){return nb_process;}
  inline static int get_nb_workers(){return nb_workers;}
  inline static int get_nb_scouts(){return nb_scouts;}
  inline static int get_mode(){return mode;}
  inline static int get_rank() {return rank;}
  inline static int get_rank_worker(const int& num){return num+1;}
  inline static int get_rank_scout(const int& num){return num+nb_workers+1;}

  //Main methods with MPI
  static void init(const int& n_NbProcess
                   ,const int& n_mode
                   ,const int& n_NbWorkers
                   ,const int& n_NbScoutCubes
                   ,const int& n_nb_conflict_scout
                   ,const int& n_nb_conflict_workers);//initialisation

  static void listen_send_all();//Main method

  //For real and cpu time 
  inline static double get_cpu_time() {return (double)clock() / CLOCKS_PER_SEC;}
  inline static double get_wall_time() {return wall_time()-start_wall_time;}
 
  static double start_wall_time; /*RealTime when start program*/
  inline static void init_wall_time(){start_wall_time = wall_time();}
  inline static double wall_time(){
    struct timeval time;
    if (gettimeofday(&time,NULL)){return 0;}
    return (double)time.tv_sec + (double)time.tv_usec * .000001;
  }

  //MPI macro for send/receive message
  inline static void init_listen_worker(const int& i){
    flag_workers[i]=0;
    MPI_Irecv(message_workers+i, 1, MPI_INT, get_rank_worker(i), TAG_W_SEND_M_MODE, MPI_COMM_WORLD,request_workers+i);
  }

  inline static void init_listen_scout(const int& i){
    flag_scouts[i]=0;
    MPI_Irecv(message_scouts+i, 1, MPI_INT, get_rank_scout(i), TAG_S_SEND_M_MODE, MPI_COMM_WORLD,request_scouts+i);
  }

  inline static void send_workers(const int& message){
    for(int m = 0;m < nb_workers;m++){
      //printf("SEND %d at worker %d\n",message,get_rank_worker(m));
      MPI_Send(&message, 1, MPI_INT, get_rank_worker(m), TAG_M_SEND_W_MODE, MPI_COMM_WORLD); 
    }
  }

  inline static void send_worker(const int& worker,const int& message){
    
    //printf("SEND %d at worker %d\n",message,get_rank_worker(worker));
    MPI_Send(&message, 1, MPI_INT, get_rank_worker(worker), TAG_M_SEND_W_MODE, MPI_COMM_WORLD); 
   
  }

  inline static void send_scouts(const int& message){
    for(int m = 0;m < nb_scouts;m++){
      //printf("SEND %d at scouts %d\n",message,get_rank_scout(m));
      MPI_Send(&message, 1, MPI_INT, get_rank_scout(m), TAG_M_SEND_S_MODE, MPI_COMM_WORLD); 
    }
  }
  inline static void kill_all(const int code){

    printf("%sKILL real_time %f\n",name,get_wall_time());
    send_workers(MSG_KILL);
    send_scouts(MSG_KILL);
    exit(code);
    MPI_Finalize();
    printf("%sKILL finalize_real_time:%f\n",name,get_wall_time());
    exit(0);
  }

  static int nb_conflict_scout;
 
  //For worker
  static int nb_conflict_workers;

 private:
  
  //For main informations
  static const char name[];/*Name of master*/
  static const int rank;/*rank MPI of master*/
  
  static int mode; /* Operating mode : CONCURENTS:0 vs CUBES:1*/
  static int nb_process; /* Number of process */
  static int nb_workers; /* Number of workers */
  static int nb_scouts; /* Number of scouts */
  static int* type_of_workers; /*the type of each worker (glucose or penelope or minisat ...)*/
  static int* type_of_scouts; /*the type of each scouts (...)*/

  //For message MPI
  static int* message_workers; /* messages received by workers */
  static MPI_Request* request_workers;  /* request for listening workers */
  static int* flag_workers;  /* flag, 1 if message has been received of each workers, 0 else */

  static int* message_scouts; /* messages received by scouts */
  static MPI_Request* request_scouts;  /* request for listening scouts */
  static int* flag_scouts;  /* flag, 1 if message has been received of each scouts, 0 else */

  //For scouts
  static bool scout_available; /*When the scouts are available for the workers */
 
  
};

