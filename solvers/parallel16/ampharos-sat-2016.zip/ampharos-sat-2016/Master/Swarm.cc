
#include "mpi.h"

#include "Swarm.h" 

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <assert.h>
#include <vector>


#include "../define.h"

//For main informations
const char Swarm::name[] = "[MASTER 0]"; /*Name of master*/
int const Swarm::rank = 0; /*rank MPI of master*/

int Swarm::mode = 0; /* Operating mode : CONCURENTS:0 vs CUBES:1*/
int Swarm::nb_process = 0; /* Number of process */
int Swarm::nb_workers = 0; /* Number of workers */
int Swarm::nb_scouts = 0; /* Number of scouts */
int* Swarm::type_of_workers = NULL; /*the type of each worker (glucose or penelope or minisat ...)*/
int* Swarm::type_of_scouts = NULL; /*the type of each scouts (...)*/

//For message MPI
int* Swarm::message_workers = NULL; /* messages received by workers */
MPI_Request* Swarm::request_workers = NULL; /* request for listening workers */
int* Swarm::flag_workers = NULL; /* flag, 1 if message has been received of each workers, 0 else */

int* Swarm::message_scouts = NULL; /* messages received by scouts */
MPI_Request* Swarm::request_scouts = NULL; /* request for listening scouts */
int* Swarm::flag_scouts = NULL; /* flag, 1 if message has been received of each scouts, 0 else */

//For real time
double Swarm::start_wall_time = 0; /*RealTime when start program*/

//For scouts
bool Swarm::scout_available = false;
int Swarm::nb_conflict_scout = 0;
int Swarm::nb_conflict_workers = 0;

void Swarm::init(const int& n_nb_process
                 , const int& n_mode
                 , const int& n_nb_workers
                 , const int& n_nb_scouts
                 , const int& n_nb_conflict_scout
                 , const int& n_nb_conflict_workers){

  int w = 0;

  /*main informations*/
  char hostname[256];
  gethostname(hostname, sizeof(hostname));
  nb_process = n_nb_process;
  mode = n_mode;
  nb_workers =  n_nb_workers;
  nb_scouts = n_nb_scouts;
  nb_conflict_scout = n_nb_conflict_scout;
  nb_conflict_workers = n_nb_conflict_workers;
  
  /*Initialisation mémoire pour les message recu des workers et des scouts*/
  message_workers = (int*)malloc(nb_workers*sizeof(int));
  request_workers = (MPI_Request*)malloc(nb_workers*sizeof(MPI_Request));
  flag_workers = (int*)calloc(nb_workers,sizeof(int));

  message_scouts = (int*)malloc(nb_scouts*sizeof(int));
  request_scouts = (MPI_Request*)malloc(nb_scouts*sizeof(MPI_Request));
  flag_scouts = (int*)calloc(nb_scouts,sizeof(int));

  /*recois les types des workers (glucose, penelope, minisat ...) et initialise l'ecoute de ces workers*/
  type_of_workers = (int*)malloc(nb_workers*sizeof(int));
  for(;w < nb_workers;w++){
    MPI_Recv(type_of_workers+w, 1, MPI_INT, get_rank_worker(w), TAG_W_SEND_M_MODE, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
    init_listen_worker(w);
  }
  
  if(nb_scouts && !mode)
    {
      printf("KILL : Il y a %d scouts alors que le mode est CONCURENTS\n",nb_scouts);
      kill_all(0);
    }
  /*recois les types des scouts et initialise l'ecoute de ces scouts*/
  type_of_scouts = (int*)malloc(nb_scouts*sizeof(int));

  for(w = 0;w < nb_scouts;w++){
     MPI_Recv(type_of_scouts+w, 1, MPI_INT, get_rank_scout(w), TAG_S_SEND_M_MODE, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
     init_listen_scout(w);
  }
  
 /*Envoie le nombre de scouts et le nombre de workers au workers*/
  send_workers(nb_workers);
  send_workers(nb_scouts);
  send_scouts(nb_workers);
  send_scouts(nb_scouts);
  
  /*Send type of each worker at Scout*/
  for(w = 0;w < nb_scouts;w++){
    MPI_Send(type_of_workers
             , nb_workers
             ,MPI_INT, get_rank_scout(w), TAG_M_SEND_S_MODE, MPI_COMM_WORLD);
  }

 
  std::cout    << name << "hostname : " << hostname << "\n"
               << name << "nb_process : " << nb_process << "\n"
               << name << "nb_workers : " << nb_workers << "\n"
               << name << "nb_scouts : " << nb_scouts << "\n"
               << name << "mode : " << (!mode?"CONCURENTS":"SCOUTS") << "\n"
               << name << "init_real_time : " << get_wall_time() << "\n"
               << name << "READY\n";
}

/* Fonction principale du M : ecoute et envoie les messages */
void Swarm::listen_send_all(){
  int w = 0;
  int worker_stop = 0;
  int size_model = 0;
  int* model = NULL;
  int tata = 34;
  for(;;)
    {
    for(w = 0;w < nb_workers;w++)
      {//Ecoute des workers
      MPI_Test(request_workers+w,flag_workers+w,MPI_STATUS_IGNORE);
      if(flag_workers[w])
        {//si un message est recu d'un worker
        switch(message_workers[w])
          {
          case MSG_SAT :
            send_worker(w,10);    
            MPI_Recv(&tata, 1, MPI_INT, get_rank_worker(w), TAG_W_SEND_M_MODE, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            exit(10);
            //while(1);
            //kill_all(10);
            break;
          case MSG_UNSAT :
            send_worker(w,10);    
            MPI_Recv(&tata, 1, MPI_INT, get_rank_worker(w), TAG_W_SEND_M_MODE, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            exit(20);
            break;
          case MSG_INDET :
            //printf("[MASTER %d]INDETERMINATE BY [WORKER %d]\n",rank,get_rank_worker(w));
            break;
          default:
            printf("[MASTER %d]BUG MESSAGE: %d\n",rank,message_workers[w]);
            break;
          }
        init_listen_worker(w);
        }
      }
    for(w = 0;w < nb_scouts;w++)
      {//Ecoute des scouts
        MPI_Test(request_scouts+w,flag_scouts+w,MPI_STATUS_IGNORE);
        if(flag_scouts[w])
          {//si un message est recu d'un scouts
            switch(message_scouts[w])
              {
              case MSG_SAT :
                //printf("[MASTER %d]SATISFIABLE\n",rank);
                printf("s SATISFIABLE\n ");
                exit(0);
                break;
              case MSG_UNSAT :
                //printf("[MASTER %d]UNSATISFIABLE\n",rank);
                printf("s UNSATISFIABLE\n");
                exit(20);
                break;
              case MSG_INDET :
                printf("[MASTER %d]CUBE AVAILABLE BY [SCOUT %d]\n",rank,get_rank_scout(w));
                if(!scout_available)
                  {
                    scout_available=true;
                    send_workers(MSG_STOP);
                  }
                send_workers(MSG_SCOUT_AVAILABLE);
                send_workers(w);
                send_workers(nb_conflict_workers);
                break;
              case MSG_STOP_AT_ONCE :
                MPI_Recv(&worker_stop, 1, MPI_INT, get_rank_scout(w), TAG_S_SEND_M_MODE, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
#ifdef DEBUG_SCOUT
                printf("[MASTER %d]STOP AT ONCE [WORKER %d]\n",rank,get_rank_worker(worker_stop));
#endif
                send_worker(worker_stop,MSG_STOP_AT_ONCE);
                break;
              default:
                printf("[MASTER %d]BUG MESSAGE: %d\n",rank,message_scouts[w]);
                break;
              }
            init_listen_scout(w);
          }
      }
  }
}




