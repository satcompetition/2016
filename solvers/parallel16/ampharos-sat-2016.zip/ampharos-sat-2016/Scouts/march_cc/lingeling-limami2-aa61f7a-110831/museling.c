#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdarg.h>

#include "lglib.h"

#define EMPTY(STACK) ((STACK).top == (STACK).start)
#define FULL(STACK) ((STACK).top == (STACK).end)
#define SIZE(STACK) ((STACK).end - (STACK).start)
#define COUNT(STACK) ((STACK).top - (STACK).start)

#define ENLARGE(STACK) \
do { \
  size_t OLD_SIZE = SIZE(STACK); \
  size_t NEW_SIZE = OLD_SIZE ? 2 * OLD_SIZE : 1; \
  size_t OLD_COUNT = COUNT(STACK); \
  (STACK).start = \
    realloc ((STACK).start, NEW_SIZE * sizeof *(STACK).start); \
  (STACK).top = (STACK).start + OLD_COUNT; \
  (STACK).end = (STACK).start + NEW_SIZE; \
} while (0)

#define PUSH(STACK,ELEM) \
do { \
  if (FULL(STACK)) ENLARGE (STACK); \
  *(STACK).top++ = ELEM; \
} while (0)

#define CLEAN(STACK) do { (STACK).top = (STACK).start; } while (0)

#define POP(STACK) (assert (!EMPTY (STACK)), *--(STACK).top)

#define STACK(TYPE) struct { TYPE * start; TYPE * top; TYPE * end; }

typedef struct Clause { int sel, removed, assumed, fixed, * lits; } Clause;

static STACK(char) token;
static STACK(int) clause, units;
static STACK(Clause) clauses;

static int m, n, remaining, assumed; 

static int iclose;
static FILE * ifile, * ofile;
static const char * iname, * oname;
static int lineno = 1, lastch;
static int header;

static int verbose, nowitness;
static int reductions;

static void msg (int level, const char * fmt, ...) {
  va_list ap;
  if (verbose < level) return;
  printf ("c ");
  va_start (ap, fmt);
  vfprintf (stdout, fmt, ap);
  fputc ('\n', stdout);
  fflush (stdout);
}

static void die (const char * fmt, ...) {
  va_list ap;
  fputs ("*** museling error: ", stdout);
  va_start (ap, fmt);
  vprintf (fmt, ap);
  fputc ('\n', stdout);
  fflush (stdout);
  exit (1);
}

static void perr (const char * fmt, ...) {
  va_list ap;
  if (lastch == '\n') { assert (lineno > 1), lineno--; }
  printf ("%s:%d: ", iname, lineno);
  va_start (ap, fmt);
  vprintf (fmt, ap);
  fputc ('\n', stdout);
  fflush (stdout);
  exit (1);
}

static int read_token () {
RESTART:
  while (isspace (lastch = getc (ifile)))
    if (lastch == '\n') lineno++, header = 0;
      ;
  if (!header && lastch == 'c') {
    while ((lastch = getc (ifile)) != '\n')
      if (lastch == EOF) perr ("unexpected end of ifile in comment");
    lineno++;
    header = 0;
    goto RESTART;
  }
  CLEAN (token);
  if (lastch == EOF) return 0;
  if (lastch == 'p') header = 1;
  PUSH (token, lastch);
  while (!isspace (lastch = getc (ifile)) && lastch != EOF)
    PUSH (token, lastch);
  if (lastch == '\n') lineno++, header = 0;
  PUSH (token, 0);
  return 1;
}

static int parse_number () {
  const char * p;
  p = token.start;
  if (*p == '-') p++;
  if (!isdigit (*p++)) perr ("expected number");
  while (*p) if (!isdigit (*p++)) perr ("invalid number");
  return atoi (token.start);
}

static LGL * lgl;

static void check_sat (Clause * c) {
  const int * p;
  int lit;
  for (p = c->lits; (lit = *p); p++) if (lglderef (lgl, lit) > 0) return;
  die ("clause %d unsatisfied", c - clauses.start);
}

static double percent (double a, double b) { return b ? 100.0 * a / b : 0; }

static void unit (int lit) { lgladd (lgl, lit); lgladd (lgl, 0); }

static void update () {
  int count = 0;
  Clause * p;
  for (p = clauses.start; p < clauses.top; p++) {
    if (p->fixed) continue;
    if (p->removed) continue;
    if (p->assumed < assumed) continue;
    if (lglfailed (lgl, p->sel)) continue;
    msg (3, "removing clause %d",  p - clauses.start);
    PUSH (units, -p->sel);
    p->removed = 1;
    assert (remaining > 0);
    remaining--;
    count++;
  }
  while (!EMPTY (units)) unit (POP (units));
  if (count) msg (2, "removed %d additional clauses", count);
}

static void reduction () {
  reductions++;
  msg (1, "reduction %d to %d = %.0f%% out of %d after %.2f seconds",
       reductions, remaining, percent (remaining, n), n, lglprocesstime ());
}

static void try_to_remove (Clause * c) {
  int res, cid;
  Clause * p;
  assumed++;
  assert (assumed > 0);
  assert (!c->removed);
  cid = c - clauses.start;
  msg (3, "trying to remove clause %d", cid);
  for (p = clauses.start; p < clauses.top; p++) {
    if (p->removed) continue;
    if (p == c) continue;
    p->assumed = assumed;
    lglassume (lgl, p->sel);
  }
  res = lglsat (lgl);
  if (res == 10) {
    c->fixed = 1;
    msg (3, "fixing clause %d", cid);
    PUSH (units, c->sel);
  } else {
    c->removed = 1;
    msg (3, "removing clause %d",  cid);
    assert (remaining > 0);
    remaining--;
    PUSH (units, -c->sel);
    update ();
    reduction ();
  }
}

int main (int argc, char ** argv) {
  int i, size, lit, * q, res;
  Clause * p, c;
  for (i = 1; i < argc; i++) {
    if (!strcmp (argv[i], "-h")) {
      printf ("usage: museling [-h][-v][-n][<input>[<output>]\n");
      exit (0);
    } else if (!strcmp (argv[i], "-v")) verbose++;
    else if (!strcmp (argv[i], "-n")) nowitness = 1;
    else if (argv[i][0] == '-') 
      die ("invalid command line option '%s'", argv[i]);
    else if (oname)
      die ("too many files specified '%s', '%s' and '%s'",
           iname, oname, argv[i]);
    else if (iname) oname = argv[i]; else iname = argv[i];
  }
  if (iname) { 
    if (!(ifile = fopen (iname, "r"))) die ("can not read '%s'", iname);
    iclose = 1;
  } else iname = "<stdin>", ifile = stdin;
  if (verbose) lglbnr ("Museling", "c ", stdout), printf ("c \n");
  msg (1, "reading '%s'", iname);
  if (!read_token () || strcmp (token.start, "p") ||
      !read_token () || strcmp (token.start, "cnf") ||
      !read_token () || (m = parse_number ()) < 0 ||
      !read_token () || (n = parse_number ()) < 0)
    perr ("invalid header");
  msg (1, "found header 'p cnf %d %d'", m, n);
  c.removed = c.assumed = c.fixed = 0;
  while (read_token ()) {
    if (abs (lit = parse_number ()) > m) perr ("invalid literal %d", lit);
    if (COUNT (clauses) == n) perr ("too many clauses");
    if (lit) {
      PUSH (clause, lit);
    } else {
      size = COUNT (clause);
      c.lits = malloc ((size + 1) * sizeof (int));
      for (i = 0; i < size; i++) c.lits[i] = clause.start[i];
      c.lits[size] = 0;
      c.sel = COUNT (clauses) + m + 1;
      PUSH (clauses, c);
      CLEAN (clause);
    }
  }
  if (!EMPTY (clause)) perr ("zero sentinel missing");
  if (COUNT (clauses) < n) perr ("clauses missing");
  if (iclose) fclose (ifile);
  msg (1, "parsed '%d' clauses", COUNT (clauses));
  lgl = lglinit ();
  if (verbose >= 2) lglsetopt (lgl, "verbose", 1);
  assumed = 1;
  for (p = clauses.start; p < clauses.top; p++) {
    lglfreeze (lgl, p->sel);
    lglassume (lgl, p->sel);
    p->assumed = assumed;
    lgladd (lgl, -p->sel);
    for (q = p->lits; (lit = *q); q++) lgladd (lgl, lit);
    lgladd (lgl, 0);
  }
  msg (2, "starting first SAT call");
  res = lglsat (lgl);
  msg (2, "first SAT call returned %d", res);
  if (res == 10) {
    for (p = clauses.start; p < clauses.top; p++)
      check_sat (p);
    printf ("s SATISFIABLE\n");
    fflush (stdout);
    if (!nowitness) {
      for (i = 1; i <= m; i++) {
	fputs ("v ", stdout);
	if (lglderef (lgl, i) < 0) putc ('-', stdout);
	printf ("%d\n", i);
      }
      printf ("v 0\n");
      fflush (stdout);
    }
  } else {
    printf ("s UNSATISFIABLE\n");
    fflush (stdout);
    remaining = n;
    update ();
    if (remaining < n) reduction ();
    for (p = clauses.start; p < clauses.top; p++)
      if (!p->removed)
	try_to_remove (p);
    if (!nowitness) {
      for (p = clauses.start; p < clauses.top; p++)
	if (!p->removed)
	  printf ("v %d\n", 1 + (int)(p - clauses.start));
      printf ("v 0\n");
      fflush (stdout);
    }
    if (oname) {
      if (!(ofile = fopen (oname, "w")))
	die ("can not write to '%s'", oname);
      fprintf (ofile, "p cnf %d %d\n", m, remaining);
      for (p = clauses.start; p < clauses.top; p++)
	if (!p->removed) {
	  for (q = p->lits; (lit = *q); q++)
	    fprintf (ofile, "%d ", lit);
	  fprintf (ofile, "0\n");
	}
      fclose (ofile);
    }
  }
  if (verbose >= 2) lglstats (lgl);
  lglrelease (lgl);
  free (token.start);
  free (clause.start);
  for (p = clauses.start; p < clauses.top; p++)
    free (p->lits);
  free (clauses.start);
  msg (1, "computed MUS of size %d = %.0f%% in %d reductions and %.2f seconds", 
       remaining, percent (remaining, n), reductions, lglprocesstime ());
  return res;
}
