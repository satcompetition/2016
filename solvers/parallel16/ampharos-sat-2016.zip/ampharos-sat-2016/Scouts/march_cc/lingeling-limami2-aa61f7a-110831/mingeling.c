/* Copyright 2011 Armin Biere Johannes Kepler University Linz Austria */

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <ctype.h>
#include <stdarg.h>
#include <string.h>
#include <signal.h>
#include <unistd.h>

#include "lglib.h"

#define SWAP(A,B) do { typeof(A) TMP = (A); (A) = (B); (B) = TMP; } while (0)

#define FALSE ((AIG*)0)
#define TRUE ((AIG*)1)

#define NEW(PTR) do { (PTR) = allocate (sizeof *(PTR)); } while (0)
#define DEL(PTR) do { deallocate ((PTR), sizeof *(PTR)); (PTR) = 0; } while (0)
#define NEWN(PTR,N) \
  do { (PTR) = allocate ((N)*sizeof *(PTR)); } while (0)
#define DELN(PTR,N) \
  do { deallocate ((PTR), (N)*sizeof *(PTR)); (PTR) = 0; } while (0)
#define RSZ(PTR,O,N) \
  do { \
    size_t OLDBYTES = (O) * sizeof *(PTR); \
    size_t NEWBYTES = (N) * sizeof *(PTR); \
    (PTR) = reallocate ((PTR), OLDBYTES, NEWBYTES); \
  } while (0)

typedef struct AIG {
  int lit, var;
  struct AIG * left, * right, * next, * chain;
} AIG;

typedef struct Clause { 
  int64_t limit;
  int lit, mark, * lits;
} Clause;

static AIG ** aigtable, * firstaig, * lastaig;
static unsigned szaigtable, naigs, aigtablelookups;
static signed char * model;

static int nvars, nclauses;
static Clause * clauses;
static int firstclauselit, nextclauselit, truelit, firstandlit, nextandlit;

static FILE * input;
static const char * name;
static int clin, lineno = 1;

static int * lits, nlits, szlits;
static int verbose, nowitness, catchedsig;
static int forcepar, forceup, forcedown;
static LGL * lgl;

static void (*sig_int_handler)(int);
static void (*sig_segv_handler)(int);
static void (*sig_abrt_handler)(int);
static void (*sig_term_handler)(int);

struct { size_t current, max; } allocated;

static void msg (int level, const char * fmt, ...) {
  va_list ap;
  if (verbose < level) return;
  printf ("c ");
  va_start (ap, fmt);
  vfprintf (stdout, fmt, ap);
  fputc ('\n', stdout);
  fflush (stdout);
}

static void die (const char * fmt, ...) {
  va_list ap;
  fputs ("*** mingeling error: ", stdout);
  va_start (ap, fmt);
  vprintf (fmt, ap);
  fputc ('\n', stdout);
  fflush (stdout);
  exit (1);
}

static void * allocate (size_t bytes) {
  void * res = malloc (bytes);
  if (!res) die ("out of memory");
  memset (res, 0, bytes);
  allocated.current += bytes;
  if (allocated.current > allocated.max) allocated.max = allocated.current;
  return res;
}

static void deallocate (void * ptr, size_t bytes) {
  assert (bytes <= allocated.current);
  allocated.current -= bytes;
  free (ptr);
}

static void * reallocate (void * ptr, size_t oldbytes, size_t newbytes) {
  char * res;
  assert (oldbytes <= allocated.current);
  allocated.current -= oldbytes;
  res = realloc (ptr, newbytes);
  if (!res) die ("out of memory");
  if (oldbytes < newbytes) memset (res + oldbytes, 0, newbytes - oldbytes);
  allocated.current += newbytes;
  if (allocated.current > allocated.max) allocated.max = allocated.current;
  return res;
}

static void * new (void * state, size_t bytes) {
  char * res;
  (void) state;
  NEWN (res, bytes); 
  return res;
}

static void del (void * state, void * ptr, size_t bytes) {
  char * cptr = ptr;
  (void) state;
  DELN (cptr, bytes);
}

static void * rsz (void * state, void * ptr, size_t o, size_t n) {
  char * cptr = ptr;
  RSZ (cptr, o, n);
  return cptr;
}

static void resetsighandlers (void) {
  (void) signal (SIGINT, sig_int_handler);
  (void) signal (SIGSEGV, sig_segv_handler);
  (void) signal (SIGABRT, sig_abrt_handler);
  (void) signal (SIGTERM, sig_term_handler);
}

static void caughtsigmsg (int sig) {
  if (!verbose) return;
  printf ("c CAUGHT SIGNAL %d\n", sig);
  fflush (stdout);
}

static void stats (void) {
  if (lgl) {
    printf ("c ---- start of lglib stats -----------------------\n");
    lglstats (lgl);
    printf ("c ---- end of lglib stats -------------------------\n");
  }
  printf ("c %.2f seconds, %.1f MB\n", lglprocesstime (), 
          allocated.max/(double)(1<<20));
  fflush (stdout);
}

static void catchsig (int sig) {
  if (!catchedsig) {
    fputs ("s UNKNOWN\n", stdout);
    fflush (stdout);
    catchedsig = 1;
    caughtsigmsg (sig);
    if (verbose) stats (), caughtsigmsg (sig);
  }
  resetsighandlers ();
  if (!getenv ("LGLNABORT")) raise (sig); else exit (1);
}

static void setsighandlers (void) {
  sig_int_handler = signal (SIGINT, catchsig);
  sig_segv_handler = signal (SIGSEGV, catchsig);
  sig_abrt_handler = signal (SIGABRT, catchsig);
  sig_term_handler = signal (SIGTERM, catchsig);
}

static int nextch () {
  int res = getc (input);
  if (res == '\n') lineno++;
  return res;
}

static int isws (int ch) {
  return ch == '\n' || ch == '\r' || ch == ' ' || ch == '\t';
}

static void pushlit (int lit) {
  if (szlits == nlits) {
    szlits = szlits ? 2 * szlits : 1;
    RSZ (lits, nlits, szlits);
  }
  lits[nlits++] = lit;
}

static void pushclause (int cid) {
  Clause * clause;
  int i;
  clause = clauses + cid;
  NEWN (clause->lits, nlits + 1);
  for (i = 0; i < nlits; i++) clause->lits[i] = lits[i];
  clause->lits[i] = 0;
  clause->lit = nextclauselit++;
  nlits = 0;
}

static const char * parse (void) {
  int ch, idx, sign, cls, lits;
HEADER:
  ch = nextch ();
  if (ch == 'c') {
    while ((ch = nextch ()) != '\n')
      if (ch == EOF) return "end of file in comment";
    goto HEADER;
  }
  if (ch != 'p') return "expected header or comments";
  if (nextch () != ' ')
INVHEAD: return "expected 'p cnf <vars> <clauses>' header";
  while ((ch = nextch ()) == ' ')
    ;
  if (ch  != 'c') goto INVHEAD;
  if (nextch () != 'n') goto INVHEAD;
  if (nextch () != 'f') goto INVHEAD;
  if (nextch () != ' ') goto INVHEAD;
  while ((ch = nextch ()) == ' ')
    ;
  if (!isdigit (ch)) goto INVHEAD;
  nvars = ch - '0';
  while (isdigit (ch = nextch ())) nvars = 10*nvars + (ch - '0');
  if (ch != ' ') goto INVHEAD;
  while ((ch = nextch ()) == ' ')
    ;
  if (!isdigit (ch)) goto INVHEAD;
  nclauses = ch - '0';
  while (isdigit (ch = nextch ())) nclauses = 10*nclauses + (ch - '0');
  msg (0, "found 'p cnf %d %d' header", nvars, nclauses);
  if (!isws (ch)) return "expected white space after header";
  lits = idx = cls = 0;
  NEWN (clauses, nclauses);
  firstclauselit = nextclauselit = nvars + 1;
LIT:
  if ((isws (ch = nextch ()))) goto LIT;
  if (ch == EOF) {
    assert (cls <= nclauses);
    if (idx) return "terminating zero missing";
    if (cls < nclauses) return "clauses missing";
    msg (1, "parsed %d literals", lits);
    assert (nextclauselit == nvars + nclauses + 1);
    return 0;
  }
  if (ch == '-') {
    sign = -1;
    if (!isdigit (ch = nextch ()) || ch == '0')
      return "expected positive digit after '-'";
  } else {
    sign = 1;
    if (!isdigit (ch)) return "expected '-' or digit";
  }
  if (cls == nclauses) return "too many clauses";
  idx = ch - '0';
  while (isdigit (ch = nextch ())) idx = 10*idx + (ch - '0');
  if (!isws (ch)) return "expected white space after literal";
  if (idx > nvars) return "maximum variable index exceeded";
  if (idx) lits++, pushlit (sign*idx);
  else pushclause (cls++);
  goto LIT;
}

static AIG * notaig (AIG * a) { return (AIG*)(1l ^ (long) a); }
static AIG * stripaig (AIG * a) { return (AIG*)(~1l & (long) a); }
static int signaig (AIG * a) { return (int)(long)(1l & (long) a); }

static int aig2lit (AIG * a) {
  AIG * b;
  int res;
  if (a == TRUE) return truelit;
  if (a == FALSE) return -truelit;
  b = stripaig (a);
  res = b->lit;
  if (signaig (a)) res = -res;
  return res;
}

static int cmplit (int a, int b) {
  int res =  (abs (a) - abs (b));
  if (res) return res;
  return a - b;
}

static int cmpaig (AIG * a, AIG * b) {
  return cmplit (aig2lit (a), aig2lit (b));
}

static unsigned hashaig (int var, AIG * left, AIG * right) {
  unsigned res = var;
  res *= 12842491;
  res += aig2lit (left);
  res *= 568445461;
  res += aig2lit (right);
  res *= 33233087;
  return res & (szaigtable - 1);
}

static int matchaig (AIG * a, int var, AIG * left, AIG * right) {
  if (a->var != var) return 0;
  if (a->left != left) return 0;
  if (a->right != right) return 0;
  return 1;
}

static AIG ** lookup (int var, AIG * left, AIG * right) {
  AIG ** p, * a;
  int h;
  aigtablelookups++;
  assert (cmpaig (left, right) <= 0);
  h = hashaig (var, left, right);
  for (p = aigtable + h; (a = *p); p = &a->chain)
    if (matchaig (a, var, left, right)) break;
  return p;
}

static void enlargetable () {
  AIG ** oldtable = aigtable, * p, * chain;
  unsigned oldsize = szaigtable, h;
  szaigtable = szaigtable ? 2*szaigtable : 1;
  NEWN (aigtable, szaigtable);
  for (h = 0; h < oldsize; h++)
    for (p = oldtable[h]; p; p = chain) {
      chain = p->chain;
      p->chain = aigtable[h];
      aigtable[h] = p;
    }
  DELN (oldtable, oldsize);
}

static AIG * varaig (int lit) {
  int idx = abs (lit);
  AIG * res, ** p;
  if (naigs == szaigtable) enlargetable ();
  if (!(res = *(p = lookup (idx, 0, 0)))) {
    NEW (res);
    res->lit = res->var = idx;
    res->next = res->chain = res->left = res->right = 0;
    if (lastaig) lastaig->next = res;
    else firstaig = res;
    lastaig = res;
    naigs++;
  }
  if (lit < 0) res = notaig (res);
  return res;
}

static AIG * andaig (AIG * a, AIG * b) {
  AIG * res, ** p;
  if (a == FALSE || b == FALSE || a == notaig (b)) return FALSE;
  if (a == TRUE || a == b) return b;
  if (b == TRUE) return a;
  if (naigs == szaigtable) enlargetable ();
  if (cmpaig (a, b) > 0) SWAP (a, b);
  if (!(res = *(p = lookup (0, a, b)))) {
    NEW (res);
    res->lit = nextandlit++;
    res->var = 0;
    res->left = a;
    res->right = b;
    res->next = res->chain = 0;
    if (lastaig) lastaig->next = res;
    else firstaig = res;
    lastaig = res;
    naigs++;
  }
  return res;
}

static void releaseaigs () {
  AIG * p, * next;
  for (p = firstaig; p; p = next) { next = p->next; DEL (p); }
  DELN (aigtable, szaigtable);
}

static int counterbits (int n) {
  int res;
  assert (n >= 0);
  if (n <= 1) return 1;
  if (n <= 3) return 2;
  for (res  = 3; (1 << res) <= n; res++)
    ;
  assert ((1<<(res-1)) <= n && n < (1<<res));
  return res;
}

static AIG * oraig (AIG * a, AIG * b) {
  return notaig (andaig (notaig (a), notaig (b)));
}

static AIG * xoraig (AIG * a, AIG * b) {
  return oraig (andaig (a, b), andaig (notaig (a), notaig (b)));
}

static void  fulladder (AIG * x, AIG * y, AIG * i, AIG ** sptr, AIG ** optr) {
  *sptr = xoraig (xoraig (x, y), i);
  *optr = oraig (oraig (andaig (x, y), andaig (x, i)), andaig (y, i));
}

static int odd (int m) { return m & 1; }

static void countones (AIG ** x, int n, AIG ** s, int m) {
  AIG ** sl, ** sr, * cin, * cout;
  int n2, m1, i;
  assert (n >= 0);
  if (n == 0) {
    assert (m == 1);
    s[0] = FALSE;
  } else if (n == 1) {
    assert (m == 1);
    s[0] = x[0];
  } else if (n == 2) {
    fulladder (x[0], x[1], FALSE, s+0, s+1);
  } else if (n == 3) {
    fulladder (x[0], x[1], x[2], s+0, s+1);
  } else {
    n2 = n/2;
    m1 = m-1;
    NEWN (sl, m1);
    NEWN (sr, m1);
    countones (x + odd (n),      n2, sl, m1);
    countones (x + odd (n) + n2, n2, sr, m1);
    cin = odd (n) ? x[0] : FALSE;
    for (i = 0; i < m1; i++) {
      fulladder (sl[i], sr[i], cin, s + i, &cout);
      cin = cout;
    }
    s[m1] = cout;
    DELN (sl, m1);
    DELN (sr, m1);
  }
}

static void bin (int a, int b) {
  lgladd (lgl, a);
  lgladd (lgl, b);
  lgladd (lgl, 0);
}

static void trn (int a, int b, int c) {
  lgladd (lgl, a);
  lgladd (lgl, b);
  lgladd (lgl, c);
  lgladd (lgl, 0);
}

static void encbin (AIG * a, AIG * b) { bin (aig2lit (a), aig2lit (b)); }

static void enctrn (AIG * a, AIG * b, AIG * c) {
 trn (aig2lit (a), aig2lit (b), aig2lit (c));
}

static double pcnt (double a, double b) { return b ? 100.0 * (a / b) : 0.0; }

static double avg (double a, double b) { return b ? (a / b) : 0.0; }

#if 0
static int int2u (int i) { return 2*abs (i) + (i < 0); }

void dumpaig (AIG ** x, int n, AIG ** s, int m) {
  AIG * p;
  int i;
  printf ("aag %d %d 0 %d %d\n", lastaig->lit, n, m, nextandlit - firstandlit);
  for (i = 0; i < n; i++)
    printf ("%d\n", int2u (aig2lit (x[i])));
  for (i = 0; i < m; i++)
    printf ("%d\n", int2u (aig2lit (s[i])));
  for (p = firstaig; p; p = p->next)
    if (!p->var)
      printf ("%d %d %d\n", 
	      int2u (aig2lit (p)),
	      int2u (aig2lit (p->left)),
	      int2u (aig2lit (p->right)));
}
#endif

static AIG ** parencode (int * mptr) {
  int n = nclauses, m = counterbits (n), i, lit;
  int ivars, iclauses, addvars, addclauses;
  AIG ** x, ** s, * p;
  lgladd (lgl, (truelit = nvars + nclauses + 1)), lgladd (lgl, 0);
  nextandlit = firstandlit = truelit + 1;
  if (nclauses)
    msg (1, "clause selector variable range from %d to %d", 
	 firstclauselit, nextclauselit - 1);
  else
    msg (1, "no clause selector variables");
  msg (1, "%d counter bits", m);
  NEWN (x, n);
  NEWN (s, m);
  lit = firstclauselit;
  for (i = 0; i < n; i++) x[i] = varaig (lit++);
  assert (lit == nextclauselit);
  countones (x, n, s, m);
  // dumpaig (x, n, s, m);
  DELN (x, n);
  addclauses = 0;
  msg (1, "generated %u aigs (%u lookups)", naigs, aigtablelookups);
  for (p = firstaig; p; p = p->next) {
    if (p->var) continue;
    encbin (notaig (p), p->left);
    encbin (notaig (p), p->right);
    enctrn (notaig (p->left), notaig (p->right), p);
    addclauses += 3;
  }
  ivars = nextandlit - 1;
  iclauses = nclauses + addclauses;
  msg (0, "using %d variables and %d clauses altogether", ivars, iclauses);
  addvars = ivars - nvars;
  msg (0, "%d additional variables %.1f%% blow-up factor %.1f", 
       addvars, pcnt (addvars, ivars), avg (ivars, nvars));
  msg (0, "%d additional clauses %.1f%% blow-up factor %.1f", 
       addclauses, pcnt (addclauses, iclauses), avg (iclauses, nclauses));
  *mptr = m;
  return s;
}

static int deref (int lit) {
  int res = model [abs (lit)];
  if (lit < 0) res = -res;
  return res;
}

static int satisfied (const Clause * c) {
  const int * p;
  int lit;
  for (p = c->lits; (lit = *p); p++)
    if (deref (lit) > 0) return 1;
  return 0;
}

static int check () {
  int unsatisfied = 0;
  const Clause * p;
  for (p = clauses; p < clauses + nclauses; p++)
    if (!satisfied (p)) unsatisfied++;
  return unsatisfied;
}

static void releaseclauses () {
  Clause * p;
  int * q;
  for (p = clauses; p < clauses + nclauses; p++) {
    for (q = p->lits; *q; q++)
      ;
    DELN (p->lits, (q - p->lits) + 1);
  }
  DELN (clauses, nclauses);
}

static int seqlit (int c, int k) {
  assert (0 < k);
  assert (k-1 <= c && c < nclauses);
  return nextclauselit + nclauses*(k-1) + (k*(3 - k))/2 + c - k;
}

static int downseqsolve (int initialopt) {
  int lit, prev, down, addclauses, addvars, last, newopt, improvedopt;
  int k, c, opt, * q, res, i, sumvars, sumclauses;
  LGL * saved;
  Clause * p;
  assert (initialopt > 1);
  printf ("c initial down sequential %d\n", initialopt); fflush (stdout);
  lgl = lglminit (0,new,rsz,del);
  if (verbose) lglsetopt (lgl, "verbose", verbose);
  for (p = clauses; p < clauses + nclauses; p++) {
    for (q = p->lits; (lit = *q); q++) lgladd (lgl, lit);
    lgladd (lgl, p->lit);
    lgladd (lgl, 0);
    lglforcephase (lgl, -p->lit);
  }
  addclauses = addvars = 0;
  for (k = 1; k <= initialopt; k++) {
    for (c = k-1; c < nclauses; c++) {
      p = clauses + c;
      lit = seqlit (c, k);
      addvars++;
      if (c >= k) {
	prev = seqlit (c-1, k);
	bin (-prev, lit);
	addclauses++;
      }
      if (k == 1) {
	bin (-p->lit, lit);
	addclauses++;
      } else {
	down = seqlit (c-1, k-1);
	trn (-down, -p->lit, lit);
	addclauses++;
      }
    }
  }
  sumvars = addvars + nvars;
  sumclauses = addclauses + nclauses;
  msg (0, "using %d variables and %d clauses altogether", sumvars, sumclauses);
  msg (0, "%d additional variables %.1f%% blow-up factor %.1f", 
       addvars, pcnt (addvars, nvars), avg (sumvars, nvars));
  msg (0, "%d additional clauses %.1f%% blow-up factor %.1f", 
       addclauses, pcnt (addclauses, nclauses), avg (sumclauses, nclauses));
  opt = initialopt;
  last = nclauses - 1;
  for (k = 1; k <= opt; k++) lglfreeze (lgl, seqlit (last, k));
  while (opt > 1) {
    printf ("c trying sequential bound %d\n", opt); fflush (stdout);
    lit = seqlit (last, opt);
    lglassume (lgl, -lit);
    res = lglsat (lgl);
    if (res == 20) break;
    assert (res == 10);
    for (i = 1; i <= nvars; i++) 
      model[i] = (lglderef (lgl, i) > 0) ? 1 : -1;
    newopt = opt - 1;
    improvedopt = check ();
    if (improvedopt > newopt) die ("invalid model");
    opt = improvedopt;
    printf ("o %d\n", opt), fflush (stdout);
    lgladd (lgl, -lit); lgladd (lgl, 0);
    lglmelt (lgl, lit);
  }
  printf ("c final down sequential %d\n", opt);
  fflush (stdout);
  saved = lgl;
  lgl = 0;
  lglrelease (saved);
  return opt;
}

static int upseqsolve (int initialopt) {
  int lit, prev, down, addclauses, addvars, last, newopt, improvedopt;
  int k, c, opt, * q, res, i, sumvars, sumclauses;
  LGL * saved;
  Clause * p;
  assert (initialopt > 1);
  printf ("c initial sequential %d\n", initialopt); fflush (stdout);
  lgl = lglminit (0,new,rsz,del);
  if (verbose) lglsetopt (lgl, "verbose", verbose);
  for (p = clauses; p < clauses + nclauses; p++) {
    for (q = p->lits; (lit = *q); q++) lgladd (lgl, lit);
    lgladd (lgl, p->lit);
    lgladd (lgl, 0);
    lglforcephase (lgl, -p->lit);
  }
  opt = initialopt;
  last = nclauses - 1;
  addclauses = addvars = 0;
  for (c = 0; c < nclauses; c++) lglfreeze (lgl, clauses[c].lit);
  for (k = 1; k < initialopt; k++) {
    for (c = k-1; c < nclauses; c++) {
      p = clauses + c;
      lit = seqlit (c, k);
      lglfreeze (lgl, lit);
      addvars++;
      if (c >= k) {
	prev = seqlit (c-1, k);
	bin (-prev, lit);
	addclauses++;
      }
      if (k == 1) {
	bin (-p->lit, lit);
	addclauses++;
      } else {
	down = seqlit (c-1, k-1);
	trn (-down, -p->lit, lit);
	addclauses++;
      }
    }
    printf ("c trying sequential lower bound %d\n", k); fflush (stdout);
    lit = seqlit (last, k);
    lglassume (lgl, -lit);
    res = lglsat (lgl);
    if (res == 10) {
      for (i = 1; i <= nvars; i++) 
	model[i] = (lglderef (lgl, i) > 0) ? 1 : -1;
      newopt = k - 1;
      improvedopt = check ();
      if (improvedopt != newopt) die ("invalid model");
      opt = newopt;
      printf ("o %d\n", opt), fflush (stdout);
      break;
    }
    assert (res == 20);
    for (c = k-1; c < nclauses; c++) lglmelt (lgl, seqlit (c, k));
    lgladd (lgl, lit); lgladd (lgl, 0);
  }
  sumvars = addvars + nvars;
  sumclauses = addclauses + nclauses;
  msg (0, "using %d variables and %d clauses altogether", sumvars, sumclauses);
  msg (0, "%d additional variables %.1f%% blow-up factor %.1f", 
       addvars, pcnt (addvars, nvars), avg (sumvars, nvars));
  msg (0, "%d additional clauses %.1f%% blow-up factor %.1f", 
       addclauses, pcnt (addclauses, nclauses), avg (sumclauses, nclauses));
  printf ("c final up sequential %d\n", opt);
  fflush (stdout);
  saved = lgl;
  lgl = 0;
  lglrelease (saved);
  return opt;
}

static int parsolve (int initialopt) {
  int i, j, m, res, mask, opt, newopt, improvedopt, lit, * q;
  double time;
  LGL * saved;
  Clause * p;
  AIG ** s;
  assert (initialopt > 1);
  printf ("c initial parallel %d\n", initialopt); fflush (stdout);
  lgl = lglminit (0,new,rsz,del);
  if (verbose) lglsetopt (lgl, "verbose", verbose);
  for (p = clauses; p < clauses + nclauses; p++) {
    for (q = p->lits; (lit = *q); q++) lgladd (lgl, lit);
    lgladd (lgl, p->lit);
    lgladd (lgl, 0);
    lglforcephase (lgl, -p->lit);
  }
  s = parencode (&m);
  mask = (1 << m) - 1;
  assert (nclauses <= mask);
  opt = initialopt;
  for (i = m-1; i >= 0; i--) lglfreeze (lgl, aig2lit (s[i]));
  for (i = m-1; i >= 0; i--) {
    printf ("c ");
    for (j = m-1; j > i; j--)
      fputc ((opt & (1 << j)) ? '1' : '0', stdout);
    fputc ('?',  stdout);
    for (j = i-1; j >= 0; j--)
      fputc ('x', stdout);
    printf (" bit[%d]\n", i);
    fflush (stdout);
    lit = aig2lit (s[i]);
    time = lglprocesstime ();
    if ((opt & (1<<i))) {
      lglassume (lgl, -lit);
      res = lglsat (lgl);
    } else res = 0;
    printf ("c ");
    for (j = m-1; j > i; j--)
      fputc ((opt & (1 << j)) ? '1' : '0', stdout);
    fputc ((res <= 10) ? '0' : '1',  stdout);
    for (j = i-1; j >= 0; j--)
      fputc ('x', stdout);
    printf (" bit[%d] = %c", i, (res <= 10) ? '0' : '1');
    if (res) printf (" in %.3f seconds\n", lglprocesstime () - time);
    else printf (" skipped\n");
    fflush (stdout);
    mask >>= 1;
    if (!res) {
      lgladd (lgl, -lit), lgladd (lgl, 0);
    } else if (res == 10) {
      for (j = 1; j <= nvars; j++) 
	model[j] = (lglderef (lgl, j) > 0) ? 1 : -1;
      newopt = (opt & ~(1<<i)) | mask;
      improvedopt = check ();
      if (improvedopt > newopt) die ("invalid model");
      lgladd (lgl, -lit), lgladd (lgl, 0);
      opt = improvedopt;
      printf ("o %d\n", opt), fflush (stdout);
    } else {
      opt |= (1 << i);
      assert (res == 20);
      lgladd (lgl, lit), lgladd (lgl, 0);
    }
    lglmelt (lgl, lit);
  }
  releaseaigs ();
  DELN (s, m);
  assert (!mask);
  printf ("c ");
  for (j = m-1; j >= 0; j--)
    fputc ((opt & (1 << j)) ? '1' : '0', stdout);
  printf (" final bits\n");
  printf ("c final parallel %d\n", opt);
  fflush (stdout);
  saved = lgl;
  lgl = 0;
  lglrelease (saved);
  return opt;
}

static int ddsolve (int initialopt) {
  int granularity, nfrozen, start, end, mark, marked, i, lowerbound = -1;
  int * q, lit, idx, opt, newopt, improvedopt, res, incremental;
  Clause * p, * eoc = clauses + nclauses;
  Clause ** configs;
  char * frozen;
  int nconfigs;
  LGL * saved;
  if (!initialopt) return 0;
  printf ("c initial dd %d\n", initialopt); fflush (stdout);
  NEWN (configs, nclauses);
  NEWN (frozen, nvars + 1);
  granularity = nconfigs = nclauses;
  for (i = 0; i < nclauses; i++) configs[i] = clauses + i;
  opt = initialopt;
  mark = 1;
  while (opt > lowerbound + 1) {
    printf ("c granularity %d remaining %d\n", granularity, nconfigs);
    fflush (stdout);
    end = 0;
    while (opt > 0 && end < nconfigs) {
      start = end;
      end = start + granularity;
      if (end > nconfigs) end = nconfigs;
      marked = 0;
      for (i = start; i < end; i++)
	if (!(p = configs[i])->mark)
	  p->mark = mark, marked++;
      if (!marked) continue;
      if (lgl) {
	incremental = 1;
	for (lit = 1; lit <= nvars; lit++)
	  if (frozen[lit]) lglmelt (lgl, lit), frozen[lit] = 0;
      } else {
	incremental = 0;
	lgl = lglminit (0,new,rsz,del);
	if (verbose) lglsetopt (lgl, "verbose", verbose);
      }
      nfrozen = newopt = 0;
      for (p = clauses; p < eoc; p++) {
	if (p->mark) { 
	  if (incremental && p->mark < mark) continue;
	  for (q = p->lits; (lit = *q); q++) lgladd (lgl, lit);
	  lgladd (lgl, 0);
	} else {
	  newopt++;
	  for (q = p->lits; (idx = abs (*q)); q++) {
	    if (frozen[idx]) continue;
	    lglfreeze (lgl, idx);
	    frozen[idx] = 1;
	    nfrozen++;
	  }
	}
      }
      msg (1, "granularity %d start %d end %d marked %d frozen %d", 
           granularity, start, end, marked, nfrozen);
      res = lglsat (lgl);
      if (res == 20) {
	for (i = start; i < end; i++)
	  if ((p = configs[i])->mark == mark) 
	    p->mark = 0;
	if (marked == nclauses) {
	  lowerbound = 0;
	  printf ("c lower bound %d\n", lowerbound);
	  fflush (stdout);
	}
	saved = lgl; lgl = 0; lglrelease (saved);
	memset (frozen, 0, nvars + 1); 
      } else {
	for (lit = 1; lit <= nvars; lit++) 
	  model[lit] = (lglderef (lgl, lit) > 0) ? 1 : -1;
	improvedopt = 0;
	for (p = clauses; p < eoc; p++)
	  if (!satisfied (p)) improvedopt++;
	assert (improvedopt <= newopt);
	assert (check () == improvedopt);
	if (improvedopt < opt) {
	  opt = improvedopt;
	  printf ("o %d\n", opt); fflush (stdout);
	}
      }
      mark++;
    }
    if (granularity == 2) granularity = 1;
    else if (granularity == 1) break;
    else granularity = (granularity + 1)/2;
    nconfigs = 0;
    for (p = clauses; p < eoc; p++)
      if (!p->mark) configs[nconfigs++] = p;
  }
  if (lgl) { saved = lgl; lgl = 0; lglrelease (saved); }
  DELN (frozen, nvars + 1);
  DELN (configs, nclauses);
  printf ("c final dd %d\n", opt); fflush (stdout);
  return opt;
}

static void usage () {
  printf ("usage: mingeling [-h][-v][-n][-p][-u][-d][<input>]\n");
  exit (0);
}

int main (int argc, char ** argv) {
  const char * perr;
  int i, j, opt;
  for (i = 1; i < argc; i++) {
    if (!strcmp (argv[i], "-h")) usage ();
    else if (!strcmp (argv[i], "-v")) verbose++;
    else if (!strcmp (argv[i], "-n")) nowitness = 1;
    else if (!strcmp (argv[i], "-p")) forcepar = 1;
    else if (!strcmp (argv[i], "-u")) forceup = 1;
    else if (!strcmp (argv[i], "-d")) forcedown = 1;
    else if (argv[i][0] == '-') 
      die ("invalid command line option '%s' (try '-h')", argv[i]);
    else if (name) 
      die ("multiple input files '%s' and '%s'", name, argv[i]);
    else if (!(input = fopen ((name = argv[i]), "r")))
      die ("can not read '%s'", name);
    else clin = 1;
  }
  if (forceup && forcedown) die ("can not use '-d' and '-u'");
  if (forceup && forcepar) die ("can not use '-p' and '-u'");
  if (forcedown && forcepar) die ("can not use '-p' and '-d'");
  lglbnr ("Mingeling", "c ", stdout), printf ("c \n");
  if (!name) name = "<stdin>", input = stdin;
  setsighandlers ();
  msg (0, "parsing %s", name);
  if ((perr = parse ())) {
    printf ("%s:%d: parse error: %s\n", name, lineno, perr);
    fflush (stdout);
    exit (1);
  }
  if (clin) fclose (input);
  DELN (lits, szlits);
  NEWN (model, nvars + 1);
  for (j = 1; j <= nvars; j++) model[j] = -1;
  opt = nclauses;
  printf ("o %d\n", opt), fflush (stdout);
  opt = ddsolve (opt);
  if (opt > 1) {
    if ((!forcedown && !forceup && (opt > 50)) || forcepar)
      opt = parsolve (opt);
    else if (forcedown || (!forceup && opt > 10)) opt = downseqsolve (opt);
    else opt = upseqsolve (opt);
  }
  printf ("s OPTIMUM FOUND\n");
  if (!nowitness) {
    printf ("v");
    for (j = 1; j <= nvars; j++)
      printf (" %d", model[j]*j);
    printf ("\n");
    fflush (stdout);
  }
  DELN (model, nvars + 1);
  releaseclauses ();
  resetsighandlers ();
  if (verbose) stats ();
  assert (getenv ("LEAK") || !allocated.current);
  return 0;
}
