#include "malloc.h"
#include "assumptions.h"
#include "common.h"

FILE *cubes;
FILE *learnt;

int *trail;
int nrofDnodes;
int Dnodes_size;
struct Dnode *Dnodes;

int Dnode_left( int index )
{        return Dnodes[ index ].left; }

int Dnode_right( int index )
{        return Dnodes[ index ].right; }

void Dnode_setType( int index, int type )
{        Dnodes[ index ].type = type; }

void Dnode_setDecision( int index, int decision )
{        Dnodes[ index ].decision = decision; }

void Dnode_close( int index )
{
	if( (Dnodes[ Dnodes[ index ].left ].type == REFUTED_DNODE) && (Dnodes[ Dnodes[ index ].right ].type == REFUTED_DNODE) )
		Dnodes[ index ].type = REFUTED_DNODE;
	else
		Dnodes[ index ].type = INTERNAL_DNODE;
}

int Dnode_new()
{        
	nrofDnodes++;
//	Dnodes[ nrofDnodes ].index = nrofDnodes;
	Dnodes[ nrofDnodes ].type  = REFUTED_DNODE;

	return nrofDnodes; 
}

void Dnode_init( int index )
{
	Dnodes[ index ].index = index;
        Dnodes[ index ].left  = Dnode_new();
        Dnodes[ index ].right = Dnode_new();
//	Dnodes[ index ].decision  = 0;
	Dnodes[ index ].type  = INTERNAL_DNODE;

	if( nrofDnodes + 3 > Dnodes_size )
	{
	    int i;
	    Dnodes = (struct Dnode*) realloc( Dnodes, sizeof(struct Dnode) * Dnodes_size * 2 );
	    for( i = Dnodes_size; i < 2*Dnodes_size; i++ )
	    {
	        Dnodes[ i ].index = 0;
	        Dnodes[ i ].left = 0;
	        Dnodes[ i ].right = 0;
	        Dnodes[ i ].decision = 0;
	        Dnodes[ i ].type = 0;
	    }
	    Dnodes_size *= 2;
	}

//	printf("c Dnodes %i\n", nrofDnodes );
}

void init_assumptions()
{
	int i;

	nrofDnodes = 1;	

	Dnodes_size = 100;
	Dnodes = (struct Dnode*) malloc( sizeof(struct Dnode) * Dnodes_size );
	for( i = 0; i < Dnodes_size; i++ )
	{
	    Dnodes[ i ].index = 0;
	    Dnodes[ i ].left = 0;
	    Dnodes[ i ].right = 0;
	    Dnodes[ i ].decision = 0;
	    Dnodes[ i ].type = 0;
	}
}

void printDecisionNode( struct Dnode Dnode, int depth, int discrepancies, int max_dis )
{
  int i;
	if( Dnode.type == CUBE_DNODE )
	{
	    if( max_dis == -1 || discrepancies == max_dis )
	    {
	    	fprintf(cubes, "a ");
	    	for( i = 0; i < depth; i++ )
		    fprintf(cubes, "%d ", trail[ i ] );
	    	fprintf(cubes, "0\n" );
	    }
	    return;
	} 

	if( Dnodes[ Dnode.left ].type == REFUTED_DNODE )
	{
	    if( max_dis == -1 || discrepancies == max_dis )
	    {
              printf("c Dnode %i is REFUTED %d\n", Dnode.left, Dnodes[ Dnode.left ].decision);
	        for( i = 0; i < depth; i++ )
		    fprintf(learnt, "%d ", -trail[ i ] );
	        fprintf(learnt, "%d 0\n", -Dnodes[ Dnode.left ].decision );
	    }
		printDecisionNode( Dnodes[ Dnode.right ], depth, discrepancies, max_dis );
		return;
	}

	if( Dnodes[ Dnode.right ].type == REFUTED_DNODE )
	{
	    if( max_dis == -1 || discrepancies == max_dis )
	    {
              printf("c Dnode %i is REFUTED %d\n", Dnode.right, Dnodes[ Dnode.left ].decision);
	        for( i = 0; i < depth; i++ )
		    fprintf(learnt, "%d ", -trail[ i ] );
	        fprintf(learnt, "%d 0\n", -Dnodes[ Dnode.right ].decision );
	    }
		printDecisionNode( Dnodes[ Dnode.left ], depth, discrepancies, max_dis );
		return;
	}

#ifndef FLIP_ASSUMPTIONS
	trail[ depth ] = Dnodes[ Dnode.left ].decision;
	printDecisionNode( Dnodes[ Dnode.left ], depth + 1, discrepancies+1, max_dis );
#endif
	trail[ depth ] = Dnodes[ Dnode.right ].decision;
	printDecisionNode( Dnodes[ Dnode.right ], depth + 1, discrepancies, max_dis );
#ifdef FLIP_ASSUMPTIONS
	trail[ depth ] = Dnodes[ Dnode.left ].decision;
	printDecisionNode( Dnodes[ Dnode.left ], depth + 1, discrepancies+1, max_dis );
#endif

}

void printUNSAT( )
{
	cubes  = fopen ("/tmp/cubes", "w");
	learnt = fopen ("/tmp/learnt",  "w");

	fprintf(learnt, "0\n");
	fprintf(cubes, "a 0\n");

	fclose(cubes);
	fclose(learnt);
}

void printFULL( )
{
	cubes  = fopen ("/tmp/cubes", "w");
	learnt = fopen ("/tmp/learnt",  "w");

	fprintf(cubes, "a 0\n");

	fclose(cubes);
	fclose(learnt);
}

void printDecisionTree( )
{
/*	
  int i;
	int discrepancy_search = 0;
        
#ifdef DISCREPANCY_SEARCH
	discrepancy_search = 1;
#endif
	if( nr_cubes > 200000 ) discrepancy_search = 1;

	if( Dnodes[1].type == REFUTED_DNODE )
	    return printUNSAT();

//	if( conflicts == 0 )
//	    return printFULL();
	trail = (int*) malloc(sizeof(int) * nrofvars );

	for( i = 0; i < nrofvars; i++ ) trail[ i ] = 0;

	cubes  = fopen ("tmp/cubes", "w");
	learnt = fopen ("tmp/learnt",  "w");
        
	printf("c print learnt clauses and cubes\n");

	if( discrepancy_search )
	{
	    for( i = 0; i <= 100; i++)
	        printDecisionNode( Dnodes[1], 0, 0, i);
	}
	else printDecisionNode( Dnodes[1], 0, 0, -1);

	fclose(cubes);
	fclose(learnt);
        
	free(trail);*/
}
