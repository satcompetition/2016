
/*
#ifndef treee
#define treee
#include "tree.h"
#endif

Node* racine = NULL;
Node* pos = NULL;
bool unsat = false;

int nb_cubes_total = 0;
int nb_cubes = 0;

int tree_get_nb_cubes_total(){return nb_cubes_total;}
int tree_get_nb_cubes(){return nb_cubes;}

void tree_set_nb_cubes_total(int val){nb_cubes_total=val;}
void tree_set_nb_cubes(int val){nb_cubes=val;};



void display_branch_left_rec(Node* n){
  printf("%d ",n->value);
  if(n->right_child){
    display_branch_left_rec(n->right_child);
  }
}


void tree_cut(Node* erase){
  if(erase->left_child)
    tree_cut(erase->left_child);
  if(erase->right_child)
    tree_cut(erase->right_child);
  //printf("CUT:%d\n",erase->value);
  if(erase->value == -1)
    nb_cubes--;
  delete erase;  
}


Node* tree_get_node_racine(){return racine;}

void setRacine(Node *r){racine = r;}

int tree_get_racine(){return racine->value;}
int tree_get_pos(){return pos->value;}

void tree_set_pos_left(){pos = pos->left_child;}
void tree_set_pos_right(){pos = pos->right_child;}
void tree_set_pos_racine(){pos = racine;}
void tree_cut_pos(){tree_cut(pos);}

bool is_unsat(){return unsat;}

void tree_cut_verif_father(Node* fat){
  Node* father = fat;
  while(father)
    {
    if(father->left_child==NULL && father->right_child==NULL)
      {
        Node* tmp_father = father;
        if(father->father == NULL)
          {// C'est que l'on met la racine a NULL : c'est UNSAT
            unsat = true;
            return;
          }
        father=father->father;
        if(father->left_child != NULL && father->left_child == tmp_father){
          father->left_child = NULL;
        }
        if(father->right_child != NULL && father->right_child == tmp_father){
          father->right_child = NULL;
        }
        //printf("CUT:%d\n",tmp_father->value);
        tree_cut(tmp_father);
      }
    else
      {
        break;
      }
  }
}


void tree_cut_father(){
  if(pos->father == NULL)
    {// C'est que l'on met la racine a NULL : c'est UNSAT
      unsat = true;
      return;
    }

  if(pos == NULL){
    printf("BUG : JE SAIS PAS SI C'EST POSSIBLE !\n");
  }

  if(pos->left_child != NULL){
    tree_cut(pos->left_child);
    pos->left_child = NULL;
  }

  if(pos->right_child != NULL){
    tree_cut(pos->right_child);
    pos->right_child = NULL;
  }

  tree_cut_verif_father(pos);


  printf("[TREE] nb_cubes : %d\n", nb_cubes);
}

void tree_cut_pos_left(){
  if(pos->left_child != NULL){
    tree_cut(pos->left_child);
    pos->left_child = NULL;
  }
  
  tree_cut_verif_father(pos);

  printf("[TREE] nb_cubes : %d\n", nb_cubes);
}


void tree_cut_pos_right(){
  if(pos->right_child != NULL){
    tree_cut(pos->right_child);
    pos->right_child = NULL;
  }

  tree_cut_verif_father(pos);

  printf("[TREE] nb_cubes : %d\n", nb_cubes);
}


int tree_get_pos_left(){return pos->left_child->value;}
int tree_get_pos_right(){return pos->right_child->value;}

Node* tree_pos_left(){return pos->left_child;}
Node* tree_pos_right(){return pos->right_child;}


void tree_set_pos(int new_pos){pos->value = new_pos;}


void tree_add_racine(int value){
  if(racine == NULL)racine = new Node(value, NULL, NULL, NULL); 
}


Node* tree_add(int value, Node* node, bool direction)
{
  // Création de notre nouveau noeud en mémoire
  Node* new_node = new Node(value, NULL, NULL, node);
  
  if(direction) node->right_child = new_node; else node->left_child = new_node;      
  //if(value == -1) nb_cubes_total++;
  
  return new_node;
}// tree_add
*/
/*
 *0 : affiche le cube le plus a gauche
 *1 : affiche le cube le plus a droite
 *2 : affiche un cube aléatoirement
 */



/*
void tree_display(int rank){
  
  //printf("[TREE] Display :");
  //display_branch_left_rec(racine);
  //printf("\n");
  printf("[SCOUT %d]0:%d\n",rank,racine->value);
  printf("[SCOUT %d]1:",rank);
  display_tree_largeur_rec(racine,1,0);
  printf("\n"); 
  printf("[SCOUT %d]2:",rank);
  display_tree_largeur_rec(racine,2,0);
  printf("\n"); 
  printf("[SCOUT %d]3:",rank);
  display_tree_largeur_rec(racine,3,0);
  printf("\n"); 

}
*/
/*
void tree_add_tab2(int* tab, int size){
  
  
   printf("[SCOUT X]CREATE TREE FOR :\n");
  for(int i = 0;i < size;i++)printf("%d ",tab[i]);
  printf("\n");
  printf("ess:");
  display_branch_left_rec(racine);
  printf("\n"); 
  printf("1:");
  display_tree_largeur_rec(racine,1,0);
  printf("\n"); 
  printf("2:");
  display_tree_largeur_rec(racine,2,0);
  printf("\n"); 
  printf("3:");
  display_tree_largeur_rec(racine,3,0);
  printf("\n"); 

  printf("4:");
  display_tree_largeur_rec(racine,4,0);
  printf("\n"); 

  printf("5:");
  display_tree_largeur_rec(racine,5,0);
  printf("\n"); 
  
  printf("6:");
  display_tree_largeur_rec(racine,6,0);
  printf("\n"); 
 
}
*/


