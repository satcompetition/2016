
#include <vector>
#include "mpi.h"
#include <sys/time.h>

class VirtualScout{
 public:
  VirtualScout(int argc, char** argv);
  
  int start();
  int start(int* cube);

  void add_learn_clause(int*clause, int size);
  
  void backtrack();
  void restart();
  
  char is_assigned(const int& variable);
  int decision_propagate(const int& variable, const char& polarity);
  
  int nb_vars();
  
  int getMPThread();
  int getMPCore();
};
