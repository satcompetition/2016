
#include "../../define.h"

#include "mpi.h"
#include <stdint.h>

#ifndef virscout
#define virscout
#include "VirtualScout.h"
#endif

#ifndef treee
#define treee
#include "tree.h"
#endif

#include <vector>


struct hash_clauses{
  int* addr;
  uint64_t hash;
  int size;
  int nb_visit;
};

class Scout{
 public: 
  inline static int get_nb_process(){return nb_process;}
  inline static int get_nb_workers(){return nb_workers;}
  inline static int get_nb_scouts(){return nb_scouts;}
  inline static const int get_rank() {return rank;}
  inline static int get_rank_worker(const int& num){return num+1;}
  inline static int get_type(){return type;}

  //For real and cpu time
  inline static void init_wall_time(){start_wall_time = wall_time();}
  
  inline static double wall_time(){
    struct timeval time;
    if (gettimeofday(&time,NULL)){return 0;}
    return (double)time.tv_sec + (double)time.tv_usec * .000001;
  }
  
  static double sum_wall_time;
  static double sum_wall_time2;
  static double sum_wall_time_msg;

  inline static double get_wall_time(){
    return wall_time()-start_wall_time;
  }

  inline static double get_avg_depth_unsat()
  {
    if(!nb_depth_unsat)
      return -1;
    return sum_depth_unsat/(double)nb_depth_unsat; 
  }
  
  inline static double get_log_int(int x){
    int cpt = 0;
    while(x>>cpt)cpt++;
    return (double)cpt;
  }

  inline static void display_stats(const char* raison){
    static bool first = true;
    int nb_glu_extend=0; 
    int nb_mini_extend=0; 
    int nb_minipsm_extend=0; 
    int nb_glu_unsat=0; 
    int nb_mini_unsat=0; 
    int nb_minipsm_unsat=0; 

    int nb_c_glu = 0;
    int nb_c_mini = 0;
    int nb_c_miniPsm = 0;

    for(int w = 0;w < nb_workers;w++){
      switch (type_of_workers[w])
      {
      case W_GLUCOSE:
        nb_glu_extend+=type_of_workers_extend[w];
        nb_glu_unsat+=type_of_workers_unsat[w];
        nb_c_glu+=nb_clauses_received_by_workers[w];
        break;
      case W_MINISAT:
        nb_mini_extend+=type_of_workers_extend[w];
        nb_mini_unsat+=type_of_workers_unsat[w];
        nb_c_mini+=nb_clauses_received_by_workers[w]; 
        break;
      case W_MINISATPSM:
        nb_minipsm_extend+=type_of_workers_extend[w];
        nb_minipsm_unsat+=type_of_workers_unsat[w];
        nb_c_miniPsm+=nb_clauses_received_by_workers[w];
        break;
      }
    }
    if(first){
      first = false;
        fprintf(stderr,"[S] _____________________________________________________________________________________________________________ \n");
        fprintf(stderr,"[S]|        |       |__SHARED_UNITS LITERAL_|____SHARED CLAUSES_________________________|_________UNSAT_________|\n");
        fprintf(stderr,"[S]| REASON | CUBES |  UL0  |  ULN  |  ULT  | RECEIVED |   KEEP   |  FACTOR | DELETED | SENT ALL |   G   |   M   |  MPSM |\n");
        fprintf(stderr,"[S]|________|_______|_______|_______|_______|__________|__________|________|__________|__________|_______|_______|_______|\n");
    }
    
    int min_pos_worker = size_clauses;
    for(int w = 0; w < nb_workers;w++)
      if(pos_workers_for_clauses_sent[w] < min_pos_worker)min_pos_worker=pos_workers_for_clauses_sent[w];
    
    nb_clauses_sent = 0;
    for(int i = 0; i < min_pos_worker;i++)
      if(clauses[i]==LIMIT_BETWEEN_CLAUSES)nb_clauses_sent++;
   

    //if(nb_clauses_keep)
    // ratio = (double)nb_clauses_received/(double)nb_clauses_keep;
    const int ult = tree->get_units_literals();
    const int ul0 = tree->get_units_literals_racine();
    const int uln = ult-ul0;
    
    fprintf(stderr,"[S]| %6s | %5d | %5d | %5d | %5d |%10d|%10d|%8f|%10d|%10d|%7d|%7d|%7d|%4f\n"
           ,raison,tree->get_nb_cubes()
           ,ul0, uln, ult
           ,nb_clauses_received, nb_clauses_keep, ratio,nb_clauses_deleted,nb_clauses_sent
           //,nb_c_glu,nb_c_mini,nb_c_miniPsm
           ,nb_glu_unsat,nb_mini_unsat,nb_minipsm_unsat,get_wall_time());
    //fprintf(stderr,"ADD UL SPE %d\n",tree->get_add_spe_UL());
    //printf("ESS %d\n",nb_spe_max);
    /*
    for(int i =0;i<nb_workers;i++)
      printf("%d ",stats_workers[i]);
    printf("\n");
    */
    
  }

  inline static void display_workers_extend(){
    int nb_glu=0; 
    int nb_mini=0; 
    int nb_minipsm=0; 
    for(int w =0;w < nb_workers;w++){
      if(type_of_workers[w] == W_GLUCOSE)
        nb_glu+=type_of_workers_extend[w];
      else if(type_of_workers[w] == W_MINISAT)
        nb_mini+=type_of_workers_extend[w];
      else if(type_of_workers[w] == W_MINISATPSM)
        nb_minipsm+=type_of_workers_extend[w];
    }
    //printf("[SCOUT %d]EXTEND : %d %d %d\n",rank,nb_glu,nb_mini,nb_minipsm);
    //printf("[SCOUT %d]UL0 : %d\n",rank,tree->get_units_literals_racine());
  }
  

  inline static void display_workers_unsat(){
    int nb_glu=0; 
    int nb_mini=0; 
    int nb_minipsm=0; 
    for(int w =0;w < nb_workers;w++){
      if(type_of_workers[w] == W_GLUCOSE)
        nb_glu+=type_of_workers_unsat[w];
      else if(type_of_workers[w] == W_MINISAT)
        nb_mini+=type_of_workers_unsat[w];
      else if(type_of_workers[w] == W_MINISATPSM)
        nb_minipsm+=type_of_workers_unsat[w];
    }
    //printf("[SCOUT %d]UNSAT : %d %d %d\n",rank,nb_glu,nb_mini,nb_minipsm);
    //printf("[SCOUT %d]UL0 : %d\n",rank,tree->get_units_literals_racine());
  }

  inline static void display_workers_type(){
    int nb_glu=0; 
    int nb_mini=0; 
    int nb_minipsm=0; 
    for(int w =0;w < nb_workers;w++){
      if(type_of_workers[w]== W_GLUCOSE)
        nb_glu++;
      else if (type_of_workers[w]== W_MINISAT)
        nb_mini++;
      else if (type_of_workers[w]== W_MINISATPSM)
        nb_minipsm++;
    }
    printf("[SCOUT %d]TYPE : %d %d %d\n",rank,nb_glu,nb_mini,nb_minipsm);
  }

  //methods call for resolution
  static void intern_main();

  //methods call for cube creation
  static void intern_create_tree(std::vector<int>& tabVarSelect);
  inline static int intern_get_tree_size(){return tree->get_size();}

  inline static void delete_and_stop_workers(Node* the_node){

    // We recuperate all workers that must be going to stop and the node which must be going to delete 
    std::vector<int> recuperate_workers;
    Node* to_delete_node = the_node->recuperate_workers_of_nodes_to_delete(recuperate_workers);

#ifdef DEBUG_DELETE_WORKERS
    printf("[SCOUT %d]Delete Node : %d\n",rank,to_delete_node->value);
    printf("[SCOUT %d]WORKER TOTAL (%d):",rank,(int)recuperate_workers.size());
    for (std::vector<int>::const_iterator i = recuperate_workers.begin(); i != recuperate_workers.end(); ++i){
      printf("%d ",*i);
    }
    printf("\n");
#endif
    
    //We stop these workers
    if(!recuperate_workers.empty())
      for (std::vector<int>::const_iterator i = recuperate_workers.begin(); i != recuperate_workers.end(); ++i)
        stop_worker(*i);
      
    //We remove the good node with its children

#ifdef DOT
    int value = to_delete_node->value;
#endif
    
    
    Node* father = to_delete_node->father;
    to_delete_node->deleteNode(); 
    
    if(father && father->puch_up_units_literals(father)){
      fprintf(stderr,"[SCOUT %d]NODE UNSAT BY UNITS LITERALS IN DELETE\n",rank);
      Node* tmp_father = father;
      Node* last_UNSAT = NULL;
      do{
        if(tmp_father->verif_unsat_by_UL())
          last_UNSAT = tmp_father;
        
        tmp_father=tmp_father->father;
      }while(tmp_father);

      delete_and_stop_workers(last_UNSAT);
    }
      

#ifdef DOT
    char buffer [200];
    sprintf(buffer, "DELETING_NODE => %d\\nCUBES => %d", value,tree->get_nb_cubes());
    tree->write_tree_dot(get_wall_time(),buffer);
#endif
    display_stats("UNSAT");
    
    extern_UNSAT();
  }

  inline static void stop_worker(const int w){
    //printf("[SCOUT %d]STOP AT ONCE [WORKER %d]\n",rank,get_rank_worker(w));
    
    //send_worker(w,MSG_STOP_AT_ONCE);
    node_per_worker[w]->dec_nb_workers();
    node_per_worker[w]=NULL;
   
  }

  inline static void extern_UNSAT(){
    if(tree->is_unsat()){
      fprintf(stderr,"[SCOUT %d]UNSATISFIABLE BY THE TREE(%s)\n",rank,type_name);
#ifdef DOT
      tree->write_tree_dot(get_wall_time(),"UNSATISFIABLE");
#endif        
      send_master(MSG_UNSAT);
      //extern_kill();
    }
  }
  
  inline static bool is_worker_to_NULL(const int w){
    if(node_per_worker[w] == NULL){
#ifdef VERB 
      printf("[SCOUT %d][WORKER %d] STOP AT ONCE\n",rank,get_rank_worker(w));
#endif 
      send_worker(w,MSG_STOP_AT_ONCE_YES);
      return true;
    }
    send_worker(w,MSG_STOP_AT_ONCE_NO);
    return false;
  }

  

  /**
   * Select an unaffected variable in a set given in parameter.     
   *  @param[in] setOfPossibleVariable, a set of variable.
   * \return a variale not assigned in setOfPossibleVariable else TREE_END_CUBE
   */
  static inline int selectVariable(std::vector<int> &setOfPossibleVariable)
  {
    for(unsigned int i = 0 ; i<setOfPossibleVariable.size() ; i++) 
      if(solver->is_assigned(setOfPossibleVariable[i]) == VAR_NOT_ASSIGNED) 
        return setOfPossibleVariable[i];
    return TREE_END_CUBE;
  }
  
  static Node* build_tree(std::vector<int> &setOfPossibleVariable, Node *father = NULL);


  //methods call for no resolution
  static void extern_all(int argc, char** argv,const int n_type,const int n_tree_height,const char* n_typeName
                         ,const int n_type_com, const int n_type_extend);
  static void extern_listen();
  static void extern_listen_master();
  static void extern_listen_workers();
  static Node* extern_listen_for_send_cube(Node* current_node, const int w);
  static void extern_cube_UNSAT_by_scout(Node* my_cube);
  //methods called when a worker answer something concerning his resolution  
  static void extern_recup_solution(int sol);
  static void extern_cut_assertif(int w, int assertif_lit);  
  static void extern_stop_workers(Node* the_node);
  
  static void main_send_cube(const int& w);


  inline static void extern_kill(){
    //printf("[Scout %d]BEFORE EXTERN KILL\n",rank); 

    //On vide les messages
    bool ok = true;
    while(ok){
      bool mess = false; 
      for(int w = 0;w < nb_workers;w++)
        {//Ecoute des workers
          MPI_Test(request_workers+w,flag_workers+w,MPI_STATUS_IGNORE);
          if(flag_workers[w])
            {//si un message est recu d'un worker
              printf("BUG MESSAGE KILL: WORKER %d : %d\n",get_rank_worker(w),message_workers[w]);
             
              mess = true;
              if(message_workers[w] == MSG_GIVE_MY_SONS){
                send_worker(w, MSG_KILL_SPE);
                send_worker(w, MSG_KILL_SPE);
              }else if(message_workers[w] == MSG_GO_ROOT){
                send_worker(w, MSG_KILL_SPE);
              }

              init_listen_worker(w);
            }
        }
      MPI_Test(&request_master,&flag_master,MPI_STATUS_IGNORE);
      if(flag_master)
        { 
          printf("BUG MESSAGE KILL: MASTER %d : %d\n",0,message_master);
          mess = true;
          init_listen_master();
        }      
      if(!mess)ok=false;
    }
    
    MPI_Finalize();
    //printf("[Scout %d]EXTERN KILL\n",rank); 
    exit(0);
  }


  


  //MPI macro for send/receive message
  inline static void init_listen_master(){
    flag_master=0;
    MPI_Irecv(&message_master, 1, MPI_INT, rank_master, TAG_M_SEND_S_MODE, MPI_COMM_WORLD,&request_master); 
  }

  inline static void init_listen_worker(const int& i){
    flag_workers[i]=0;
    MPI_Irecv(message_workers+i, 1, MPI_INT, get_rank_worker(i), TAG_W_SEND_S_MODE, MPI_COMM_WORLD,request_workers+i);
  }

  inline static void send_master(const int& message){
    MPI_Send(&message, 1, MPI_INT, rank_master, TAG_S_SEND_M_MODE, MPI_COMM_WORLD); 
  }


 
  inline static void send_worker_node(const int& w,const Node* my_node){
    if(my_node){
      send_worker(w, my_node->value);
      send_worker(w, my_node->nb_cubes);
      send_worker(w, my_node->nb_workers);
    }else{
      send_worker(w, TREE_CONFLICT);
    }
  }  

  inline static void send_worker_double(const int& worker,const double& message){
    //printf("[SCOUT %d]SEND %d at worker %d\n",rank,message,get_rank_worker(worker));
    MPI_Send(&message, 1, MPI_DOUBLE, get_rank_worker(worker), TAG_S_SEND_W_MODE, MPI_COMM_WORLD); 
  }


  inline static void send_worker(const int& worker,const int& message){
    //printf("[SCOUT %d]SEND %d at worker %d\n",rank,message,get_rank_worker(worker));
    MPI_Send(&message, 1, MPI_INT, get_rank_worker(worker), TAG_S_SEND_W_MODE, MPI_COMM_WORLD); 
  }


  inline static int receive_worker(const int& worker){
    int message = 0;
    MPI_Recv(&message, 1, MPI_INT, get_rank_worker(worker), TAG_W_SEND_S_MODE, MPI_COMM_WORLD,MPI_STATUS_IGNORE);
    return message;
  }
 

  


  inline static void print_literals(Node* my_node){
    std::vector<int>& my_units_literals = my_node->units_literals;
    printf("[SCOUT %d]racine UL :",rank);
    for(int i =0;i < (int)my_units_literals.size();i++)
      printf("%d ",my_units_literals[i]);
    printf("\n");
  }

  inline static void print_receive_literals_lim(int w){
    printf("[SCOUT %d] LIT_TRAIL OF [WORKER %d] :",rank, get_rank_worker(w));
    int i = 0;
    for(; i < size_receive_literals_lim ;i++){
      printf("%d : %d - ",i,receive_literals_lim[i]);
    }
    printf("%d : %d - ",i,size_receive_literals);
    printf("END\n");
  }

  inline static bool add_units_literals(Node* my_node,const int& start, const int& end){
    for(int i = start; i < end;i++)
      if(my_node->add_unit_literal(receive_literals[i]))return true;
    return false;
  }

  inline static bool add_all_units_literals(Node* my_node){
    if(size_receive_literals_lim != my_node->get_depth()){
      my_node->display_cube(NULL);
      printf("Problème: %d %d\n",size_receive_literals_lim,my_node->get_depth());
      exit(0);
    }
    int pos = size_receive_literals_lim-1;
    int start = receive_literals_lim[pos];
    int end = size_receive_literals;
    Node* current_node = my_node;
    for(;;)
    {
      while(current_node->adjacent_is_NULL()){
        //printf("voisin NULL pass noded: %d\n",current_node->value);
        current_node=current_node->father;
      
        
        pos--;
        start = (pos==-1)?0:receive_literals_lim[pos];
        //start = receive_literals_lim[pos];
        //printf("voisin NULL new start : %d\n",start);
      }
          
      //printf("pos : %d\n",pos);
      //printf("node : %d start : %d - end : %d\n",current_node->value,start,end);
      
      if(add_units_literals(current_node,start,end))
        {//this node is UNSAT
          printf("[SCOUT %d]NODE UNSAT BY UNITS LITERALS ADD\n",rank);
          Node* tmp_father = current_node;
          Node* last_UNSAT = NULL;
          do{
            if(tmp_father->verif_unsat_by_UL())
              last_UNSAT = tmp_father;
            
            tmp_father=tmp_father->father;
          }while(tmp_father);

          delete_and_stop_workers(last_UNSAT);
          return true;
        }
      
      if(pos==-1)return false;
      pos--;
      start = (pos==-1)?0:receive_literals_lim[pos];
      end = receive_literals_lim[pos+1];
      current_node=current_node->father;
    }   
    return false;
    //add_units_literals(tree->get_racine(),0,receive_literals_lim[0]);
  }


  inline static void send_worker_clauses(const int& worker){
    const int size = lim_clauses-pos_workers_for_clauses_sent[worker];
    const int* addr_depart = clauses+pos_workers_for_clauses_sent[worker];
    if(size)
    {// C'est qu'il y a des clauses a envoyées
      send_worker(worker,MSG_START_CLAUSES);
      send_worker(worker,size);
      /*int nb_c = 0;
      for(int j = pos_workers_for_clauses_sent[worker]; j < lim_clauses;j++){
        if(clauses[j] == -1)nb_c++;
      }
      printf("[SCOUT %d]send %d clauses (%d) to [WORKER %d]\n",rank,nb_c,size,get_rank_worker(worker));*/
      MPI_Send(addr_depart,size-1
               ,MPI_INT, get_rank_worker(worker), TAG_S_SEND_W_MODE, MPI_COMM_WORLD);
      pos_workers_for_clauses_sent[worker]=lim_clauses;
    }
    else
      send_worker(worker,MSG_NO_START_CLAUSES);   
  }


/*
  inline static void send_worker_clauses(const int& worker){
#ifdef DEBUG_SHARES_CLAUSES
    printf("[SCOUT %d]Envoye du packet %d au [WORKER %d]\n",rank,pos_pack,get_rank_worker(worker));
#endif
    send_worker(worker,size_receive_clauses[pos_pack]);
    MPI_Send(receive_clauses[pos_pack]
               ,size_receive_clauses[pos_pack]
               ,MPI_INT, get_rank_worker(worker), TAG_S_SEND_W_MODE, MPI_COMM_WORLD);
               }*/
  

  
  inline static void receive_worker_clauses(const int& worker){ 
#ifdef DEBUG_SHARES_CLAUSES
    printf("[SCOUT %d]receive_worker_clauses\n",rank);
#endif
    const int size = receive_worker(worker);
    if(size)
      {
        //Suppression des clauses checks ou/et aggrandissement du tableau
        if(buffer_reveived_clauses_lim >= buffer_reveived_clauses_size-1){

          if(buffer_reveived_clauses_checks < 100000000){
            printf("subsum 100000\n");
            add_buffer_to_clauses(100000);    
          }
          if(buffer_reveived_clauses_checks){
            int j = 0;
            for(int i = buffer_reveived_clauses_checks; i < buffer_reveived_clauses_lim; i++,j++){
              buffer_reveived_clauses[j] = buffer_reveived_clauses[i];
            }
            buffer_reveived_clauses_checks = 0;
            buffer_reveived_clauses_lim = j+1;
            printf("New buffer : %d / %d \n",buffer_reveived_clauses_lim,buffer_reveived_clauses_size);
          }else{
            printf("Extend memory scout received clauses MÉMOIRE PLEINE\n");
            exit(0);
          }
        }
           
 
        //Update nb_clauses_received
        const int nb_c = receive_worker(worker); 
        nb_clauses_received+=nb_c;
        (nb_clauses_received_by_workers[worker])+=nb_c;
      
        
        MPI_Recv(buffer_reveived_clauses+buffer_reveived_clauses_lim,size
                 , MPI_INT, get_rank_worker(worker)
                 , TAG_W_SEND_S_MODE
                 , MPI_COMM_WORLD
                 , MPI_STATUS_IGNORE);
      
        buffer_reveived_clauses_lim+=size;
      
        //printf("[SCOUT %d]receive %d clauses (%d) by [WORKER %d] lim : %d\n",rank,nb_c,size,get_rank_worker(worker),buffer_reveived_clauses_lim);
      }
  }

  inline static uint64_t calculate_hash(const int* clause, const int size){
    uint64_t hash = 0;
    for(int i=0;i < size;i++)hash |= 1<<(clause[i]%64);
    return hash;
  } 


//struct hash_clauses{
//  int* addr;
//  uint64_t hash;
//};

  inline static void init_subsum(const int* clause, const int size){
    memset(verif_subsum,false,nb_total_literals);
    for(int i = 0; i < size; i++)verif_subsum[clause[i]]=true;
  }

  static int nb_spe_max;

  inline static bool subsum(const int* clause, const int size, const uint64_t hash){
    init_subsum(clause,size);
    bool subsum = false;
    for(int i = 0; i < size; i++){
      //printf("size : %d %d\n",clause[i],(int)watch[clause[i]].size());
      if((*(watch[clause[i]])).size()){
        for (std::vector<hash_clauses>::iterator it = (*(watch[clause[i]])).begin() ; it !=  (*(watch[clause[i]])).end(); ++it){
    
          if((hash & (it->hash)) == (it->hash) && size >= it->size){//&& size >= it->size
            
            subsum = true;
            int* other_clause = it->addr;
            for(int j = 0;other_clause[j] != LIMIT_BETWEEN_CLAUSES && subsum;j++)subsum=verif_subsum[other_clause[j]];
           
            if(subsum){
              //printf("it->nb_visit : %d\n",it->nb_visit);
              (it->nb_visit)++;
              
              //printf("it->nb_visit2 : %d\n",it->nb_visit);
               

              if(it->nb_visit == 63){
                /*for(int j = 0;other_clause[j] != LIMIT_BETWEEN_CLAUSES;j++)
                  clauses[lim_clauses++]=other_clause[j];
                clauses[lim_clauses++]=LIMIT_BETWEEN_CLAUSES;
                */
                it->nb_visit = 0;
                nb_spe_max++;
              }
              /*for(int o = 0; o < size; o++){
                printf("%d ",clause[o]);
              }
              printf(" est subsumé par ");
              for(int j = 0;other_clause[j] != LIMIT_BETWEEN_CLAUSES;j++){
                printf("%d ",other_clause[j]);
              }
              printf("addr : %p %p\n",other_clause,it);
              */
              return true;
            }
          }
        }
      }    
    }
      
    return false;
  }

  inline static void add_buffer_to_clauses(const int nb_checks){
    int tmp_clauses[CUBES_SIZE];
    int pos = 0;
    int lit_en_cours = 0;
    bool delete_by_UL = false;
    uint64_t hash = 0;
    
    const int debut = buffer_reveived_clauses_checks;
    int end_theo = buffer_reveived_clauses_checks+nb_checks;
  

    end_theo = end_theo > buffer_reveived_clauses_lim ? buffer_reveived_clauses_lim : end_theo;

    while(end_theo < buffer_reveived_clauses_lim && buffer_reveived_clauses[end_theo] != LIMIT_BETWEEN_CLAUSES)end_theo++;
    if(end_theo < buffer_reveived_clauses_lim)end_theo++;
    const int end = end_theo;
    if(end - debut){
      /*printf("end - debut %d \n",end-debut);
      printf("buffer : debut %d - end %d / %d / %d\n",debut, end,buffer_reveived_clauses_lim, buffer_reveived_clauses_size);
      printf("verif debut : %d\n",buffer_reveived_clauses[debut]);
      printf("verif end : %d\n",buffer_reveived_clauses[end]);*/
      for(int i = debut; i< end;i++){
        lit_en_cours = buffer_reveived_clauses[i];
        if(lit_en_cours == LIMIT_BETWEEN_CLAUSES){
 
          hash = calculate_hash(tmp_clauses,pos);
          if(delete_by_UL || subsum(tmp_clauses,pos,hash))nb_clauses_deleted++;
          else
            {//On la garde
              // Takes the first litteral like watch
              /*hash_clauses info;
              info.addr = clauses+lim_clauses;
              info.hash = hash;
              info.size = pos; 
              info.nb_visit = 0;
              
              (watch[*tmp_clauses])->push_back(info);
              */

              (watch[*tmp_clauses])->push_back(hash_clauses());
              (watch[*tmp_clauses])->back().addr = clauses+lim_clauses; 
              (watch[*tmp_clauses])->back().hash = hash; 
              (watch[*tmp_clauses])->back().size = pos;
              (watch[*tmp_clauses])->back().nb_visit = 0;
                //printf("ess : %p %d\n",info.addr,(int)info.hash);
              if(lim_clauses>size_clauses-1){
                printf("Tableau clauses 17 giga plein\n");
                exit(0);
              }
              for(int j = 0; j < pos;j++)clauses[lim_clauses++]=tmp_clauses[j];
              clauses[lim_clauses++]=LIMIT_BETWEEN_CLAUSES;
              
              nb_clauses_keep++;
            
              }
          pos=0;
          delete_by_UL = false;
        }else{
          tmp_clauses[pos++] = lit_en_cours;
          delete_by_UL = tree->present_in_ul(lit_en_cours);
        }
      }
      buffer_reveived_clauses_checks+=(end - debut);
      //printf("fin %d \n",buffer_reveived_clauses_checks);
    }
    /*static int verif_nb_clauses = 0;
    int tmp_clauses[CUBES_SIZE];
    int pos = 0;
    int lit_en_cours = 0;
    bool delete_by_UL = false;
    uint64_t hash = 0;
    
    for(int i = 0; i< size_clause_received;i++){
      lit_en_cours = clause_received[i];
      if(lit_en_cours == LIMIT_BETWEEN_CLAUSES){
        verif_nb_clauses++;
        hash = calculate_hash(tmp_clauses,pos);
        if(delete_by_UL || subsum(tmp_clauses,pos,hash))nb_clauses_deleted++;
        else
        {//On la garde
          // Takes the first litteral like watch
          hash_clauses info;
          info.addr = clauses+lim_clauses;
          info.hash = hash;
          info.size = pos; 
          (watch[*tmp_clauses])->push_back(info);
        
          //printf("ess : %p %d\n",info.addr,(int)info.hash);
          
          for(int j = 0; j < pos;j++)clauses[lim_clauses++]=tmp_clauses[j];
          clauses[lim_clauses++]=LIMIT_BETWEEN_CLAUSES;


          }
        pos=0;
        delete_by_UL = false;
      }else{
        tmp_clauses[pos++] = lit_en_cours;
        delete_by_UL = tree->present_in_ul(lit_en_cours);
      }
    }
    pos_workers_for_clauses_sent[worker]=lim_clauses;
    */
    //printf("%d\n",verif_nb_clauses);
  }


  inline static bool receive_worker_literals(const int& worker, Node* my_node){
    
    size_receive_literals = receive_worker(worker);
    if(size_receive_literals){
      MPI_Recv(receive_literals, size_receive_literals
               , MPI_INT, get_rank_worker(worker)
               , TAG_W_SEND_S_MODE
               , MPI_COMM_WORLD
               , MPI_STATUS_IGNORE);

      size_receive_literals_lim = receive_worker(worker);
      MPI_Recv(receive_literals_lim, size_receive_literals_lim
               , MPI_INT, get_rank_worker(worker)
               , TAG_W_SEND_S_MODE
               , MPI_COMM_WORLD
               , MPI_STATUS_IGNORE);
      //print_receive_literals_lim(worker);
      return add_all_units_literals(my_node);
    }
    return false;
  }

  inline static void send_worker_literals(const int& worker, Node* my_node){
    const int position_worker = my_node->units_literals_pos_workers[worker];
    const int size_units_literals = my_node->units_literals.size();
    int size_send_literals = size_units_literals-position_worker;//On prend que ceux qui n'ont pas été deja envoyés
    send_worker(worker,size_send_literals);
    if(size_send_literals)
    {
      //printf("Info : worker:%d pos:%d size_send:%d\n",get_rank_worker(worker),position_worker,size_send_literals);
      int* send_literals = (int*)malloc(size_send_literals*sizeof(int)); 
      for(int i = position_worker,j = 0; i < size_units_literals;i++,j++){ 
        send_literals[j]=my_node->units_literals[i];
      }
      MPI_Send(send_literals
               ,size_send_literals
               ,MPI_INT, get_rank_worker(worker), TAG_S_SEND_W_MODE, MPI_COMM_WORLD);
      my_node->units_literals_pos_workers[worker]=my_node->units_literals.size();
      free(send_literals);
    }
    my_node->units_literals_pos_workers[worker]=my_node->units_literals.size();
     

  }
  


  /** @name Internal variables of associated solver
   *  These variables are often used inside this associated solver
   */
  ///@{
  //  
  static int nb_conflict; /**< number of conflict while the resolution, initialize to zero at every start-up */
  static int limit_conflict; /**< limit of conflict for stop resolution, set to zero for no limit */
  static bool solver_stop; /**< used for stop the solver */

  static int nb_propagate;

  ///@}

private:  
 
  /** @name Main information
   *  Variables containing global information useful to all processes : the number of process and the MPI ranks   
   */
  ///@{
  static int type; /**< type of worker */
  static const char* type_name; /**< name of type of worker */ 
  static int type_extend;
  static int type_com;
  static int* type_of_workers; /*the type of each worker (glucose or penelope or minisat ...)*/
  static int* type_of_workers_unsat; /*the type of each worker (glucose or penelope or minisat ...)*/
  static int* type_of_workers_extend; /*the type of each worker (glucose or penelope or minisat ...)*/
  static int* type_of_workers_extend_nb;
  static int rank; /**< rank MPI of worker */
  const static int rank_master; /**< rank MPI of master */
  static int nb_process; /**< number of process */
  static int nb_workers; /**< number of workers */
  static int nb_scouts; /**< number of workers */
  static double start_wall_time; /**< realtime when start program */
  static int nb_total_literals;
///@}
  
  /** @name Tree variables
   *  The tree contains all the cubes whose workers are needed   
   */
  ///@{
  static int tree_height; /**< for example, if the tree height is to 9, we have 512 paths (cubes)*/ 
  static Tree* tree; /**< this class contains the tree */
  ///@}

  /** @name MPI communications variables
   *  Used for receive the messages from the workers and the master   
   */
  ///@{
  static int message_master; /**< messages received by the master */
  static MPI_Request request_master; /**< request used to listen the master */
  static int flag_master; /**< flag, to 1 if message has been received by the master, otherwise to 0 */

  static int* message_workers; /**< messages received by the workers */
  static MPI_Request* request_workers;  /**< requests used to listen the masters */
  static int* flag_workers;  /**< flag, 1 if message has been received of each workers, otherwise to 0 */
  ///@} 

  /** @name Internal variables of associated solver
   *  Used to associate a part of the tree to workers   
   */
  ///@{
  static VirtualScout* solver; /* this class allows to use the associated solver */  
  static Node** node_per_worker; /* for each worker, it is the final node to work (representing a cube) 
                                    warning : to NULL if the worker is breaking */

  static int nb_depth_unsat;
  static int sum_depth_unsat;

  static int size_receive_literals;
  static int* receive_literals;

  static int size_receive_literals_lim;
  static int* receive_literals_lim;

  
  //For learnts clauses 
  static int* clauses;//Tableau de clauses apprises des workers
  static int size_clauses;//Taille des clauses apprises
  static int lim_clauses;//Taille des clauses apprises
  
  static int* pos_workers_for_clauses_sent;//Pour chaque worker, la position des clauses renvoyées. 
  static int nb_clauses_received;//Clauses reçues
  static int nb_clauses_deleted;//Clauses éliminées
  static int nb_clauses_sent;//Clauses envoyées
  static int nb_clauses_keep;
  static int* nb_clauses_received_by_workers;

  static int* buffer_reveived_clauses;
  static int buffer_reveived_clauses_size;
  static int buffer_reveived_clauses_lim;
  static int buffer_reveived_clauses_checks;
  
  
  



  static std::vector<hash_clauses>** watch;
  static bool* verif_subsum;


  static int* stats_workers;
  static double factor_extend;
  static double ratio;

  static std::vector<int>* ratio_keep_clauses;
  static std::vector<int>* ratio_received_clauses;
  
};
