
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#include <time.h>
#include "../../define.h"

namespace {
class Node
{
 public:
  
  int id;
  int value;
  Node* left_child;
  Node* right_child;
  Node* father;

   int nb_cubes;
  int nb_workers;
  int nb_ask_extend;
  
  std::vector<int> workers; // workers on this node
  
  std::vector<int> units_literals; // Units literals of this node
  std::vector<int> units_literals_pos_workers; //Position of units literals already send for each worker
  std::vector<bool> units_literals_checks;
  
 
  static int addSpe;
 
  

Node(int v
     , Node *l, Node *r, Node *f
     , int n_nb_cubes
     , int nb_total_workers
     , int nb_total_literals) : 
  value(v),
    left_child(l),
    right_child(r), 
    father(f),
    nb_cubes(n_nb_cubes),
    nb_workers(0),
    nb_ask_extend(0),
    units_literals_pos_workers(nb_total_workers,0),
    units_literals_checks(nb_total_literals,false)
    {
    static int id_tmp = 0;
    id = ++id_tmp;
  }

  

  /**
   * \brief Allow to delete the node enter in parameter, delete also the children but not the fathers.
   */
  inline ~Node()
    {  
      if(value == TREE_END_CUBE)
        deinc_nb_cubes_father();
      if(right_child) delete(right_child);
      if(left_child) delete(left_child);
      
    }

  inline void clear_units_literals()
  {
    units_literals.clear();
    for (std::vector<bool>::iterator i = units_literals_checks.begin(); i != units_literals_checks.end(); ++i) *i=false;
    for (std::vector<int>::iterator i = units_literals_pos_workers.begin(); i != units_literals_pos_workers.end(); ++i) *i=0;
  }

  inline bool is_units_literals_UNSAT(const int& lit){
    const int opposed_lit = lit%2?lit-1:lit+1;
    if(units_literals_checks[lit] && units_literals_checks[opposed_lit]){
      fprintf(stderr,"[TREE]lit : %d - opposed_lit : %d\n",lit,opposed_lit);
      return true;
    }
    return false;
  }

  inline int count_units_literals(){
    if(left_child && right_child)
      return units_literals.size() + left_child->count_units_literals() + right_child->count_units_literals();
    else if (left_child)
      return units_literals.size() + left_child->count_units_literals();
    else if (right_child)
      return units_literals.size() + right_child->count_units_literals();
    return units_literals.size();
  }

  inline bool up_unit_literal(const int& lit){
    if(father != NULL 
         && ((father->left_child == this && father->right_child && father->right_child->units_literals_checks[lit] == true)
             || (father->right_child == this && father->left_child && father->left_child->units_literals_checks[lit] == true))
       )
      {
        if(father->father == NULL)
          printf("ADD UL0 UP\n");
        else
          printf("ADD ULN UP\n");
        return true;
      }
    return false;
  }

  inline bool add_unit_literal(const int& lit){
    if(!units_literals_checks[lit]){      
      units_literals.push_back(lit);
      units_literals_checks[lit]=true;
      if(father != NULL 
         && ((father->left_child == this && father->right_child && father->right_child->units_literals_checks[lit] == true)
             || (father->right_child == this && father->left_child && father->left_child->units_literals_checks[lit] == true))
         )
        {
          addSpe++;
          /*if(father->father == NULL)
            printf("ADD UL0 UP\n");
          else
          printf("ADD ULN UP\n");*/
          const bool unsatByUl = is_units_literals_UNSAT(lit);
          const bool unsatByUlFather = father->add_unit_literal(lit);
          return unsatByUl || unsatByUlFather;
        }
            /*    if(father == NULL)
            printf("[TREE]UNITS_LITERALS : %d\n",(int)units_literals.size());*/
      const bool unsatByUl = is_units_literals_UNSAT(lit);
      return unsatByUl;
    }
    return false;
  }

  inline bool verif_unsat_by_UL()
  {
    const int s = (int)units_literals_checks.size();
    for(int i = 0; i < s;i+=2){
      if(units_literals_checks[i] && units_literals_checks[i+1])
        return true; 
    } 
    return false;
  }

  inline bool puch_up_units_literals(Node* the_node){
    if(this != the_node)
    {//On met les UL de ce noeud dans the_node 
      if(!units_literals.empty())
      {
        for (std::vector<int>::const_iterator i = units_literals.begin(); i != units_literals.end(); ++i)
          if(the_node->add_unit_literal(*i))return true;
        clear_units_literals();//On enleve tous les literaux de ce noeud.
      }
    }
    
    if((!right_child && left_child) || (!left_child && right_child)){
      if(right_child)
        return right_child->puch_up_units_literals(the_node);
      else
        return left_child->puch_up_units_literals(the_node);
    }
    return false;
  }


  

  inline bool adjacent_is_NULL(){
    if(father &&
       ((father->left_child == this && father->right_child == NULL)
        ||
        (father->right_child == this && father->left_child == NULL)
         )
      )
    {
      return true;
    }
    return false;
  }

  inline Node* is_units_literals(const int& lit){
    if(units_literals_checks[lit])
      return this;
    if(father)
      return father->is_units_literals(lit);
    return NULL;
  }

  inline void inc_nb_cubes_father(){
    nb_cubes++;
    if(father)
      father->inc_nb_cubes_father();
  }

  inline void deinc_nb_cubes_father(){
    nb_cubes--;
    if(father)
      father->deinc_nb_cubes_father();
  }

  inline void affectNode(int v,  Node *l, Node *r, Node *f)
  {
    value = v;
    right_child = r;
    left_child = l;
    father = f;
    if(r)
      nb_cubes+=r->nb_cubes;
    if(l)
      nb_cubes+=l->nb_cubes;
  }// affectNode


  inline int get_depth()
  {
    if(father)
      return father->get_depth() + 1;
    return 0;
  }

  /**
   * \brief Recuperate the workers of this node.
   * \param[in,out] recup_workers Follow recuperate the workers of this node
   */
  inline void get_workers(std::vector<int>& recup_workers)
  {
    if(!workers.empty())
      for (std::vector<int>::const_iterator i = workers.begin(); i != workers.end(); ++i)
        recup_workers.push_back(*i);    
  }

  /**
   * \brief To go down in the others nodes if necessary (the children) in order to later delete it 
   and recuperate theirs workers that we later stop it.
   * \param[in,out] workers_to_stop Follow recuperate the workers of these nodes
   */
  inline void recuperate_workers_of_nodes_to_delete_for_children(std::vector<int>& workers_to_stop)
  {
    if(right_child){
      right_child->get_workers(workers_to_stop);
      right_child->recuperate_workers_of_nodes_to_delete_for_children(workers_to_stop);
    }
    if(left_child){
      left_child->get_workers(workers_to_stop);
      left_child->recuperate_workers_of_nodes_to_delete_for_children(workers_to_stop);
    }
  }

  /**
   * \brief To go up in the others nodes (himself and fathers) if necessary in order to later delete it 
   * and recuperate theirs workers that we later stop it.
   * \param[in,out] workers_to_stop Follow recuperate the workers of these nodes
   * \return The node to delete 
   */
  inline Node* recuperate_workers_of_nodes_to_delete_for_himself_and_fathers(std::vector<int>& workers_to_stop)
  {
    get_workers(workers_to_stop);
    if(father && (!father->left_child || !father->right_child))
      return father->recuperate_workers_of_nodes_to_delete_for_himself_and_fathers(workers_to_stop);
    return this;
  }

  /**
   * \brief To go up and to go down int the others nodes (children, himself and fathers) if necessary in order 
   * to later delete it and recuperate theirs workers that we later stop it.
   * \param[in,out] workers_to_stop Follow recuperate the workers of these nodes
   * \return The node to delete 
   */
  inline Node* recuperate_workers_of_nodes_to_delete(std::vector<int>& workers_to_stop)
  {
    recuperate_workers_of_nodes_to_delete_for_children(workers_to_stop);
    return recuperate_workers_of_nodes_to_delete_for_himself_and_fathers(workers_to_stop);
  }



  inline void expend_node(const int& the_variable, const int& n_nb_total_workers, const int& n_nb_total_literals){
    value=the_variable;
    left_child = new Node(TREE_END_CUBE, NULL, NULL, this,1,n_nb_total_workers,n_nb_total_literals);
    right_child = new Node(TREE_END_CUBE, NULL, NULL, this,1,n_nb_total_workers,n_nb_total_literals);
    inc_nb_cubes_father();
  }
  
  inline void deleteNode(){
    if(father){
      if(father->left_child == this)
        father->left_child = NULL;
      else
        father->right_child = NULL;
      delete(this);
    }else{
      left_child = NULL;
      right_child = NULL;
      nb_cubes=0;
    }
  }
 
  inline void dec_nb_workers(){
    nb_workers--;
    if(father)
      father->dec_nb_workers();
  }
  
  inline void inc_nb_workers(){
    nb_workers++;
    if(father)
      father->inc_nb_workers();
  }

  inline void addWorker(int w){
    workers.push_back(w);
    inc_nb_workers();
  }

  inline void delWorker(const int w){
    for(std::vector<int>::iterator it = workers.begin(); it != workers.end(); it++)
      {
        if (*it == w)
          {
            workers.erase(it);
            break;  //it is now invalud must break!
          }
      }
  }

  inline void display_cube(Node* child){
    if(father)
      father->display_cube(this);
    if(child == left_child)
      printf("%d (%d) ",value,nb_workers);
    else if(child == right_child)
      printf("-%d (%d) ",value,nb_workers);
    else
      printf("%d (%d) ",value,nb_workers);
      
  }

  inline Node* get_node_lit(int lit){
    if(value == lit)
      return this;
    else if(father)
      return father->get_node_lit(lit);
    else
      return NULL;
  }
#ifdef DOT
  inline double get_fatter_edge_dot(const int nb_work){
    double titi = (nb_work/64.0)*10;
    if(titi < 1)
      return 1;
    return titi;
  }
  
  inline const char* get_fatter_edge_color_dot(const int nb_work){
    if(nb_work < 7){
      return "#643A42";
    }else if (nb_work < 14){
      return "#77373D";
    }else if (nb_work < 21){
      return "#8A3439";
    }else if (nb_work < 28){
      return "#9E3134";
    }else if (nb_work < 35){
      return "#B12E30";
    }else if (nb_work < 42){
      return "#C42B2C";
    }else if (nb_work < 49){
      return "#D82827";
    }else if (nb_work < 56){
      return "#EB1824";
    }else{
      return "#FF1420";
    }
  }

  inline void write_node_dot(){
    static int null_node = 0;
    
    if(value == TREE_END_CUBE)
      printf("DOT:%d [label=\"%d\", shape=box, width=0.2, height=0.2, color=red];\n", id,nb_workers);
    else
      printf("DOT:%d [label=\"%d\\n%d\", fontsize=8];\n", id,value,nb_workers);
    if(value != TREE_END_CUBE){
      if(left_child)
      {
        if(left_child->nb_workers)
          printf("DOT:%d -> %d [penwidth=%f, color=\"%s\"];\n", id, left_child->id,get_fatter_edge_dot(left_child->nb_workers),get_fatter_edge_color_dot(left_child->nb_workers));
        else
          printf("DOT:%d -> %d;\n", id, left_child->id);
        left_child->write_node_dot();
      }
      else
      {
        null_node++;
        printf("DOT:%d -> N%d;\n", id, null_node);
        printf("DOT:N%d [label=\"\", shape=box, width=0.2, height=0.2, style=\"filled\", fillcolor=blue];\n", null_node);
      }
      if(right_child)
      {
        if(right_child->nb_workers)
          printf("DOT:%d -> %d [penwidth=%f, color=\"%s\"];\n", id, right_child->id,get_fatter_edge_dot(right_child->nb_workers),get_fatter_edge_color_dot(right_child->nb_workers));
        else
          printf("DOT:%d -> %d;\n", id, right_child->id);
        right_child->write_node_dot();
      }

      else
      {
        null_node++;
        printf("DOT:%d -> N%d;\n", id, null_node);
        printf("DOT:N%d [label=\"\", shape=box, width=0.2, height=0.2, style=\"filled\", fillcolor=blue];\n", null_node);
    
      }
    }
  }
#endif
};
int Node::addSpe = 0;
} //close namespace

class Tree
{

 private:
  const int size; // The number of VSIDS variable for create the tree
  int rank; // The MPI rank of this process
  Node* racine; // The racine of the tree
 
 public:

 Tree(int n_size, int n_rank) : 
  size(n_size),
    rank(n_rank),
    racine(NULL)
      {
      }
  
  //Tree-----------------------Getter / Setter
  //?_value : return the value of the node

  inline int get_add_spe_UL(){return racine->addSpe;}

  inline int get_units_literals_racine() {return racine->units_literals.size();}

  inline int get_units_literals() {return racine->count_units_literals();}

  inline bool present_in_ul(const int& lit){
    for (std::vector<int>::iterator i = racine->units_literals.begin(); i != racine->units_literals.end(); ++i)
      if(*i == lit)return true;
    return false;
  }

  inline int get_size() {return size;}
  inline int get_nb_cubes() {return racine->nb_cubes;}
  inline Node* get_racine() {return racine;}
  inline void set_racine(Node* n_racine) {racine = n_racine;}
  inline bool is_unsat(){return !racine->nb_cubes;}
  inline int rand_a_b(int a, int b){return rand()%(b-a) +a;}

#ifdef DOT
  inline void write_tree_dot(double walltime,const char* info){
    static int numfile = 0;
    numfile++;
    printf("DOT START : %d\n",numfile);
    printf("DOT:digraph G {\n");
    printf("DOT:graph [ dpi = 150, label=\"WT => %.3f s\\n%s\\n\", labelloc=t; labeljust=center, fontname=Helvetica, fontsize=12 ];\n",walltime,info);
    printf("DOT:nodesep=0.1;\n");
    printf("DOT:ranksep=0.1;\n");
    printf("DOT:margin=0.0;\n");
    printf("DOT:node [shape=circle];\n");
    printf("DOT:edge [arrowsize=0.2];\n");
    if(racine != NULL)
      racine->write_node_dot();
    else
      printf("DOT:N [label=\"\", shape=box, width=0.2, height=0.2, style=\"filled\", fillcolor=blue];\n");
    printf("DOT:}\n");
    printf("DOT END : %d\n",numfile);
  }
#endif
  /**
   * \brief Display the tree's informations.
   */
  inline void display(){
    srand(time(NULL)); // initialisation de rand
    printf("[SCOUT %d]nb_cubes : %d\n",rank,get_nb_cubes());
    printf("[SCOUT %d]0:%d (%d)\n",rank,racine->value,racine->nb_cubes);
    printf("[SCOUT %d]1:",rank);
    display_largeur(racine,1,0);
    printf("\n"); 
    printf("[SCOUT %d]2:",rank);
    display_largeur(racine,2,0);
    printf("\n"); 
    printf("[SCOUT %d]3:",rank);
    display_largeur(racine,3,0);
    printf("\n"); 
  
    display_alea(0);
    display_alea(1);
    display_alea(2);
    display_alea(2);
    display_alea(2);
    display_alea(2);
    display_alea(2);
    display_alea(2);
  }
  
  inline void display_largeur(Node* n, int larg, int pos){
    if(larg == pos){
      printf("%d (%d)",n->value,n->nb_cubes);
    }
    if(n->right_child){
      display_largeur(n->right_child,larg,pos+1);
    }
    if(n->left_child){
      display_largeur(n->left_child,larg,pos+1);
    }
  }
  
  inline void display_alea(int value)
  {
  
    if(!value)//uniquement a gauche
      printf("[SCOUT %d]Display Left:",rank);
    else if(value == 1)//uniquement a droite
      printf("[SCOUT %d]Display Right:",rank);
    else//aleatoirement
      printf("[SCOUT %d]Display Alea:",rank);
  
    Node* current = racine;
    for(;;)
      {
        if(current == NULL){ 
          printf("NULL");
          break;
        }
        if(!value){//uniquement a gauche
          printf("%d ",current->value);
          if(current->father != NULL)
            printf("(%d) ",current->father->value);
          else
            printf("(N) ");
          current=current->left_child;
        }else if(value == 1){//uniquement a droite
          printf("%d ",current->value==-1?current->value:-current->value);
        
          if(current->father != NULL)
            printf("(%d) ",current->father->value);
          else
            printf("(N) ");
          current=current->right_child;
        }else{//aleatoirement
          if(rand_a_b(0,2)){       
            printf("%d : %d",current->value==-1?current->value:-current->value,current->nb_cubes);
            
            if(current->father != NULL)
              printf("(%d) ",current->father->value);
            else
              printf("(N) ");
            current=current->right_child;
          }else{
            printf("%d : %d",current->value,current->nb_cubes);
          
            if(current->father != NULL)
              printf("(%d) ",current->father->value);
            else
              printf("(N) ");
            current=current->left_child;

          }
        }
      }
    printf("\n");
  }
};
