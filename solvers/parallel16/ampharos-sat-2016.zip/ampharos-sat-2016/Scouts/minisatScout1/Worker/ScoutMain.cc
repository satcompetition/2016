#include "ScoutMain.h"

#include "utils/Options.h"
#include <sys/types.h>
#include "utils/System.h"

#ifndef scout
#define scout
#include "Scout.h"
#endif

#include "../../../define.h"

using namespace MinisatScout;

int ScoutMain(int argc, char** argv){
  parseOptions(argc, argv, true);
  /*Association du Worker*/
  Scout::extern_all(argc,argv,1,1,"Original Method",3,1);
  return 0;
}

