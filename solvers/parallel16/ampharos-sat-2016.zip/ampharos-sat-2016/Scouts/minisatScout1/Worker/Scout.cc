/**
 * \file Scout.cc
 * \brief It is a scout, contains a solver minisat and a class Tree
 * \author Szczepanski Nicolas
 * \version 4
 * \date 15 juillet 2015
 *
  This program creates a binary tree using the associated solver
  minisat. The workers communicates with this scout to get the
  cubes. When all cubes are proven unsatisfiable by the workers, then
  the initial problem is unsatisfiable. On the other hand, if there is
  at least one cube satisfiable, the initial problem is satisfiable.
 *
 */


#include "../../define.h"
#include <string.h>
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <math.h>

#ifndef scout
#define scout
#include "Scout.h"
#endif



int Scout::rank = 0; 
const int Scout::rank_master=0;
int Scout::nb_process=0; 
int Scout::nb_workers=0;
int Scout::nb_scouts=0;
int Scout::type = 0;
const char* Scout::type_name = NULL;
double Scout::start_wall_time = 0;
int Scout::nb_total_literals = 0;
double Scout::sum_wall_time = 0;
double Scout::sum_wall_time2 = 0;
double Scout::sum_wall_time_msg = 0;

MPI_Request Scout::request_master; 
int Scout::flag_master=0;
int Scout::message_master=0; 
int* Scout::message_workers = NULL; 
MPI_Request* Scout::request_workers = NULL;
int* Scout::flag_workers = NULL; 

int Scout::tree_height = 0;
Tree* Scout::tree = NULL;

int Scout::nb_conflict = 0; 
int Scout::limit_conflict = 0; 
bool Scout::solver_stop = false; 

VirtualScout* Scout::solver = NULL; 
Node** Scout::node_per_worker = NULL;

int Scout::type_extend = 0;
int Scout::type_com = 0;

int* Scout::type_of_workers = NULL; /*the type of each worker (glucose or penelope or minisat ...)*/
int* Scout::type_of_workers_unsat = NULL; /*for each worker (glucose or penelope or minisat ...), the number of cube UNSAT*/
int* Scout::type_of_workers_extend = NULL; /*for each worker (glucose or penelope or minisat ...), the number of extend*/
int* Scout::type_of_workers_extend_nb = NULL;

int* Scout::stats_workers = NULL;

int Scout::nb_depth_unsat = 0;
int Scout::sum_depth_unsat = 0;

int Scout::nb_propagate=0;

int Scout::size_receive_literals = 0;
int* Scout::receive_literals = NULL;

int Scout::size_receive_literals_lim = 0;
int* Scout::receive_literals_lim = NULL;

//For learnts clauses 
int* Scout::clauses = NULL;//Tableau de clauses apprises des workers
int Scout::size_clauses = 0;//Taille du tableau des clauses apprises
int Scout::lim_clauses = 0;
int* Scout::pos_workers_for_clauses_sent = NULL;//Pour chaque worker, la position des clauses renvoyées. 
int* Scout::nb_clauses_received_by_workers = NULL;//Pour les stats

int Scout::nb_clauses_received = 0;//Clauses reçues
int Scout::nb_clauses_deleted = 0;//Clauses éliminées
int Scout::nb_clauses_sent = 0;//Clauses envoyées
int Scout::nb_clauses_keep = 0;


int* Scout::buffer_reveived_clauses = NULL;
int Scout::buffer_reveived_clauses_size = 0;
int Scout::buffer_reveived_clauses_lim = 0;
int Scout::buffer_reveived_clauses_checks = 0;


std::vector<hash_clauses>** Scout::watch = NULL;
bool* Scout::verif_subsum = NULL;

double Scout::factor_extend = 10;
double Scout::ratio = 1;

std::vector<int>* Scout::ratio_keep_clauses = NULL;
std::vector<int>* Scout::ratio_received_clauses = NULL;

int Scout::nb_spe_max = 0;

void Scout::extern_all(int argc,char** argv,const int n_type,const int n_tree_height,const char* n_type_name
                       ,const int n_type_com,const int n_type_extend){
  int w = 0;
  /*Initialisation*/  
  init_wall_time();
  //MPI::Init();


  /*main informations*/
  char hostname[256];
  gethostname(hostname, sizeof(hostname));
  rank = MPI::COMM_WORLD.Get_rank();  
  type = n_type;
  type_name = n_type_name;
  type_extend=n_type_extend;
  type_com = n_type_com;

  tree_height= n_tree_height;
  tree = new Tree(tree_height,rank);


  /* envoie le type au master */
  send_master(type);
  /* recois le nombre de workers et le nombre de scouts */
  MPI_Recv(&nb_workers, 1, MPI_INT, rank_master, TAG_M_SEND_S_MODE, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
  MPI_Recv(&nb_scouts, 1, MPI_INT, rank_master, TAG_M_SEND_S_MODE, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
  

  type_of_workers = (int*)malloc(nb_workers*sizeof(int)) ; 
  type_of_workers_extend = (int*)calloc(nb_workers,sizeof(int)) ; 
  type_of_workers_extend_nb = (int*)calloc(nb_workers,sizeof(int)) ; 
  type_of_workers_unsat = (int*)calloc(nb_workers,sizeof(int)) ; 
  nb_clauses_received_by_workers = (int*)calloc(nb_workers,sizeof(int)) ;
  MPI_Recv(type_of_workers,nb_workers
           ,MPI_INT, rank_master
           ,TAG_M_SEND_S_MODE
           ,MPI_COMM_WORLD
           ,MPI_STATUS_IGNORE);

  //For clauses
  size_clauses = 1<<28;
  printf("taille clause : %d\n",size_clauses);
  clauses = (int*)malloc(size_clauses*sizeof(int));
  pos_workers_for_clauses_sent = (int*)calloc(nb_workers,sizeof(int));
 
  buffer_reveived_clauses_size = size_clauses;
  buffer_reveived_clauses = (int*)malloc(size_clauses*sizeof(int));

  //For message Worker
  message_workers = (int*)malloc(nb_workers*sizeof(int));
  request_workers = (MPI_Request*)malloc(nb_workers*sizeof(MPI_Request));
  flag_workers = (int*)calloc(nb_workers,sizeof(int));
  
  node_per_worker = (Node**)calloc(nb_workers,sizeof(Node*));
  
  stats_workers = (int*)calloc(nb_workers,sizeof(int));//Nombre de message reçu par worker

  for(;w < nb_workers;w++){
    init_listen_worker(w);
  }
  display_workers_type();

  /*Initialisation du solveurs*/
  solver = new VirtualScout(argc,argv);
  
  ratio_keep_clauses = new std::vector<int>();
  ratio_received_clauses = new std::vector<int>();

  nb_total_literals = solver->nb_vars()*2;
  watch = (std::vector<hash_clauses>**)malloc(nb_total_literals*sizeof(std::vector<hash_clauses>*));
  for(int i = 0; i < nb_total_literals; i++)watch[i] = new std::vector<hash_clauses>();
  verif_subsum = (bool*)malloc(nb_total_literals*sizeof(bool));
  
  receive_literals = (int*)malloc((nb_total_literals/2)*sizeof(int));
  receive_literals_lim = (int*)malloc(CUBES_SIZE*sizeof(int));
    

  init_listen_master();
  

  printf("[SCOUT %d]Method %d : %s ()\n"
         ,rank,type
         ,type_name);

  printf("[SCOUT %d]Tree Height:%d - Nb VSIDS Varaible:%d - Nb Cubes MAX: %d\n"
         ,rank
         ,tree_height
         ,tree_height
         ,(int)pow(2,tree_height));
  
  extern_listen(); 
}


void Scout::extern_recup_solution(int const res)
{ //on vérifie avant qu'un autre solveur n'a pas trouver la solution
  int flag_kill_master = 0;
  MPI_Test(&request_master,&flag_kill_master,MPI_STATUS_IGNORE);
  if(flag_kill_master)
  {
    if(message_master == MSG_KILL)
    {
      //printf("[SCOUT %d]OTHER SOLUTION SOLVER KILL\n",rank);
      extern_kill();
    }
  }
  if(!res)
  {//satisfiable
    printf("[SCOUT %d]SATISFIABLE(%s)\n",rank,type_name);
    send_master(MSG_SAT);
  }
  else if(res == 1)
  {//unsatisfiable
    printf("[SCOUT %d]UNSATISFIABLE(%s)\n",rank,type_name);
    send_master(MSG_UNSAT);
  }
  else if(res == 2)
  {//cube insatisfiable
    printf("[SCOUT %d]CUBE UNSAT BUG IMPOSSIBLE\n",rank);
    //send_master(MSG_CUBE_UNSAT);
  }
  else
  {//indeterminer
    send_master(MSG_INDET);
    solver->restart();
  }
}

void Scout::extern_cut_assertif(int w,int assertif_lit){
#ifdef DOT
  char buffer [200];
  sprintf(buffer, "UNSAT_WORKER => %d - UNSAT_VARIABLE => %d (%d)\\nCUBES => %d"
          , get_rank_worker(w)
          ,assertif_lit==-1?-1:assertif_lit >> 1
          ,assertif_lit==-1?-1:assertif_lit & 1
          ,tree->get_nb_cubes());
  tree->write_tree_dot(get_wall_time(),buffer);      
#endif
  Node* final_Node = node_per_worker[w];
  (type_of_workers_unsat[w])++;
  //display_workers_unsat();
  nb_depth_unsat++;
  
  sum_depth_unsat+=final_Node->get_depth();
#ifdef VERB
  printf("[SCOUT %d]CUT ASSERTIF CUBE FOR [WORKER %d]:",rank,get_rank_worker(w));
  final_Node->display_cube(NULL);
  printf("\n");
#endif
  //Delete the worker w of the list of workers of final_node
  final_Node->delWorker(w);
  final_Node->dec_nb_workers(); 
  //Change the final_node into delele node : the assertif node
  if(assertif_lit != -1){
    //final_Node = final_Node->get_node_lit(assertif_lit>0?assertif_lit:-assertif_lit);
    final_Node = final_Node->get_node_lit(assertif_lit >> 1);
    //If the assertif litteral is negatif (positif) then the cut node is the left (right) child 
    final_Node=assertif_lit & 1?final_Node->left_child:final_Node->right_child;
  }
#ifdef VERB
  printf("[SCOUT %d]DELETE NODE FOR [WORKER %d]:%d (%d)\n",rank,get_rank_worker(w),final_Node->value,final_Node->nb_workers);
#endif
  //Delete the node and stop the workers on this road
  delete_and_stop_workers(final_Node);  
}



Node* Scout::extern_listen_for_send_cube(Node* current_node, const int w){
  int message_cube = receive_worker(w);
  switch(message_cube)
    {
    case MSG_ERASE_FATHER : 
      {//erase the father and you restart the cummunication from the root
#ifdef DEBUG_SCOUT
        printf("[SCOUT %d]ERASE FATHER: %d\n",rank,current_node->value);
#endif
        delete_and_stop_workers(current_node);
        return NULL;
      }
    case MSG_GIVE_MY_SONS : 
      {//Send the children at the worker w
        send_worker_node(w, current_node->left_child);
        send_worker_node(w, current_node->right_child);
        break;
      }         
    case MSG_ALREADY_ASSIGNED : 
      {//The litteral is already assigned (0 <=> positif, 1 <=> negatif)
#ifdef DEBUG_SCOUT
      printf("[SCOUT %d]ALREADY ASSIGNED %d\n",rank,current_node->value);
#endif 
      if(receive_worker(w)) delete_and_stop_workers(current_node->left_child);
      else delete_and_stop_workers(current_node->right_child);
      break;
      }       
    case MSG_GO_LEFT : 
      {//Replace the node called "current_node" to the left node
#ifdef DEBUG_SCOUT
        printf("[SCOUT %d]GO LEFT : %d\n",rank,current_node->value);
#endif 
        current_node = current_node->left_child;
        if(type_com == TYPE_COM_SHARE_UNITS_LITERALS
	   || type_com == TYPE_COM_SHARE_ALL)
          send_worker_literals(w, current_node); 
        if(current_node->value == TREE_END_CUBE)return current_node;//The communication of cubes has finished
        break;
      }
    case MSG_GO_RIGHT : 
      {//Replace the node called "current_node" to the right node
#ifdef DEBUG_SCOUT
        printf("[SCOUT %d]GO RIGHT : -%d\n",rank,current_node->value);
#endif
        current_node = current_node->right_child;
        if(type_com == TYPE_COM_SHARE_UNITS_LITERALS
	   || type_com == TYPE_COM_SHARE_ALL)
          send_worker_literals(w, current_node);
                
        if(current_node->value == TREE_END_CUBE)return current_node;//The communication of cubes has finished
        break;
      }        
    default: 
      {// For debug
        printf("[SCOUT %d]BUG MESSAGE RECUPERATE CUBE: %d\n",rank,message_cube);
        exit(0);
        break;
      }
    }
  return extern_listen_for_send_cube(current_node,w);
}
          

void Scout::extern_listen_master(){
  int tmp_message_master=0; //For the message of master
  MPI_Test(&request_master,&flag_master,MPI_STATUS_IGNORE);
  if(flag_master)
    { 
      tmp_message_master = message_master;
      switch(tmp_message_master)
        {
        case MSG_START: 
          {
            if(limit_conflict)
              printf("[SCOUT %d]START FOR %d CONFLICTS\n",rank,limit_conflict);
            else
              printf("[SCOUT %d]START\n",rank);
            init_listen_master();
            extern_recup_solution(solver->start());
            break;
          }
        case MSG_CONFLICTS: 
          {
            MPI_Recv(&limit_conflict, 1, MPI_INT, rank_master, TAG_M_SEND_S_MODE, MPI_COMM_WORLD, 
                     MPI_STATUS_IGNORE);
            init_listen_master();
            break;
          }
        case MSG_KILL: 
          {
            //extern_kill();
            break;
          }
        default: 
          {
            printf("[SCOUT %d]BUG MESSAGE: %d\n",rank,tmp_message_master);
            break;
          }
        }
    }
}

void Scout::extern_listen(){
  for(;;){extern_listen_master();extern_listen_workers();}
}


void Scout::extern_cube_UNSAT_by_scout(Node* my_cube){
  // We verifie the cube by the solver of scout
  static int nb_UNSAT_by_scout = 0;
  solver->restart();
  printf("[SCOUT %d] Test UNSAT : ",rank);
  Node* my_cube_previous = my_cube;
  my_cube=my_cube->father;
  for(;my_cube;my_cube_previous = my_cube,my_cube=my_cube->father){
    int assign = solver->is_assigned(my_cube->value);
    if(assign == VAR_NOT_ASSIGNED)
      {
        if(my_cube_previous == my_cube->left_child)
          {
            if(solver->decision_propagate(my_cube->value,POSITIF) == DECISION_PROPAGATE_CONFLICT){
              nb_UNSAT_by_scout++;
              printf("[SCOUT %d]nb_UNSAT_by_scout : %d\n",rank,nb_UNSAT_by_scout);
              break;
            }
            printf("%d ",my_cube->value);
          }
        else
          { 
            if(solver->decision_propagate(my_cube->value,NEGATIF) == DECISION_PROPAGATE_CONFLICT){
              nb_UNSAT_by_scout++;
              printf("[SCOUT %d]nb_UNSAT_by_scout : %d\n",rank,nb_UNSAT_by_scout);
              break;
            }
            printf("-%d ",my_cube->value);
          }
      }
    else
      {
        if((my_cube_previous == my_cube->left_child && assign==VAR_NEGATIF_ASSIGNED)
           || (my_cube_previous == my_cube->right_child && assign==VAR_POSITIF_ASSIGNED))
          {
            nb_UNSAT_by_scout++;
            printf("[SCOUT %d]nb_UNSAT_by_scout : %d\n",rank,nb_UNSAT_by_scout);
            break;
          }
        
      }
  }
  printf("\n");
  solver->restart();
}

void Scout::extern_listen_workers()
{  
  int w = 0; //The worker in comunication
  
  add_buffer_to_clauses(2000);
  //listen the workers
  for(w = 0;w < nb_workers;w++)
    {//Ecoute des workers
      add_buffer_to_clauses(1000);
 
      MPI_Test(request_workers+w,flag_workers+w,MPI_STATUS_IGNORE);
      if(flag_workers[w])
      
        {//si un message est recu d'un worker
          stats_workers[w]++;
          
      
          
          switch(message_workers[w])
            {
            case MSG_INFO :
              {     
                if(!is_worker_to_NULL(w)){
                  switch(type_com)
                    {//Pour les communication des ULs et clauses
                    case TYPE_COM_SHARE_CLAUSES :
                      send_worker_double(w,ratio);
                      send_worker_clauses(w);
                      receive_worker_clauses(w);
                      break;
                    case TYPE_COM_SHARE_ALL :      
                      send_worker_double(w,ratio);
                      send_worker_clauses(w);
                      receive_worker_clauses(w);
                      break;
                    case TYPE_COM_SHARE_ALL_NO_ULN :
                      send_worker_double(w,ratio);
                      send_worker_clauses(w);
                      receive_worker_clauses(w);
                      break;
                    }
                }
                break;
              }

            case MSG_CUBE_INDETERMINATE :
              {
                bool ext = false;
                if(!is_worker_to_NULL(w))
                  {//Here, we must not cut the litteral
#ifdef VERB
                    printf("[SCOUT %d]CUBE INDETERMINATE BY [WORKER %d]\n",rank,get_rank_worker(w));
#endif
                    node_per_worker[w]->delWorker(w);
                    node_per_worker[w]->dec_nb_workers();
		    bool ok_extend = true; //Si les ULs ont éliminer le noeud, nous ne pouvons pas étendre
                    if(receive_worker(w) == MSG_EXPAND_CUBE){
                      int the_expand_variable = receive_worker(w);
                      Node* the_node = node_per_worker[w];
                     
                      

                      //Update the ratio
                      if(nb_clauses_keep){  
                        ratio_keep_clauses->push_back(nb_clauses_keep);
                        ratio_received_clauses->push_back(nb_clauses_received);
                        if(ratio_keep_clauses->size() >= 20000){
                          const int pos = ratio_keep_clauses->size()-20000;
                          const int k = nb_clauses_keep - (*ratio_keep_clauses)[pos];
                          const int r = nb_clauses_received - (*ratio_received_clauses)[pos];
                          ratio = (double)r/(double)k;
                        }else{
                          ratio = (double)nb_clauses_received/(double)nb_clauses_keep;
                          }
                        //ratio = (double)nb_clauses_received/(double)nb_clauses_keep;
                       
                      }
                      switch(type_com)
                        {//Pour les communication des ULs et clauses
                        case TYPE_COM_SHARE_UNITS_LITERALS :
                          ok_extend = !receive_worker_literals(w,the_node);
                          break;
                        case TYPE_COM_SHARE_CLAUSES :
                          send_worker_double(w,ratio);
                          send_worker_clauses(w);
			  receive_worker_clauses(w);
                          break;
                        case TYPE_COM_SHARE_ALL :
			  ok_extend = !receive_worker_literals(w,the_node);
                          
                          send_worker_double(w,ratio);
                          send_worker_clauses(w);
                          receive_worker_clauses(w);
                          break;
                        case TYPE_COM_SHARE_ALL_NO_ULN :
                          
			  ok_extend = !receive_worker_literals(w,the_node);
                          
                          send_worker_double(w,ratio);
                          send_worker_clauses(w);
                          receive_worker_clauses(w);
                          break;
                        }
                              
		      
		      if(ok_extend && the_node->value==TREE_END_CUBE)
			{//if the node is end cubes
			  (the_node->nb_ask_extend)++;
                          if(nb_clauses_keep)
                            {
                              //Update the factor extend
                              // factor_extend = 1000 * (1 / (ratio * ratio * ratio));
                              // if(factor_extend < 10) factor_extend = 10;
                              
                              factor_extend = ((double) 1000) / (ratio * ratio * ratio);                              
                              if(factor_extend < 10) factor_extend = 10;
                            }                          
                            
                        
                          if(type_extend == TYPE_EXTEND_MODE_2
                             || (type_extend == TYPE_EXTEND_MODE_1 && the_node->nb_ask_extend >= (factor_extend * tree->get_nb_cubes())))
                            {
                              fprintf(stderr,"[SCOUT %d]factor_extend %.2lf\n",rank, factor_extend);
#ifdef VERB
                              printf("[SCOUT %d]EXPAND CUBE - WITH THE VARIABLE %d\n",rank,the_expand_variable);
#endif
                              
                              
                              the_node->expend_node(the_expand_variable,nb_workers,nb_total_literals);
#ifdef DOT  
                              char buffer [200];
                              sprintf(buffer, "EXPAND_WORKER => %d - EXPAND_VARIABLE => %d\\nCUBES => %d"
                                      ,get_rank_worker(w)
                                      ,the_expand_variable
                                      ,tree->get_nb_cubes());
                              tree->write_tree_dot(get_wall_time(),buffer);
#endif
                              (type_of_workers_extend[w])++;   
                              display_stats("EXTEND");
                              ext=true;
                            }
                        }
                    }
                    const int same_cube = receive_worker(w);
                  
                    if(same_cube == MSG_RESTART_THE_CUBE_YES){
                      node_per_worker[w]=NULL;
                      main_send_cube(w);
                    }else{
                      if(ext || !ok_extend)
                      {
                        send_worker(w, MSG_RESTART_THE_CUBE_YES);
                        node_per_worker[w]=NULL;
                        main_send_cube(w);
                      }
                      else
                      {
                        send_worker(w, MSG_RESTART_THE_CUBE_NO);
                        node_per_worker[w]->addWorker(w);
                        node_per_worker[w]->inc_nb_workers();
                      }

                    }
                    //->il a avait que ca : node_per_worker[w]=NULL;
                  }
                //On lui redonne un cube directement
                //main_send_cube(w);
                 
                break;
              }
            case MSG_CUBE_UNSAT_COMPLETE :
              {                                
                if(!is_worker_to_NULL(w))
                  {//Here, the cut litteral is the last litteral of cube
#ifdef VERB                            
                    printf("[SCOUT %d]CUBE UNSAT BY [WORKER %d] COMPLETE MODE\n",rank,get_rank_worker(w));
#endif
                    if (type_com == TYPE_COM_SHARE_CLAUSES || type_com == TYPE_COM_SHARE_ALL || type_com == TYPE_COM_SHARE_ALL_NO_ULN){
                     
                      send_worker_double(w,ratio);
                      send_worker_clauses(w);
                      receive_worker_clauses(w);
                    }
                    extern_cut_assertif(w,-1); //-1 en parametre a la place du litteral assertif
                    node_per_worker[w]=NULL;
                  }
                //On lui redonne un cube directement
                main_send_cube(w);
             
                break;
              }
            case MSG_CUBE_UNSAT_LIT_ASSERTIF : 
              {
                if(!is_worker_to_NULL(w))
                  {//Here, the cut litteral is receive from the worker w
                    
                    if (type_com == TYPE_COM_SHARE_CLAUSES || type_com == TYPE_COM_SHARE_ALL || type_com == TYPE_COM_SHARE_ALL_NO_ULN){
                   
                      send_worker_double(w,ratio);
                      send_worker_clauses(w);
                      receive_worker_clauses(w);
                    }
                    int assertif_lit = receive_worker(w);
#ifdef VERB                            
                    printf("[SCOUT %d]CUBE UNSAT BY [WORKER %d](LIT_ASSERTIF MODE:%d var:%d sign:%d)\n"
                           ,rank
                           ,get_rank_worker(w)
                           ,assertif_lit
                           ,assertif_lit >> 1
                           ,assertif_lit & 1);
#endif                    
                    extern_cut_assertif(w,assertif_lit);
                    node_per_worker[w]=NULL;                            
                  }
                //On lui redonne un cube directement
                main_send_cube(w);
                
                break;
              }
            case MSG_GO_ROOT : //Send the racine at the worker w and go to the while communication
              {
                main_send_cube(w);
                break;
              }
            default: //For debug
              printf("[SCOUT %d]BUG MESSAGE: %d\n",rank,message_workers[w]);
              exit(0);
              break;
            }
          init_listen_worker(w);
        }
    }
}

void Scout::main_send_cube(const int& w){
#ifdef DEBUG_SCOUT
  printf("[SCOUT %d]START A CUBE COMMUNICATION - FIRST NODE:%d\n",rank,tree->get_racine()->value);
#endif
  send_worker(w, tree->get_racine()->value);
  send_worker(w, tree->get_nb_cubes());

  if(type_com == TYPE_COM_SHARE_UNITS_LITERALS
     || type_com == TYPE_COM_SHARE_ALL 
     || type_com == TYPE_COM_SHARE_ALL_NO_ULN)
    send_worker_literals(w, tree->get_racine());
                          
  Node* my_cube = extern_listen_for_send_cube(tree->get_racine(),w);
  if(my_cube)
    {//Le cube communiqué
       my_cube->addWorker(w);
      node_per_worker[w]=my_cube;     
      //extern_cube_UNSAT_by_scout(my_cube);                             
#ifdef DEBUG_SCOUT
      printf("[SCOUT %d]END A CUBE COMUNICATION - LAST NODE:%d\n",rank,my_cube->value);       
                    
      printf("[SCOUT %d]CUBE RECEIVE BY THE [WORKER %d]:",rank,get_rank_worker(w));
      my_cube->display_cube(NULL);
      printf("\n");
#endif
    }
}


void Scout::intern_main(){
  MPI_Test(&request_master,&flag_master,MPI_STATUS_IGNORE);
  if(flag_master){
    int tmp_message = message_master;
    init_listen_master(); 
    if(tmp_message == MSG_KILL){
      printf("[SCOUT %d]INTERN KILL\n",rank); 
      MPI_Finalize();
      exit(0);
    }       
  }
}



/*
 *tab_vsids : best variables of vsids heuristic 
 *number of best variable == size of tab_vsids == variable tree_height
 *Start the creation of tree depending on the type of the scout (variable type)
 */
void Scout::intern_create_tree(std::vector<int>& tabVarSelect){
  /*Display the VSIDS variables*/
  printf("[SCOUT %d]%d (check %d) VSIDS VARIABLES :",rank,tree->get_size(),(int)tabVarSelect.size());
  for(int i = 0;i < tree->get_size();i++)printf("%d ",tabVarSelect[i]);
  printf("\n");
  // tree creation  
  switch(type)
  {
  case 1 :
    tree->set_racine(build_tree(tabVarSelect));
    break;
  default :
    printf("ERROR: BAD TYPE SCOUT\n");
    exit(0);
    break;
  }
  //Display tree's informations 
  tree->display();

#ifdef DOT
  char buffer [200];
  sprintf(buffer,"FIRST TREE - CUBES => %d",tree->get_nb_cubes());
  tree->write_tree_dot(get_wall_time(),buffer);      
#endif                     
}

/**
   Create a tree w.r.t. the set of variable given in parameter.
   
   @param[in] setOfPossibleVariable, a set of variable
   
   \return a tree built w.r.t. setOfPossibleVariable
*/
Node* Scout::build_tree(std::vector<int> &setOfPossibleVariable, Node *father)
{
  int v = selectVariable(setOfPossibleVariable);
  // all the variable are affected
  if(v == TREE_END_CUBE) {
    return new Node(TREE_END_CUBE, NULL, NULL, father,1,nb_workers,nb_total_literals);
  }
  
  Node *l = NULL, *r = NULL, *ret = new Node(v, NULL, NULL, NULL,0,nb_workers,nb_total_literals);
  
  // considere the left branch
  int resPu = solver->decision_propagate(v, false);
  if(resPu != DECISION_PROPAGATE_CONFLICT) l = build_tree(setOfPossibleVariable, ret);    
  solver->backtrack();

  // considere the right branch
  resPu = solver->decision_propagate(v, true);
  if(resPu != DECISION_PROPAGATE_CONFLICT) r = build_tree(setOfPossibleVariable, ret);
  solver->backtrack();

  // collect the father
  ret->affectNode(v, l, r, father);

  if(l == NULL && r == NULL){delete(ret); return NULL;} // both literals produce a conflict
  return ret;
}// build_tree
