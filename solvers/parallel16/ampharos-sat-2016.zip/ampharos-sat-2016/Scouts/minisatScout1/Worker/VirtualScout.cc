/*****************************************************************************************[Main.cc]
 Scout Version
---------------

MinisatScout -- Copyright (c) 2003-2006, Niklas Een, Niklas Sorensson
Copyright (c) 2007-2010, Niklas Sorensson

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and
associated documentation files (the "Software"), to deal in the Software without restriction,
including without limitation the rights to use, copy, modify, merge, publish, distribute,
sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or
substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT
OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
**************************************************************************************************/

#include <errno.h>

#include <signal.h>
#include <zlib.h>
#include <sys/resource.h>

#include "utils/System.h"
#include "utils/ParseUtils.h"
#include "utils/Options.h"
#include "core/Dimacs.h"
#include "simp/SimpSolver.h"

#ifndef virscout
#define virscout
#include "VirtualScout.h"
#endif



using namespace MinisatScout;



IntOption    verbe   ("MAIN", "verb",   "Verbosity level (0=silent, 1=some, 2=more).", 1, IntRange(0, 2));
BoolOption   pree    ("MAIN", "pre",    "Completely turn on/off any preprocessing.", true);
StringOption dimacss ("MAIN", "dimacs", "If given, stop after preprocessing and write the result to this file.");
IntOption    cpu_limm("MAIN", "cpu-lim","Limit on CPU time allowed in seconds.\n", INT32_MAX, IntRange(0, INT32_MAX));
IntOption    mem_limm("MAIN", "mem-lim","Limit on memory usage in megabytes.\n", INT32_MAX, IntRange(0, INT32_MAX));

static Solver* solver;
SimpSolver* SS;
FILE* ress;

//=================================================================================================


void printStats(Solver& solver)
{
    double cpu_time = cpuTime();
    double mem_used = memUsedPeak();
    printf("restarts              : %"PRIu64"\n", solver.starts);
    printf("conflicts             : %-12"PRIu64"   (%.0f /sec)\n", solver.conflicts   , solver.conflicts   /cpu_time);
    printf("decisions             : %-12"PRIu64"   (%4.2f %% random) (%.0f /sec)\n", solver.decisions, (float)solver.rnd_decisions*100 / (float)solver.decisions, solver.decisions   /cpu_time);
    printf("propagations          : %-12"PRIu64"   (%.0f /sec)\n", solver.propagations, solver.propagations/cpu_time);
    printf("conflict literals     : %-12"PRIu64"   (%4.2f %% deleted)\n", solver.tot_literals, (solver.max_literals - solver.tot_literals)*100 / (double)solver.max_literals);
    if (mem_used != 0) printf("Memory used           : %.2f MB\n", mem_used);
    printf("CPU time              : %g s\n", cpu_time);
}


// Terminate by notifying the solver and back out gracefully. This is mainly to have a test-case
// for this feature of the Solver as it may take longer than an immediate call to '_exit()'.
static void SIGINT_interrupt(int signum) { solver->interrupt(); }

// Note that '_exit()' rather than 'exit()' has to be used. The reason is that 'exit()' calls
// destructors and may cause deadlocks if a malloc/free function happens to be running (these
// functions are guarded by locks for multithreaded use).
static void SIGINT_exit(int signum) {
    printf("\n"); printf("*** INTERRUPTED ***\n");
    if (solver->verbosity > 0){
        printStats(*solver);
        printf("\n"); printf("*** INTERRUPTED ***\n"); }
    _exit(1); }


//=================================================================================================
// Main:


void VirtualScout::add_learn_clause(int* clause, int size){
  printf("CLAUSE UNSAT - SIZE:%d  <=",size);  
  for(int i = 0;i < size;i++){
    printf("%d ", clause[i]);
  }
  printf("\n");
  vec<Lit> my_clause;
  for(int i = 0;i < size;i++)my_clause.push(toLit(clause[i]));
  SS->add_learn_clause(my_clause);

}

int VirtualScout::getMPThread(){return 1;}
int VirtualScout::getMPCore(){return 1;}

void VirtualScout::backtrack(){SS->backtrack();}

/**
 * \brief Restart the solver : Backtrack until to first level of decision. 
 */
void VirtualScout::restart(){SS->restart();}


/**
 * \brief Checks if a variable is assigned or not by the solver.
 * \param[in] variable The variable to test.
 * \return 
 If this variable is assigned to false, she is positif : return 0 <=> VAR_POSITIF_ASSIGNED
 If this variable is assigned to true, she is negatif : return 1 <=> VAR_NEGATIF_ASSIGNED 
 If this variable is not assigned : return 2 <=> VAR_NOT_ASSIGNED 
*/
char VirtualScout::is_assigned(const int& variable){return SS->is_assigned(variable);}


/**
 * \brief Create a new decision level, decide a litteral to assign and make the necessary propagations
 * \param[in] variable The decision variable.
 * \param[in] polarity The decision polarity. This variable and this polarity produce a literal
 * \return 
 If the initial problem is satisfiable return 0 <=> DECISION_PROPAGATE_SAT
 If the propagation produce a conflict return -1 <=> DECISION_PROPAGATE_CONFLICT
 Else return the number of propagation 
*/
int VirtualScout::decision_propagate(const int& variable, const char& polarity){return SS->decision_propagate(variable,polarity);}

int VirtualScout::nb_vars(){return SS->nVars();}

/* 0 : sat
 * 1 : unsat
 * 2 : cube unsat
 * 3 : indeterminate */
int VirtualScout::start(int* cube){
  vec<Lit> my_cube;
  for(int i = 0;;i++){
    int lit=cube[i];
    if(!lit)break;
    Lit p = mkLit(lit>0?(lit-1):(-lit)-1,lit>0?false:true);
    my_cube.push(p);
  }
  //displayVecLit(my_cube);
  lbool ret = SS->solveLimited(my_cube); 
  if(ret == l_True) return 0; else if(ret == l_False) return (!SS->okay()) ? 1 : 2;   
  return 3;
}


/* 0 : sat
 * 1 : unsat
 * 2 : cube unsat
 * 3 : indeterminate */
int VirtualScout::start(){
  vec<Lit> dummy;
  lbool ret = SS->solveLimited(dummy);
        
  if (SS->verbosity > 0){
    printStats(*SS);
    printf("\n"); }
  
  /*printf(ret == l_True ? "s SATISFIABLE\n" : ret == l_False ? "s UNSATISFIABLE\n" : "s INDETERMINATE\n");*/
  /*
  if (res != NULL){
    if (ret == l_True){
      printf("SAT\n");
      for (int i = 0; i < SS->nVars(); i++)
        if (S->model[i] != l_Undef)
          fprintf(res, "%s%s%d", (i==0)?"":" ", (S->model[i]==l_True)?"":"-", i+1);
      fprintf(res, " 0\n");
    } else {
      if (ret == l_False){
        fprintf(res, "UNSAT\n"), fclose(res);
      }
    }
    fclose(res);
  } else {
    if(S->showModel && ret==l_True) {
      printf("v ");
      for (int i = 0; i < S->nVars(); i++)
        if (S->model[i] != l_Undef)
          printf("%s%s%d", (i==0)?"":" ", (S->model[i]==l_True)?"":"-", i+1);
      printf(" 0\n");
    }
    }*/
  if(ret == l_True){
    return 0;
  }else if(ret == l_False){
    if(!SS->okay()){
      return 1;
    }else{
      return 2;
    }
  }
  return 3;
}



VirtualScout::VirtualScout(int argc, char** argv){

  try {
    /*printf("c\nc This is glucose 3.0 --  based on MiniSAT (Many thanks to MiniSAT team)\nc Simplification mode is turned on\nc\n");
     */
    setUsageHelp("c USAGE: %s [options] <input-file> <result-output-file>\n\n  where input may be either in plain or gzipped DIMACS.\n");
        
        
#if defined(__linux__)
    fpu_control_t oldcw, newcw;
    _FPU_GETCW(oldcw); newcw = (oldcw & ~_FPU_EXTENDED) | _FPU_DOUBLE; _FPU_SETCW(newcw);
    /*printf("WARNING: for repeatability, setting FPU to use double precision\n");*/
#endif
    // Extra options:
    //

    
    double      initial_time = cpuTime();
    
    SS = new SimpSolver();
   
    if (!pree) SS->eliminate(true);

    SS->verbosity = verbe;
     SS->verbosity = 0;
    //SS->verbEveryConflicts = vv;
    //S->showModel = mod;
    solver = SS;
    // Use signal handlers that forcibly quit until the solver will be able to respond to
    // interrupts:
    signal(SIGINT, SIGINT_exit);
    signal(SIGXCPU,SIGINT_exit);

    // Set limit on CPU-time:
    if (cpu_limm != INT32_MAX){
      rlimit rl;
      getrlimit(RLIMIT_CPU, &rl);
      if (rl.rlim_max == RLIM_INFINITY || (rlim_t)cpu_limm < rl.rlim_max){
        rl.rlim_cur = cpu_limm;
        if (setrlimit(RLIMIT_CPU, &rl) == -1)
          printf("WARNING! Could not set resource limit: CPU-time.\n");
      } }
    // Set limit on virtual memory:
    if (mem_limm != INT32_MAX){
      rlim_t new_mem_lim = (rlim_t)mem_limm * 1024*1024;
      rlimit rl;
      getrlimit(RLIMIT_AS, &rl);
      if (rl.rlim_max == RLIM_INFINITY || new_mem_lim < rl.rlim_max){
        rl.rlim_cur = new_mem_lim;
        if (setrlimit(RLIMIT_AS, &rl) == -1)
          printf("WARNING! Could not set resource limit: Virtual memory.\n");
      } }
        
    if (argc == 1)
      printf("Reading from standard input... Use '--help' for help.\n");

    gzFile in = (argc == 1) ? gzdopen(0, "rb") : gzopen(argv[1], "rb");
    if (in == NULL)
      printf("ERROR! Could not open file: %s\n", argc == 1 ? "<stdin>" : argv[1]), exit(1);
        
    if (SS->verbosity > 0){
      printf("c ========================================[ Problem Statistics ]===========================================\n");
      printf("c |                                                                                                       |\n"); }
        
    ress = (argc >= 3) ? fopen(argv[argc-1], "wb") : NULL;
   
    parse_DIMACS(in, *SS);
    gzclose(in);


    if (SS->verbosity > 0){
      printf("c |  Number of variables:  %12d                                                                   |\n", SS->nVars());
      printf("c |  Number of clauses:    %12d                                                                   |\n", SS->nClauses()); }
        
    double parsed_time = cpuTime();
    if (SS->verbosity > 0){
      printf("c |  Parse time:           %12.2f s                                                                 |\n", parsed_time - initial_time);
      printf("c |                                                                                                       |\n"); }

    // Change to signal-handlers that will only notify the solver and allow it to terminate
    // voluntarily:
    signal(SIGINT, SIGINT_interrupt);
    signal(SIGXCPU,SIGINT_interrupt);

    
    SS->eliminate(true);
    double simplified_time = cpuTime();
    if (SS->verbosity > 0){
      printf("c |  Simplification time:  %12.2f s                                                                 |\n", simplified_time - parsed_time);
      printf("c |                                                                                                       |\n"); }

    if (!SS->okay()){
      //if (SS->certifiedUNSAT) fprintf(S->certifiedOutput, "0\n"), fclose(S->certifiedOutput);
      if (ress != NULL) fprintf(ress, "UNSAT\n"), fclose(ress);
      if (SS->verbosity > 0){
        printf("c =========================================================================================================\n");
        printf("Solved by simplification\n");
        printStats(*SS);
        printf("\n"); }
      printf("s UNSATISFIABLE\n");
      exit(20);
    }

    if (dimacss){
      if (SS->verbosity > 0)
        printf("c =======================================[ Writing DIMACS ]===============================================\n");
      SS->toDimacs((const char*)dimacss);
      if (SS->verbosity > 0)
        printStats(*SS);
      exit(0);
    }
    
  } catch (OutOfMemoryException&){
    printf("c =========================================================================================================\n");
    printf("INDETERMINATE\n");
    exit(0);
  }
}
