
int ScoutMain(int argc, char** argv);
