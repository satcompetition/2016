INSTALL
---------------

You must install the last version of Open MPI :
http://www.open-mpi.org/faq/?category=building

We are in the folder ampharos :

    cd Script/

    make all -j


SIMPLE USE ON ANY COMPUTER
---------------

./ampharos_simple.sh problem.cnf

USE
---------------
The script **ampharos.sh** is used to start the solver, this script contains 8
parameters :

./ampharos.sh **O1 O2 O3 O4 O5 O6 O7 O8**

**O1** Machine type : CLUSTER || PC 
    
    CLUSTER : many processor in a massively parallel way with Torque,
    on two node of 32 core. It start 62 workers, 1 manager and 1 master
    on this processor. So we have 64 process. To change these numbers,
    it is in the file ampharos.sh.
    
    PC : one processor, it start 4 workers, 1 manager and 1 master on
    this processor.  So we have 6 process. To change these numbers, it
    is in the file ampharos.sh
    
**O2** Type of sequential solvers : GLUCOSE_MINISAT_MINISATPSM

**O3** Operating Mode : CONCURENTS || MANAGER
   
    CONCURENTS : start the sequential solvers in concurrent without the
    scout.

    MANAGER : the sequential solvers solve the cubes of scout.
   
**O4** It the name of LOG folder, it must exist in the folder
   ampharos/Log/ !

**O5** Relative path of the CNF formula

**O6** Worker Polarity Heuristic : 0 || 1 || 2 || 3 || 4 || 5 || 6 || 7
   
    For choose a cube, the workers use this Polarity Heuristic. 
   
        0 : polarity of the worker
        1 : random polarity
        2 : always positif polarity 
        3 : always negatif polarity
        4 : selects the polarity following the number of propagations
        5 : 1/4 random, 3/4 polarity
        6 : choose random heuristique for each cube following a probability
        distribution
        7 : followinf the number of cubes and the number of worker on each
        node with the polarity

**O7** the height of the tree build by the scout 

**O8** kinds of communications : SHARE_ALL || NO_SHARE || SHARE_UNITS_LITERALS || SHARE_CLAUSES || SHARE_ALL_NO_ULN
   
**O9** Number of conflicts for the manager (10000)

**10** Number of conflicts for the workers (1000)

**11** Put 1

EXAMPLE
---------------
./ampharos.sh PC GLUCOSE_MINISAT_MINISATPSM MANAGER logEss ../../dimacs_sc2015_pre/002-80-12.cnf 7 1 SHARE_ALL 10000 1000 1

In the example : we start SwarmSAT on a PC, we use 2 Glucose, 2
Minisat and 2 MinisatPsm for the workers, the manager build the tree with a height of 1
and the worker solve the cubes of this tree, the LOG is in the folder
ampharos/Log/logEss, we solve the CNF formula 002-80-12.cnf. We exchange every information.
