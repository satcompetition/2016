
for ERR in $(ls $1/*.err)
do 
    NAME=$(basename $ERR)
    NAME=${NAME%.*}
    LOG="$1/$NAME.log"
    SOL="IN"

    TIME=`grep -i "\[MASTER 0\]KILL real_time" $LOG | cut -d ' ' -f4`
    if [ "$TIME" == "" ];then
        TIME="1200"
    fi

    NB_CUBES_INIT=`grep -i "\[SCOUT 65\]nb_cubes" $LOG | cut -d ':' -f2`
    NB_CUBES_INIT=$(echo "$NB_CUBES_INIT" | head -n 1 ) 
    if [ "$NB_CUBES_INIT" == "" ];then
        NB_CUBES_INIT="0"
    fi

    CUBES=`grep -i "\[SCOUT 65\]nb_cubes" $LOG | cut -d ':' -f2 | sed 's/ //g'`
    CUBES=$(echo "$CUBES" | tail -n 1 ) 
    if [ "$CUBES" == "" ];then
        CUBES="0"
    fi

    if grep -q "\[MASTER 0\]UNSATISFIABLE" "$LOG"
    then
        SOL="UNSAT"
    fi

    if grep -q "\[MASTER 0\]SATISFIABLE" "$LOG"
    then
        SOL="SAT"
    fi

    echo $TIME 
done

