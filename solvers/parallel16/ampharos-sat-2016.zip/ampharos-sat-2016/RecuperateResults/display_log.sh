display_log()
{
    (( CPT_INST = 0 ))
    (( CPT_SEGFAULT = 0 ))
    (( CPT_ERRMPI = 0 ))
    for INSTANCE in $(ls $1/*.err)
    do 
        NAME=$(basename $INSTANCE)
        NAME=${NAME%.*}
        LOG="$1/$NAME.log"



        if grep -q "\[MASTER 0\]UNSATISFIABLE" "$LOG"
        then
            TATA="UNSATISFIABLE"
        else 
            if grep -q "\[MASTER 0\]SATISFIABLE" "$LOG"
            then
                TATA="SATISFIABLE" 
            else
                TATA="INDETERMINATE"
            fi
        fi
        (( CPT_INST++ ))
        tail -n 300 $LOG
        
        echo $LOG
        echo $INSTANCE
        echo
        echo $TATA
        TROIS=$(tail -n 3 $INSTANCE)
        echo $TROIS
        read -p "Press any key to continue ..."

    done
}

display_log $1