
echo "==="
name=`basename $1`
echo "name=$name"
echo "prefixe=$1"
echo "==="
echo "name:finalState:time(sec.):nbCubesInit:nbCubesFinal:nbScoutUNSAT"
(( ESS=0 ))

for ERR in $(ls $1/*.err)
do 
    NAME=$(basename $ERR)
    NAME=${NAME%.*}
    NAME2="${NAME}"
    LOG="$1/$NAME.log"
    SOL="IN"
    (( ESS++ ))
    GOOD_ESS=`printf "%02d\n" "$ESS"`  
    TIME=`grep -i "\[MASTER 0\]KILL real_time" $LOG | cut -d ' ' -f4`
    if [ "$TIME" == "" ];then
        TIME="2400"
    fi

    UL=`grep -i "\[S\]|" $LOG | cut -d '|' -f4 | sed 's/ //g'`
    UL=$(echo "$UL" | tail -n 1 )


    RECEIVE=`grep -i "\[S\]|" $LOG | cut -d '|' -f7 | sed 's/ //g'`
    RECEIVE=$(echo "$RECEIVE" | tail -n 1 )

    KEEP=`grep -i "\[S\]|" $LOG | cut -d '|' -f8 | sed 's/ //g'`
    KEEP=$(echo "$KEEP" | tail -n 1 )
 
    RATIO=`grep -i "\[S\]|" $LOG | cut -d '|' -f9 | sed 's/ //g'`
    RATIO=$(echo "$RATIO" | tail -n 1 )
 
  
    CUBE=`grep -i "\[S\]|" $LOG | cut -d '|' -f3 | sed 's/ //g'`
    CUBE=$(echo "$CUBE" | tail -n 1 )
      
   
    if grep -q "\[MASTER 0\]UNSATISFIABLE" "$LOG"
    then
        SOL="UNSAT"
    fi

    if grep -q "\[MASTER 0\]SATISFIABLE" "$LOG"
    then
        SOL="SAT"
    fi
   
    printf "%-3.3s %-16.16s %-10.9s %-10.9s %-10.9s %-10.9s %-10.10s %-10.9s %-10.9s\n" "$GOOD_ESS" "$NAME2" "$SOL" "$TIME" "$CUBE" "$UL" "$RECEIVE" "$KEEP" "$RATIO"  

#printf "%s %s\n" "$NAME2" "$TIME"

#printf "%s %s\n" "$NAME2" "$TIME"

done

