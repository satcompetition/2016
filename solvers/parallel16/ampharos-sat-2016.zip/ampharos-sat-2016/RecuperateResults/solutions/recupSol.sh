#!/bin/bash


(( CPT = 0 ))
(( NB_SAT = 0 ))
(( NB_UNSAT = 0 ))
(( NB_IN = 0 ))
for i in `cat syrup-adapt-satrace15.txt | cut -d ' ' -f1`

do
    NAME=`basename $i`



    NAME=$(echo "$NAME" |  sed 's/\.bz2//g')


    SAT=`grep -c "$NAME" sats.list`
    UNSAT=`grep -c "$NAME" unsats.list`
    IN=`grep -c "$NAME" unsolved.list`

    if [ "$SAT" == "1" ];then
        echo "$NAME SAT"     
        (( NB_SAT++ ))
        (( CPT++ ))
    elif [ "$UNSAT" == "1" ];then
        echo "$NAME UNSAT"
        (( NB_UNSAT++ ))
        (( CPT++ ))
    elif [ "$IN" == "1" ];then
        echo "$NAME IN"
        (( NB_IN++ ))
        (( CPT++ ))
    fi

    
done
echo "SAT:$NB_SAT UNSAT:$NB_UNSAT IN:$NB_IN TOTAL:$CPT"
