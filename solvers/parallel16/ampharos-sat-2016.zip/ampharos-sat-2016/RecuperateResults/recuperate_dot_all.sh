
rm -rf ../Log/traceDOT
mkdir ../Log/traceDOT

for log in $(ls $1/*.log)
do 
    ./recuperate_dot.sh $log
done
