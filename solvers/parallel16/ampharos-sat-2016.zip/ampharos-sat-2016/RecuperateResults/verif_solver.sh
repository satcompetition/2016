
for ERR in $(ls $1/*.err)
do 
    NAME=$(basename $ERR)
    NAME=${NAME%.*}
    NAME2="${NAME}"
    LOG="$1/$NAME.log"
    echo $LOG
    for i in $(seq 62)
    do
        TIME_1=`grep -i "\[WORKER $i\]I am" $LOG  | cut -d ':' -f2 | sed 's/ //g'`

        TIME_1=$(echo "$TIME_1" | tail -n 1 ) 
        TIME_2=`grep -i "\[WORKER $i\]I have finished" $LOG | cut -d ':' -f2 | sed 's/ //g'`
        TIME_2=$(echo "$TIME_2" | tail -n 1 ) 
        echo "[WORKER $i] $TIME_1 $TIME_2"
    done
   
done