

NAME=$(basename $1 | sed 's/\.log//g')

echo $NAME
echo $1

rm -rf ../Log/traceDOT/$NAME
mkdir ../Log/traceDOT/$NAME


NB_DOT=`grep "^DOT END :" $1 | tail -n 1 | cut -d ':' -f2 | sed 's/ //g'`

(( DOT_CURRENT = 0 ))
(( diff_ligne = 0 ))

if [ "$NB_DOT" == "" ];then
    echo "Aucun DOT dans le LOG"
    return
fi

while [ "$DOT_CURRENT" -ne "$NB_DOT" ]
do
    (( DOT_CURRENT++ ))
    GOOD_DOT_CURRENT=`printf "%04d\n" "$DOT_CURRENT"`  
    touch ../Log/traceDOT/$NAME/tree$GOOD_DOT_CURRENT.dot
    first_ligne=`grep -n "^DOT START : $DOT_CURRENT$" $1 | cut -d ':' -f1 | sed 's/ //g'`
    end_ligne=`grep -n "^DOT END : $DOT_CURRENT$" $1 | cut -d ':' -f1 | sed 's/ //g'`
    
    (( end_ligne-- ))
    (( diff_ligne=end_ligne-first_ligne ))
    `head -n $end_ligne $1 | tail -n $diff_ligne | grep "^DOT:" | cut -d ':' -f2 > ../Log/traceDOT/$NAME/tree$GOOD_DOT_CURRENT.dot` 

    `dot ../Log/traceDOT/$NAME/tree$GOOD_DOT_CURRENT.dot | neato -n -Tpng -o > ../Log/traceDOT/$NAME/tree$GOOD_DOT_CURRENT.png`
    
    echo "tree$GOOD_DOT_CURRENT.png"
done

#DOT=`grep "^DOT:" $1 | cut -d ':' -f2 > ../Log/traceDOT/$NAME.dot` 

#`dot "../Log/traceDOT/$NAME.dot" | gvpr -c -f tree.gv | neato -n -Tpng -o treeGoodLayout.png`
#`dot "../Log/traceDOT/$NAME.dot" | neato -n -Tpng -o treeGoodLayout.png`


