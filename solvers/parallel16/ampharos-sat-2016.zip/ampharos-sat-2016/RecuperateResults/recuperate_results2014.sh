
#
#Display results of the log files, these directories must be given in parameters (from $1 to $9)
#

saved=$@
echo 
echo "CHECK 1 :  Verification de la solution des instances"
echo "CHECK 2 :  Nombre de *.log =  nombre de *.err"
echo "CHECK 3 :  Nombre d'instance = Nombre de SAT + Nombre de UNSAT + Nombre de TIME OUT"
echo "CHECK 4 :  Aucune erreur valgrind"
echo

(( NB_EXPS=0 ))

while [ -n "$1" ]
do
    (( SAT = 0 ))
    (( UNSAT = 0 ))
    (( TOTAL = 0 ))
    (( CPT_INST = 0 ))
    (( TIME_OUT = 0 ))
    (( NB_EXPS++ ))
    name=`basename $1`

    CPT_LOG=`find $1 -name "*.log" | wc -l`
    CPT_ERR=`find $1 -name "*.log" | wc -l`
    
    CHECK1="OK"
    CHECK2="OK"
    CHECK3="OK"
    CHECK4="OK"    

    

    if [ "$CPT_LOG" != 0 ]
    then
        for instance in $(ls $1/*.log)
        do
            (( CPT_INST++ ))
            FILE_ERR=$(echo "$instance" |  sed 's/\.log//g')
            FILE_ERR="$FILE_ERR.err"
            name_instance=`basename $instance`
            name_instance=$(echo "$name_instance" |  sed 's/\.log//g')
            name_instance="$name_instance.cnf"

            if grep -q "Memcheck, a memory error detector" "$FILE_ERR"
            then
                if grep -q "ERROR SUMMARY" "$FILE_ERR"
                then
                    CHECK4="PROBLEME"   
                fi         
            fi


            if grep -q "exceeded limit 5000" "$FILE_ERR"
            then
                (( TIME_OUT ++ ))
                inter_total[$CPT_INST]=0
            else
                if ! grep -q "\[MASTER 0\]UNSATISFIABLE" "$instance" ;
                then 
                    if ! grep -q "\[MASTER 0\]SATISFIABLE" "$instance" ;
                    then
                        echo $instance
                    fi
                fi
            fi
            

            if grep -q "\[MASTER 0\]UNSATISFIABLE" "$instance"
            then
                (( UNSAT++ ))
                union_unsat[$CPT_INST]=1
                union_total[$CPT_INST]=1
                (( inter_unsat[$CPT_INST]++ ))
                (( inter_total[$CPT_INST]++ ))
               
                verif_unsat=`grep -i "^$name_instance" solution-sc2014.txt | cut -d ' ' -f2`
                if [ "$verif_unsat" == "SAT" ]
                then
                    echo $instance
                        CHECK1="PROBLEME"
                fi

                (( TOTAL++ ))
            fi
            if grep -q "\[MASTER 0\]SATISFIABLE" "$instance"
            then
                union_sat[$CPT_INST]=1
                union_total[$CPT_INST]=1
                (( inter_sat[$CPT_INST]++ ))
                (( inter_total[$CPT_INST]++ ))
                (( SAT ++ ))
                verif_sat=`grep -i "^$name_instance" solution-sc2014.txt | cut -d ' ' -f2`
                if [ "$verif_sat" == "UNSAT" ]
                then
                    echo $instance
                     CHECK1="PROBLEME"
                fi
                (( TOTAL++ ))
            fi

        done

        if [ "$CPT_LOG" -ne "$CPT_ERR" ]
        then
            CHECK2="PROBLEME"
        fi
        (( VERIF=SAT+UNSAT+TIME_OUT ))  
        if [ "$VERIF" -ne "$CPT_INST" ]
        then
            CHECK3="PROBLEME"
        fi
        
        echo "$name :"
        echo
        printf "%-10.9s %-10.9s %-10.9s %-10.9s %-10.9s \n" "SAT" "UNSAT" "SAT+UNSAT" "TIME OUT" "INSTANCE" 
        printf "%-10.9s %-10.9s %-10.9s %-10.9s %-10.9s \n" "$SAT" "$UNSAT" "$TOTAL" "$TIME_OUT" "$CPT_INST" 
        printf "%-10.9s %-10.9s %-10.9s %-10.9s \n" "CHECK 1" "CHECK 2" "CHECK 3" "CHECK 4" 
        printf "%-10.9s %-10.9s %-10.9s %-10.9s \n" "$CHECK1" "$CHECK2" "$CHECK3" "$CHECK4"
        echo
    fi
    shift 1
done

echo

(( current = 0 ))
(( SAT = 0 ))
(( UNSAT = 0 ))
(( TOTAL = 0 ))
while [ "$current" -ne "$CPT_INST" ]
do
  
    (( current++ ))
 
    if [ "${union_sat[$current]}" == "1" ];then
        (( SAT++ ))
    fi
    if [ "${union_unsat[$current]}" == "1" ];then
        (( UNSAT++ ))
    fi
    if [ "${union_total[$current]}" == "1" ];then
        (( TOTAL++ ))
    fi
    if [ "${inter_total[$current]}" == "$NB_EXPS" ];then
            (( INTOTAL++ ))
    fi
   if [ "${inter_sat[$current]}" == "$NB_EXPS" ];then
            (( INSAT++ ))
    fi
   if [ "${inter_unsat[$current]}" == "$NB_EXPS" ];then
            (( INUNSAT++ ))
    fi
   if [ "${union_total[$current]}" == "1" ];then
      if [ "${inter_total[$current]}" != "$NB_EXPS" ];then
         echo `head -n $current solution-sc2015.txt | tail -n 1`
        (( ESS++ ))
    fi
fi
done
echo "INTER - UNION : $ESS"
printf "%-40.35s %-10.9s %-10.9s %-10.9s %-10.9s %-10.9s %-10.9s\n" "INTER" "$INSAT" "$INUNSAT" "$INTOTAL" 
printf "%-40.35s %-10.9s %-10.9s %-10.9s %-10.9s %-10.9s %-10.9s\n" "UNION" "$SAT" "$UNSAT" "$TOTAL" 
echo


set -- $saved


printf "%-40.35s %-14.14s %-14.14s %-14.14s %-14.14s %-14.14s\n" "NAME" "AVG SAT" "AVG UNSAT" "AVG SAT+UNSAT" "AVG INIT CUBE" "AVG FINAL CUBE"
while [ -n "$1" ]
do
    (( SAT = 0 ))
    (( UNSAT = 0 ))
    (( TOTAL = 0 ))
    (( CPT_INST = 0 ))
    (( TIME_OUT = 0 ))
    (( SUM_TIME_SAT = 0 ))
    (( SUM_TIME_UNSAT = 0 ))
    (( SUM_TIME_BOTH = 0 ))
    (( SUM_NB_CUBES_INIT = 0 ))
    (( SUM_NB_CUBES_FIN = 0 ))
    name=`basename $1`

    CPT_LOG=`find $1 -name "*.log" | wc -l`
    CPT_ERR=`find $1 -name "*.log" | wc -l`
    
    

    if [ "$CPT_LOG" != 0 ]
    then
        for instance in $(ls $1/*.log)
        do
            FILE_ERR=$(echo "$instance" |  sed 's/\.log//g')
            FILE_ERR="$FILE_ERR.err"
            
            NB_CUBES_INIT=`grep -i "\[SCOUT 65\]nb_cubes" $instance | cut -d ':' -f2`
             
            NB_CUBES_INIT=$(echo "$NB_CUBES_INIT" | head -n 1 )
     
            if [ "$NB_CUBES_INIT" == "" ];then
                (( NB_CUBES_INIT = 0 ))
            fi
            SUM_NB_CUBES_INIT=$(echo "scale=3; $SUM_NB_CUBES_INIT+$NB_CUBES_INIT" | bc -l)

            if grep -q "exceeded limit 1200" "$FILE_ERR"
            then
                (( TIME_OUT ++ ))
                

                NB_CUBES_FIN=`grep -i "\[SCOUT 65\]nb_cubes" $instance | cut -d ':' -f2`
                NB_CUBES_FIN=$(echo "$NB_CUBES_FIN" | tail -n 1 )
                #Instance indeterminer ou l'arbre a était crée
                if [ "$NB_CUBES_FIN" != "" ];then
                    
                    SUM_NB_CUBES_FIN=$(echo "scale=3; $SUM_NB_CUBES_FIN+$NB_CUBES_FIN" | bc -l)
                fi

            fi

            (( CPT_INST++ ))
            if grep -q "\[MASTER 0\]UNSATISFIABLE" "$instance"
            then
                TIME_UNSAT=`grep -i "\[MASTER 0\]KILL real_time" $instance | cut -d ' ' -f4`
                SUM_TIME_UNSAT=$(echo "scale=3; $SUM_TIME_UNSAT+$TIME_UNSAT" | bc -l)
                SUM_TIME_BOTH=$(echo "scale=3; $SUM_TIME_BOTH+$TIME_UNSAT" | bc -l)
                (( UNSAT++ ))
                (( TOTAL++ ))
            fi
            if grep -q "\[MASTER 0\]SATISFIABLE" "$instance"
            then
                TIME_SAT=`grep -i "\[MASTER 0\]KILL real_time" $instance | cut -d ' ' -f4`
                SUM_TIME_SAT=$(echo "scale=3; $SUM_TIME_SAT+$TIME_SAT" | bc -l)
                SUM_TIME_BOTH=$(echo "scale=3; $SUM_TIME_BOTH+$TIME_SAT" | bc -l)
                (( SAT ++ ))
                (( TOTAL++ ))
            fi
        done
        AVG_TIME_SAT=$(echo "scale=3; $SUM_TIME_SAT/$SAT" | bc -l)
        AVG_TIME_UNSAT=$(echo "scale=3; $SUM_TIME_UNSAT/$UNSAT" | bc -l)
        AVG_TIME_BOTH=$(echo "scale=3; $SUM_TIME_BOTH/$TOTAL" | bc -l)
        AVG_NB_CUBES_INIT=$(echo "scale=3; $SUM_NB_CUBES_INIT/$CPT_INST" | bc -l)
        AVG_NB_CUBES_FIN=$(echo "scale=3; $SUM_NB_CUBES_FIN/$TIME_OUT" | bc -l)
        printf "%-40.35s %-14.14s %-14.14s %-14.14s %-14.14s %-14.14s\n" "$name" "$AVG_TIME_SAT" "$AVG_TIME_UNSAT" "$AVG_TIME_BOTH" "$AVG_NB_CUBES_INIT" "$AVG_NB_CUBES_FIN"
    fi
    shift 1
done
