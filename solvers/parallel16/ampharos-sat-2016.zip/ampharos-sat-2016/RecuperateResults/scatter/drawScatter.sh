#!/bin/bash 

# $1 final result 1
# $2 final result 2
# $3 name of the first method
# $4 name of the seconde method
# $5 bench name
# $6 the column
# $7 name of the picture
# $8 name of the legend

# ./drawScatter.sh normal.res lessWorker.res "normal" "less" benchParallel 3 normal-vs-less.png "time"
./extractPoint.sh $5 $6 $1 $2 > /tmp/toDrawTmp.txt
#./extractRatio.sh ../CSP/verifMUC/wcoreDCRecursiveMR.res ../CSP/verifMUC/wcoreDC+rotation.res 7 9 benchmarksCSP > /tmp/toDrawTmp.txt


cat /tmp/toDrawTmp.txt | grep -v "?" > /tmp/toDraw.txt

echo "Scatter : points : OK"

max=0
for i in `cat /tmp/toDraw.txt`
do
    tmp=`echo $i | cut -d '.' -f1`
    tmp=`expr $tmp + 1`
    if [ $tmp -gt $max ]
    then
        max=$tmp
    fi
done

num1=`cat /tmp/toDraw.txt | cut -d ' ' -f1`
num2=`cat /tmp/toDraw.txt | cut -d ' ' -f2`


size=`echo $num1 | grep -o ' ' | wc -l`
size=$(($size + 1))
cpt=0

pnt1=0
pnt2=0

while test $cpt != $size
do
    val1=`echo $num1 | cut -d ' ' -f$(($cpt + 1))`
    val2=`echo $num2 | cut -d ' ' -f$(($cpt + 1))`
    val1=`echo $val1 | cut -d '.' -f1`
    val2=`echo $val2 | cut -d '.' -f1`
    
    if [ $val1 -lt $val2 ]
    then
        pnt1=$(($pnt1 + 1))
    fi
    
    if [ $val1 -gt $val2 ]
    then
        pnt2=$(($pnt2 + 1))
    fi

    cpt=$(($cpt + 1))
    
done

#max=1000
min=10

echo "set grid" > nuage.gnu
echo "set key on inside left" >> nuage.gnu

echo "set xrange [ $min : $max ]" >> nuage.gnu
echo "set yrange [ $min : $max ]" >> nuage.gnu

echo "set log y; set log x;" >> nuage.gnu
#echo "set ytics add (\"\" 1000)" >> nuage.gnu
#echo "set ytics add (\"\" 10)" >> nuage.gnu
#echo "set ytics (1, \"\" 10, 100, \"\" 1000, 10000)" >> nuage.gnu
echo "set ylabel font \",20\" \"$4 : $pnt2 dots\"" >> nuage.gnu

#echo "set log x; set xtics 1,10,10000" >> nuage.gnu
#echo "set xtics add (\"\" 1000)" >> nuage.gnu
#echo "set xtics add (\"\" 10)" >> nuage.gnu
#echo "set xtics (1, \"\" 10, 100, \"\" 1000, 10000)" >> nuage.gnu
echo "set xlabel font \",20\" \"$3 : $pnt1 dots\"" >> nuage.gnu

#echo "set xlabel offset 20,1.5" >> nuage.gnu
#echo "set ylabel offset 6.8,7.7" >> nuage.gnu
#echo "set ylabel rotate by 0" >> nuage.gnu

#echo "set label \"$3\" at 2,400" >> nuage.gnu
#echo "set label \"$4\" at 300,3" >> nuage.gnu

#echo "set arrow from 10,950 to 950,950 nohead lw 1 lt 2" >> nuage.gnu
#echo "set arrow from 950,10 to 950,950 nohead lw 1 lt 2" >> nuage.gnu

echo "plot x notitle" >> nuage.gnu

#echo "set xtics axis" >> nuage.gnu
#echo "set ytics axis" >> nuage.gnu

echo "replot '/tmp/toDraw.txt' using 1:2 lt 4 pt 4 notitle" >> nuage.gnu

echo "set terminal postscript eps noenhanced defaultplex" >> nuage.gnu
#echo "set terminal png size 600,500" >> nuage.gnu
echo "set output '$7'" >> nuage.gnu
echo "replot" >> nuage.gnu 
#echo "pause -1" >> nuage.gnu

gnuplot nuage.gnu
rm nuage.gnu

echo "Scatter : finish : OK"
