
#!/bin/bash 

name1=`basename $1`
name2=`basename $2`

path_res_1="../res/$name1.res"
path_res_2="../res/$name2.res"

../recuperate_res.sh $1 > $path_res_1
echo "Scatter : $path_res_1 : OK"

../recuperate_res.sh $2 > $path_res_2
echo "Scatter : $path_res_2 : OK"

./drawScatter.sh $path_res_1 $path_res_2 $name1 $name2 ../solution.txt 3 "$name1-vs-$name2.png" "time"
