#!/bin/bash

# $1 the list of benchmark
# $2 the column comparaison
# $3 the first file
# $4 the second file

bench=`cat $1 | cut -d ' ' -f1`

for i in $bench
do    
    if [ $i == "c" ]; then continue; fi

  

    nom=$(echo $i | sed 's/\.cnf//g')
   
    
    #c1=`cat $3 | grep "$nom.log " | cut -d ' ' -f$2`    
    #c2=`cat $4 | grep "$nom.log " | cut -d ' ' -f$2`
    
    c1=`cat $3 | grep "^$nom " | cut -d ' ' -f$2`
    c2=`cat $4 | grep "^$nom " | cut -d ' ' -f$2`


    if [ "$c1" == "" ]; then continue; fi
    if [ "$c2" == "" ]; then continue; fi
    echo "$c1 $c2"        
done


