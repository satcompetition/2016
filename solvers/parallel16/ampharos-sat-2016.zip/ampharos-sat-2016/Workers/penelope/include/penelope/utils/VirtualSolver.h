
#include <vector>
#include "mpi.h"


class VirtualSolver{
 public:
  VirtualSolver(int argc, char** argv,int n_rank);
  int start();


  void setMPIrequest(MPI_Request* n_requestListenMaster);
  void setMPImessageMaster(int* n_messageMaster);
  void setMPIrankMaster(const int& n);
  void setMPItag(const int&  n);
  void setMPIrank(const int& n);

  int getMPThread();
  int getMPCore();
  
};
