/*****************************************************************************************[Main.cc]
 Glucose -- Copyright (c) 2009, Gilles Audemard, Laurent Simon
				CRIL - Univ. Artois, France
				LRI  - Univ. Paris Sud, France
 
Glucose sources are based on MiniSat (see below MiniSat copyrights). Permissions and copyrights of
Glucose are exactly the same as Minisat on which it is based on. (see below).

 Syrup (Glucose Parallel) -- Copyright (c) 2013-2014, Gilles Audemard, Laurent Simon
                                CRIL - Univ. Artois, France
                                Labri - Univ. Bordeaux, France

---------------

Copyright (c) 2003-2006, Niklas Een, Niklas Sorensson
Copyright (c) 2007-2010, Niklas Sorensson

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and
associated documentation files (the "Software"), to deal in the Software without restriction,
including without limitation the rights to use, copy, modify, merge, publish, distribute,
sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or
substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT
OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
**************************************************************************************************/

#include <errno.h>

#include <signal.h>
#include <zlib.h>
#include <sys/resource.h>

#include "utils/System.h"
#include "utils/ParseUtils.h"
#include "utils/Options.h"
#include "core/Dimacs.h"
#include "simp/SimpSolver.h"
#include "core/MinisatSolver.h"

#ifndef virsol
#define virsol
#include "VirtualSolver.h"
#endif



using namespace Glucose;



IntOption    verb   ("MAIN", "verb",   "Verbosity level (0=silent, 1=some, 2=more).", 0, IntRange(0, 2));
BoolOption   mod   ("MAIN", "model",   "show model.", false);
IntOption    vv  ("MAIN", "vv",   "Verbosity every vv conflicts", 10000, IntRange(1,INT32_MAX));
BoolOption   pre    ("MAIN", "pre",    "Completely turn on/off any preprocessing.", true);
StringOption dimacs ("MAIN", "dimacs", "If given, stop after preprocessing and write the result to this file.");
IntOption    cpu_lim("MAIN", "cpu-lim","Limit on CPU time allowed in seconds.\n", INT32_MAX, IntRange(0, INT32_MAX));
IntOption    mem_lim("MAIN", "mem-lim","Limit on memory usage in megabytes.\n", INT32_MAX, IntRange(0, INT32_MAX));

Solver* solver;
MinisatSolver *msolver;

SimpSolver* preproc;


inline void initGlucose()
{
  solver = new Solver();
  solver->verbosity = 0;
  solver->verbEveryConflicts = 10000;
  solver->showModel = false;
  
  while(solver->nVars() < preproc->nVars()){
    solver->newVar();
  }
  for(int i = 0 ; i<(preproc->trail).size() ; i++) solver->uncheckedEnqueue((preproc->trail)[i]);

  for(int i = 0 ; i<(preproc->clauses).size() ; i++)
    {
      vec<Lit> cl;
      for(int j = 0 ; j<(preproc->ca)[preproc->clauses[i]].size() ; j++) cl.push((preproc->ca)[preproc->clauses[i]][j]);
      solver->addClause(cl);
    }
}

inline void initMinisat()
{
  msolver = new MinisatSolver();
  msolver->verbosity = 0;

  while(msolver->nVars() < preproc->nVars()) msolver->newVar();
  for(int i = 0 ; i<(preproc->trail).size() ; i++) msolver->uncheckedEnqueue((preproc->trail)[i]);

  for(int i = 0 ; i<(preproc->clauses).size() ; i++)
    {
      vec<Lit> cl;
      for(int j = 0 ; j<(preproc->ca)[preproc->clauses[i]].size() ; j++) cl.push((preproc->ca)[preproc->clauses[i]][j]);
      msolver->addClause_(cl);
    }
  
}


inline void optionMemoryAndTime()
{
  // Set limit on CPU-time:
  if (cpu_lim != INT32_MAX)
    {
      rlimit rl;
      getrlimit(RLIMIT_CPU, &rl);
      if (rl.rlim_max == RLIM_INFINITY || (rlim_t)cpu_lim < rl.rlim_max)
        {
          rl.rlim_cur = cpu_lim;
          if (setrlimit(RLIMIT_CPU, &rl) == -1) printf("WARNING! Could not set resource limit: CPU-time.\n");
        }
    }
    
  // Set limit on virtual memory:
  if (mem_lim != INT32_MAX)
    {
      rlim_t new_mem_lim = (rlim_t)mem_lim * 1024*1024;
      rlimit rl;
      getrlimit(RLIMIT_AS, &rl);
      if (rl.rlim_max == RLIM_INFINITY || new_mem_lim < rl.rlim_max){
        rl.rlim_cur = new_mem_lim;
        if (setrlimit(RLIMIT_AS, &rl) == -1)
          printf("WARNING! Could not set resource limit: Virtual memory.\n");
      }
    }

}

//=================================================================================================

// Note that '_exit()' rather than 'exit()' has to be used. The reason is that 'exit()' calls
// destructors and may cause deadlocks if a malloc/free function happens to be running (these
// functions are guarded by locks for multithreaded use).
static void SIGINT_exit(int signum)
{
  printf("\n"); printf("*** INTERRUPTED ***\n");
  _exit(1);
}


//=================================================================================================
// Main:

int VirtualSolver::getMPThread(){return 1;}
int VirtualSolver::getMPCore(){return 1;}

/**
 * \brief Backtrack until to the previous level of decision.
 */    
void VirtualSolver::backtrack(){if(isMinisat) msolver->backtrack(); else solver->backtrack();}

/**
 * \brief Restart the solver : Backtrack until to first level of decision. 
 */
void VirtualSolver::restart(){if(isMinisat) msolver->restart(); else solver->restart();}

/**
 * \brief Checks if a variable is assigned or not by the solver.
 * \param[in] variable The variable to test.
 * \return 
 If this variable is assigned to false, she is positif : return 0 <=> VAR_POSITIF_ASSIGNED
 If this variable is assigned to true, she is negatif : return 1 <=> VAR_NEGATIF_ASSIGNED 
 If this variable is not assigned : return 2 <=> VAR_NOT_ASSIGNED 
*/
char VirtualSolver::is_assigned(const int& variable)
{
  if(isMinisat) return msolver->is_assigned(variable); else return solver->is_assigned(variable);
}

/**
 * \brief Create a new decision level, decide a litteral to assign and make the necessary propagations
 * \param[in] variable The decision variable.
 * \param[in] polarity The decision polarity. This variable and this polarity produce a literal
 * \return 
 If the initial problem is satisfiable return 0 <=> DECISION_PROPAGATE_SAT
 If the propagation produce a conflict return -1 <=> DECISION_PROPAGATE_CONFLICT
 Else return the number of propagation 
*/
int VirtualSolver::decision_propagate(const int& variable, const char& polarity)
{
  if(isMinisat) return msolver->decision_propagate(variable, polarity);
  else  return solver->decision_propagate(variable,polarity);
}


int VirtualSolver::nb_vars(){if(isMinisat) return msolver->nVars(); else return solver->nVars();}

char VirtualSolver::get_polarity(const int& variable)
{
  if(isMinisat) return msolver->getPolarity(variable); else return solver->getPolarity(variable);
}

void VirtualSolver::recuperate_variables(){if(isMinisat) return msolver->recuperate_variables(); else return solver->recuperate_variables();}
void VirtualSolver::recuperates_units_literals()
{
  if(isMinisat) return msolver->recuperates_units_literals(); else return solver->recuperates_units_literals();
}

bool VirtualSolver::add_unit_literal(const int& lit)
{
  if(isMinisat) return msolver->add_unit_literal(lit); else return solver->add_unit_literal(lit);
}

bool VirtualSolver::add_received_clauses()
{
  if(isMinisat) return msolver->add_received_clauses(); else return solver->add_received_clauses();
}

int* modus;

int* VirtualSolver::model()
{

   modus = (int*) calloc(isMinisat ? msolver->nVars() : solver->nVars(),sizeof(int));
 
  int j = 0;

 
  
  vec<lbool> &modelSolver = isMinisat ? msolver->model : solver->model;
  

  modelSolver.copyTo(preproc->model);
  
   preproc->extendModel();
  vec<lbool> &model = preproc->model;

  
  for (int i = 0; i < model.size() ; i++)
    if (model[i] != l_Undef)
      {
        modus[j] = (model[i] == l_True) ? i+1 : -(i+1);
        j++;
      }
  modus[j] = 0;

  
  return modus;
}

/* 0 : sat
 * 1 : unsat
 * 2 : cube unsat
 * 3 : indeterminate */
int VirtualSolver::start(int* cube, int size)
{
  vec<Lit> my_cube;
  for(int i = 0 ; i < size ; i++) my_cube.push(toLit(cube[i]));  
  lbool ret = isMinisat ? msolver->solveLimited(my_cube) : solver->solveLimited(my_cube);
 
  if(ret == l_True) return 0;
  else if(ret == l_False) return (isMinisat ? (!msolver->okay()) : (!solver->okay())) ? 1 : 2;
  return 3;  
}


/* 0 : sat
 * 1 : unsat
 * 2 : cube unsat
 * 3 : indeterminate */
int VirtualSolver::start()
{  
  return start(NULL, 0);
}// start



VirtualSolver::VirtualSolver(int argc, char** argv, bool isMini){
  isMinisat = isMini;
  solver = NULL;
  msolver = NULL;
  
  try {
    /*printf("c\nc This is glucose 3.0 --  based on MiniSAT (Many thanks to MiniSAT team)\nc Simplification mode is turned on\nc\n");
     */
    setUsageHelp("c USAGE: %s [options] <input-file> <result-output-file>\n\n  where input may be either in plain or gzipped DIMACS.\n");
        
    
#if defined(__linux__)
    fpu_control_t oldcw, newcw;
    _FPU_GETCW(oldcw); newcw = (oldcw & ~_FPU_EXTENDED) | _FPU_DOUBLE; _FPU_SETCW(newcw);
    /*printf("WARNING: for repeatability, setting FPU to use double precision\n");*/
#endif
    signal(SIGINT, SIGINT_exit);
    signal(SIGXCPU,SIGINT_exit);
    
    double      initial_time = cpuTime();
    
    preproc = new SimpSolver();    
    preproc->parsing = 1;
        
    if (argc == 1) printf("Reading from standard input... Use '--help' for help.\n");
    gzFile in = (argc == 1) ? gzdopen(0, "rb") : gzopen(argv[1], "rb");
    if (in == NULL) printf("ERROR! Could not open file: %s\n", argc == 1 ? "<stdin>" : argv[1]), exit(1);

    parse_DIMACS(in, *preproc);
    gzclose(in);

    //lbool result = lbool(preproc->eliminate(true));    
    
    if(isMinisat) initMinisat(); 
    else
      initGlucose();
    
    double parsed_time = cpuTime();
    
    // Change to signal-handlers that will only notify the solver and allow it to terminate voluntarily:    
    signal(SIGINT, SIGINT_exit);
    signal(SIGXCPU,SIGINT_exit);

    double simplified_time = cpuTime();
    

    if ((isMinisat && !msolver->okay()) || (!isMinisat && !solver->okay())) exit(20);
  } catch (OutOfMemoryException&)
    {
      printf("c =========================================================================================================\n");
      printf("INDETERMINATE\n");
      exit(0);
    }
}
