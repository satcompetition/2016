


int glucoseMain(int argc, char** argv, int typeSolver);
