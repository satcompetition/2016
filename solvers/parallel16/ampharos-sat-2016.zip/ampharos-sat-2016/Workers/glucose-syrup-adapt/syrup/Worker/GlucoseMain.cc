#include "utils/Options.h"
#include <sys/types.h>
#include "utils/System.h"


#ifndef work
#define work
#include "Worker.h"
#endif

#include "../../../define.h"

using namespace Glucose;

int glucoseMain(int argc, char** argv, int typeSolver)
{
  parseOptions(argc, argv, true);
  /*Association du Worker*/
  Worker::extern_all(argc, argv, 7, typeSolver, (typeSolver) ? "GlucoseSyrup" : "Minisat", 3, 1);
  return 0;
}

