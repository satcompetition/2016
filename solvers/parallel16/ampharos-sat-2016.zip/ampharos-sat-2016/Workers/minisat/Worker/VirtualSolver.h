
#include <vector>
#include "mpi.h"
#include <sys/time.h>


class VirtualSolver{
 public:
  VirtualSolver(int argc, char** argv);
  
  int start();
  int start(int* cube, int size);
  
  void backtrack();  
  void restart();

  char is_assigned(const int& variable);
  int decision_propagate(const int& variable, const char& polarity);

  char get_polarity(const int& variable);
  
  int nb_vars();

  void recuperate_variables();
  void recuperates_units_literals();

  int* model();

  bool add_received_clauses();
     
  bool add_unit_literal(const int& lit);

  int getMPThread();
  int getMPCore();
};
