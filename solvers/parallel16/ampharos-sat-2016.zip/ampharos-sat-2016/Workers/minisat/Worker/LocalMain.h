#ifndef LocalMainMinisat
#define LocalMainMinisat

#include "../utils/Options.h"
#include <sys/types.h>
#include "../utils/System.h"

#include "Worker.h"
#include "../../../define.h"

class RunMinisat
{  
public:
  int localMain(int argc, char** argv);
};

#endif
