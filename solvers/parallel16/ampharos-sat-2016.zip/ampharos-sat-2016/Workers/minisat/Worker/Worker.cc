


#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#include <time.h>
#include <math.h>

#ifndef work
#define work
#include "Worker.h"
#endif

#include "../../define.h"

//Main informations
int Worker::rank = 0;
const int Worker::rank_master=0;
int Worker::nb_process=0; /* Le nombre de processus MPI total */
int Worker::nb_workers=0; /* Le nombre de worker total */
int Worker::nb_scouts=0; /* Le nombre de scouts total */
int Worker::type = 0; /* Le type du worker */
const char* Worker::type_name = NULL; /* Le nom du type du worker */ 

int Worker::nb_cubes = 0; /*Le nombre de cube du scout attaché*/

int Worker::h_pol = 0; /* Heuristique en cours */ 
int Worker::h_pol_first = 0; /* Premiere heuristique */ 

//For MPI communications
MPI_Request Worker::request_master; /* Pour ecouter le master */
int Worker::flag_master=0; /* drapeau a vrai si un message est recu par le master */
int Worker::message_master=0; /* Le message recu par le Master*/

//For wall time;
double Worker::start_wall_time = 0; /*RealTime when start program*/
double Worker::sum_wall_time = 0;

double Worker::start_wall_time2 = 0; /*RealTime when start program*/
double Worker::sum_wall_time2 = 0;

//For the operations of solver
VirtualSolver* Worker::solver = NULL; /* Le solveur en question */
int Worker::nb_conflict = 0; /* Nombre de conflict pour un start*/
int Worker::init_limit_conflict = 0;
int Worker::limit_conflict = 0; /* Limite pour une résolution d'un cube dans le worker , 0 pour aucune limite*/

//int* Worker::cube = NULL; /*Le cube en création ... et en résolution */
//int* Worker::cube_clause_UNSAT = NULL; /*La clause prouvant que le cube est UNSAT*/
//int Worker::cube_clause_UNSAT_size = 0; /*La taille de la clause prouvant que le cube est UNSAT*/
//int Worker::cube_UNSAT_assertif_lit = 0;
int* Worker::clause_UNSAT=NULL;
int Worker::clause_UNSAT_size=0;
bool Worker::clause_UNSAT_complete = false;
bool Worker::restart_cube = false;
int Worker::type_com = 0;
int Worker::type_extend = 0;

//For shares clauses
int* Worker::send_clauses = NULL;//Tableau de clauses envoyer quand un worker est indéterminer
int Worker::send_clauses_lim = 0;//Prochain espace libre de send_clauses
int Worker::send_clauses_size = 0;//Taille dynamique de send_clauses
int Worker::nb_send_clauses = 0;
int* Worker::received_clauses = NULL;//Tableau de clauses reçu lorque qu'un worker est a MSG GO ROOT
int Worker::received_clauses_size = 0;//Taille dynamique de received_clauses
int Worker::received_clauses_lim = 0;

//For share literals
int* Worker::checks_variables = NULL;
bool* Worker::checks_variables_learnt_level_0 = NULL;

int* Worker::units_literals = NULL;
int Worker::nb_units_literals = 0;

int* Worker::level_units_literals = NULL;
int Worker::nb_level_units_literals = 0;
 
int* Worker:: receive_literals = NULL;
int Worker::nb_receive_literals = 0;

int* Worker::extend_variables = NULL;
int Worker::extend_size = 1;

bool Worker::solver_stop = false; /*Si vrai, le solver est en train de s'arréter, il termine sont restart*/
bool Worker::solver_stop_at_once = false;

//For cubes
int Worker::pos_cube = 0;
int* Worker::cube = NULL;

bool Worker::delete_father = false;

int Worker::previous_pos_cube = 0;
int* Worker::previous_cube = NULL;

//For the operations with the scouts
bool* Worker::scouts_available = NULL;/*tableau des scouts possédant des cubes disponible pour le workers*/
bool Worker::scouts_mode = false;/*Résolution via des cubes grace au scouts*/

int Worker::choice_scouts = 0;
int Worker::current_node_value = 0;
int Worker::assignement = 0;
int Worker::polarity = 0; 
int Worker::left_son = 0;
int Worker::left_son_nb_cubes = 0;
int Worker::left_son_nb_workers = 0;              
int Worker::right_son = 0;
int Worker::right_son_nb_cubes = 0;
int Worker::right_son_nb_workers = 0;    

int Worker::cpt = 0;

int** Worker::clauseStanby = NULL;
int Worker::clauseStanby_lim = 0;
int Worker::clauseStanby_size = 0;

int Worker::send_analyse_1 = SEND_ANALYSE_1;
int Worker::send_analyse_2 = SEND_ANALYSE_2;
int Worker::send_analyse = SEND_ANALYSE;
double Worker::ratio_clauses = 0;
int Worker::send_analyse_1_nb_visit = SEND_ANALYSE_1_NB_VISIT;
int Worker::reduce_purgatory = REDUCE_PURGATORY_CONFLICTS;
int Worker::psm_from_stanby_to_purgatory = PSM_FROM_STANBY_TO_PURGATORY;

int Worker::nb_conflict_same_cube = 0;

void Worker::extern_all(int argc,char** argv,const int n_hpol,const int n_type,const char* n_type_name, const int n_type_com, const int n_type_extend){
  /*Initialisation*/  
  init_wall_time();
  //MPI::Init();

        
  /*main informations*/
  char hostname[256];
  gethostname(hostname, sizeof(hostname));
  rank = MPI::COMM_WORLD.Get_rank();  
  srand(time(NULL)*(rank+1)); // initialisation de rand
  
  type = n_type;
  type_name = n_type_name;
  h_pol = n_hpol;
  h_pol_first = n_hpol; 
  type_com = n_type_com;
  type_extend = n_type_extend;
  /* envoie le type au worker */
  send_master(type); 
  /* recois le nombre de workers et le nombre de scouts */
  MPI_Recv(&nb_workers, 1, MPI_INT, rank_master, TAG_M_SEND_W_MODE, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
  MPI_Recv(&nb_scouts, 1, MPI_INT, rank_master, TAG_M_SEND_W_MODE, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
  
  scouts_available = (bool*)calloc(nb_scouts,sizeof(bool));
  /*Initialisation du solveurs*/
  
  solver = new VirtualSolver(argc,argv);
  const int nb_vars = solver->nb_vars();

  /*For shares units literals */

  //-1 si le litteral n'est pas dans les assumptions
  //sinon le niveau du littéral
  // Permet de distinguer ceux a envoyer 
  // Si c'est -1, c'est qu'il a jamais été envoyer
  checks_variables = (int*)calloc(nb_vars,sizeof(int));
  for (int i = 0; i < nb_vars; i++)checks_variables[i]=-1;
  
  //Pour distinguer les litteraux unitaire level 0 apprit par rapport aux autres.
  checks_variables_learnt_level_0 = (bool*)calloc(nb_vars,sizeof(bool));
  
  //Littéraux unitaire a envoyer au scouts
  //Nombre de units_literals => nb_units_literals
  units_literals = (int*)malloc(nb_vars*sizeof(int));

  //limit pour les niveaux des units littérals
  //Exemple : 
  //level_units_literals[0] = 16
  //=> units_littérals posséde 16 ULs level 0 , a la position  0 a 15
  //level_units_literals[1] = 32
  //=> units_littérals posséde 16 ULs level 1 , a la position 16 a 31
  //Nombre de level_units_literals => nb_level_units_literals
  // Taille max (taille d'un cube)
  level_units_literals = (int*)malloc(CUBES_SIZE*sizeof(int));
  
  //Litéraux reçu pour un noeud par le scout
  //Nombre de receive_literals => nb_receive_literals
  receive_literals = (int*)malloc(nb_vars*sizeof(int));
  
  /*For shares clauses */
  // Clauses a envoyer au scouts
  // Tableau dynamique
  send_clauses_size = CLAUSES_SHARES;
  send_clauses = (int*)calloc(CLAUSES_SHARES,sizeof(int));
  received_clauses_size = CLAUSES_SHARES;
  received_clauses = (int*)calloc(CLAUSES_SHARES,sizeof(int));
  
  clauseStanby = (int**)calloc(CLAUSES_SHARES,sizeof(int*));
  clauseStanby_lim = 0;
  clauseStanby_size = CLAUSES_SHARES;
  
  
  
  /*For the cubes */
  clause_UNSAT = (int*)malloc(CUBES_SIZE*sizeof(int)) ;  
  cube = (int*)malloc(CUBES_SIZE*sizeof(int));//cube send in the solver
  previous_cube = (int*)malloc(CUBES_SIZE*sizeof(int));
  
  /*For extension */
  extend_variables = (int*)malloc(extend_size*sizeof(int));
   
  init_listen_master();
  extern_main();
}




//void Worker::intern_clause_UNSAT(vec<lit>& clause){
  
  /*cube_clause_UNSAT = clauseUNSAT;
  cube_clause_UNSAT_size = size;
  */ 
  /*printf("[WORKER %d]Cube_UNSAT :\n",rank);
  for(int i = 0;i < size;i++){
    printf("%d ", clauseUNSAT[i]);
  }
  printf("\n[WORKER %d]Cube_UNSAT_size:%d\n",rank,size);

  printf("[WORKER %d]Cube_UNSAT LIT ASSERTIF %d\n",rank,clauseUNSAT[0]);
  */
  /* 
  MPI_Send(&size, 1, MPI_INT, getRankMaster(master), TAG_W_SEND_M_MODE, MPI_COMM_WORLD); 
  MPI_Send(clauseUNSAT, size, MPI_INT, getRankMaster(master), TAG_W_SEND_M_MODE, MPI_COMM_WORLD); 
  */
//}


void Worker::extern_recup_solution(int res){
  //if(Worker::get_rank() == 50)  
  //printf("[WORKER %d]I finished to work : %d\n",rank, nb_conflict);  

  if(!res){//satisfiable
    MPI_Cancel(&request_master);
    fprintf(stderr,"[WORKER %d]SATISFIABLE(%s)\n",rank,type_name);
    int* mod = solver->model();
    int j=0;
    send_master(MSG_SAT);
    int mel = 0;    
    MPI_Recv(&mel, 1, MPI_INT, rank_master, TAG_M_SEND_W_MODE, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
    printf("s SATISFIABLE\nv ");
    while(mod[j]!=0)printf("%d ",mod[j++]);
    printf("0 \n ");
    send_master(MSG_SAT);
  }else if(res == 1){//unsatisfiable
    MPI_Cancel(&request_master);
    int mel = 0;    
    MPI_Recv(&mel, 1, MPI_INT, rank_master, TAG_M_SEND_W_MODE, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
    printf("s UNSATISFIABLE\n");
    send_master(MSG_UNSAT);
  }else if(res == 2){//cube unsatiafiable
    if(h_pol_first == EXTEND_CONFLICTS){
      limit_conflict=limit_conflict>>1; 
    }
    
    nb_conflict_same_cube = 0;
    if(clause_UNSAT_complete)
    {
      send_scout(choice_scouts,MSG_CUBE_UNSAT_COMPLETE);
      if(!is_stop_at_once_for_scout()){
        if (type_com == TYPE_COM_SHARE_CLAUSES || type_com == TYPE_COM_SHARE_ALL || type_com == TYPE_COM_SHARE_ALL_NO_ULN){
          extern_receive_ratio_clauses();
          if(receive_scout(choice_scouts)==MSG_START_CLAUSES)extern_receive_clauses();           
          extern_send_clauses();
        }
      }
#ifdef VERB
      printf("[WORKER %d]CUBE UNSATISFIABLE COMPLETE\n",rank);
#endif
      //recommunication d'un cube
      extern_send_MSG_GO_ROOT(false);
      extern_recuperate();
    }
    else
    {
      send_scout(choice_scouts,MSG_CUBE_UNSAT_LIT_ASSERTIF);
      if(!is_stop_at_once_for_scout())
      {//Il ne faut pas envoyer le lit si il est STOP AT ONCE
        if (type_com == TYPE_COM_SHARE_CLAUSES || type_com == TYPE_COM_SHARE_ALL || type_com == TYPE_COM_SHARE_ALL_NO_ULN){
          extern_receive_ratio_clauses();
          if(receive_scout(choice_scouts)==MSG_START_CLAUSES)extern_receive_clauses();    
          extern_send_clauses();
        }
        send_scout(choice_scouts,clause_UNSAT[0]);
#ifdef VERB
        printf("[WORKER %d]CUBE UNSATISFIABLE LIT ASSERTIF %d\n",rank,clause_UNSAT[0]);    
#endif 
        
      }
      //recommunication d'un cube
      extern_send_MSG_GO_ROOT(false);
      extern_recuperate();
    }

  }
  else
    {//indeterminer
      if(scouts_mode){// en mode cube

        send_scout(choice_scouts,MSG_CUBE_INDETERMINATE);
 
       
        if(!is_stop_at_once_for_scout()){
      
          send_scout(choice_scouts,MSG_EXPAND_CUBE);
     
          // We recuperate one variable and we send it to the scout
          solver->recuperate_variables();
          send_scout(choice_scouts,extend_variables[0]);
          
          //We must send units literals to the scout

          
          if(type_com == TYPE_COM_SHARE_UNITS_LITERALS)
            extern_send_units_literals(); 
	  else if (type_com == TYPE_COM_SHARE_CLAUSES){
            extern_receive_ratio_clauses();
            if(receive_scout(choice_scouts)==MSG_START_CLAUSES)extern_receive_clauses();  
	    extern_send_clauses();
	  }else if (type_com == TYPE_COM_SHARE_ALL || type_com == TYPE_COM_SHARE_ALL_NO_ULN){
	    extern_send_units_literals();
            extern_receive_ratio_clauses();            
            if(receive_scout(choice_scouts)==MSG_START_CLAUSES)extern_receive_clauses();    
            extern_send_clauses();
	  }
	    
          /*
          //Get the position of the cube
          extern_receive_current_node_value();
          if(!restart_cube)
          extern_recuperate();*/
//recommunication d'un cube
        //ŧŧŧŧŧŧŧŧŧŧŧŧŧŧŧŧ
        int factor_extend = 1000 * (1 / (ratio_clauses * ratio_clauses * ratio_clauses));
        if(factor_extend < 10) factor_extend = 10;
        //printf("[WORKER %d]nb_conflict : %d\n",rank,nb_conflict);
        if(nb_conflict_same_cube > 10000){
          //Je veux changer de cube
          //printf("[WORKER %d]CHANGE %d\n",rank,nb_conflict_same_cube);
          send_scout(choice_scouts,MSG_RESTART_THE_CUBE_YES);
          nb_conflict_same_cube = 0;
          extern_send_MSG_GO_ROOT(false);           
          extern_recuperate();
        }else{
          nb_conflict_same_cube+=nb_conflict;
          // Je veux rester sur le meme cube 
          //printf("LA\n");
         
          send_scout(choice_scouts,MSG_RESTART_THE_CUBE_NO);
          const int rep = receive_scout(choice_scouts);
        
         
          if(rep == MSG_RESTART_THE_CUBE_YES){
            nb_conflict_same_cube = 0;
           
            extern_send_MSG_GO_ROOT(false);           
            extern_recuperate();
          }else{
            extern_recuperate();
          }
        } 
        }else{
          nb_conflict_same_cube = 0;
        }
        
        //ŧŧŧŧŧŧŧŧŧŧŧŧŧŧŧŧ
        /*
        extern_send_MSG_GO_ROOT(false);           
        extern_recuperate();
        */
      }
      else
        {//en mode concurentielle 
          send_master(MSG_INDET);
        }
    }
  
  init_share_clauses();


  //printf("[WORKER %d]I finished to work 2: %d\n",rank, nb_conflict);  

  
}




void Worker::extern_listen_master(){
  MPI_Test(&request_master,&flag_master,MPI_STATUS_IGNORE);
  if(flag_master)
    { 
      const int tmp_message_master = message_master;     
      switch(tmp_message_master)
        {
        case MSG_START :
          {//Nous somme en mode concurentielle
            char hostname[256];
            gethostname(hostname, sizeof(hostname));
            printf("[WORKER %d]START (%s) (%s) (%d variables)\n",rank,type_name,hostname,solver->nb_vars());
            init_listen_master();//On réinitialise l'ecoute avant pour pouvoir écouter le maitre pendant la résolution
            extern_recup_solution(solver->start());
            init_listen_master();//Car pendant le résolution, il a recu un message STOP du maitre sans réinitialisé l'ecoute 
            break;
          }
        case MSG_SCOUT_AVAILABLE : 
          {          
            int scout=0;
            MPI_Recv(&scout, 1, MPI_INT, rank_master, TAG_M_SEND_W_MODE, MPI_COMM_WORLD, 
                     MPI_STATUS_IGNORE);
            if(!scouts_mode)scouts_mode=true;
            scouts_available[scout]=true;
            MPI_Recv(&limit_conflict, 1, MPI_INT, rank_master, TAG_M_SEND_W_MODE, MPI_COMM_WORLD, 
                     MPI_STATUS_IGNORE);
            init_limit_conflict = limit_conflict;
            display_scouts_available();
            init_listen_master();
            break;
          }
        case MSG_KILL :
          { 
            extern_kill();
            break;
          }
        default : // For debug
          {
            printf("[WORKER %d]BUG MESSAGE EXTERN message: %d - nb_conflict: %d\n",rank,tmp_message_master,nb_conflict);
            init_listen_master();
            break;
          }
        }
    }
}


bool Worker::extern_recuperate_assigned(){
  
#ifdef DEBUG_WORKER
  printf("[WORKER %d]AA variable: %d assignement : %d\n",rank,current_node_value,assignement);
#endif
  if(left_son!=TREE_CONFLICT && right_son!=TREE_CONFLICT)
    {
#ifdef DEBUG_WORKER
      printf("[WORKER %d]AA:%d NO CONFLICT POUR L'ARBRE\n",rank,current_node_value);
#endif
      send_scout(choice_scouts,MSG_ALREADY_ASSIGNED);
      send_scout(choice_scouts,assignement);
      if(!assignement) extern_send_MSG_GO_LEFT();//assignement==VAR_POSITIF_ASSIGNED
      else extern_send_MSG_GO_RIGHT();//assignement==VAR_NEGATIF_ASSIGNED
    }
  else if(left_son == TREE_CONFLICT && right_son == TREE_CONFLICT)
    {
      printf("[WORKER %d]AA TREE CONFLICT LEFT AND RIGHT\n",rank);
      exit(0);
    }
  else if(left_son == TREE_CONFLICT)
    {
#ifdef DEBUG_WORKER
      printf("[WORKER %d]AA CONFLICT LEFT POUR L'ARBRE\n",rank);
#endif
      if(!assignement)
        {//assignement==VAR_POSITIF_ASSIGNED
#ifdef DEBUG_WORKER
          printf("[WORKER %d]AA CONFLICT LEFT POUR L'ARBRE ET ASSIGNEMENT LEFT\n",rank);  
#endif
          send_scout(choice_scouts, MSG_ERASE_FATHER);
          solver->restart();
          return false;
        }
      else
        extern_send_MSG_GO_RIGHT();
    }
  else if(right_son == TREE_CONFLICT)
    {
#ifdef DEBUG_WORKER
      printf("[WORKER %d]AA CONFLICT RIGHT POUR L'ARBRE\n",rank);
#endif
      if(assignement)
        {//assignement==VAR_NEGATIF_ASSIGNED
#ifdef DEBUG_WORKER                
          printf("[WORKER %d]AA CONFLICT RIGHT POUR L'ARBRE ET ASSIGNEMENT RIGHT\n",rank);  
#endif
          send_scout(choice_scouts, MSG_ERASE_FATHER);
          solver->restart();
          return false;
        }
      else
        extern_send_MSG_GO_LEFT();
    }
  return true;
  
}

bool Worker::extern_recuperate_no_assigned(){
  if(left_son == TREE_CONFLICT && right_son == TREE_CONFLICT)
    {
      printf("[WORKER %d]UNSAT BY THE TREE A VERIF LOUCHE\n",rank);
      return false;
    }
  else if(left_son == TREE_CONFLICT)
    {
#ifdef DEBUG_WORKER
      printf("[WORKER %d]SEUL LE GAUCHE EST CONFLICT POUR L'ARBRE\n",rank);
#endif
      int result_right=solver->decision_propagate(current_node_value,NEGATIF);                          
      if(result_right == DECISION_PROPAGATE_CONFLICT)
        {//Le gauche est aussi conflict pour le worker
#ifdef DEBUG_WORKER
          printf("[WORKER %d]CONFLICT LEFT POUR L'ARBRE ET CONFLICT RIGHT SOLVER\n",rank);  
#endif
          send_scout(choice_scouts, MSG_ERASE_FATHER);
          solver->restart();
          return false;
        }
      else
        extern_send_MSG_GO_RIGHT();
    }
  else if(right_son == TREE_CONFLICT)
    {
#ifdef DEBUG_WORKER
      printf("[WORKER %d]SEUL LE DROITE EST CONFLICT POUR L'ARBRE\n",rank);
#endif
      int result_left = solver->decision_propagate(current_node_value,POSITIF);
                          
      if(result_left == DECISION_PROPAGATE_CONFLICT)
        {//Le gauche est aussi conflict pour le worker
#ifdef DEBUG_WORKER          
          printf("[WORKER %d]CONFLICT RIGHT POUR L'ARBRE ET CONFLICT LEFT SOLVER\n",rank);  
#endif
          send_scout(choice_scouts, MSG_ERASE_FATHER);
          solver->restart();
          return false;
        }
      else
        extern_send_MSG_GO_LEFT();
    }




  else //Variable not assigned and no conflict for tree
    {
#ifdef DEBUG_WORKER
      printf("[WORKER %d]NO CONFLICT POUR L'ARBRE\n",rank);
#endif
      
      //solver->get_polarity(current_node_value);//Here, polarity=? 0<=>POSITIF xor 1<=>NEGATIF 
      polarity = heuristic_choice_of_polarity(solver->get_polarity(current_node_value),
                                              left_son_nb_cubes, 
                                              right_son_nb_cubes, 
                                              left_son_nb_workers, 
                                              right_son_nb_workers);

#ifdef DEBUG_WORKER
      printf("[WORKER %d]HEURISTIC POLARITY:%d\n",rank,polarity);
#endif

      //We will test first the polarity to come from the heuristic 
      int result_heuristic = solver->decision_propagate(current_node_value,polarity);

      if(result_heuristic==DECISION_PROPAGATE_SAT)
        {
          printf("C'est SAT coder cette partie: %d\n",result_heuristic);
          exit(0);
        }
      else if(result_heuristic== DECISION_PROPAGATE_CONFLICT)
        {// We must test the other polarity 
          solver->backtrack();
          polarity = polarity?0:1; //Inverse the polarity
          result_heuristic = solver->decision_propagate(current_node_value,polarity);
          if(result_heuristic==DECISION_PROPAGATE_SAT)
            {
              printf("C'est SAT coder cette partie: %d\n",result_heuristic);        
              exit(0);
            }
          else if(result_heuristic== DECISION_PROPAGATE_CONFLICT)
            {// The both polarity are conflicts, We erase the father node
              send_scout(choice_scouts, MSG_ERASE_FATHER);
              solver->restart();
              return false;
            }
          else
            {// One is conflict but not the other
              send_scout(choice_scouts,MSG_ALREADY_ASSIGNED);
              send_scout(choice_scouts,polarity);
              extern_send_MSG_GO_POLARITY(polarity);
            }
        }
      else
        {// We not have conflict for this polarity
          extern_send_MSG_GO_POLARITY(polarity);
        }
    }
  return true;
}

void Worker::extern_recuperate()
{
   while(true)
    {
      if(current_node_value == TREE_END_CUBE)//C'est la fin de l'arbre on résout le cube 
        {
          delete_father = false;
#ifdef DEBUG_WORKER
          printf("[WORKER %d]END CUBE\n",rank);
#endif
          if(type_extend == TYPE_EXTEND_MODE_2)
            {//following nb_cubes
              if(nb_cubes < 100)
                {
                  limit_conflict=init_limit_conflict;                   
                }
              else
                limit_conflict = 0;
            }
#ifdef VERB
            printf("[WORKER %d]CUBE - SIZE: %d <= ",rank,pos_cube);
            for(int i = 0;i<pos_cube;i++){printf("%d ",cube[i]);}
            printf("\n");
#endif
            const int diff = extern_diff_old_cube();
            //printf("[WORKER %d]extern_diff_old_cube() : %d\n",rank,diff);
           
            solver->restart();
            int cpt = 0;

            if(diff != -1){
              const int nb_vars = solver->nb_vars();
              for(int i = 0; i < nb_vars;i++){
                if(checks_variables[i]> diff){
                  checks_variables[i] = -1;
                  cpt++;
                }
              }
            }
            //printf("Cpt : %d\n",cpt);
            
            extern_recup_solution(solver->start(cube,pos_cube)); 
            break;
        }

      extern_send_MSG_GIVE_MY_SONS();
      if(delete_father){
        delete_father = false;
        send_scout(choice_scouts, MSG_ERASE_FATHER);
        solver->restart();
        break;
      }
      assignement = solver->is_assigned(current_node_value);
      //Here, assignement=? 2<=>VAR_NOT_ASSIGNED xor 1<=>VAR_NEGATIF_ASSIGNED xor 0<=>VAR_POSITIF_ASSIGNED
      if(assignement != VAR_NOT_ASSIGNED)
        {
          if(!extern_recuperate_assigned())break;
        }
      else
        {
          if(!extern_recuperate_no_assigned())break;
        }
    }
}


void Worker::extern_main()
{  
  for(;;)
  {
    extern_listen_master();
    if(scouts_mode)
    { //Si il y a des scouts disponible
      choice_scouts = heuristic_choice_of_scout();
      if(choice_scouts != NO_SCOUTS)
      {
        extern_send_MSG_GO_ROOT(true);
        extern_recuperate();
      }
    }
  }
}







/*
void Worker::intern_clause_assumptions(int* clauseUNSAT, int size){
  cube_UNSAT = clauseUNSAT;
  cube_UNSAT_size = size;
  printf("GLU UNSAT :\n");
  for(int i = 0;cube_UNSAT[i]<cube_UNSAT_size;i++){
    printf("%d ", cube_UNSAT[i]);
  }
  printf("\ntaille:%d\n",cube_UNSAT_size);
  //MPI_Send(&size, 1, MPI_INT, getRankMaster(master), TAG_W_SEND_M_MODE, MPI_COMM_WORLD); 
  //MPI_Send(clauseUNSAT, size, MPI_INT, getRankMaster(master), TAG_W_SEND_M_MODE, MPI_COMM_WORLD); 
}
*/
/*initialisation de l'ecoute du master */


