
#include "mpi.h"
#include <time.h>


#include <vector>

#ifndef virsol
#define virsol
#include "VirtualSolver.h"
#endif

#include "../../define.h"

class Worker{
 public:
  //Main informations
  inline static int get_nb_process(){return nb_process;}
  inline static int get_nb_workers(){return nb_workers;}
  inline static int get_nb_scouts(){return nb_scouts;}
  inline static const int get_rank() {return rank;}
  inline static const char* get_type_name() {return type_name;}
  inline static int get_rank_worker(const int& num){return num+1;}
  inline static int get_rank_scout(const int& num){return num+nb_workers+1;}
  
  
  inline static int get_type_com(){return type_com;}

  //For real and cpu time
  static double start_wall_time; /*RealTime when start program*/
  inline static void init_wall_time(){start_wall_time = wall_time();}
  static double sum_wall_time;
  static double sum_wall_time2;
  static double start_wall_time2;

  inline static double wall_time(){
    struct timeval time;
    if (gettimeofday(&time,NULL)){return 0;}
    return (double)time.tv_sec + (double)time.tv_usec * .000001; 
  }

  //methods call for resolution

  static void intern_main_initialize_for_each_cube(){
    solver_stop = false;//S'arrete au prochain restart
    solver_stop_at_once = false;//S'arrete de suite
    nb_conflict = 0;         
  }

  static bool intern_main_after_restart(){
     if(!scouts_mode)
       {//On ecoute le maitre en mode concu
         intern_main_master();
       }
     /*  if(solver_stop_at_once)
       printf("[WORKER %d] SORT D'UN RESTART ET STOP_AT_ONCE\n",rank);
     else
       if(solver_stop)
         printf("[WORKER %d] SORT D'UN RESTART ET STOP\n",rank);
     */
     return solver_stop || solver_stop_at_once;
  }

  static void intern_main_work_during_each_conflict(const int& nb_total_conflict_solver){
    nb_conflict++;
    if(!scouts_mode)
      {//Je suis en mode CONCU, j'ecoute le maitre et c'est tout
        if(!solver_stop && nb_total_conflict_solver%1000==0)
          {//Je l'ecoute tous les 5000 conflicts// Le seul message en mode conrentielle est STOP
            intern_main_master();
          }// Si il recois STOP, Worker::solver_stop = true; 
      }
    else
      {
        //Je suis en mode SCOUT
        if(nb_total_conflict_solver%500==0)
          {  
            send_scout(choice_scouts,MSG_INFO);
            if(is_stop_at_once_for_scout()){
              solver_stop = true;   
            }else{
              if (type_com == TYPE_COM_SHARE_CLAUSES || type_com == TYPE_COM_SHARE_ALL || type_com == TYPE_COM_SHARE_ALL_NO_ULN){
                extern_receive_ratio_clauses();
                if(receive_scout(choice_scouts)==MSG_START_CLAUSES)extern_receive_clauses();           
                extern_send_clauses();
              }
            }
          }
        /*if(nb_conflict%70000==0){
          printf("[WORKER %d] forced stop\n",rank);
          solver_stop = true;         
          solver_stop_at_once = true;
          }*/
        if(nb_conflict%Worker::limit_conflict==0)
          {//if j'ai depasser ma limite de conflict
            solver_stop = true;         
            //solver_stop_at_once = true;
          }
      }
  }

  static void intern_main_master()
  {
    MPI_Test(&request_master,&flag_master,MPI_STATUS_IGNORE);
    if(flag_master)
      {
        int tmp_message = message_master;      
        switch(tmp_message)
          {
          case MSG_KILL : //Kill pour le mode concurentielle
            extern_kill();
            break;
          case MSG_STOP : //Stop pour le mode concurentielle
            //printf("[WORKER %d]STOP BY MASTER\n",rank); 
            solver_stop = true;
            solver_stop_at_once = true;
            break;
          default:
            printf("[WORKER %d]BUG MESSAGE INTERN MASTER message: %d - nb_conflict: %d\n",rank,tmp_message,nb_conflict);
            break;
          }
      }
  }
  
  //methods call for no resolution
  static void extern_all(int argc, char** argv,const int n_hpol,const int n_type,const char* n_typeName, const int n_type_com, const int n_type_extend);
  static void extern_main();
  static void extern_listen_master();

  static void extern_recup_solution(int sol);
  static void extern_recuperate(); 
  static bool extern_recuperate_assigned();
  static bool extern_recuperate_no_assigned();

  static int send_analyse;
  static int send_analyse_1;
  static int send_analyse_2;
  static int send_analyse_1_nb_visit;
  
/*
  return le level de décision qui differe avec l'ancien cube -1 si aucune différence
*/
  inline static int extern_diff_old_cube(){
    int diff = -1;

    for(int i = 0; i < previous_pos_cube;i++){
      if(previous_cube[i]!=cube[i]){
        diff = i;
      } 
    }
    
    //Update of the previous cube
    for(int i = 0; i < pos_cube;i++)previous_cube[i]=cube[i];
    previous_pos_cube = pos_cube;
    
    return diff;
  }

  inline static void extern_add_units_literals(){
    if(extern_receive_units_literals(pos_cube)){
      delete_father = true;
      printf("[WORKER %d]delete node by units literals\n",rank);
    }
  }
  
  inline static void extern_send_MSG_GO_POLARITY(const int polarity){
    cube[pos_cube++] = current_node_value+current_node_value+polarity;
    current_node_value = polarity?right_son:left_son;
    send_scout(choice_scouts,polarity?MSG_GO_RIGHT:MSG_GO_LEFT);
    if(type_com == TYPE_COM_SHARE_UNITS_LITERALS
       || type_com == TYPE_COM_SHARE_ALL )
      extern_add_units_literals();
  }

  inline static void extern_send_MSG_GO_LEFT(){
    cube[pos_cube++] = current_node_value+current_node_value;
    current_node_value = left_son;
    send_scout(choice_scouts,MSG_GO_LEFT);
    if(type_com == TYPE_COM_SHARE_UNITS_LITERALS
       || type_com == TYPE_COM_SHARE_ALL )
      extern_add_units_literals();
  }

  inline static void extern_send_MSG_GO_RIGHT(){
    cube[pos_cube++] = current_node_value+current_node_value+1;
    current_node_value = right_son;
    send_scout(choice_scouts,MSG_GO_RIGHT);
    if(type_com == TYPE_COM_SHARE_UNITS_LITERALS
       || type_com == TYPE_COM_SHARE_ALL )
      extern_add_units_literals();
  }

  inline static void extern_send_MSG_GO_ROOT(const bool with_send_msg_go_root){
#ifdef DEBUG_WORKER
    printf("[WORKER %d]Choose scout : %d\n",rank, choice_scouts);
#endif
    heuristic_choice_of_polarity_adjustment();
    if(with_send_msg_go_root)
      send_scout(choice_scouts,MSG_GO_ROOT);
    current_node_value = receive_scout(choice_scouts);
    nb_cubes = receive_scout(choice_scouts);  //Update nb_cubes
    if(current_node_value == MSG_KILL_SPE){
      printf("[WORKER %d]OTHER SOLUTION SOLVER KILL DEBUG MSG_KILL_SPE\n",rank);
      extern_kill();
    }
   
    pos_cube = 0;//position of last literal in the cube
    solver->restart();
    if(type_com == TYPE_COM_SHARE_UNITS_LITERALS
       || type_com == TYPE_COM_SHARE_ALL
       || type_com == TYPE_COM_SHARE_ALL_NO_ULN)
      extern_add_units_literals();
  }
  

  inline static void extern_receive_ratio_clauses()
  {
    MPI_Recv(&ratio_clauses, 1, MPI_DOUBLE, get_rank_scout(choice_scouts), TAG_S_SEND_W_MODE, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
    
    send_analyse_1_nb_visit = (int) sqrt(ratio_clauses);
    psm_from_stanby_to_purgatory = 6 / ratio_clauses;    
  }

  inline static void extern_receive_clauses(){
    
    int tmp_clauses[CUBES_SIZE];
    int pos = 0;
    received_clauses_lim = receive_scout(choice_scouts);
    while(received_clauses_size < received_clauses_lim+1)extend_memory_received_clauses();
        
    //printf("[WORKER %d]Receive %d %d\n",rank,received_clauses_lim, received_clauses_size);
    MPI_Recv(received_clauses, received_clauses_lim
             , MPI_INT, get_rank_scout(choice_scouts)
             , TAG_S_SEND_W_MODE
             , MPI_COMM_WORLD
             , MPI_STATUS_IGNORE);
        
    int k = 0;
    if(received_clauses_size <= received_clauses_lim){
      printf("ici\n");
      exit(0);
    }
    for(int i=0, j=0; i < received_clauses_lim; i++){
      if(received_clauses[i] == LIMIT_BETWEEN_CLAUSES){
        int* my_clause = (int*)malloc((pos+2)*sizeof(int));
        *my_clause=0;
        for(j=0,k=1;j < pos;j++,k++)my_clause[k]=tmp_clauses[j];
        my_clause[k]=LIMIT_BETWEEN_CLAUSES;
        if(clauseStanby_size < clauseStanby_lim+1)extend_memory_standby();
        clauseStanby[clauseStanby_lim++]=my_clause;
        pos=0;
      }
      else
        tmp_clauses[pos++] = received_clauses[i];
    }
        
    //solver->add_received_clauses();
    //printf("[WORKER %d]OK ADD Receive %d %d\n",rank,clauseStanby_lim,clauseStanby_size);
      
  }


  inline static void extend_memory_standby(){
    clauseStanby_size*=2;
    clauseStanby=(int**)realloc(clauseStanby,clauseStanby_size*sizeof(int*));
    //printf("[WORKER %d] REALLOC RECEIVED CLAUSES\n",rank);
  }


  inline static void extend_memory_received_clauses(){
     const int last = received_clauses_size;
     
    received_clauses_size*=2;
    received_clauses=(int*)realloc(received_clauses,received_clauses_size*sizeof(int));
    for(int i = last; i < received_clauses_size;i++)received_clauses[i]=0;
   
    // printf("[WORKER %d] REALLOC RECEIVED CLAUSES\n",rank);
  }

  inline static void extend_memory_send_clauses(){
    const int last = send_clauses_size;
    send_clauses_size*=2;
    send_clauses=(int*)realloc(send_clauses,send_clauses_size*sizeof(int));
    for(int i = last; i < send_clauses_size;i++)send_clauses[i]=0;
    
    //printf("[WORKER %d] REALLOC SEND CLAUSES\n",rank);
  }
  

  inline static void init_share_clauses(){
    send_clauses_lim = 0;
    nb_send_clauses = 0;  
  }

  static int cpt;

  inline static void end_literal_share_clause(){
    send_clauses[send_clauses_lim++] = LIMIT_BETWEEN_CLAUSES;
    //printf("[WORKER %d]Verif : %d %d \n",rank,send_clauses[send_clauses_lim-1],send_clauses_lim-1);
    /* if(cpt >=300){
      printf("ICI : %d\n",cpt);
    }
    cpt=0;*/
    nb_send_clauses++;
    if(send_clauses_lim == send_clauses_size-1)
      extend_memory_send_clauses();
  }
  
  inline static void add_literal_share_clause(const int& c){
    send_clauses[send_clauses_lim++] = c;
    //cpt++;
    // printf("[WORKER %d]Verif : %d %d \n",rank,send_clauses[send_clauses_lim-1],send_clauses_lim-1);
    if(send_clauses_lim == send_clauses_size-1)
      extend_memory_send_clauses();
  }


  inline static void extern_send_clauses(){
    send_scout(choice_scouts,send_clauses_lim);
    //if(Worker::get_rank() == 10 || Worker::get_rank() == 30 || Worker::get_rank() == 50)
    
    if(send_clauses_lim){
      send_scout(choice_scouts,nb_send_clauses);
      //double factor = (double)nb_send_clauses/(double)nb_conflict;
      //printf("factor : %f %d %d\n",factor,nb_send_clauses,nb_conflict);
      //printf("[WORKER %d]Envoie %d clauses / %d conflict (%d / %d)\n",rank,nb_send_clauses,nb_conflict, send_clauses_lim, send_clauses_size);   
      MPI_Send(send_clauses
               ,send_clauses_lim 
               ,MPI_INT, get_rank_scout(choice_scouts), TAG_W_SEND_S_MODE, MPI_COMM_WORLD);     
      send_clauses_lim=0;
      nb_send_clauses = 0;
    }
    
  }


  inline static void print_units_literals(){
    int lev = 0;
    printf("verif tab : %d %d\n", nb_units_literals,nb_level_units_literals);
    printf("\n[WORKER %d](%s)level 0 :",Worker::get_rank(),Worker::get_type_name());
    for(int i = 0; i < Worker::nb_units_literals;i++){
      while(lev < nb_level_units_literals && i == Worker::level_units_literals[lev])
        printf("\n[WORKER %d]level %d :",Worker::get_rank(),++lev);
      printf(" %d",Worker::units_literals[i]);
    }
    while(lev < nb_level_units_literals)
       printf("\n[WORKER %d]level %d :",Worker::get_rank(),++lev);
    printf("\n"); 
  }


  inline static void extern_send_units_literals(){
    solver->recuperates_units_literals();
    //print_units_literals();

    send_scout(choice_scouts,nb_units_literals);
    if(nb_units_literals){
      MPI_Send(units_literals
               ,nb_units_literals
               ,MPI_INT, get_rank_scout(choice_scouts), TAG_W_SEND_S_MODE, MPI_COMM_WORLD);
      send_scout(choice_scouts,nb_level_units_literals);
      if(nb_level_units_literals){
        MPI_Send(level_units_literals
                 ,nb_level_units_literals
                 ,MPI_INT, get_rank_scout(choice_scouts), TAG_W_SEND_S_MODE, MPI_COMM_WORLD);
      }
    }
  }

 

  inline static bool extern_receive_units_literals(const int& level){
    //static int cpt = 0; 
    nb_receive_literals = receive_scout(choice_scouts);
    /*printf("[WORKER %d]CUBE - SIZE: %d <= ",rank,pos_cube);
    for(int i = 0;i<pos_cube;i++){printf("%d ",cube[i]);}
    printf("\n");*/    

    if(nb_receive_literals)
      {
        
        //if(level) printf("(%d) Nb received = %d\n", level, nb_receive_literals);
        MPI_Recv(receive_literals, nb_receive_literals
                 , MPI_INT, get_rank_scout(choice_scouts)
                 , TAG_S_SEND_W_MODE
                 , MPI_COMM_WORLD
                 , MPI_STATUS_IGNORE);
        
        if(!level)
          {
            for(int i = 0, my_var = (*(receive_literals+i))>>1; i < nb_receive_literals;my_var = (*(receive_literals+(++i)))>>1)
              {
                //if not alredy send && if not learnt
                //printf("[WORKER %d]i:%d lit:%d var:%d\n",rank,i,receive_literals[i],my_var);
                if(checks_variables[my_var] != 0 && !checks_variables_learnt_level_0[my_var])
                  {
                    checks_variables[my_var]=0;//I don't send
                    checks_variables_learnt_level_0[my_var]=true;//I am learning
                    solver->add_unit_literal(receive_literals[i]);                    
                  }
              }
          }
      else
      {
        //cpt+=nb_receive_literals;
        //printf("[WORKER %d] ADD ULN : %d\n",rank,cpt);
        for(int i = 0, my_var = (*(receive_literals+i))>>1; i < nb_receive_literals;my_var = (*(receive_literals+(++i)))>>1){
          //if not alredy send && if not learnt
          //printf("[WORKER %d]i:%d lit:%d var:%d\n",rank,i,receive_literals[i],my_var);
          if(checks_variables[my_var] == -1 || level < checks_variables[my_var]){ 
            checks_variables[my_var]=level;//I don't send
            if(solver->add_unit_literal(receive_literals[i]))
              return true;
            solver->add_unit_literal(receive_literals[i]);
          }
        }
      }   
    }
    return false;
  }


  inline static void extern_receive_current_node_value(){
#ifdef DEBUG_WORKER
    printf("[WORKER %d]Choose scout : %d\n",rank, choice_scouts);
#endif
    heuristic_choice_of_polarity_adjustment();
    current_node_value = receive_scout(choice_scouts);
    nb_cubes = receive_scout(choice_scouts);  //Update nb_cubes
    restart_cube = (receive_scout(choice_scouts) == MSG_RESTART_THE_CUBE_YES)?true:false;
    if(current_node_value == MSG_KILL_SPE){
      printf("[WORKER %d]OTHER SOLUTION SOLVER KILL DEBUG MSG_KILL_SPE\n",rank);
      extern_kill();
    }
  
#ifdef VERB
    printf("[WORKER %d]OLD CUBE - SIZE: %d <= ",rank,pos_cube);
    for(int i = 0;i<pos_cube;i++){printf("%d ",cube[i]);}
    printf("\n");
#endif
  }



  inline static void extern_send_MSG_GIVE_MY_SONS(){    
    send_scout(choice_scouts,MSG_GIVE_MY_SONS);
    left_son = receive_scout(choice_scouts);
    if(left_son != TREE_CONFLICT){
      left_son_nb_cubes = receive_scout(choice_scouts);
      left_son_nb_workers = receive_scout(choice_scouts);
    }
    right_son = receive_scout(choice_scouts);
    if(right_son != TREE_CONFLICT){
      right_son_nb_cubes = receive_scout(choice_scouts);
      right_son_nb_workers = receive_scout(choice_scouts);
    }             
    if(left_son == MSG_KILL_SPE && right_son == MSG_KILL_SPE){
      printf("[WORKER %d]OTHER SOLUTION SOLVER KILL DEBUG MSG_KILL_SPE\n",rank);
      extern_kill();
    }
#ifdef DEBUG_WORKER
    printf("[WORKER %d]current_node_value : %d - left_son : %d - right_son : %d\n",rank
           ,current_node_value,left_son,right_son);
#endif
  }
  
  inline static void extern_kill(){
    MPI_Finalize();
    printf("[WORKER %d]EXTERN KILL\n",rank); 
    exit(0);
  }


  //For recuperation of cubes
  static int* cube;
  static int pos_cube;
  static bool delete_father;

  static int* previous_cube;
  static int previous_pos_cube;

  //For the operations of solver  
  static int nb_conflict; /* Nombre de conflict pour un start*/
  static int init_limit_conflict;
  static int limit_conflict; /* Limite pour une résolution d'un cube dans le worker , 0 pour aucune limite*/
  static bool solver_stop; /*Si vrai, le solver doit s'arréter car il a travialler trop longtmeps sur un cube*/
  static bool solver_stop_at_once;
  static bool scouts_mode;
  static bool restart_cube;
  static int little_restart_mode;

  static int* extend_variables;
  static int extend_size;

  static int* clause_UNSAT;
  static int clause_UNSAT_size;
  static bool clause_UNSAT_complete;
  static int type_com; 
  static int type_extend;

  static int reduce_purgatory;
  static int psm_from_stanby_to_purgatory;

  static int nb_conflict_same_cube;
 

  inline static void check_variable_learnt(const int& var, const int& lit){
    checks_variables_learnt_level_0[var]=true;
    //printf("[WORKER %d] NEW UL : %d\n",rank,lit);
  }

  //For shares clauses
  static int* tmp_clause;//Clause en mémoire temporaire
  static int* send_clauses;//Tableau de clauses envoyer quand un worker est indéterminer
  static int send_clauses_lim;//Prochain espace libre de send_clauses
  static int send_clauses_size;//Taille dynamique de send_clauses
  
  static int* received_clauses;//Tableau de clauses reçu lorque qu'un worker est a MSG GO ROOT
  static int received_clauses_size;//Taille dynamique de received_clauses
  static int received_clauses_lim;//Prochain espace libre de received_clauses
  
  static int** clauseStanby;
  static int clauseStanby_lim;
  static int clauseStanby_size;
  static int nb_send_clauses;

  //For share litterals
  static int* checks_variables;
  static bool* checks_variables_learnt_level_0;
  
  static int* units_literals;
  static int nb_units_literals;

  static int* level_units_literals;
  static int nb_level_units_literals;

  static int* receive_literals;//Literals recu pour un noeud
  static int nb_receive_literals;

  static int* receive_literals_total;//Literals recu pour un cube
  static int size_receive_literals;
 
  static int* receive_literals_lim;//Limite pour les Literals recu pour un cube
  static int size_receive_literals_lim;
  

//MPI macro for send/receive message
  inline static void init_listen_master(){
    flag_master=0;
    MPI_Irecv(&message_master, 1, MPI_INT, rank_master, TAG_M_SEND_W_MODE, MPI_COMM_WORLD,&request_master); 
  }

  inline static void send_master(const int& message){
    MPI_Send(&message, 1, MPI_INT, rank_master, TAG_W_SEND_M_MODE, MPI_COMM_WORLD); 
  }

  inline static void send_scout(const int& rank_scout,const int& message){
    //printf("[WORKER %d]SEND %d at scouts %d\n",rank,message,get_rank_scout(rank_scout));
    MPI_Send(&message, 1, MPI_INT, get_rank_scout(rank_scout), TAG_W_SEND_S_MODE, MPI_COMM_WORLD); 
  }


  inline static int receive_scout(const int& rank_scout){
    int message = 0;
    MPI_Recv(&message, 1, MPI_INT, get_rank_scout(rank_scout), TAG_S_SEND_W_MODE, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
    return message;
  }

  inline static bool is_stop_at_once_for_scout(){
    int answer_stop_at_once = receive_scout(choice_scouts);
    if(answer_stop_at_once == MSG_STOP_AT_ONCE_YES)
      return true;
    else
      return false;
  }

  //For the operations with the scouts
  inline static void display_scouts_available(){
    /*printf("[WORKER %d]SCOUT DISPO:",rank);
    for(int s=0;s < nb_scouts;s++){
      if(scouts_available[s])
        printf("%d ",get_rank_scout(s));
    }
    printf("\n");*/
  }



  // On suppose a<b
  inline static int rand_a_b(int a, int b){
    return rand()%(b-a) +a;
  }

  //renvoie NO_SCOUTS si il n'y a pas de scouts disponible
  static int heuristic_choice_of_scout(){return scouts_available[0]?0:NO_SCOUTS;}
  
  static void heuristic_choice_of_polarity_adjustment(){
    if(h_pol_first == HP_CHOOSE_RANDOM_HEURISTIQUES){
      const int rand = rand_a_b(0,10);
      h_pol=rand<5?HP_USE_NUMBER_OF_WORKERS_AND_CUBE:HP_RANDOM;
      printf("[WORKER %d]SPECIFIC HEURISTIC FOR THIS CUBE: %d\n",rank,h_pol);
    }
  }

  static int heuristic_choice_of_polarity(const int polarity, 
                                          const int left_son_nb_cubes,const int right_son_nb_cubes, 
                                          const int left_son_nb_workers,const int right_son_nb_workers)
  {
    switch(h_pol)
      {
      case HP_POLARITY :
        {//Choose the know polarity by the solver 
          return polarity;
        }
      case HP_RANDOM :
        {//Random between positif and negatif
          return rand_a_b(0,2);
        }
      case HP_ALWAYS_POSITIF :
        { 
          return POSITIF;
        }
      case HP_ALWAYS_NEGATIF :
        { 
          return NEGATIF;
        }
      case HP_NUMBER_OF_PROPAGATION :
        {// Following the number of propagation // Delete for refactoring
          return polarity;
        }
      case HP_ALEA_POLARITY_RANDOM :
        {// 1/4 random, 3/4 polarity
          return rand_a_b(0,101)?polarity:rand_a_b(0,2);
        }
      case HP_CHOOSE_RANDOM_HEURISTIQUES : 
        {//impossible task through the method heuristic_choice_of_polarity_adjustment()
          return polarity;
        }
      case HP_USE_NUMBER_OF_WORKERS_AND_CUBE :
        {// Followinf the number of cubes and the number of worker on each node
  
          if(!(left_son_nb_cubes <= left_son_nb_workers && right_son_nb_cubes <= right_son_nb_workers))
            {
              if(!polarity)
                {
                  if(left_son_nb_cubes <= left_son_nb_workers){/*printf("Change %d\n", get_rank());*/ return NEGATIF;}
                }else
                {
                  if(right_son_nb_cubes <= right_son_nb_workers){/*printf("Change %d\n", get_rank());*/ return POSITIF;}
                }
            }
          
          return polarity;
        }
      }
    return polarity;
  }


 private:  
  //Main informations
  static int type; /* Type of worker */
  
  static const char* type_name; /* Name of type of worker */   
  static int rank; /*rank MPI of worker*/
  const static int rank_master; /*rank MPI of master*/
  static int nb_process; /* Number of process */
  static int nb_workers; /* Number of workers */
  static int nb_scouts; /* Number of scouts */
  static int h_pol; /* Heuristic for polarity of tree */
  static int h_pol_first; /* First Heuristic for polarity of tree */
  static int nb_cubes; /*Le nombre de cube du scout attaché*/

  //For MPI communications
  static int message_master; /* messages received by master */
  static MPI_Request request_master; /* request for listening master */
  static int flag_master; /* flag, 1 if message has been received by master, 0 else */
 
  //For the operations of solver
  static VirtualSolver* solver; /* the associated solver */
 
  //For the operations with the scouts
  static bool* scouts_available;
  static int choice_scouts;
  static int current_node_value;
  static int assignement;
  static int polarity; 
  static int left_son;
  static int left_son_nb_cubes;
  static int left_son_nb_workers;              
  static int right_son;
  static int right_son_nb_cubes;
  static int right_son_nb_workers;   
 
  static double ratio_clauses;


};


