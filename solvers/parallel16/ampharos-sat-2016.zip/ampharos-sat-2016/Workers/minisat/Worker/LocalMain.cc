
#include "LocalMain.h"

int RunMinisat::localMain(int argc, char** argv)
{
  Minisat::parseOptions(argc, argv, true);
  /*Association du Worker*/
  Worker::extern_all(argc, argv, 7, 2, "Minisat", 3, 1);
  return 0;
}// localMain
