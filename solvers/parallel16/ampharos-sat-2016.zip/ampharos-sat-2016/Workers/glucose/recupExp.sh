# $1, instance a traiter
INSTANCE=$(basename "$1" .cnf)
INSTANCENAME=${INSTANCE//_/"\_"}
INSTANCENAME="${INSTANCENAME:0:4} ... ${INSTANCENAME:(-4)}" 



for MY_LOG in $(ls)
do
    chiffre="$(sed 's/[^[:digit:]]//g' <<< "${MY_LOG}")"
    if [ -n "$chiffre" ]; then 
	chiffres="$chiffres $chiffre"
    fi

done


sort_table=$( echo $chiffres | sed -e 's/ /\n/g' | sort -n | uniq)
(( CPT = 0 ))
(( CPT2 = 0 ))
for REST in $sort_table
do
    (( CPT2 = CPT2 + 1 ))
done
(( CPT2 = CPT2 - 1 ))
for REST in $sort_table
do 
    
    SOL="TIMEOUT"
    MY_LOG="$2$REST/$INSTANCE.log"
    nb_SAT=$(grep -c "^s SATISFIABLE" "$MY_LOG")
   
    nb_IN=$(grep -c "^s INDETERMINATE" "$MY_LOG")
    nb_UNSAT=$(grep -c "^s UNSATISFIABLE" "$MY_LOG")
    nb_UNSAT_vrai=$(grep -c "^s UNSATISFIABLE VRAI" "$MY_LOG")
    if [ $nb_UNSAT_vrai -eq 1 ]; then
	SOL="UNSAT"
    fi
    (( nb_UNSAT = nb_UNSAT - nb_UNSAT_vrai ))
    NUM_CUBE=`grep -i "^Cube N°" $MY_LOG | cut -d ' ' -f2 | sed 's/ //g'`
    NUM_CUBE=$(echo "$NUM_CUBE" | tail -n 1 )
    NUM_CUBE=${NUM_CUBE:2}
  
    TIME=`grep -i "^c CPU time              :" $MY_LOG | cut -d ':' -f2 | cut -d 's' -f1 | sed 's/ //g'`
    TIME=$(echo "$TIME" | tail -n 1 ) 
   
    
    if [ $nb_SAT -ge 1 ]; then
	SOL="SAT"
	LIGNE_SAT=`grep -in "^s SATISFIABLE" $MY_LOG | cut -d ':' -f1 | sed 's/ //g'`
	LIGNE_SAT=$(echo "$LIGNE_SAT" | head -n 1 )
	(( LIGNE_SAT = LIGNE_SAT - 2 ))
	TIME=`head -$LIGNE_SAT $MY_LOG | tail -1 | cut -d ':' -f2 | cut -d 's' -f1 | sed 's/ //g'`
	(( LIGNE_SAT = LIGNE_SAT + 3 ))
	
	NUM_CUBE=`head -$LIGNE_SAT $MY_LOG | tail -1 | cut -d 'N' -f2 | sed 's/ //g'`
	NUM_CUBE=${NUM_CUBE//"°"/""}

	(( NUM_CUBE-- ))
	
	if [ $NUM_CUBE -ne 1 ]; then
	    TIMES=`grep -i "^c CPU time              :" $MY_LOG | cut -d ':' -f2 | cut -d 's' -f1 | sed 's/ //g'`
	    (( NUM_CUBES = NUM_CUBE - 1 ))
	    TIMES=$(echo "$TIMES" | head -n  $NUM_CUBES) 
	    TIMESOL=$(echo "$TIMES" | tail -n 1 ) 
	    
	    #LIGNE_NUM_CUBE=`grep -in "^Cube N°$NUM_CUBE$" $MY_LOG | cut -d ':' -f1 | sed 's/ //g'`
	      #(( LIGNE_NUM_CUBE = LIGNE_NUM_CUBE - 3 ))
	    #echo $LIGNE_NUM_CUBE
	    #TIMESOL=`head -$LIGNE_NUM_CUBE $MY_LOG | tail -1 | cut -d ':' -f2 | cut -d 's' -f1 | sed 's/ //g'`
	    #echo $TIMESOL
	    TIMESOL=`echo "$TIME - $TIMESOL" |bc -l`
	else
	    TIMESOL=$TIME
	fi
	 
	nb_IN=$(head -$LIGNE_SAT $MY_LOG | grep -c "^s INDETERMINATE" )
	nb_UNSAT=$(head -$LIGNE_SAT $MY_LOG | grep -c "^s UNSATISFIABLE")

    else
	if [ $NUM_CUBE -ne 1 ]; then
	    TIMESOL=`grep -i "^c CPU time              :" $MY_LOG | cut -d ':' -f2 | cut -d 's' -f1 | sed 's/ //g'`
	    TIMESOL=$(echo "$TIMESOL" | tail -n 3 )
	    TIMESOL=$(echo "$TIMESOL" | head -n 1 )
	    TIMESOL=`echo "$TIME - $TIMESOL" |bc -l`
	else
	    TIMESOL=$TIME
	fi

    fi
    
    if [ $CPT -eq 0 ]; then
	echo "\multirow{$CPT2}*{$INSTANCENAME} & $REST & $nb_IN & $nb_UNSAT & $nb_SAT & $SOL & $NUM_CUBE & $TIME & $TIMESOL & \multirow{$CPT2}*{$3} \\\\" 
    else
	if [ $CPT -eq 1 ]; then
	    echo "$4 & $REST & $nb_IN & $nb_UNSAT & $nb_SAT & $SOL & $NUM_CUBE & $TIME & $TIMESOL & \\\\" 
	else
	    echo " & $REST & $nb_IN & $nb_UNSAT & $nb_SAT & $SOL & $NUM_CUBE & $TIME & $TIMESOL & \\\\" 
	fi
    fi
    (( CPT = CPT + 1 ))
done
echo "\hline"
