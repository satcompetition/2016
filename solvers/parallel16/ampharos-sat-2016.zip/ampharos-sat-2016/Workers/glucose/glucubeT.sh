#!/bin/bash

# $1, dossier log
# $2, option glucube

./glucube.sh $1 5 $2
./glucube.sh $1 10 $2
./glucube.sh $1 20 $2
./glucube.sh $1 50 $2
./glucube.sh $1 100 $2
./glucube.sh $1 500 $2
./glucube.sh $1 1000 $2
./glucube.sh $1 2000 $2
