#!/bin/bash

# $1, dossier log
# $2, nombre de restart pour chaque cube
# $3, option glucube

rm -rf $1$2
mkdir $1$2



CLUSTER="-q normal8 -l cput=02:00:00 -l walltime=02:00:00"
PROG="$PWD/cube/glucube"

echo "Cluster: $CLUSTER"
echo "Restarts: $2"
echo "Exec: $PROG"
echo "Option: $3"

for i in `ls dimacs/*.cnf`
do
    CNF="$PWD/$i"
    out="$PWD/$1$2/$(basename $i | sed 's/.cnf//g')"
    echo "Log : $out.log"
    qadd -e "$out.err" -o "$out.log" $CLUSTER -- $PROG $CNF -restart_cube=$2 $3
done



