#!/bin/bash

# $1, Le fichier contenant les instances a résoudre.
# $2, the folder where are save the experiments

rm -rf $2
mkdir $2

for i in `cat $1`
do
    out="$PWD/$2/$(basename $i | sed 's/.cnf//g')"
    qadd -e "$out.err" -o "$out.log" -q normal8 -l walltime=02:00:00 -- $PWD/simp/glucose $i
done



