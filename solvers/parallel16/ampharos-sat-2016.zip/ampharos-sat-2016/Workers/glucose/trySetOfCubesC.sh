#!/bin/bash

for CNF in `ls dimacs/*.cnf`
do
      D="$PWD/$CNF"
      ./trySetOfCubes.sh $D $1 $2
done
