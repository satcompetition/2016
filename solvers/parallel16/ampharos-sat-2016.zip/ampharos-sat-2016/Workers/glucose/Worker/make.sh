#!/bin/bash



CHEMIN=$PWD
cd ..
export MROOT=$PWD
cd $CHEMIN
if [ "$1" = "clean" ]; then
    make clean
else 
    make
fi

