

#include "utils/Options.h"
#include <sys/types.h>
#include "utils/System.h"


#ifndef work
#define work
#include "Worker.h"
#endif

#include "../../../define.h"

using namespace Glucose;

static IntOption opt_sw_type("SWARMSAT", "type","type du solver\n", 0);
static IntOption opt_sw_hpol("SWARMSAT", "hpol","heuristique de polarité pour l'arbre\n", 0);
static IntOption opt_sw_type_com("SWARMSAT", "type_com","Type des communication\n", 0);
static IntOption opt_sw_type_extend("SWARMSAT", "type_extend","Type extend of the tree\n", 0);

int main(int argc, char** argv){
  parseOptions(argc, argv, true);
  /*Association du Worker*/
  Worker::extern_all(argc,argv,opt_sw_hpol,opt_sw_type,"Glucose",opt_sw_type_com,opt_sw_type_extend);
  return 0;
}

