#!/bin/bash

# $1, the complete path of the benchmark
# $2, number of first cubes considered
# $3, number of cubes's partition 
# ./trySetOfCubes.sh /home/cril/szczepanski/cluster/Cube/minisat/dimacs/pb_300_01_lb_00.cnf 100 100 traceSolveCube/pb_300_01_lb_00/

TRACE="traceSolveCube"
fileName=$(basename $1 | sed 's/.cnf//g')
rm -rf $TRACE/
out="$PWD/$TRACE/$fileName/$fileName"
nbCubes=$(grep "CUBES " $PWD/cubes/$fileName.cubes | cut -d ' ' -f2)

echo "c Number of cubes: $nbCubes"
nbLaunchedCubes=$2
if [ $2 -gt $nbCubes ]
then
    nbLaunchedCubes=$nbCubes
fi

# the $nbLaunchedCubes first cubes
for i in  `seq 1 $nbLaunchedCubes`
do
    echo $1 $i
    qadd -e "$out.${i}.err" -o "$out.${i}.log" -q short8 -l nodes=1:ppn=2 -l cput=00:30:00 -l walltime=00:30:00 -- $PWD/cube/glucube $1 -resolve_cubes=$i
done

# step by step
if [ $3 -eq 0 ]; then exit 0; fi

oneStep=`echo "($nbCubes - $nbLaunchedCubes) / $3" | bc`
#oneStep=$(expr ($nbCubes - $nbLaunchedCubes) / $3)

if [ $oneStep -eq 0 ]; then exit 0; fi

for i in `seq 1 $3`
do
#    numCube=$(expr $nbLaunchedCubes + ($i * $oneStep))
    numCube=`echo "$nbLaunchedCubes + ($i * $oneStep)" | bc`
    qadd -e "$out.${numCube}.err" -o "$out.${numCube}.log" -q short8 -l nodes=1:ppn=2 -l cput=00:30:00 -l walltime=00:30:00 -- $PWD/cube/glucube $1 -resolve_cubes=$numCube
done


