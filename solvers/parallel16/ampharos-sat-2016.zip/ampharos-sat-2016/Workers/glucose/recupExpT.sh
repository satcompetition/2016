SAT="003 aes_64_1_keyfind_1 pb_200_03_lb_03 pb_300_01_lb_00 pb_300_02_lb_06 UTI-20-5p1"
UNSAT="6s153 arcfour_initialPermutation_6_16 bob12m06 b_unsat pb_400_09_lb_02"

TSAT="TIMEOUT TIMEOUT 28.7346 4.12737 105.313 732.336"
TUNSAT="78.3331 1240.57 3114.77 593.464 43.0205"

echo "\documentclass[10pt,a4paper]{article}"
echo "\usepackage[T1]{fontenc}"
echo "\usepackage[utf8]{inputenc}"
echo "\usepackage[french]{babel}"
echo "\usepackage{blindtext}"


echo "\usepackage{multirow}"
echo "\usepackage{geometry}"
echo "\geometry{scale=0.8, nohead}"
echo "\newcommand{\SC}{S\textsc{cout}C\textsc{ube}\xspace}"

echo "\begin{document}"
echo ""

echo "\begin{figure}[htb]"
echo "\leftskip -2cm{"
echo "\begin{tabular}{|c|c|c|c|c|c|c|c|c|c|}"
echo "\hline"
echo "Instances & Restarts & Cbs TO & Cbs UNSAT & Cbs SAT & SOLUTION & Cb SOL & Temps T & Temps SOL & Temps Glucose\\\\"
echo "\hline"

#./recupExp.sh dimacs/pb_200_03_lb_03.cnf $1
CPT=1
for inst in $SAT
do
   TGLU=`echo $TSAT | cut -d" " -f$CPT`
   MY_LOGC="cubes/$inst.cubes"
   CUBES=$(head -n 1  "$MY_LOGC" | cut -d ' ' -f2 ) 
   ./recupExp.sh dimacs/$inst.cnf $1 $TGLU $CUBES
   (( CPT++ ))
done

echo "\end{tabular}"
echo "\caption{Expérimentations Gilles}}"
echo "\end{figure}"

echo "\begin{figure}[htb]"
echo "\leftskip -2cm{"
echo "\begin{tabular}{|c|c|c|c|c|c|c|c|c|c|c|}"
echo "\hline"
echo "Instances & Restarts & Cbs TO & Cbs UNSAT & Cbs SAT & SOLUTION & Cb SOL & Temps T & Temps SOL & Temps Glucose\\\\"
echo "\hline"

CPT=1
for inst in $UNSAT
do
    TGLU=`echo $TUNSAT | cut -d" " -f$CPT` 
    MY_LOGC="cubes/$inst.cubes"
    CUBES=$(head -n 1  "$MY_LOGC" | cut -d ' ' -f2 ) 
   ./recupExp.sh dimacs/$inst.cnf $1 $TGLU $CUBES
   (( CPT++ ))
done

echo "\end{tabular}"
echo "\caption{Expérimentations Gilles}}"
echo "\end{figure}"

echo "\end{document}"
echo ""
