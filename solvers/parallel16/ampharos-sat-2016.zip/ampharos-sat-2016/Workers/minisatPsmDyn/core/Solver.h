/****************************************************************************************[Solver.h]
Copyright (c) 2003-2006, Niklas Een, Niklas Sorensson
Copyright (c) 2007-2010, Niklas Sorensson

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and
associated documentation files (the "Software"), to deal in the Software without restriction,
including without limitation the rights to use, copy, modify, merge, publish, distribute,
sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or
substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT
OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

MinisatPsnDyn
**************************************************************************************************/



#ifndef Minisat_Solver_h
#define Minisat_Solver_h

#include "mtl/Vec.h"
#include "mtl/Heap.h"
#include "mtl/Alg.h" 
#include "utils/Options.h"
#include "core/SolverTypes.h"
#include "mtl/Sort.h" 
#define INIT_LIMIT 500

#ifndef work
#define work
#include "Worker.h"
#endif


namespace Minisat {

//=================================================================================================
// Solver -- the main class:

class Solver {
public:
  int MAX_NB_USE;
  int INCREASE_LIMIT;
    // Constructor/Destructor:
    //
    Solver();
    virtual ~Solver();

    // Problem specification:
    //
    Var     newVar    (bool polarity = true, bool dvar = true); // Add a new variable with parameters specifying variable mode.

    bool    addClause (const vec<Lit>& ps);                     // Add a clause to the solver. 
    bool    addEmptyClause();                                   // Add the empty clause, making the solver contradictory.
    bool    addClause (Lit p);                                  // Add a unit clause to the solver. 
    bool    addClause (Lit p, Lit q);                           // Add a binary clause to the solver. 
    bool    addClause (Lit p, Lit q, Lit r);                    // Add a ternary clause to the solver. 
    bool    addClause_(      vec<Lit>& ps);                     // Add a clause to the solver without making superflous internal copy. Will
                                                                // change the passed vector 'ps'.
    // For SwarmSAT (class VirtualSolver)
    //

    /**
     * \brief Backtrack until to the previous level of decision.
     */
    void inline backtrack(){cancelUntil(decisionLevel()-1);}

    /**
     * \brief Restart the solver : Backtrack until to first level of decision. 
     */
    void inline restart(){cancelUntil(0);}
   
    /**
     * \brief Checks if a variable is assigned or not by the solver.
     * \param[in] variable The variable to test.
     * \return 
     If this variable is assigned to false, she is positif : return 0 <=> VAR_POSITIF_ASSIGNED
     If this variable is assigned to true, she is negatif : return 1 <=> VAR_NEGATIF_ASSIGNED 
     If this variable is not assigned : return 2 <=> VAR_NOT_ASSIGNED 
    */
    inline char is_assigned(const int& variable){return toInt(assigns[variable]);}


    /**
     * \brief Create a new decision level, decide a litteral to assign and make the necessary propagations
     * \param[in] variable The decision variable.
     * \param[in] polarity The decision polarity. This variable and this polarity produce a literal
     * \return 
     If the initial problem is satisfiable return 0 <=> DECISION_PROPAGATE_SAT
     If the propagation produce a conflict return -1 <=> DECISION_PROPAGATE_CONFLICT
     Else return the number of propagation 
    */
    inline int decision_propagate(const int& variable,const char& polarity)
    {
      Lit lit = mkLit(variable, polarity);
      decisions++;
      newDecisionLevel();
      uncheckedEnqueue(lit);
      CRef confl = propagate();
      int res = trail.size();
      return (confl != CRef_Undef)?DECISION_PROPAGATE_CONFLICT:((res == nVars())?DECISION_PROPAGATE_SAT:res);
    }

    
   inline int calculatePSM(int* clauses){
     int psm, i, val;
     for(psm = 0, i = 1, val = clauses[i]; val != LIMIT_BETWEEN_CLAUSES && psm<=Worker::psm_from_stanby_to_purgatory;i++,val = clauses[i]){
       Lit my_lit = toLit(val); 
       if(polarity[var(my_lit)] == sign(my_lit))psm++;
     }
     return psm;
   }

   
struct reduceDB_lt { 
  ClauseAllocator& ca;
  reduceDB_lt(ClauseAllocator& ca_) : ca(ca_) {}
  bool operator () (CRef x, CRef y) { 
    //return ca[x].size() > 2 && (ca[y].size() == 2 || ca[x].activity() < ca[y].activity()); } 
    return ca[x].size() > 2 && (ca[y].size() == 2 || ca[x].activity() < ca[y].activity()); } 
};

   inline void reducePurgatory(){
     int i, j;
     int learn = 0;
     int del = 0;  
     
     sort(purgatory, reduceDB_lt(ca));
     int limit = purgatory.size()/2;

     for (i = j = 0; i < purgatory.size(); i++){
       Clause& c = ca[purgatory[i]];	 
       if(c.purgatory())
         {// Dans le purgatoire
           if(c.nbNotVisit() < 15)c.nbNotVisit(c.nbNotVisit() +1);
           if(c.size() > 2 && !locked(c) && c.nbNotVisit() == DELETE_PURGATORY_BY_NOT_VISIT && i < limit)
             {//On la vire, si ca fait 7 fois quelle est dans le purgatoire
               removeClause(purgatory[i]);
               del++;
             }else //On la garde
             purgatory[j++] = purgatory[i];
         }
       else
         { //on la garde pas mais on ne la supprime pas : elle est passé dans les learnts         
           learn++;
         }
     }
     /*if(Worker::get_rank() == 50) printf("[WORKER %d]reducePurgatory : avant : %d - apres : %d - learnts : %d - delete : %d  --- %ld %d\n",
                                         Worker::get_rank(),i,j,learn,del, conflicts, Worker::reduce_purgatory);
     */
                                         purgatory.shrink(i - j);
     checkGarbage();
   }

   /**
      Reduce the set of clauses in the standby database. This function
      also transfers clauses with a lbd value less than
      Worker::psm_from_stanby_to_purgatory.

      /!\ this function can realized a brackjump!!!!

      \return true if everything is OK, false if the problem is proved unsatisfiable
   */
   inline bool reduceStanby()
   {
     bool status = true;
     int stats_psm = 0, i, j, *my_clause;
     
     for(i = j = 0 ; i < Worker::clauseStanby_lim ; i++)
       {
         my_clause = (Worker::clauseStanby[i]);                      // we consider a new clause
         (*my_clause)++;                                                           // we increase the visit counter
         
         int psm = 0;
         int pos1 = 0, pos2 = 0;
         Lit lPos1 = lit_Undef, lPos2 = lit_Undef;

         for(int k = 1 ; my_clause[k] != LIMIT_BETWEEN_CLAUSES && psm <= Worker::psm_from_stanby_to_purgatory ; k++)
           {
             Lit l = toLit(my_clause[k]);
             if(polarity[var(l)] == sign(l)) psm++;
            
             if(!pos1){pos1 = k; lPos1 = l;}
             else if(value(l) != l_False || (value(lPos1) == l_False && level(var(l)) > level(var(lPos1))))
               {
                 pos2 = pos1; lPos2 = lPos1;
                 pos1 = k; lPos1 = l;
               }
             else if(!pos2 || (value(lPos2) == l_False && level(var(l)) > level(var(lPos2)))){pos2 = k; lPos2 = l;}
           }
                  
         if(status && psm <= Worker::psm_from_stanby_to_purgatory)
           {
             int tmp = my_clause[1]; my_clause[1] = my_clause[pos1]; my_clause[pos1] = tmp;   // switch 1

             if(pos2 == 1) pos2 = pos1; 
             tmp = my_clause[2]; my_clause[2] = my_clause[pos2]; my_clause[pos2] = tmp;        // switch 2
              
             // clause creation
             vec<Lit> learnt_clause;
             for(int j=1 ; my_clause[j] != LIMIT_BETWEEN_CLAUSES ; j++) learnt_clause.push(toLit(my_clause[j]));
             
             // we add the clause in the purgatory
             CRef cr = ca.alloc(learnt_clause, true);
             ca[cr].purgatory(1);
             ca[cr].alreadySent(1);
             purgatory.push(cr);
             attachClause(cr);
             claBumpActivity(ca[cr]);
             free(my_clause);
             stats_psm++;

             // cancelUntil + uncheckedEnqueue ???
             if(value(learnt_clause[1]) != l_False) continue;
             if(value(learnt_clause[0]) == l_Undef || level(var(learnt_clause[0])) > level(var(learnt_clause[1])))
               {
                 cancelUntil(level(var(learnt_clause[1])));
                 uncheckedEnqueue(learnt_clause[0], cr);
               }
             else if(value(learnt_clause[0]) == l_False)
               {
                 if(level(var(learnt_clause[1]))) cancelUntil(level(var(learnt_clause[1])) - 1);
                 else 
                   {
#if 0
                     for(int k = 0 ; k<learnt_clause.size() ; k++)
                       {
                         assert(value(learnt_clause[k]) == l_False);
                         printf("%d(%d) ", printLit(learnt_clause[k]), level(var(learnt_clause[k]))); 
                       }
                     printf(" :: %d\n", Worker::get_rank());
#endif
                     status = false;
                   }
               }  
           }
         else if(*my_clause==REDUCE_STANBY) free(my_clause);
         else Worker::clauseStanby[j++] = Worker::clauseStanby[i];
       }
     
     Worker::clauseStanby_lim = j;
     return status;
   }// reduceStanby



 inline bool add_received_clauses(){
      int tmp_clauses[CUBES_SIZE];
      int pos = 0;
      //int last = 0;
      for(int i=0; i < Worker::received_clauses_lim; i++){
        if(Worker::received_clauses[i] == LIMIT_BETWEEN_CLAUSES){
          //printf("\n");
          /* if(pos >= CUBES_SIZE){
            printf("pos : %d - i: %d -max : %d\n",pos,i,Worker::received_clauses_lim);
            printf("LA\n");
            }*/
          vec<Lit>    learnt_clause;
          for(int j=0;j < pos;j++)learnt_clause.push(toLit(tmp_clauses[j]));
          CRef cr = ca.alloc(learnt_clause, true);
          learnts.push(cr);
          attachClause(cr);
          
          claBumpActivity(ca[cr]);
          pos=0;
          //last = i;
        }
        else
        {
          //printf("%d ",Worker::received_clauses[i]);
          tmp_clauses[pos++] = Worker::received_clauses[i];
        }
      }
      //printf("[WORKER %d](%s)learnt : %d - last : %d - lim : %d\n",Worker::get_rank(),Worker::get_type_name(),learnts.size(),last,Worker::received_clauses_lim);
      return false;
    }



    inline bool add_unit_literal(const int& lit){
      Lit my_lit = toLit(lit);
      int& level = Worker::pos_cube;
      if(value(my_lit) == l_Undef)
      {
        if(!level){
          uncheckedEnqueue(my_lit);
        }else{
          vec<Lit>    learnt_clause;
          learnt_clause.push(my_lit);
          for(int i=0;i<level;i++)learnt_clause.push(~toLit(Worker::cube[i]));
          CRef cr = ca.alloc(learnt_clause, true);
          purgatoryUL.push(cr);
          attachClause(cr);
          claBumpActivity(ca[cr]);
          uncheckedEnqueue(learnt_clause[0], cr);
        }
      }
      else
        if(assigns[var(my_lit)] != lbool(!sign(my_lit)))
          return true;
      return false;
    }


    inline void recuperate_variables()
    { //Recup the extend variables
      if(decisionLevel() != assumptions.size()){
        printf("Bugue : INDETERMINATE AND decisionLevel() != assumptions.size() BY %s\n",Worker::get_type_name());exit(0);
      }
      for(int cpt=0;cpt<Worker::extend_size;cpt++)Worker::extend_variables[cpt] = order_heap.removeMin(); 
      rebuildOrderHeap();//Replace the Order Heap
    }

    inline void recuperates_units_literals()
    {
      Worker::nb_units_literals = 0;
      Worker::nb_level_units_literals = 0;
      
      const int end = trail.size();     
      const int level_0 = trail_lim[0];
  

      int next_level = level_0;
      
      for(int i = 0; i < end;i++){
        Lit my_lit = trail[i];
        Var my_var = var(my_lit);
        
        while(i == next_level && Worker::nb_level_units_literals < assumptions.size())
        {//On change de level, on sauvegarde une sorte de nouveau trail_lim dans level_units_literals 
          Worker::level_units_literals[Worker::nb_level_units_literals++]=Worker::nb_units_literals;
          next_level = trail_lim[Worker::nb_level_units_literals];

          //printf("BUG Ess : %d %d %d\n",Worker::nb_level_units_literals,next_level,end);
        }
        if(i < level_0)
        {//C'est un literal unitaire du level 0

          /*printf("[WORKER %d]toInt(my_lit) : %d - Worker::checks_variables[my_var] : %d - Worker::checks_variables_learnt_level_0[my_var] : %d\n"
                 ,Worker::get_rank()
                 ,toInt(my_lit)
                 ,Worker::checks_variables[my_var]
                 ,Worker::checks_variables_learnt_level_0[my_var]);
          */
          if(Worker::checks_variables[my_var] && Worker::checks_variables_learnt_level_0[my_var])
          {//Si je l'ai pas deja envoyer au level 0 et que je l'ai apprises
            Worker::checks_variables[my_var]=0;
            Worker::units_literals[Worker::nb_units_literals++]=toInt(my_lit);
          }
        }
        else
        {//C'est un literal unitaire d'un autre level
          //CRef tmpCRef = reason(my_var);
          if(Worker::type_com != TYPE_COM_SHARE_ALL_NO_ULN && (Worker::checks_variables[my_var] == -1 || Worker::nb_level_units_literals < Worker::checks_variables[my_var])
               //&& tmpCRef != CRef_Undef 
               //&& ca[tmpCRef].learnt()
               ){
              //printf("[WORKER %d] ADD %d - level : %d\n",Worker::get_rank(),toInt(my_lit),Worker::nb_level_units_literals);
            Worker::checks_variables[my_var] = Worker::nb_level_units_literals;
            Worker::units_literals[Worker::nb_units_literals++]=toInt(my_lit);
          }
        }
      }

      while(Worker::nb_level_units_literals < assumptions.size()){
        Worker::level_units_literals[Worker::nb_level_units_literals++]=Worker::nb_units_literals;
      }

      if(Worker::nb_level_units_literals != assumptions.size())
        {
          printf("BUG Ess : %d %d\n",Worker::nb_level_units_literals,assumptions.size());
          exit(0);
        }
    }


    // Solving:
    //
    bool    simplify     ();                        // Removes already satisfied clauses.
    bool    solve        (const vec<Lit>& assumps); // Search for a model that respects a given set of assumptions.
    lbool   solveLimited (const vec<Lit>& assumps); // Search for a model that respects a given set of assumptions (With resource constraints).
    bool    solve        ();                        // Search without assumptions.
    bool    solve        (Lit p);                   // Search for a model that respects a single assumption.
    bool    solve        (Lit p, Lit q);            // Search for a model that respects two assumptions.
    bool    solve        (Lit p, Lit q, Lit r);     // Search for a model that respects three assumptions.
    bool    okay         () const;                  // FALSE means solver is in a conflicting state

    void    toDimacs     (FILE* f, const vec<Lit>& assumps);            // Write CNF to file in DIMACS-format.
    void    toDimacs     (const char *file, const vec<Lit>& assumps);
    void    toDimacs     (FILE* f, Clause& c, vec<Var>& map, Var& max);

    // Convenience versions of 'toDimacs()':
    void    toDimacs     (const char* file);
    void    toDimacs     (const char* file, Lit p);
    void    toDimacs     (const char* file, Lit p, Lit q);
    void    toDimacs     (const char* file, Lit p, Lit q, Lit r);
    
    // Variable mode:
    // 
    void    setPolarity    (Var v, bool b); // Declare which polarity the decision heuristic should use for a variable. Requires mode 'polarity_user'.
    void    setDecisionVar (Var v, bool b); // Declare if a variable should be eligible for selection in the decision heuristic.
    char    getPolarity    (Var v);

    // Read state:
    //
    lbool   value      (Var x) const;       // The current value of a variable.
    lbool   value      (Lit p) const;       // The current value of a literal.
    lbool   modelValue (Var x) const;       // The value of a variable in the last model. The last call to solve must have been satisfiable.
    lbool   modelValue (Lit p) const;       // The value of a literal in the last model. The last call to solve must have been satisfiable.
    int     nAssigns   ()      const;       // The current number of assigned literals.
    int     nClauses   ()      const;       // The current number of original clauses.
    int     nLearnts   ()      const;       // The current number of learnt clauses.
    int     nVars      ()      const;       // The current number of variables.
    int     nFreeVars  ()      const;

    // Resource contraints:
    //
    void    setConfBudget(int64_t x);
    void    setPropBudget(int64_t x);
    void    budgetOff();
    void    interrupt();          // Trigger a (potentially asynchronous) interruption of the solver.
    void    clearInterrupt();     // Clear interrupt indicator flag.

    // Memory managment:
    //
    virtual void garbageCollect();
    void    checkGarbage(double gf);
    void    checkGarbage();

    // Extra results: (read-only member variable)
    //
    vec<lbool> model;             // If problem is satisfiable, this vector contains the model (if any).
    vec<Lit>   conflict;          // If problem is unsatisfiable (possibly under assumptions),
                                  // this vector represent the final conflict clause expressed in the assumptions.

    // Mode of operation:
    //
    
    int       verbosity;
    double    var_decay;
    double    clause_decay;
    double    random_var_freq;
    double    random_seed;
    bool      luby_restart;
    int       ccmin_mode;         // Controls conflict clause minimization (0=none, 1=basic, 2=deep).
    int       phase_saving;       // Controls the level of phase saving (0=none, 1=limited, 2=full).
    bool      rnd_pol;            // Use random polarities for branching heuristics.
    bool      rnd_init_act;       // Initialize variable activities with a small random value.
    double    garbage_frac;       // The fraction of wasted memory allowed before a garbage collection is triggered.

    int       restart_first;      // The initial restart limit.                                                                (default 100)
    double    restart_inc;        // The factor with which the restart limit is multiplied in each restart.                    (default 1.5)
    double    learntsize_factor;  // The intitial limit for learnt clauses is a factor of the original clauses.                (default 1 / 3)
    double    learntsize_inc;     // The limit for learnt clauses is multiplied with this factor each restart.                 (default 1.1)

    int       learntsize_adjust_start_confl;
    double    learntsize_adjust_inc;
    int currentLimit;

    // Statistics: (read-only member variable)
    //
    uint64_t solves, starts, decisions, rnd_decisions, propagations, conflicts;
    uint64_t dec_vars, clauses_literals, learnts_literals, max_literals, tot_literals;

protected:

    // Helper structures:
    //
    struct VarData { CRef reason; int level; };
    static inline VarData mkVarData(CRef cr, int l){ VarData d = {cr, l}; return d; }
    
    struct Watcher {
      CRef cref;
      Lit  blocker;
    Watcher(CRef cr, Lit p) : cref(cr), blocker(p) {}
      bool operator==(const Watcher& w) const { return cref == w.cref; }
      bool operator!=(const Watcher& w) const { return cref != w.cref; }
    };

    struct WatcherDeleted
    {
        const ClauseAllocator& ca;
        WatcherDeleted(const ClauseAllocator& _ca) : ca(_ca) {}
        bool operator()(const Watcher& w) const { return ca[w.cref].mark() == 1; }
    };

    struct VarOrderLt {
        const vec<double>&  activity;
        bool operator () (Var x, Var y) const { return activity[x] > activity[y]; }
        VarOrderLt(const vec<double>&  act) : activity(act) { }
    };

    // Solver state:
    //
    bool                ok;               // If FALSE, the constraints are already unsatisfiable. No part of the solver state may be used!
    vec<CRef>           clauses;          // List of problem clauses.
    vec<CRef>           learnts;          // List of learnt clauses.
    vec<CRef>           purgatoryUL;
    vec<CRef>           purgatory;

    double              cla_inc;          // Amount to bump next clause with.
    vec<double>         activity;         // A heuristic measurement of the activity of a variable.
    double              var_inc;          // Amount to bump next variable with.
    OccLists<Lit, vec<Watcher>, WatcherDeleted>
                        watches;          // 'watches[lit]' is a list of constraints watching 'lit' (will go there if literal becomes true).
    vec<lbool>          assigns;          // The current assignments.
    vec<char>           polarity;         // The preferred polarity of each variable.
    vec<char>           savePolarity;     // The initial preferred polarity of each variable for the current run.
    vec<char>           viewVariable;     // The initial preferred polarity of each variable for the current run.
    int hammingDistance;
    vec<char>           decision;         // Declares if a variable is eligible for selection in the decision heuristic.
    vec<Lit>            trail;            // Assignment stack; stores all assigments made in the order they were made.
    vec<int>            trail_lim;        // Separator indices for different decision levels in 'trail'.
    vec<VarData>        vardata;          // Stores reason and level for each variable.
    int                 qhead;            // Head of queue (as index into the trail -- no more explicit propagation queue in MiniSat).
    int                 simpDB_assigns;   // Number of top-level assignments since last execution of 'simplify()'.
    int64_t             simpDB_props;     // Remaining number of propagations that must be made before next execution of 'simplify()'.
    vec<Lit>            assumptions;      // Current set of assumptions provided to solve by the user.
    Heap<VarOrderLt>    order_heap;       // A priority queue of variables ordered with respect to the variable activity.
    double              progress_estimate;// Set by 'search()'.
    bool                remove_satisfied; // Indicates whether possibly inefficient linear scan for satisfied clauses should be performed in 'simplify'.

    ClauseAllocator     ca;

    // Temporaries (to reduce allocation overhead). Each variable is prefixed by the method in which it is
    // used, exept 'seen' wich is used in several places.
    //
    vec<char>           seen;
    vec<int>            permDiff;
    int MYFLAG;
    vec<Lit>            analyze_stack;
    vec<Lit>            analyze_toclear;
    vec<Lit>            add_tmp;

    int                 use_learnts;
    double              learntsize_adjust_confl;
    int                 learntsize_adjust_cnt;

    // Resource contraints:
    //
    int64_t             conflict_budget;    // -1 means no budget.
    int64_t             propagation_budget; // -1 means no budget.
    bool                asynch_interrupt;

    // Main internal methods:
    //
    void     insertVarOrder   (Var x);                                                 // Insert a variable in the decision order priority queue.
    Lit      pickBranchLit    ();                                                      // Return the next decision variable.
    void     newDecisionLevel ();                                                      // Begins a new decision level.
    void     uncheckedEnqueue (Lit p, CRef from = CRef_Undef);                         // Enqueue a literal. Assumes value of literal is undefined.
    bool     enqueue          (Lit p, CRef from = CRef_Undef);                         // Test if fact 'p' contradicts current state, enqueue otherwise.
    CRef     propagate        ();                                                      // Perform unit propagation. Returns possibly conflicting clause.
    void     cancelUntil      (int level);                                             // Backtrack until a certain level.
    void     analyze          (CRef confl, vec<Lit>& out_learnt, int& out_btlevel,int &lbd);    // (bt = backtrack)
    void     analyzeFinal     (Lit p, vec<Lit>& out_conflict);                         // COULD THIS BE IMPLEMENTED BY THE ORDINARIY "analyze" BY SOME REASONABLE GENERALIZATION?
    bool     litRedundant     (Lit p, uint32_t abstract_levels);                       // (helper method for 'analyze()')
    lbool    search           (int nof_conflicts);                                     // Search for a given number of conflicts.
    lbool    solve_           ();                                                      // Main solve method (assumptions given in 'assumptions').
    void     reduceDB         (double deviation);                                                      // Reduce the set of learnt clauses.
    void     removeSatisfied  (vec<CRef>& cs);                                         // Shrink 'cs' to contain only non-satisfied clauses.
    void     rebuildOrderHeap ();

    // Maintaining Variable/Clause activity:
    //
    void     varDecayActivity ();                      // Decay all variables with the specified factor. Implemented by increasing the 'bump' value instead.
    void     varBumpActivity  (Var v, double inc);     // Increase a variable with the current 'bump' value.
    void     varBumpActivity  (Var v);                 // Increase a variable with the current 'bump' value.
    void     claDecayActivity ();                      // Decay all clauses with the specified factor. Implemented by increasing the 'bump' value instead.
    void     claBumpActivity  (Clause& c);             // Increase a clause with the current 'bump' value.

    // Operations on clauses:
    //
    void     attachClause     (CRef cr);               // Attach a clause to watcher lists.
    void     detachClause     (CRef cr, bool strict = false); // Detach a clause to watcher lists.
    void     removeClause     (CRef cr);               // Detach and free a clause.
    bool     locked           (const Clause& c) const; // Returns TRUE if a clause is a reason for some implication in the current state.
    bool     satisfied        (const Clause& c) const; // Returns TRUE if a clause is satisfied in the current state.

    void     relocAll         (ClauseAllocator& to);

    // Misc:
    //
    int      decisionLevel    ()      const; // Gives the current decisionlevel.
    uint32_t abstractLevel    (Var x) const; // Used to represent an abstraction of sets of decision levels.
    CRef     reason           (Var x) const;
    int      level            (Var x) const;
    double   progressEstimate ()      const; // DELETE THIS ?? IT'S NOT VERY USEFUL ...
    bool     withinBudget     ()      const;

    // Static helpers:
    //

    // Returns a random float 0 <= x < 1. Seed must never be 0.
    static inline double drand(double& seed) {
        seed *= 1389796/Worker::get_rank();
        int q = (int)(seed / 2147483647);
        seed -= (double)q * 2147483647;
        return seed / 2147483647; }

    // Returns a random integer 0 <= x < size. Seed must never be 0.
    static inline int irand(double& seed, int size) {
        return (int)(drand(seed) * size); }

    inline unsigned int computeLBD(const vec<Lit> & lits) 
    {
      int nblevels = 0;
      MYFLAG++;
      for(int i=0;i<lits.size();i++) 
        {
          int l = level(var(lits[i]));
          if (permDiff[l] != MYFLAG) 
            {
              permDiff[l] = MYFLAG;
              nblevels++;
            }
        }
      return nblevels;
    }

    int controlReduce;
    
    uint64_t nextCallPurgatory;
    int nbLb2;
    int notLb2; 
    int anal_para;
    int anal_para_total;
    inline unsigned int computeLBD(Clause &lits) 
    {
      int nblevels = 0;
      MYFLAG++;
      for(int i=0;i<lits.size();i++) 
        {
          int l = level(var(lits[i]));
          if (permDiff[l] != MYFLAG) 
            {
              permDiff[l] = MYFLAG;
              nblevels++;
            }
        }
      return nblevels;
    }

};


//=================================================================================================
// Implementation of inline methods:

inline CRef Solver::reason(Var x) const { return vardata[x].reason; }
inline int  Solver::level (Var x) const { return vardata[x].level; }

inline void Solver::insertVarOrder(Var x) {
    if (!order_heap.inHeap(x) && decision[x]) order_heap.insert(x); }

 inline void Solver::varDecayActivity() {var_inc *= (1 / var_decay); }
inline void Solver::varBumpActivity(Var v) { varBumpActivity(v, var_inc); }
inline void Solver::varBumpActivity(Var v, double inc) {
    if ( (activity[v] += inc) > 1e100 ) {
        // Rescale:
        for (int i = 0; i < nVars(); i++)
            activity[i] *= 1e-100;
        var_inc *= 1e-100; }

    // Update order_heap with respect to new activity:
    if (order_heap.inHeap(v))
        order_heap.decrease(v); }

inline void Solver::claDecayActivity() { cla_inc *= (1 / clause_decay); }
inline void Solver::claBumpActivity (Clause& c) {
        if ( (c.activity() += cla_inc) > 1e20 ) {
            // Rescale:
            for (int i = 0; i < learnts.size(); i++)
                ca[learnts[i]].activity() *= 1e-20;
            cla_inc *= 1e-20; } }

inline void Solver::checkGarbage(void){ return checkGarbage(garbage_frac); }
inline void Solver::checkGarbage(double gf){
    if (ca.wasted() > ca.size() * gf)
        garbageCollect(); }

// NOTE: enqueue does not set the ok flag! (only public methods do)
inline bool     Solver::enqueue         (Lit p, CRef from)      { return value(p) != l_Undef ? value(p) != l_False : (uncheckedEnqueue(p, from), true); }
inline bool     Solver::addClause       (const vec<Lit>& ps)    { ps.copyTo(add_tmp); return addClause_(add_tmp); }
inline bool     Solver::addEmptyClause  ()                      { add_tmp.clear(); return addClause_(add_tmp); }
inline bool     Solver::addClause       (Lit p)                 { add_tmp.clear(); add_tmp.push(p); return addClause_(add_tmp); }
inline bool     Solver::addClause       (Lit p, Lit q)          { add_tmp.clear(); add_tmp.push(p); add_tmp.push(q); return addClause_(add_tmp); }
inline bool     Solver::addClause       (Lit p, Lit q, Lit r)   { add_tmp.clear(); add_tmp.push(p); add_tmp.push(q); add_tmp.push(r); return addClause_(add_tmp); }
inline bool     Solver::locked          (const Clause& c) const { return value(c[0]) == l_True && reason(var(c[0])) != CRef_Undef && ca.lea(reason(var(c[0]))) == &c; }
inline void     Solver::newDecisionLevel()                      { trail_lim.push(trail.size()); }

inline int      Solver::decisionLevel ()      const   { return trail_lim.size(); }
inline uint32_t Solver::abstractLevel (Var x) const   { return 1 << (level(x) & 31); }
inline lbool    Solver::value         (Var x) const   { return assigns[x]; }
inline lbool    Solver::value         (Lit p) const   { return assigns[var(p)] ^ sign(p); }
inline lbool    Solver::modelValue    (Var x) const   { return model[x]; }
inline lbool    Solver::modelValue    (Lit p) const   { return model[var(p)] ^ sign(p); }
inline int      Solver::nAssigns      ()      const   { return trail.size(); }
inline int      Solver::nClauses      ()      const   { return clauses.size(); }
inline int      Solver::nLearnts      ()      const   { return learnts.size(); }
inline int      Solver::nVars         ()      const   { return vardata.size(); }
inline int      Solver::nFreeVars     ()      const   { return (int)dec_vars - (trail_lim.size() == 0 ? trail.size() : trail_lim[0]); }
inline void     Solver::setPolarity   (Var v, bool b) { polarity[v] = b; }
inline char     Solver::getPolarity    (Var v){return polarity[v];}
inline void     Solver::setDecisionVar(Var v, bool b) 
{ 
    if      ( b && !decision[v]) dec_vars++;
    else if (!b &&  decision[v]) dec_vars--;

    decision[v] = b;
    insertVarOrder(v);
}
inline void     Solver::setConfBudget(int64_t x){ conflict_budget    = conflicts    + x; }
inline void     Solver::setPropBudget(int64_t x){ propagation_budget = propagations + x; }
inline void     Solver::interrupt(){ asynch_interrupt = true; }
inline void     Solver::clearInterrupt(){ asynch_interrupt = false; }
inline void     Solver::budgetOff(){ conflict_budget = propagation_budget = -1; }
inline bool     Solver::withinBudget() const {
    return !asynch_interrupt &&
           (conflict_budget    < 0 || conflicts < (uint64_t)conflict_budget) &&
           (propagation_budget < 0 || propagations < (uint64_t)propagation_budget); }

// FIXME: after the introduction of asynchronous interrruptions the solve-versions that return a
// pure bool do not give a safe interface. Either interrupts must be possible to turn off here, or
// all calls to solve must return an 'lbool'. I'm not yet sure which I prefer.
inline bool     Solver::solve         ()                    { budgetOff(); assumptions.clear(); return solve_() == l_True; }
inline bool     Solver::solve         (Lit p)               { budgetOff(); assumptions.clear(); assumptions.push(p); return solve_() == l_True; }
inline bool     Solver::solve         (Lit p, Lit q)        { budgetOff(); assumptions.clear(); assumptions.push(p); assumptions.push(q); return solve_() == l_True; }
inline bool     Solver::solve         (Lit p, Lit q, Lit r) { budgetOff(); assumptions.clear(); assumptions.push(p); assumptions.push(q); assumptions.push(r); return solve_() == l_True; }
inline bool     Solver::solve         (const vec<Lit>& assumps){ budgetOff(); assumps.copyTo(assumptions); return solve_() == l_True; }
inline lbool    Solver::solveLimited  (const vec<Lit>& assumps){ assumps.copyTo(assumptions); return solve_(); }
inline bool     Solver::okay          ()      const   { return ok; }

inline void     Solver::toDimacs     (const char* file){ vec<Lit> as; toDimacs(file, as); }
inline void     Solver::toDimacs     (const char* file, Lit p){ vec<Lit> as; as.push(p); toDimacs(file, as); }
inline void     Solver::toDimacs     (const char* file, Lit p, Lit q){ vec<Lit> as; as.push(p); as.push(q); toDimacs(file, as); }
inline void     Solver::toDimacs     (const char* file, Lit p, Lit q, Lit r){ vec<Lit> as; as.push(p); as.push(q); as.push(r); toDimacs(file, as); }


//=================================================================================================
// Debug etc:


//=================================================================================================
}

#endif
