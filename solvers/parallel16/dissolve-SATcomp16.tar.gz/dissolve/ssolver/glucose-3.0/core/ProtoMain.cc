#include <gflags/gflags.h>
#include <glog/logging.h>
//#include "timer/timer.h"

#include <iostream>
#include <string>
#include <fstream>
#include <stdlib.h>

#include <errno.h>

#include <signal.h>
#include <zlib.h>

#include "utils/System.h"
#include "utils/ParseUtils.h"
#include "utils/Options.h"
#include "core/Dimacs.h"
#include "core/Solver.h"
#include "simp/SimpSolver.h"

#include "core/solver.pb.h"

#include <google/protobuf/io/zero_copy_stream_impl.h>


//input-output flags
DEFINE_string(dimacs_in, "", "The DIMACS input file");
DEFINE_string(pb_in, "", "The input protobuf file.");
DEFINE_string(pb_out, "", "The output protobuf file.");
DEFINE_string(logfile, "/tmp/glucose_log.txt", "Where to write logs.");

using namespace Glucose;

static Solver* _solver;
static int RequestId = -42; // any negative value is fine

void printStats(Solver& solver)
{
  double cpu_time = cpuTime();
  double mem_used = memUsedPeak();
  VLOG(2) << "c restarts              : " << solver.starts << " (" << (solver.starts>0 ?solver.conflicts/solver.starts : 0) << " conflicts in avg)\n";
  VLOG(2) << "c blocked restarts      : " << solver.nbstopsrestarts << " (multiple: " << solver.nbstopsrestartssame << ") \n";
  VLOG(2) << "c last block at restart : " << solver.lastblockatrestart << "\n";
  VLOG(2) << "c nb ReduceDB           : " << solver.nbReduceDB << "\n";
  VLOG(2) << "c nb removed Clauses    : " << solver.nbRemovedClauses << "\n";
  VLOG(2) << "c nb learnts            : " << solver.nLearnts() << "\n";
  VLOG(2) << "c nb learnts DL2        : " << solver.nbDL2 << "\n";
  VLOG(2) << "c nb learnts size 2     : " << solver.nbBin << "\n";
  VLOG(2) << "c nb learnts size 1     : " << solver.nbUn << "\n";
  VLOG(2) << "c nb input learnts      : " << solver.numInputLearnts() << "\n";

  VLOG(2) << "c conflicts             : " << solver.conflicts << "   (" << solver.conflicts/cpu_time << " /sec)\n";
  VLOG(2) << "c decisions             : " << solver.decisions << "   (" << (float)solver.rnd_decisions*100 / (float)solver.decisions << " % random) (" << solver.decisions   /cpu_time << " /sec)\n";
  VLOG(2) << "c propagations          : " << solver.propagations << "   (" << solver.propagations/cpu_time << " /sec)\n";
  VLOG(2) << "c conflict literals     : " << solver.tot_literals << "   (" <<  (solver.max_literals - solver.tot_literals)*100 / (double)solver.max_literals << " % deleted)\n";
  VLOG(2) << "c nb reduced Clauses    : " << solver.nbReducedClauses << "\n"; 

  if (mem_used != 0) VLOG(2) << "c Memory used           : " << mem_used << " MB\n";
  VLOG(2) << "c CPU time              : " << cpu_time << " s\n";
}


//bool same_clauses_file(
//  const solver::SolverRequest &request
//  )
//{
//  if (request.clauses().has_clauses_file())  {
//    std::string new_clause_file = request.clauses().clauses_file();
//    if (!new_clause_file.compare(clause_file_name)) return true;
//  }
//  return false;
//}

bool keep_solver_state(
  const solver::SolverRequest &request
  )
{
  bool new_request_id = (RequestId != request.request_id());
  if (request.has_solver_options()) {
    const solver::SolverOptions &so = request.solver_options();
    return so.keep_solver_state() & !new_request_id;
  }
  return !new_request_id;
}

bool clear_learnts(
  const solver::SolverRequest &request
  )
{
  if (request.has_solver_options()) {
    const solver::SolverOptions &so = request.solver_options();
    if (so.has_clear_learnts()) return so.clear_learnts();
  }
  return true;
}


std::string get_unique_tmpfilename(std::string filename) {
	std::ostringstream str_pid;
        str_pid << getpid();
	std::string cnf = filename;
	for (int i = 0; i < cnf.length(); i++) {
		if (cnf[i] == '/') { cnf[i] = '_'; }
	}
	cnf = "/tmp/" + str_pid.str() + "_" + cnf; 
	return cnf;
}

std::string get_cnf_file(std::string filename) {
	std::string cnf = filename;
      	VLOG(2) << "CNF file name is " << cnf;
	if (filename.length() >=5 && filename.substr(0,5).compare("gs://") == 0) {
		cnf = get_unique_tmpfilename(filename.substr(5,filename.length()-5));
      		VLOG(2) << "File is on Google Storage";
      		VLOG(2) << "Copying file " << filename << " to " << cnf;
		std::string cmd = "gsutil cp " + filename + " " + cnf;
		int err = system(cmd.c_str());
	}
	return cnf;
}

void parseClausesRequest(
  const solver::SolverRequest &request, 
  Solver &S)
{
  //// Parse formula clauses
  assert(request.has_clauses());  // required field 
  if (request.clauses().has_clauses_file())  {
    std::string cnf_filename = get_cnf_file(request.clauses().clauses_file());
    gzFile in = gzopen(cnf_filename.c_str(), "rb");
    if (in == NULL)
      //std::cerr << "Could not open file " << request.clauses().clauses_file(), exit(1);
      VLOG(2) << "Could not open file " << request.clauses().clauses_file(), exit(1);
    VLOG(2) << "has_clauses_file: " << request.clauses().clauses_file() << std::endl;
    parse_DIMACS(in,S);
    gzclose(in);
  } else {
    VLOG(2) << "no clauses file" << std::endl;
    S.addClauses(request.clauses());
  }
}

void parseRequest(
  const solver::SolverRequest &request, 
  Solver &S,
  bool &max_learnts_out_valid,
  google::uint64 &max_learnts_out,
  bool &online_simplification,
  bool &run_without_assumptions,
  bool &use_polarities,
  bool &use_learnts,
  vec<Lit> * assumps)
{

  RequestId = request.request_id();

  if (request.has_learnts())  {
    VLOG(2) << "\nnLearnts in: " << request.learnts().m() << std::endl; 
    S.addLearnts(request.learnts());
    VLOG(2) << "\nnb input learnts : " << S.numInputLearnts() << std::endl; 
  }

  // //// Add assumptions as unit clauses
  // for (int i=0; i<request.assumptions_size(); i++) {
  //   int parsed_lit = request.assumptions(i);
  //   int v = abs(parsed_lit)-1;
  //   while (v >= S.nVars()) S.newVar();
  //   S.addClause( (parsed_lit>0) ? mkLit(v) : ~mkLit(v)); 
  // }

  //// Set rand_seed 
  if (request.has_rand_seed())  {
    if (request.rand_seed() == 0) {
      std::cerr << "WARNING! SolverRequest.rand_seed==0. Hence, ignored." << std::endl;
      VLOG(2) << "WARNING! SolverRequest.rand_seed==0. Hence, ignored." << std::endl;
    }
    else  {
      S.random_seed = request.rand_seed();
    }
  }

  // Note: set polarities after all the calls to newVar()
  //// Set polarities
  if (request.solver_options().return_polarities()) {
    for (int i=0; i<request.polarities_size(); i++) {
      // Don't add assumptions for unused variables
      int k = request.polarities_key(i);
      if (k>=S.nVars()) continue;
      solver::Polarity p = request.polarities(i);
      if (p != solver::UNCOMPUTED) {
        S.setPolarity(k, p==solver::POS ? true : false);
      }
    }
  }

  if (request.has_solver_options()) {
    const solver::SolverOptions &so = request.solver_options();
    //// Set conflict budget
    if (so.has_conflict_budget())  {
      S.setConfBudget(so.conflict_budget());
      VLOG(2) << "Conflict budget: " << so.conflict_budget() << std::endl;
    }

    if (so.has_learnt_clauses_budget())  {
      S.setLearntsBudget(so.learnt_clauses_budget());
      VLOG(2) << "Learnt clauses budget: " << so.learnt_clauses_budget() << std::endl;
    }

    //// Set propagation budget
    if (so.has_propagation_budget())  {
      S.setPropBudget(so.propagation_budget());
      VLOG(2) << "Propagation budget: " << so.propagation_budget() << std::endl;
    } else {
      VLOG(2) << "NO Propagation budget: " << so.propagation_budget() << std::endl;
    }

    if (so.has_num_decision_lits())  {
      S.setNumDecisionLits(so.num_decision_lits());
    }

    if (so.has_max_length_clauses()) {
      S.setMaxLengthClauses(so.max_length_clauses());
    }

    if (so.has_good_lbd_limit()) {
      S.setGoodLBDLimit(so.good_lbd_limit());
      VLOG(2) << "good LBD limit: " << so.good_lbd_limit() << std::endl;
    }

    if (so.has_good_size_limit()) {
      S.setGoodSizeLimit(so.good_size_limit());
    }

    if (so.has_online_simplification()) {
      online_simplification = so.online_simplification();
    }

    if (so.has_keep_running()) {
      run_without_assumptions = so.keep_running();
    } else { // default
      run_without_assumptions = true;
    }

    use_polarities = so.return_polarities();
    use_learnts = so.return_learnts();

    // set all the Glucose-specific options defined in the request
    if (so.has_glucose_options()) {
      const solver::GlucoseOptions * glucoseOpts = &so.glucose_options();
      if (glucoseOpts->has_k())
	S.K 			= glucoseOpts->k();
      if (glucoseOpts->has_r())
	S.R 			= glucoseOpts->r();
      if (glucoseOpts->has_size_lbd_queue())
	S.sizeLBDQueue 		= glucoseOpts->size_lbd_queue();;
      if (glucoseOpts->has_size_trail_queue())
	S.sizeTrailQueue 	= glucoseOpts->size_trail_queue();;
      if (glucoseOpts->has_first_reduce_db())
	S.firstReduceDB 	= glucoseOpts->first_reduce_db();;
      if (glucoseOpts->has_inc_reduce_db())
	S.incReduceDB 		= glucoseOpts->inc_reduce_db();;
      if (glucoseOpts->has_spec_inc_reduce_db())
	S.specialIncReduceDB 	= glucoseOpts->spec_inc_reduce_db();;
      if (glucoseOpts->has_lb_lbd_frozen_clause())
	S.lbLBDFrozenClause 	= glucoseOpts->lb_lbd_frozen_clause();;
      if (glucoseOpts->has_lb_size_minimizing_clause())
	S.lbSizeMinimizingClause= glucoseOpts->lb_size_minimizing_clause();;
      if (glucoseOpts->has_lb_lbd_minimizing_clause())
	S.lbLBDMinimizingClause = glucoseOpts->lb_lbd_minimizing_clause();;
      if (glucoseOpts->has_var_decay())
	S.var_decay 		= glucoseOpts->var_decay();;
      if (glucoseOpts->has_clause_decay())
	S.clause_decay 		= glucoseOpts->clause_decay();;
      if (glucoseOpts->has_random_var_freq())
	S.random_var_freq 	= glucoseOpts->random_var_freq();;
      if (glucoseOpts->has_ccmin_mode())
	S.ccmin_mode 		= glucoseOpts->ccmin_mode();;
      if (glucoseOpts->has_phase_saving())
	S.phase_saving 		= glucoseOpts->phase_saving();;
      if (glucoseOpts->has_rnd_init_act())
	S.rnd_init_act 		= glucoseOpts->rnd_init_act();;
      if (glucoseOpts->has_garbage_frac())
	S.garbage_frac 		= glucoseOpts->garbage_frac();;
    } 
  }
      VLOG(2) << "Input assumptions:" << std::endl;
      //// Read in assumptions
      for (int i=0; i<request.assumptions_size(); i++) {
	int parsed_lit = request.assumptions(i);
	int v = abs(parsed_lit)-1;
	while (v >= S.nVars()) S.newVar();
	assumps->push( (parsed_lit>0) ? mkLit(v) : ~mkLit(v)); 
	VLOG(2) << parsed_lit << " ";
      }
      VLOG(2) << std::endl;


      max_learnts_out_valid = false;
      if (request.has_solver_options()) {
	VLOG(2) << "request has solver options" << std::endl;
	const solver::SolverOptions &so = request.solver_options();
	if (so.has_max_learnts_out())  {
	  max_learnts_out = so.max_learnts_out();
	  max_learnts_out_valid = true;
	}
      }
}

void writeStatistics(Solver &S, 
    solver::SolverStatistics &stats)
{
  stats.set_cpu_time(cpuTime());
  stats.set_mem_used(memUsedPeak());
  stats.set_restarts(S.starts);
  stats.set_blocked_restarts(S.nbstopsrestarts);
  stats.set_last_block_at_restart(S.lastblockatrestart);
  stats.set_reducedb(S.nbReduceDB);
  stats.set_removed_clauses(S.nbRemovedClauses);
  stats.set_dl2_learnts(S.nbDL2);
  stats.set_binary_learnts(S.nbBin);
  stats.set_unary_learnts(S.nbUn);
  stats.set_conflicts(S.conflicts);
  stats.set_decisions(S.decisions);
  stats.set_propagations(S.propagations_this_round);
  stats.set_conflict_literals(S.tot_literals);
  stats.set_reduced_clauses(S.nbReducedClauses);
  stats.set_cpu_time_solverequests(S.time_solverequests);
  stats.set_cpu_time_noassumptions(S.time_noassumptions);
}

// reply_pb: name of file created that contains the SolverReply protobuf
void writeReply (Solver &S, lbool status, bool max_learnts_out_valid, int max_learnts_out, bool use_polarities, bool use_learnts,
    solver::SolverReply &reply)
{

  solver::SolverStatistics *stats = reply.mutable_statistics();
  writeStatistics(S, *stats);

  // solver answer (optional)
  if      (status == l_True)  reply.set_answer(solver::SAT);
  else if (status == l_False)  reply.set_answer(solver::UNSAT);
  //Note that if the solver was interrupted then we return "UNKNOWN".
  else                         reply.set_answer(solver::UNKNOWN);

  // learnts (optional)
  if (use_learnts) { 
    solver::Dimacs *learnts = reply.mutable_learnts();
    if (!max_learnts_out_valid)  {
      max_learnts_out = S.nLearnts();
    }
    int inputLearnts = S.writeLearnts(*learnts, max_learnts_out);

    VLOG(2) << "learnts out: " << learnts->m() << ", input learnts " << inputLearnts << std::endl;
  }


  // if sat, then model 
  if (status == l_True)  {
    for (int var=0; var<S.nVars(); var++) {
      int lit = S.modelValue(var)==l_False ? -1*(var+1) : (var+1);
      reply.add_model(lit);
    }
  }

  // is unsat, then write final conflict
  if (status == l_False)  {
    VLOG(2) << "Final conflict size: " << S.conflict.size() << std::endl;
    for (int i=0; i < S.conflict.size(); i++)  {
      // Add 1 because Minisat subtracts one
      const int v = var(S.conflict[i])+1;
      int lit = sign(S.conflict[i]) ? -1*v : v;
      reply.add_conflict(lit);
      VLOG(2) << lit << " "; 
    }
    VLOG(2) <<  "\n";
  }
  //TODO
  // Solver only interrupted if request is UNSAT
  else if (S.wasInterrupted())  {
    VLOG(2) << "Final conflict size (interrupted): " << S.assumptions.size() << std::endl;
    for (int i=0; i < S.assumptions.size(); i++)  {
      // Add 1 because Minisat subtracts one
      const int v = var(S.assumptions[i])+1;
      // Negate the assumptions to get the learnt clause
      int lit = sign(S.assumptions[i]) ? v : -1*v;
      reply.add_conflict(lit);
      VLOG(2) << lit << " "; 
    }
    VLOG(2) << "\n"; 
  }

  // decision literals
  vec<Lit> dec_lits;
  S.getDecisionLits(dec_lits);

  for (int i=0; i<dec_lits.size(); ++i)  {
    // Add 1 because Minisat subtracts one
    const int v = var(dec_lits[i])+1;
    int lit = sign(dec_lits[i]) ? -1*v : v;
    reply.add_decision_lits(lit);
  }  

  // Polarities
  if (use_polarities) {
    unsigned int c = 0;
    for (int i=0; i<S.nVars(); i++)  {
      solver::Polarity p = S.getPolarity(i);
      if (p != solver::UNCOMPUTED) c++;
      reply.add_polarities(p);
      reply.add_polarities_key(i+1);
    }  
    VLOG(2) << "Number of computed polarities " << c << std::endl;
  }
  return;

}


// Terminate by notifying the solver and back out gracefully. This is mainly to have a test-case
// for this feature of the Solver as it may take longer than an immediate call to '_exit()'.

static void SIGINT_interrupt(int signum) { 
  //VLOG(2) << "\n ***INTERRUPTED " << signum << " ***" << std::endl; 
  _solver->interrupt(); 
}

static void SIGXCPU_interrupt(int signum) { 
  //VLOG(2) << "\n ***INTERRUPTED WITH SIGTERM" << signum << " ***" << std::endl; 
  _solver->finish_round(); 
}

// Note that '_exit()' rather than 'exit()' has to be used. The reason is that 'exit()' calls
// destructors and may cause deadlocks if a malloc/free function happens to be running (these
// functions are guarded by locks for multithreaded use).
static void SIGINT_exit(int signum) {
  VLOG(2) << "*** INTERRUPTED EXIT ***" << std::endl;
  if (_solver->verbosity > 0){
    printStats(*_solver);
    VLOG(2) << "*** INTERRUPTED ***\n"; 
  }
  _exit(1); }

bool in_pipe_mode() {
    return FLAGS_dimacs_in.empty() && FLAGS_pb_in.empty();
}


bool receive_request(SimpSolver * S, solver::SolverRequest &request) {
      // the protobuf message is send through stdin
      // Read solver request
      // The first 4 bytes encode the size of the message
      VLOG(2) << "Waiting for the size of the input" << std::endl;
      int32_t size;
      std::cin.read((char*)&size,4);
      // The protobuf message has size "size", read it 
      VLOG(2) << "Waiting for an input of size " << size << std::endl;
      //char * data = new char[67108864];
      char * data = new char[size];
      std::cin.read(data,size);

      // TODO: try to use ZeroCopyStreams
      //google::protobuf::io::IstreamInputStream * zerocopyinput = new google::protobuf::io::IstreamInputStream(&std::cin);
      //if (request.ParseFromBoundedZeroCopyStream(zerocopyinput,size)) {
      
      if (!request.ParseFromArray(data,size)) {
        std::cerr << "Failed to parse solver-request protobuf" << std::endl;
        VLOG(2) << "Failed to parse solver-request protobuf" << std::endl;
        exit(1);
      }

      VLOG(2) << "parse solver-request protobuf" << std::endl;
      delete data;
      return true;
}

bool send_reply(SimpSolver *S, 
		lbool status,
    		bool  max_learnts_out_valid,
		bool use_polarities,
		bool use_learnts,
    		google::uint64 max_learnts_out
		) {
    if (VLOG_IS_ON(1))  printStats(*S);

    if      (status == l_True)   VLOG(2) << "sat\n";
    else if (status == l_False)  VLOG(2) << "unsat\n";
    else                         VLOG(2) << "unknown\n";

    solver::SolverReply reply;
    writeReply(*S, status, max_learnts_out_valid, max_learnts_out, use_polarities, use_learnts, reply);
    status = l_Undef;
    if (!FLAGS_pb_out.empty())  {
      std::fstream output(FLAGS_pb_out.c_str(), std::ios::out | std::ios::trunc | std::ios::binary);
      if (!reply.SerializeToOstream(&output)) {
	std::cerr << "Failed to write SolverReply protobuf" << std::endl;
	exit(1);
      }
      output.close();
      VLOG(2) << "Returning without errors\n";
      return 0;
    } else {
      uint32_t size = (uint32_t)reply.ByteSize();
      VLOG(2) << "writing " << size << " bytes\n";
      
      std::cout.write((char*)&size,4);
      if (!reply.SerializeToOstream(&std::cout)) {
	std::cerr << "Failed to write SolverReply protobuf" << std::endl;
	exit(1);
      }
      std::cout.flush(); // flush required
    }
     return true;
}

  //=================================================================================================
  // Main:

int main(int argc, char *argv[])
{
  // Change to signal-handlers that will only notify the solver and allow it to terminate
  // voluntarily:
  signal(SIGXCPU,SIGXCPU_interrupt);
  signal(SIGINT, SIGINT_interrupt);

  lbool status = l_Undef;

  SimpSolver * S = new SimpSolver();
  _solver = S;

  google::InitGoogleLogging(argv[0]);
  google::InstallFailureSignalHandler();
  google::ParseCommandLineFlags(&argc, &argv, true);

  GOOGLE_PROTOBUF_VERIFY_VERSION;
  FLAGS_logbufsecs = 0;

#if defined(__linux__)
  fpu_control_t oldcw, newcw;
  _FPU_GETCW(oldcw); newcw = (oldcw & ~_FPU_EXTENDED) | _FPU_DOUBLE; _FPU_SETCW(newcw);
  //printf("c WARNING: for repeatability, setting FPU to use double precision\n");
#endif

  parseOptions(argc, argv, true);

  while (1) {
    bool            max_learnts_out_valid = false;
    google::uint64  max_learnts_out = 0;
    bool  online_simplification = false;
    bool  run_without_assumptions = true;
    bool use_polarities = true;
    bool use_learnts = true;
    vec<Lit> assumps;

    VLOG(2) << "solver started" << std::endl;

    if (in_pipe_mode()) {
      solver::SolverRequest request;
      receive_request(S,request);
      S->clearFinishRound();
      
      // we check whether we are solving the same CNF file as in previous round.
      // If yes, we might keep the same Solver object.
      //const bool same_file = same_clauses_file(request);

//      if (same_file && status != l_Undef)
//	// we basically skip the solving
//	// TODO: I don't like GOTOs...
//	goto solveLimited_done;

      if (keep_solver_state(request)) {
        VLOG(2) << "Using the same solver object" << std::endl;
	S->clearInterrupt();
	if (clear_learnts(request)) 
		// we try to make some place for the m new learnt clauses 
		S->cleanLearnts(request.learnts().m());
      } else {
        VLOG(2) << "Creating a new solver object" << std::endl;
	// we should never have _solver pointing to a freed memory since an interruption
	// can be triggered anytime
	SimpSolver * S_old = S;
        S = new SimpSolver();
  	_solver = S;
	delete S_old;
      	parseClausesRequest(request, *S);
        S->start_solverequest();
	S->eliminate(false);
        S->end_solverequest();
      }
      parseRequest(request, *S, max_learnts_out_valid, max_learnts_out, online_simplification, run_without_assumptions, use_polarities, use_learnts, &assumps);
    } else {
      if ( !FLAGS_dimacs_in.empty() )  {
        assert(FLAGS_pb_in.empty());
        // Parse DIMACS file into Minisat solver.
        gzFile in = gzopen(FLAGS_dimacs_in.c_str(), "rb");
        if (in == NULL)
          std::cerr << "c ERROR! Could not open file: " << argv[1] << "\n"; exit(1);

        parse_DIMACS(in, *S);
        gzclose(in);
      } else {
        assert(!FLAGS_pb_in.empty());
        // Read the solver request.
    	solver::SolverRequest request;
        std::fstream input(FLAGS_pb_in.c_str(), std::ios::in | std::ios::binary);
        if (!request.ParseFromIstream(&input)) {
          std::cerr << "Failed to parse solver-request protobuf" << std::endl;
          exit(1);
        }
        VLOG(2) << "Parsed the file given in --pb_in" << std::endl;
        input.close();
        parseClausesRequest(request, *S);
        parseRequest(request, *S, max_learnts_out_valid, max_learnts_out, online_simplification, run_without_assumptions, use_polarities, use_learnts, &assumps);
      }
    }

    VLOG(2) << "Number of variables: " << S->nVars() << std::endl;
    VLOG(2) << "Number of clauses:   " << S->nClauses() << std::endl;

    S->start_solverequest();
    status = S->solveLimited(assumps,online_simplification);
    S->end_solverequest();

//TODO: remove this label
solveLimited_done:
    S->clearInterrupt();
    send_reply(S, status, max_learnts_out_valid, use_polarities, use_learnts, max_learnts_out);
    status = l_Undef;

    S->propagations_this_round = 0;

    // let the solver run until it receives an interruption
    assumps.clear();
    if (run_without_assumptions) {
      S->budgetOff();
      VLOG(2) << "solveLimited without assumptions" << std::endl;
      S->start_noassumptions();
      status = S->solveLimited(assumps,online_simplification);
      S->end_noassumptions();
      VLOG(2) << "solveLimited without assumptions DONE" << std::endl;
    }
  }
  return 0;
}
