satvidha is a sequential SAT solver that takes in a SolverRequest
protobuf, and emits the SolverReply protobuf. 
See DSolver/src/solver/solver.proto for the format.
Note: if the formula is unsatisfiable, satvidha will emit a single empty clause.


Usage:
-------
satvidha --help 
   Help about options


Common usage:
---------------

satvidha  --pb_in=<request.pb>  --pb_out=<reply.pb> 

--pb_in specifies the input SolverRequest protobuf

NOTE: sativdha can also be used to convert the textual DIMACS CNF format into a SolverRequest protobuf;
in partciular,

  satvidha --dimacs_in=<input.cnf> --pb_out=<request.pb> --dimacs_to_pb


--pb_out will contain the learnt clauses, among other things.
   Note: if the formula is unsatisfiable, the file will contain a single empty clause;
         that is, the protobuf will contain
                   m := 1    // This means there is a single clause.
                   clauses := <0>   // This means the clause is empty, 
                                    // and hence the formula is unsatisfiable.


If you have any questions, please contact Aditya (adi@cs.wisc.edu).

