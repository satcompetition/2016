package dsolver

import (
	"log"
	"math/rand"
	"sort"

	"solver"
)

// E holds a literal and a count of that literal across all
// SovlerReply.DecisionLits. It is defined solely to do the weighted sort using
// Go's sort package.
type E struct {
	lit int32
	cnt int
}
type Es []E

func (es Es) Len() int           { return len(es) }
func (es Es) Less(i, j int) bool { return es[i].cnt > es[j].cnt || (es[i].cnt == es[j].cnt && i < j) }
func (es Es) Swap(i, j int)      { es[i], es[j] = es[j], es[i] }

type DLHistory struct {
	// m sets the priority of the different DLs based on the previous UNKNOWN answers
	// this priority defines which DL we choose for the split in the dilemma rule
	m              map[int32]int
	merge_strategy solver.DLMergeWeight
}

func NewDLHistory(ms solver.DLMergeWeight) *DLHistory {
	return &DLHistory{
		m:              make(map[int32]int),
		merge_strategy: ms,
	}
}

func (h *DLHistory) StartRound(ms solver.DLMergeWeight) {
	for dl, _ := range h.m {
		h.m[dl] = h.m[dl] / 4
	}
	//h.m = make(map[int32]int)
	h.merge_strategy = ms
}

func (h *DLHistory) StopRound() {
	// No-op so far
}

func (h *DLHistory) RecordResponse(DLs []int32, f *solver.Dimacs) {
	//log.Printf("...decision literals: %+v\n", DLs)
	inc := len(DLs)
	for _, dl := range DLs {
		// make sure the literal is positive
		if dl < 0 {
			dl = -dl
		}
		if dl == 0 {
			log.Fatal("RecordResponse: DL should not be zero")
		}
		switch h.merge_strategy {
		case solver.DLMergeWeight_RANK_WEIGHT:
			// Give higher weight to higher priority DLs
			h.m[dl] = h.m[dl] + 1 + inc
		case solver.DLMergeWeight_UNIT_WEIGHT:
			// All DLs get the same unit weight
			h.m[dl] = h.m[dl] + 1
		case solver.DLMergeWeight_RAND_WEIGHT:
			// All DLs get a random weight from 1+[0..inc)
			h.m[dl] = h.m[dl] + 1 + rand.Intn(inc)
		}
		inc--
	}

	// assign a big negative score to each DLs for which we just learnt a unit clause
	if f == nil {
		return
	}
	clauseStart := 0
	for i, l := range f.Clauses {
		if l == 0 {
			if len(f.Clauses[clauseStart:i]) == 1 { // this is a unit clause
				dl := f.Clauses[clauseStart]
				if dl < 0 {
					dl = -dl
				}
				h.m[dl] = -10000000 // big negative score
			}
			clauseStart = i + 1
		}
	}
}

func BuildSortedListFromMap(m map[int32]int) Es {
	var es Es
	for lit, cnt := range m {
		es = append(es, E{lit, cnt})
	}
	sort.Sort(es)
	return es
}

func GetFirstLit(i int, DL []int32, es Es) (int32, int32) {
	for j := 0; true; j++ {
		log.Println("accessing es[", j, "]")
		v := es[j].lit
		c := es[j].cnt
		// check whether v is already in DL
		exists := false
		for _, v2 := range DL {
			if v == v2 {
				exists = true
				break
			}
		}
		if !exists {
			return v, int32(c)
		}
	}
	return 0, 0
}

// GetDLs returns 'k' decision literals based on their frequency which
// is contained in 'm'..

func NewGetDLs(k int, m map[int32]int, VG *VariableGraph) ([]int32, []int32) {
	if len(m) < k {
		ans := []int32{}
		val := []int32{}
		for lit, cnt := range m {
			if cnt > 0 { // do not pick literal with negative score
				ans = append(ans, lit)
				val = append(val, int32(cnt))
			}
		}
		return ans, val
	}
	DL := make([]int32, k)
	Score := make([]int32, k)

	for i := 0; i < k; i++ {
		es := BuildSortedListFromMap(m)
		log.Printf("k=%d, len(es)=%d\n", k, len(es))
		DL[i], Score[i] = GetFirstLit(i, DL, es)
		VG.BoostNeighbors(DL[i], &m)
		if i > 0 {
			log.Println("neighbor coeff: ", VG.NeigborsCoeff(DL[i-1], DL[i]))
			//if VG.AreNeighbors(DL[i-1], DL[i]) {
			//	log.Println(i, "-th choice is a neighbor")
			//} else {
			//	log.Println(i, "-th choice is NOT a neighbor")
			//}
		}
	}
	if len(DL) > 0 {
		log.Printf("Max decision lit is %d with count %d\n", DL[0], m[DL[0]])
	}
	VG.NewRound()
	return DL, Score
}

func GetDLs(k int, m map[int32]int) ([]int32, []int32) {
	if len(m) < k {
		ans := []int32{}
		val := []int32{}
		for lit, cnt := range m {
			if cnt > 0 { // do not pick literal with negative score
				ans = append(ans, lit)
				val = append(val, int32(cnt))
			}
		}
		return ans, val
	}
	var es Es
	for lit, cnt := range m {
		es = append(es, E{lit, cnt})
	}
	log.Printf("k=%d, len(es)=%d\n", k, len(es))
	sort.Sort(es)
	DL := make([]int32, k)
	Score := make([]int32, k)
	for i := 0; i < k; i++ {
		DL[i] = es[i].lit
		Score[i] = int32(es[i].cnt)
	}
	if len(DL) > 0 {
		log.Printf("Max decision lit is %d with count %d\n", DL[0], m[DL[0]])
	}
	return DL, Score
}

//TODO DLHistory.Get should delete the picked literals from the DLHistory map.
// Get returns 'k' decision literals for the next round based on the previously
// observed rounds.
func (h *DLHistory) Get(k int, VG *VariableGraph, DLheuristic int32) ([]int32, []int32) {
	if DLheuristic == 2 {
		log.Println("Using VariableGraph based DL selection heuristic")
		return NewGetDLs(k, h.m, VG)
	} else {
		log.Println("Using standard DL selection heuristic")
		return GetDLs(k, h.m)
	}
}
