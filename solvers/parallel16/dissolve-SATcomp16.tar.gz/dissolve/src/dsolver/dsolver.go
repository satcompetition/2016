package dsolver

import (
	//"encoding/binary"
	"fmt"
	//"io"
	"log"
	"math"
	"math/rand"
	"net"
	"net/http"
	"net/rpc"
	//"os/exec"
	//"runtime"
	"sort"
	"strings"
	"sync"
	//"syscall"
	"time"
	//"runtime/pprof"
	//"os"

	"github.com/golang/protobuf/proto"

	"solver"
)

type DSolverOpts struct {
	Port int32
	// Name of the executable to invoke on a Solve RPC. 'Solver' should implement
	// the interface:
	//   ./solver --pb_in=<solver.SolverRequest> --pb_out=<solver.SolverReply> [args]
	// where [args] is solver dependent and specified via SolverArgs.
	//Solver string
	// Additional args to pass to 'Solver'. Can be empty.
	//SolverArgs []string
}

// Struct containing the server state.
type DSolver struct {
	// Options passed to NewDSolver
	Options DSolverOpts
	// The address this DSolver listens on.
	Addr net.Addr
	// idChan generates the infinite stream 1,2,3,...
	idChan   chan int64
	spawn_ch chan bool
	// worker manager
	workerManager *WorkerManager

	idStateMap   map[int64]*DSolverState
	idStateMapMu sync.RWMutex

	// this received a 1 each time the DSolver finds an answer
	// it is used for profiling purposes in dsolver-main.go
	cpuprofile_ch chan bool
}

//////////////////
// NewDSolver
/////////////////

// Returns nil, error if
//   -- net.Listen fails for port 'port'
func NewDSolver(addrs []string, opts DSolverOpts) (*DSolver, chan bool, error) {
	// opts.Solver must be valid.
	var err error
	cpuprofile_chan := make(chan bool, 1)

	ch := make(chan bool, 1)
	//TODO eventually have a common worker manager that is shared among
	//     various DSolvers
	w, e := NewWorkerManager(ch)
	if e != nil {
		return nil, cpuprofile_chan, err
	}
	w.AddPeers(addrs)

	d := &DSolver{
		Options:       opts,
		idChan:        make(chan int64, 16),
		spawn_ch:      ch,
		cpuprofile_ch: cpuprofile_chan,
		workerManager: w,
	}
	w.dsolver = d
	// Launch the id generator
	go func(c chan int64) {
		for i := int64(1); i < int64(1)<<48; i++ {
			c <- i
		}
		panic("Request id space exhausted")
	}(d.idChan)

	rpc.Register(d)
	rpc.HandleHTTP()
	l, e := net.Listen("tcp", fmt.Sprintf(":%d", opts.Port))
	if e != nil {
		return nil, cpuprofile_chan, e
	}
	d.Addr = l.Addr()
	http.HandleFunc("/status", d.StatusHandler)
	go http.Serve(l, nil)

	d.idStateMap = make(map[int64]*DSolverState)

	return d, cpuprofile_chan, nil
}

// StatusHandler reports status information on the DSolver via an HTTP request
// to host:port/status of the DSolver.
func (d *DSolver) StatusHandler(w http.ResponseWriter, r *http.Request) {
	req := &StatusRequest{}
	resp := &StatusResponse{}
	err := d.Status(req, resp)
	if err != nil {
		log.Fatalf("DSolver cannot report status: %s", err)
	}
	fmt.Fprintf(w, "Status: %s\n", proto.CompactTextString(resp))
}

func (d *DSolver) Status(in *StatusRequest, out *StatusResponse) error {
	out.Port = proto.Int32(d.Options.Port)
	//TODO Get status of peers using WorkerManager.
	d.workerManager.PeerStatus()
	return nil
}

////////////////////////////
// GetDSolverRequestId
///////////////////////////

// utility function that generates unique numbers
func (d *DSolver) genId() int64 {
	id := <-d.idChan
	return id
}

// This function should be called by dsolver-send before calling DSolver.Solve
func (d *DSolver) GetDSolverRequestId(in *DSolverRequestId, out *DSolverRequestId) error {
	*out = DSolverRequestId{Id: proto.Int64(d.genId())}
	return nil
}

//////////////
// Cancel
/////////////
func (d *DSolver) CancelRequest(in *DSolverRequestId) error {

	d.idStateMapMu.Lock()
	defer d.idStateMapMu.Unlock()
	requestId := in.GetId()
	ss, ok := d.idStateMap[requestId]
	if ok {
		ss.Inactive_signal <- true
	}
	return nil
}

func (d *DSolver) CancelAllRequests(in *DSolverRequestId, out *CancelResponse) error {
	//d.workerManager.CancelRequest(in)
	d.CancelRequest(in)
	return nil
}

//////////////////////
// Solve
/////////////////////

// IssueIthRequest generates assumption A for the ith request, i \in [0, 2^k).
// DSolver.Solve is issued recursively to the ith peer and the result is written
// to ch.
func (d *DSolver) IssueIthRequest(requestId int64, dVars []int32, i int, ch chan Instance, round int) SolveId {
	// 1. Generate A
	A := GenIthAssumption(dVars, i)
	// 2. Generate a new DSolverRequest
	//    The new request is a copy of origIn *except* for the Assumptions
	//    which must be assigned to A to reflect the dilemma assignment for this ith SOLVE request.
	d.idStateMapMu.RLock()
	ss := d.idStateMap[requestId]
	d.idStateMapMu.RUnlock()
	sReq := *ss.Request
	sReq.Assumptions = A
	// RandSeed needs to be positive.
	sReq.RandSeed = proto.Float64(GenIthRandSeed(i))

	req := &DSolverRequest{
		Request: &sReq,
		// T: Don't set to skip alloc b/c default is SOLVE
		//SolveId: proto.Int64(int64(i)),
		// origIn.Id can be nil meaning that the SOLVE request isn't cancellable.
		RequestId: &DSolverRequestId{
			Id: proto.Int64(requestId),
		},
	}
	sid := d.workerManager.IssueSolve(req, ch, round)
	return sid
}

func (d *DSolver) DilemmaSolve(requestId int64, initLearntsBudget uint64, round int) error {
	d.idStateMapMu.RLock()
	ss := d.idStateMap[requestId]
	d.idStateMapMu.RUnlock()

	//TODO DLHistory.Get should delete the picked literals from the DLHistory map.
	dVars := ss.GetDLs(int(ss.K), round)
	// TODO update this
	ss.DlhMu.Lock()
	ss.Dlh.StartRound(solver.DLMergeWeight_RANK_WEIGHT)
	ss.DlhMu.Unlock()

	// Update the SolverRequest.{Learnts,Polarities} for use on the next round.
	// Shift imp to other and clear imp.
	if ss.recordLearnts {
		ss.CmMu.Lock()
		// updating the Learnt clauses
		ss.Cm.StartRound(round)
		//backup_clauses := ss.Cm.Shift()
		//ss.Request.Learnts = ss.Cm.ToBoundedDimacsWithBackup(GetLearntsBudget(initLearntsBudget, round), backup_clauses)
		ss.CmMu.Unlock()
	}
	log.Printf("Round %d, learnts: %d\n", round, ss.Request.Learnts.GetM())

	ss.Request.PolaritiesKey, ss.Request.Polarities = ss.GetPolaritiesMap()

	log.Printf("Generated DL:%+v\n", dVars)

	// Fire off 2^K SOLVE requests to our peers and collect results in ch.
	// Because SolveId is an int32 K must be <= 31.
	if ss.N > 31 {
		log.Fatal(fmt.Errorf("N value too high: %d", ss.N))
	}

	indexSolveIdMap := make(map[int]SolveId) // Map from i'th request to the SolveId for that request
	SolveIdToIndexMap := make(map[SolveId]int)

	// K might be different from ss.K in case GetDLs returns less than K variables (which can happen)
	K := len(dVars)

	instCnt := 1 << uint(ss.N) // The number of branches.
	casesCnt := 1 << uint(K)   // The number of cases considered.

	ch := make(chan Instance, instCnt)

	// outstandingRequests tracks for each SOLVE index 'i' whether or not 'i' has completed.
	//outstandingRequests := make([]rune, instCnt)

	// outstandingCases tracks whether a case has been found to be unsat or not.
	const kUnsat rune = 'U'
	const kOther rune = 'O'
	outstandingCases := make([]rune, casesCnt)
	for i := 0; i < casesCnt; i++ {
		outstandingCases[i] = kOther
	}

	log.Println("issuing the requests for round ", round)
	for i := 0; i < instCnt; i++ {
		sid := d.IssueIthRequest(requestId, dVars, i, ch, round)
		indexSolveIdMap[i] = sid
		SolveIdToIndexMap[sid] = i
	}
	//d.workerManager.spawnMutex.Lock()
	d.workerManager.spawning = false
	d.workerManager.spawnMutex.Unlock()

	// Signal to DLHistory 'h' that a new round of reductions is starting ...
	//h.StartRound(in.Request.SolverOptions.GetDlMergeWeight())
	numUnsat := int(0) // Number of instances that are unsat
	total_CPU_time := float64(0.0)

	done := make(chan bool, 1)
	timed_out := false
	if ss.round_timeout != 0 {
		go func() {
			select {
			case <-done:
			case <-time.After(time.Duration(ss.round_timeout) * time.Second):
				timed_out = true
				for _, id := range indexSolveIdMap {
					log.Printf("Round Timeout for index %d after %d sec", id, ss.round_timeout)
					go d.workerManager.CancelSolve(id)
				}
			}
		}()
	}

	for i := 0; i < instCnt; i++ {
		select {
		case inst := <-ch:
			log.Println("DILEMMASOLVE: Round", round, " answer #", i+1)
			if inst.Err != nil {
				log.Fatalf("Request %d returned with error %s", inst.sid.id, inst.Err)
			}
			// Check whether instance is unsat
			if inst.Response.Reply.GetAnswer() == solver.SolverAnswer_UNSAT || inst.WasCancelledUnsat {
				// The first k bits of the instance index determines which case was solved.
				c := ExtractFirstKBits(uint(SolveIdToIndexMap[inst.sid]), uint(K))
				// If this case has not been found to be unsat, then increment the numUnsat count,
				// and mark this case has been unsat.
				if outstandingCases[c] == kOther {
					numUnsat++
					outstandingCases[c] = kUnsat
				}
			}
			if inst.WasCancelled {
				if inst.Response.Reply.GetAnswer() == solver.SolverAnswer_UNKNOWN {
					log.Printf("Cancelled request %d returned UNKNOWN answer", inst.sid.id)
				}
				if inst.Response.Reply.GetAnswer() == solver.SolverAnswer_UNSAT {
					log.Printf("Cancelled request %d returned UNSAT answer", inst.sid.id)
				}
				if inst.Response.Reply.GetAnswer() == solver.SolverAnswer_SAT {
					log.Printf("WARNING: Cancelled request %d returned SAT answer, which is unexpected", inst.sid.id)
				}
			}

			GetSolverStatistics(inst)

			d.Reduce(requestId, &total_CPU_time, inst, round)

			// Computed SAT or UNSAT answer. Done!
			ss.AnsMu.Lock()
			Response := ss.Ans
			ss.AnsMu.Unlock()
			if Response == solver.SolverAnswer_SAT || Response == solver.SolverAnswer_UNSAT {
				if Response == solver.SolverAnswer_SAT {
					log.Printf("SAT answer found...")
				} else {
					log.Printf("UNSAT answer found...")
				}
				// we need to read the CPU time of all the remaining solvers to make sure the total CPU time is correct
				for j := i + 1; j < instCnt; j++ {
					inst = <-ch
					total_CPU_time += inst.Response.Reply.GetStatistics().GetCpuTime()
					//dilemma_out.Total_CPUTime = proto.Float64(total_CPU_time)
				}
				return nil
			}

			// We have received an UNSAT reply from a branch.
			// The conflict field in the reply represents a learnt clause involving only decision literals.
			// Another way of thinking about the conflict clause is that it is the negation of the unsat-core
			// that only involves decision literals.
			// Using this conflict clause, we can determine which other branches are unsatisfiable.
			// For example if DLs = {x,y,z,w}, and conflict clause is { !x | y }.
			// Then the unsat-core is x & !y.
			// Thus, we can cancel all four branches whose assignments have x set to true and y set to false;
			// z and w are unconstrained.
			if inst.Response.Reply.GetAnswer() == solver.SolverAnswer_UNSAT {
				for _, index := range GenCancellableAssignments(dVars, inst.Response.Reply.Conflict) {
					log.Printf("Found CANCELLATION opportunity at index %d", index)
					go d.workerManager.CancelSolveUnsat(indexSolveIdMap[index])
					log.Printf("CANCELLATION opportunity at index %d done", index)
				}
			}
		}
	}

	done <- true

	log.Println("Total CPU time for sequential solvers: ", total_CPU_time)

	// Close 'ch' because no more responses should be written to it.
	close(ch)
	// At this point all SOLVE requests have finished and reduced to out.Reply.
	//if inst.Response.MinConflictClauseLength != nil {
	//	//log.Printf("Min. conflict clause length %d\n", dilemma_out.GetMinConflictClauseLength())
	//}

	//Set answer in dsolver state
	// If all 2^K cases were UNSAT then the overall query is UNSAT.
	// Note that the number of cases does not necessarily equal the number
	// of requests (or branches).
	if numUnsat == casesCnt && !timed_out {
		log.Println("All branches from the same dilemma split are UNSAT => formula is UNSAT (", numUnsat, " UNSAT)")
		ss.AnsMu.Lock()
		ss.Ans = *solver.SolverAnswer_UNSAT.Enum()
		ss.AnsMu.Unlock()
		ss.Inactive_signal <- true
		return nil
	}

	// Histogram
	ss.StatsMu.RLock()
	ss.stats.printStats()
	EmitHistogram("UNSAT", ss.stats.UnsatTimes, 10 /* numBkts */)
	EmitHistogram("UKNOWN", ss.stats.UnknownTimes, 10 /* numBkts */)
	ss.StatsMu.RUnlock()

	return nil
}

func (d *DSolver) Spawn(requestId int64, round int) error {
	d.workerManager.spawnMutex.Lock()

	d.idStateMapMu.Lock()
	ss := d.idStateMap[requestId]
	d.idStateMapMu.Unlock()

	// set a new random seed for this round
	NewRandSeed()

	// Update conflict and learnts budgets
	// Ideally, if each of the solver instances returned distinct learned clauses,
	// then we would use lBudge := GetLearntsBudget(round) >> uint64(in.GetN()).
	// But empirically we see that half the learned clauses are repeated or subsumed
	// by other learned clauses. Thus, we double the "ideal" budget.
	lBudg := 2 * (GetLearntsBudget(ss.initLearntsBudget, round) >> uint64(ss.N))
	// This is a heuristic. Don't let the number of learnts drop too low.
	if lBudg < 1000 {
		lBudg = 1000
	}

	ss.Request.SolverOptions.MaxLearntsOut = proto.Uint64(lBudg)
	ss.Request.SolverOptions.ConflictBudget = proto.Uint64(ss.inner_conf)

	log.Printf("Round %d\n", round)

	// log some stats on the learnt clauses
	ss.Request.Learnts.Stats(round)

	pBudg := ss.inner_prop
	// With a small probability run for very long,
	// provided there aren't any unsat branches in phase 1
	if rand.Float32() < 0.05 {
		log.Println("Boosting propagation budget")
		pBudg = 5 * ss.initPropagationBudget
	}
	if round == 0 {
		// if we set the propagation budget to 0, we want to never merge.
		// the initial round should then also have a budget 0
		if ss.initPropagationBudget == 0 || ss.zerothPropagationBudget == 0 {
			pBudg = 0
		} else {
			pBudg = ss.zerothPropagationBudget
		}
	}

	ss.Request.SolverOptions.PropagationBudget = proto.Uint64(pBudg)

	log.Println("Starting a dilemma solve")
	go d.DilemmaSolve(requestId, ss.initLearntsBudget, round)

	d.UpdateBudget(ss, round)
	return nil
}

func (d *DSolver) UpdateBudget(ss *DSolverState, round int) {

	// Update propagation budget according to restart strategy
	if round != 0 {
		switch ss.Request.SolverOptions.GetRestartStrategy() {
		case solver.RestartStrategy_PICO_RESTART:
			// Update restart strategy for the next round
			if ss.inner_prop >= ss.outer_prop {
				ss.outer_prop += ss.outer_prop / 5 // increase by 20%
				ss.inner_prop = ss.initPropagationBudget
			} else {
				ss.inner_prop += ss.inner_prop / 5 // increase by 20%
			}

			if ss.inner_conf >= ss.outer_conf {
				ss.outer_conf += ss.outer_conf / 10 // increase by 10%
				ss.inner_conf = ss.initConflictBudget
			} else {
				ss.inner_conf += ss.inner_conf / 10 // increase by 10%
			}

			if ss.inner_seq_timeout >= ss.outer_seq_timeout {
				ss.outer_seq_timeout += ss.outer_seq_timeout / 5 // increase by 20%
				ss.inner_seq_timeout = ss.init_seq_timeout
			} else {
				ss.inner_seq_timeout += ss.inner_seq_timeout / 5 // increase by 20%
			}
		case solver.RestartStrategy_LUBY_RESTART:
			ss.inner_prop = GetLubyPropagationBudget(ss.initPropagationBudget, round)
			ss.inner_seq_timeout = GetLubyPropagationBudget(ss.init_seq_timeout, round)
		case solver.RestartStrategy_FIXED_RESTART:
			ss.inner_prop = ss.initPropagationBudget
			ss.inner_seq_timeout = ss.init_seq_timeout
		default:
			log.Fatalf("Unknown restart strategy")
		}
	}

}

func (d *DSolver) Solve(in *DSolverRequest, out *DSolverResponse) error {
	if err := in.Request.Clauses.IsSane(); err != nil {
		// Insane request, bail with error.
		log.Println("Insane SolverRequest.Clauses: ", err)
		return err
	}

	// Always want to return a SolverReply in the non-error case.
	out.Reply = &solver.SolverReply{
		Learnts: &solver.Dimacs{
			N:       in.Request.Clauses.N,
			M:       proto.Int32(0),
			Clauses: []int32{},
		},
		DecisionLits: []int32{},
		//Polarities:   []solver.Polarity{},
	}

	if in.GetT() == DSolverRequest_SOLVE {
		log.Fatalf("Dsolve.Solve requires Solve request type of SPLIT, not SOLVE.")
	}
	// SPLIT requests require N
	if in.N == nil {
		log.Fatalf("Invalid SPLIT request, missing N: %s", in)
	}
	if in.GetN() == 0 {
		log.Fatalf("Invalid SPLIT request, N is 0: %s", in)
	}
	if in.GetN() < in.GetK() {
		log.Fatalf("Invalid SPLIT request, N < K: %s", in)
	}
	if in.RequestId == nil {
		log.Fatalf("Invalid SPLIT request, missing RequestId: %s", in)
	}
	requestId := *in.RequestId.Id

	ClManager_small_limit := in.GetClausemanagerSmallLimit()
	ClManager_imp_limit := in.GetClausemanagerImpLimit()
	ClManager_subsump_limit := in.GetClausemanagerSubsumptionLimit()
	dlMergeWeight := in.Request.SolverOptions.GetDlMergeWeight()

	//log.Printf("Incoming SPLIT with Id:%d K:%d N:%d Rounds:%d\n", in.GetId(), in.GetK(), in.GetN(), in.GetRounds())
	log.Println("Propagation budget: ", in.Request.SolverOptions.GetPropagationBudget())
	log.Println("Max learnts: ", in.Request.SolverOptions.GetMaxLearntsOut())
	log.Println("Max length of clauses: ", in.Request.SolverOptions.GetMaxLengthClauses())
	log.Println("Num decision lits: ", in.Request.SolverOptions.GetNumDecisionLits())
	log.Println("Restart strategy: ", in.Request.SolverOptions.GetRestartStrategy().String())
	log.Println("Zeroth propagation budget: ", in.Request.SolverOptions.GetZerothPropagationBudget())
	log.Println("DL merge weight: ", in.Request.SolverOptions.GetDlMergeWeight().String())
	log.Println("Keep solver state: ", in.Request.SolverOptions.GetKeepSolverState())
	log.Println("Clear learnts: ", in.Request.SolverOptions.GetClearLearnts())
	log.Println("return learnts: ", in.Request.SolverOptions.GetReturnLearnts())
	log.Println("return polarities: ", in.Request.SolverOptions.GetReturnPolarities())

	d.idStateMapMu.Lock()
	ss, ok := d.idStateMap[requestId]
	if ok {
		log.Fatalf("Invalid SPLIT request, RequestId already in use: %s", in)
	} else {
		d.idStateMap[requestId] = NewDSolverState(
			in.GetRequest(),
			in.GetK(),
			in.GetN(),
			int32(in.GetDh()),
			int64(in.GetTimeout()),
			int64(in.GetRoundTimeout()),
			int(ClManager_small_limit),
			int(ClManager_imp_limit),
			ClManager_subsump_limit,
			in.GetUBTreeSimplificationLevel(),
			dlMergeWeight,
		)
	}
	ss = d.idStateMap[requestId]
	d.idStateMapMu.Unlock()

	if ss.DLheuristic == 2 {
		log.Println("BUILD VG")
		//ss.CmMu.Lock()
		ss.VG.BuildFromDimacs(ss.Request.Clauses)
		//ss.CmMu.Unlock()
		log.Println("BUILD VG OK")
	}
	round := 0
	//d.workerManager.spawnMutex.Lock()
	d.Spawn(requestId, round)
	//d.workerManager.spawnMutex.Unlock()

	for ; round < int(in.GetRounds()) || int(in.GetRounds()) < 0; round++ {
		log.Println("Waiting for next round")
		select {
		case <-ss.Inactive_signal:
			log.Println("SOLVE: Inactive_signal received")
			go d.workerManager.CancelRequest(in.GetRequestId())
			ss.createDSolverResponse(out)
			log.Println("OUT is ", proto.MarshalTextString(out))
			d.cpuprofile_ch <- true
			return nil
		case <-d.spawn_ch:
			go func(round int) {
				//d.workerManager.spawnMutex.Lock()
				d.Spawn(requestId, round)
				//d.workerManager.spawnMutex.Unlock()
				log.Println("New round issued")
			}(round)
		}
	}
	return nil
}

// Propagation budget is InitConflictBudget, multiply by luby sequence.
func GetLubyPropagationBudget(initPropagationBudget uint64, round int) uint64 {
	if round == 0 {
		return initPropagationBudget
	}
	return solver.GetLuby(round) * initPropagationBudget
}

// Initial learnts budget is InitLearntsBudget, multiply by luby sequence.
func GetLearntsBudget(initLearntsBudget uint64, round int) uint64 {
	//TODO(adi): Reverting to a constant budget for now.
	return initLearntsBudget
	// if round == 0 {
	// 	return InitLearntsBudget
	// }
	// lb := solver.GetLuby(round) * InitLearntsBudget
	// if lb < MaxLearntsBudget {
	// 	return lb
	// } else {
	// 	return MaxLearntsBudget
	// }
}

func ExtractFirstKBits(n uint, k uint) uint {
	return n & ((1 << k) - 1)
}

func GenIthAssumption(dVars []int32, i int) []int32 {
	A := make([]int32, len(dVars))
	// i's binary form encodes the assumptions.
	for pos, dVar := range dVars {
		if i&(1<<uint(pos)) > 0 {
			A[pos] = dVar
		} else {
			A[pos] = -dVar
		}
	}
	return A
}

var current_RandSeed float64 = 9.16483e+07

func NewRandSeed() {
	current_RandSeed = float64(rand.Uint32())
}

func GenIthRandSeed(i int) float64 {
	// we always set a new random seed
	return float64(rand.Uint32())
}

// EmitHistogram emits a histogram of execution times contained in 'elapsed'.
// The times in 'elapsed' are output in 'numBkts' buckets.
func EmitHistogram(title string, elapsed []float64, numBkts int) {
	log.Printf("\n\n==== %s has %d latencies (s) in %d buckets\n", title, len(elapsed), numBkts)
	cnt := len(elapsed)
	if cnt == 0 {
		fmt.Println("NONE")
		return
	}
	if cnt == 1 {
		fmt.Println(elapsed[0])
		return
	}
	sort.Sort(sort.Float64Slice(elapsed))
	// Bucket the durations into numBkts buckets with bucket 'b' holding the
	// count of the number of solver executions in the range:
	//    min + [interval * b, interval * (b+1)]
	min := elapsed[0]
	max := elapsed[cnt-1]
	interval := (max - min) / float64(numBkts)
	if interval == 0.0 {
		// Avoid div-by-zero when elapsed is one repeated value.
		interval = 1.0
	}
	//fmt.Printf("min = %f, max = %f, interval = %f\n", min, max, interval)
	buckets := make([]int, numBkts+1) // +1 b/c of int div truncation
	for _, e := range elapsed {
		bkt := int(math.Floor((e - min) / interval))
		buckets[bkt]++
	}
	for i, bkt := range buckets {
		low := min + float64(i)*interval
		high := low + interval
		cnt := bkt
		trunc := false
		if cnt > 60 {
			cnt = 60
			trunc = true
		}
		hashes := strings.Repeat("#", cnt)
		if trunc {
			hashes += "..."
		}
		log.Printf("[%8.3f -- %8.3f)   %-63s%7d\n", low, high, hashes, bkt)
	}
}

func GenCancellableAssignments(dVars, conflict_clause []int32) []int {
	unsat_core := make([]int32, len(conflict_clause))
	for pos, v := range conflict_clause {
		unsat_core[pos] = -v
	}
	fixed, indices := ComputeFixedAndIndices(dVars, unsat_core)
	return GenAssignments(fixed, indices)
}

// GenAssignments generates all assignments, as integers, over a set of Boolean
// variables such that each assignment contains "fixed" and ranges over the
// indices specified by indices. The latter implies that the number of
// assignments generated is 2^|indices|. Example:
//
// Vars    = X Y Z
// fixed   = 1 0 0
// indices = {1, 0}
// Output  = { 100, 101, 110, 111 } or { 4, 5, 6, 7 }
//
// Another way to specify the above is to generate all assignments from the
// tempalte 1?? where each '?' ranges over {0,1}. This concise specification
// will be used below.
func GenAssignments(fixed int, indices []int) []int {
	// Generate cnt=2^|indices| assignments.
	num_assignments := 1 << uint(len(indices))
	answer := make([]int, num_assignments)
	for cnt, _ := range answer {
		// Each assignment always includes fixed.
		assignment := fixed
		for bit, index := range indices {
			// If 'cnt' contains 'bit' set 'index' in assignment.
			bit_check := 1 << uint(bit)
			if cnt&bit_check == bit_check {
				assignment |= 1 << uint(index)
			}
		}
		answer[cnt] = assignment
	}
	return answer
}

// ComputeFixedAndIndices computes the "fixed" and "indices" arguments for passing
// to GenIndices where 'dVars' is the set of decision variables and 'L' is an
// unsat core such that Vars(L) \subset Vars(dVars). Each L then represents
// a set of SOLVE requests that can be cancelled. An example should clarify the
// process. Let:
//   dVars = [X Y Z]
//   L     = [Y]
// Generate
//   fixed = ? 1 ?
//   indices = [0, 2]
// Meaning that we generate all request indices such that the question
// mark holes in 'fixed' are updated with values from the range [0,1].
func ComputeFixedAndIndices(dVars, L []int32) (fixed int, indices []int) {
	for indexDV, varDV := range dVars {
		// if varDV < 0 {
		// 	varDV *= -1
		// }
		found := false
		for _, varL := range L {
			// if varL < 0 {
			// 	varL *= -1
			// }
			if varDV == varL {
				// Found 'Y' in the example, update 'fixed' with the index of DV
				found = true
				fixed |= 1 << uint(indexDV)
				break
			} else if varDV == -varL {
				// Found 'Y' in the example, update 'fixed' with the index of DV
				found = true
				fixed |= 0 << uint(indexDV)
				break
			}
		}
		if !found {
			indices = append(indices, indexDV)
		}
	}
	return fixed, indices
}

func GetSolverStatistics(inst Instance) float64 {
	var iReply *solver.SolverReply = inst.Response.Reply
	total_time := iReply.GetStatistics().GetCpuTime()
	requests_time := iReply.GetStatistics().GetCpuTimeSolverequests()
	noassumps_time := iReply.GetStatistics().GetCpuTimeNoassumptions()
	propagations := iReply.GetStatistics().GetPropagations()
	log.Printf("--- Solver statistics, instance %d ---", inst.sid.id)
	log.Printf("CPU time: %f", total_time)
	log.Printf("CPU time, solving requests: %f   (%f%%)", requests_time, 100*requests_time/(requests_time+noassumps_time))
	log.Printf("CPU time, running without assumptions: %f   (%f%%)", noassumps_time, 100*noassumps_time/(requests_time+noassumps_time))
	log.Printf("Propagations: %d", propagations)
	return total_time
}

// Reduce reduces the DSolverResponse contained in 'inst' into 'out'.
func (d *DSolver) Reduce(requestId int64, total_CPU_time *float64, inst Instance, round int) {
	d.idStateMapMu.Lock()
	ss := d.idStateMap[requestId]
	for len(ss.stats.RoundStats) <= round {
		s := &RoundStatistics{}
		ss.stats.RoundStats = append(ss.stats.RoundStats, s)
	}
	d.idStateMapMu.Unlock()
	// iReply is the sequential solver reply
	var iReply *solver.SolverReply = inst.Response.Reply
	log.Printf("Instance %5d is %s\n", inst.sid.id, iReply.GetAnswer())
	if inst.Err != nil {
		// TODO(nkidd) Probably need to invalidate peer GetPeer(inst.Index)
		// and attempt to reconnect.
		log.Printf("SOLVE %d had error %s\n", inst.sid.id, inst.Err)
		// Treat an error as UNKNOWN with 0 learnts and an empty set of
		// returned decision literals. Hence there is nothing to do.
		return
	}

	*total_CPU_time += iReply.GetStatistics().GetCpuTime()
	// TODO
	//out.Total_CPUTime = proto.Float64(*total_CPU_time)

	// Switch on the SolverAnswer updating the solver state ss as appropriate.
	switch iReply.GetAnswer() {
	case solver.SolverAnswer_SAT:
		ss.StatsMu.Lock()
		ss.stats.SatTimes = append(ss.stats.SatTimes, inst.Response.SatTimes...)
		ss.stats.RoundStats[round].SatTimes = append(ss.stats.RoundStats[round].SatTimes, inst.Response.SatTimes...)
		ss.StatsMu.Unlock()
		// Great, problem solved, set Answer to SAT and move on.
		ss.AnsMu.Lock()
		ss.Ans = iReply.GetAnswer()
		ss.AnsMu.Unlock()
		// Copy the satisfying assignment
		ss.ModelMu.Lock()
		ss.Model = make([]int32, len(iReply.Model))
		copy(ss.Model, iReply.Model)
		ss.ModelMu.Unlock()
		// problem solved, it becomes inactive
		ss.Inactive_signal <- true

	case solver.SolverAnswer_UNSAT:
		ss.StatsMu.Lock()
		ss.stats.UnsatTimes = append(ss.stats.UnsatTimes, inst.Response.UnsatTimes...)
		ss.stats.RoundStats[round].UnsatTimes = append(ss.stats.RoundStats[round].UnsatTimes, inst.Response.UnsatTimes...)
		if ss.MinConflictClauseLength == nil || *ss.MinConflictClauseLength > int32(len(iReply.Conflict)) {
			ss.MinConflictClauseLength = proto.Int32(int32(len(iReply.Conflict)))
		}
		ss.StatsMu.Unlock()

		// If the conflict clause is empty, then the input formula is unsat.
		// Great, problem solved, set Answer to UNSAT and move on
		if len(iReply.Conflict) == 0 {
			// Update Ans in the DSolverState
			log.Printf("Conflict size is zero! Problem solved, UNSAT")
			ss.AnsMu.Lock()
			ss.Ans = iReply.GetAnswer()
			ss.AnsMu.Unlock()
			// problem solved, it becomes inactive
			ss.Inactive_signal <- true
			return
		}

		if ss.recordLearnts {
			// Insert the conflict clause into the ClauseManager cm.
			// Use subsumption checks, and treat this as an important clause.
			ss.CmMu.Lock()
			ss.Cm.InsertClause(true, iReply.Conflict, true)
			ss.CmMu.Unlock()

			// Insert the learnts clauses into the ClauseManager cm
			log.Printf("Instance %5d learned %d clauses\n", inst.sid.id, iReply.Learnts.GetM())
			ss.CmMu.Lock()
			ss.Cm.Insert(iReply.Learnts)
			//ss.VG.BuildFromDimacs(iReply.Learnts)
			ss.CmMu.Unlock()

			ss.StatsMu.Lock()
			ss.stats.RoundStats[round].nb_learnts = append(ss.stats.RoundStats[round].nb_learnts, iReply.Learnts.GetM()+1)
			ss.StatsMu.Unlock()
		}

	case solver.SolverAnswer_UNKNOWN:
		ss.StatsMu.Lock()
		ss.stats.UnknownTimes = append(ss.stats.UnknownTimes, inst.Response.UnknownTimes...)
		ss.stats.RoundStats[round].UnknownTimes = append(ss.stats.RoundStats[round].UnknownTimes, inst.Response.UnknownTimes...)
		ss.StatsMu.Unlock()
		// Only use DLs from Unknown instances.
		ss.DlhMu.Lock()
		log.Printf("learned DLs %+v\n", iReply.DecisionLits)
		ss.Dlh.RecordResponse(iReply.DecisionLits, iReply.Learnts)
		ss.DlhMu.Unlock()

		// Insert the learnts clauses into the ClauseManager cm
		log.Printf("Instance %5d learned %d clauses\n", inst.sid.id, iReply.Learnts.GetM())
		if ss.recordLearnts {
			ss.CmMu.Lock()
			ss.Cm.Insert(iReply.Learnts)
			//ss.VG.BuildFromDimacs(iReply.Learnts)
			ss.CmMu.Unlock()

			ss.StatsMu.Lock()
			ss.stats.RoundStats[round].nb_learnts = append(ss.stats.RoundStats[round].nb_learnts, iReply.Learnts.GetM())
			ss.StatsMu.Unlock()
		}

		// Update polarities using reply polarities.
		ss.RecordPolarities(iReply.PolaritiesKey, iReply.Polarities)
	}
}
