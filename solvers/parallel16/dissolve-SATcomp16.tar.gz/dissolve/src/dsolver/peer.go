package dsolver

import (
	"fmt"
	"net/rpc"
)

type Peer struct {
	index   int
	address string
	// client is nil if DialHTTP fails.
	client *rpc.Client

	// indicates the value of the latest round for which the solver already computed a request
	// this is useful to specialize which set of learnt clauses has to be sent next
	current_round int
}

func (peer *Peer) Solve(req *DSolverRequest, resp *DSolverResponse) error {
	if peer.client == nil {
		return fmt.Errorf("Peer %d is not connected", peer.index)
	}
	return peer.client.Call("Worker.Solve", req, resp)
}

func (peer *Peer) Cancel(req *CancelRequest, resp *CancelResponse) error {
	if peer.client == nil {
		return fmt.Errorf("Peer %d is not connected", peer.index)
	}
	return peer.client.Call("Worker.Cancel", req, resp)
}
