package dsolver

import (
	"flag"
	"fmt"
	"math/rand"
	"net/rpc"
	//"sort"
	"testing"
	"time"

	"github.com/golang/protobuf/proto"
	"solver"
)

var globalD *DSolver

var solverFlag = flag.String("solver", "../../ssolver/glucose-3.0/bin/solver", "Path to seq. solver for test")
var FatalIfNonNil = solver.FatalIfNonNil

const worker_addr int32 = 6282
const port int32 = 12345

func init() {
	rand.Seed(1234)
}

var reqid int64 = 0

func getRequestId() int64 {
	reqid = reqid + 1
	return reqid
}

func newSolverOrDie(t *testing.T) *DSolver {
	if globalD == nil {
		t.Log("Starting server on port", port)
		// Peer the DSolver with itself
		peer_addrs := []string{fmt.Sprintf("127.0.0.1:%d", worker_addr)}
		opts := DSolverOpts{
			Port: port,
		}
		var err error
		globalD, _, err = NewDSolver(peer_addrs, opts)
		FatalIfNonNil(err, "Start server:")
		time.Sleep(500 * time.Millisecond)
	}
	return globalD
}

// This test fails if NewDSolver does not block until it is connected
// to at least one valid peer.
func TestGetPeer(t *testing.T) {
	newSolverOrDie(t)
}

func Test(t *testing.T) {
	d := newSolverOrDie(t)
	Id := getRequestId()
	t.Log("Calling server at", d.Addr)
	client, err := rpc.DialHTTP("tcp", d.Addr.String())
	FatalIfNonNil(err, "dialing:")
	formula := &solver.Dimacs{
		N: proto.Int32(3),
		M: proto.Int32(3),
		Clauses: []int32{
			1, -2, -3, 0,
			-1, 2, -3, 0,
			-1, -2, 3, 0,
		},
	}
	request := &DSolverRequest{
		Request: &solver.SolverRequest{
			RequestId: &Id,
			Clauses:   formula,
			SolverOptions: &solver.SolverOptions{
				PropagationBudget:       proto.Uint64(100000),
				ZerothPropagationBudget: proto.Uint64(100000),
			},
		},
		T:         DSolverRequest_SPLIT.Enum(),
		K:         proto.Int32(2),
		N:         proto.Int32(2),
		RequestId: &DSolverRequestId{Id: proto.Int64(Id)},
	}
	response := &DSolverResponse{}
	fmt.Println("Invoking DSolver.Solve with\n\n", proto.MarshalTextString(request))
	err = client.Call("DSolver.Solve", request, response)
	fmt.Println("Invoking DSolver.Solve DONE\n\n")
	FatalIfNonNil(err, "dsolver err:")
	t.Log("Response:\n\n", proto.MarshalTextString(response))
	if len(response.SatTimes) != 1 {
		t.Errorf("Expected 1 SAT time, observed %v", response.SatTimes)
	}
	if len(response.UnsatTimes) != 0 {
		t.Errorf("Expected 0 UNSAT time, observed %v", response.UnsatTimes)
	}
	if len(response.UnknownTimes) != 0 {
		t.Errorf("Expected 0 UNKNOWN time, observed %v", response.UnknownTimes)
	}
}

func TestExtractFirstKBits(t *testing.T) {
	cases := []struct {
		num      uint
		k        uint
		expected uint
	}{
		{0, 0, 0},
		{0, 1, 0},
		{0, 12, 0},
		{1, 0, 0},
		{1, 1, 1},
		{1, 2, 1},
		{8, 3, 0},
		{8, 4, 8},
		{9, 3, 1},
		{42 /*101010*/, 2, 2},
		{42, 4, 10},
		{42, 6, 42},
		{42, 9, 42},
	}
	for _, c := range cases {
		ans := ExtractFirstKBits(c.num, c.k)
		if ans != c.expected {
			t.Errorf("Expected %u, actual %u", c.expected, ans)
		}
	}
}

//func TestSolve(t *testing.T) {
//	d := newSolverOrDie(t)
//
//	cases := []struct {
//		cnf      string              // DIMACS file
//		expected solver.SolverAnswer // Expected answer
//	}{
//		// Satisfiable instances
//		{"../../inputs/sat/simple_v3_c2.cnf", solver.SolverAnswer_SAT},
//		{"../../inputs/sat/aim-50-1_6-yes1-4.cnf", solver.SolverAnswer_SAT},
//		{"../../inputs/sat/par8-1-c.cnf", solver.SolverAnswer_SAT},
//		{"../../inputs/sat/quinn.cnf", solver.SolverAnswer_SAT},
//		{"../../inputs/sat/simple_v3000_c2.cnf", solver.SolverAnswer_SAT},
//		{"../../inputs/sat/zebra_v155_c1135.cnf", solver.SolverAnswer_SAT},
//
//		{"../../inputs/sat/f0010-01-s.cnf", solver.SolverAnswer_SAT},
//		{"../../inputs/sat/f0010-01-s.cnf", solver.SolverAnswer_SAT},
//		{"../../inputs/sat/f0010-02-s.cnf", solver.SolverAnswer_SAT},
//		{"../../inputs/sat/f0010-03-s.cnf", solver.SolverAnswer_SAT},
//		{"../../inputs/sat/f0010-04-s.cnf", solver.SolverAnswer_SAT},
//		{"../../inputs/sat/f0010-05-s.cnf", solver.SolverAnswer_SAT},
//		{"../../inputs/sat/f0010-06-s.cnf", solver.SolverAnswer_SAT},
//		{"../../inputs/sat/f0010-07-s.cnf", solver.SolverAnswer_SAT},
//		{"../../inputs/sat/f0010-08-s.cnf", solver.SolverAnswer_SAT},
//		{"../../inputs/sat/f0010-09-s.cnf", solver.SolverAnswer_SAT},
//		{"../../inputs/sat/f0010-10-s.cnf", solver.SolverAnswer_SAT},
//
//		{"../../inputs/sat/f0020-01-s.cnf", solver.SolverAnswer_SAT},
//		{"../../inputs/sat/f0020-01-s.cnf", solver.SolverAnswer_SAT},
//		{"../../inputs/sat/f0020-02-s.cnf", solver.SolverAnswer_SAT},
//		{"../../inputs/sat/f0020-03-s.cnf", solver.SolverAnswer_SAT},
//		{"../../inputs/sat/f0020-04-s.cnf", solver.SolverAnswer_SAT},
//		{"../../inputs/sat/f0020-05-s.cnf", solver.SolverAnswer_SAT},
//		{"../../inputs/sat/f0020-06-s.cnf", solver.SolverAnswer_SAT},
//		{"../../inputs/sat/f0020-07-s.cnf", solver.SolverAnswer_SAT},
//		{"../../inputs/sat/f0020-08-s.cnf", solver.SolverAnswer_SAT},
//		{"../../inputs/sat/f0020-09-s.cnf", solver.SolverAnswer_SAT},
//		{"../../inputs/sat/f0020-10-s.cnf", solver.SolverAnswer_SAT},
//
//		// Unsatisfiable instances
//		{"../../inputs/unsat/aim-100-1_6-no-1.cnf", solver.SolverAnswer_UNSAT},
//		{"../../inputs/unsat/bf0432-007.cnf", solver.SolverAnswer_UNSAT},
//		{"../../inputs/unsat/dubois20.cnf", solver.SolverAnswer_UNSAT},
//		{"../../inputs/unsat/dubois21.cnf", solver.SolverAnswer_UNSAT},
//		{"../../inputs/unsat/dubois22.cnf", solver.SolverAnswer_UNSAT},
//		{"../../inputs/unsat/hole6.cnf", solver.SolverAnswer_UNSAT},
//
//		{"../../inputs/unsat/f0010-01-u.cnf", solver.SolverAnswer_UNSAT},
//		{"../../inputs/unsat/f0010-01-u.cnf", solver.SolverAnswer_UNSAT},
//		{"../../inputs/unsat/f0010-02-u.cnf", solver.SolverAnswer_UNSAT},
//		{"../../inputs/unsat/f0010-03-u.cnf", solver.SolverAnswer_UNSAT},
//		{"../../inputs/unsat/f0010-04-u.cnf", solver.SolverAnswer_UNSAT},
//		{"../../inputs/unsat/f0010-05-u.cnf", solver.SolverAnswer_UNSAT},
//		{"../../inputs/unsat/f0010-06-u.cnf", solver.SolverAnswer_UNSAT},
//		{"../../inputs/unsat/f0010-07-u.cnf", solver.SolverAnswer_UNSAT},
//		{"../../inputs/unsat/f0010-08-u.cnf", solver.SolverAnswer_UNSAT},
//		{"../../inputs/unsat/f0010-09-u.cnf", solver.SolverAnswer_UNSAT},
//		{"../../inputs/unsat/f0010-10-u.cnf", solver.SolverAnswer_UNSAT},
//
//		{"../../inputs/unsat/f0020-01-u.cnf", solver.SolverAnswer_UNSAT},
//		{"../../inputs/unsat/f0020-01-u.cnf", solver.SolverAnswer_UNSAT},
//		{"../../inputs/unsat/f0020-02-u.cnf", solver.SolverAnswer_UNSAT},
//		{"../../inputs/unsat/f0020-03-u.cnf", solver.SolverAnswer_UNSAT},
//		{"../../inputs/unsat/f0020-04-u.cnf", solver.SolverAnswer_UNSAT},
//		{"../../inputs/unsat/f0020-05-u.cnf", solver.SolverAnswer_UNSAT},
//		{"../../inputs/unsat/f0020-06-u.cnf", solver.SolverAnswer_UNSAT},
//		{"../../inputs/unsat/f0020-07-u.cnf", solver.SolverAnswer_UNSAT},
//		{"../../inputs/unsat/f0020-08-u.cnf", solver.SolverAnswer_UNSAT},
//		{"../../inputs/unsat/f0020-09-u.cnf", solver.SolverAnswer_UNSAT},
//		{"../../inputs/unsat/f0020-10-u.cnf", solver.SolverAnswer_UNSAT},
//
//		// trivial examples
//		{"../../inputs/sat/empty.cnf", solver.SolverAnswer_SAT},
//		{"../../inputs/sat/oneclause.cnf", solver.SolverAnswer_SAT},
//	}
//
//	id := int64(1)
//	// Iterate over different values of k (number of dilemma variables)
//	for k := int32(1); k < 3; k++ {
//		for n := int32(k); n < 3; n++ {
//			// Iterate over number of propagations
//			for pround := uint64(1); pround < 4; pround++ {
//
//				// Iterate over each test case
//				for _, c := range cases {
//					typ := DSolverRequest_SPLIT.Enum()
//					request := &DSolverRequest{
//						Request: &solver.SolverRequest{
//							Clauses: &solver.Dimacs{
//								ClausesFile: proto.String(c.cnf),
//							},
//							SolverOptions: &solver.SolverOptions{
//								//				       DlMergeWeight: solver.DLMergeWeight_UNIT_WEIGHT.Enum(),
//								PropagationBudget:       proto.Uint64(100000 * pround),
//								ZerothPropagationBudget: proto.Uint64(100000),
//							},
//						},
//						T:         typ,
//						K:         proto.Int32(k),
//						N:         proto.Int32(n),
//						RequestId: &DSolverRequestId{Id: proto.Int64(id)},
//					}
//					response := &DSolverResponse{}
//
//					err := d.Solve(request, response)
//					if err != nil {
//						t.Log("Invoking DSolver.Solve with\n\n", proto.MarshalTextString(request))
//						t.Errorf("For %s, Solve gave error %s", c.cnf, err)
//						//t.Log("Response:\n\n", proto.MarshalTextString(response))
//					} else {
//						ans := response.Reply.GetAnswer()
//						if ans != c.expected {
//							t.Log("Invoking DSolver.Solve with\n\n", proto.MarshalTextString(request))
//							t.Errorf("For %s, output %s, expected %s.", c.cnf, ans.String(), c.expected.String())
//						}
//					}
//					id++
//				}
//			}
//		}
//	}
//
//}

// func TestUnsat(t *testing.T) {
// 	d := newSolverOrDie(t)
// 	request := &DSolverRequest{
// 		Request: &solver.SolverRequest{
// 			Clauses: &solver.Dimacs{
// 				N: proto.Int32(1),
// 				M: proto.Int32(2),
// 				Clauses: []int32{
// 					1, 0,
// 					-1, 0,
// 				},
// 			},
// 		},
// 	}
// 	response := &DSolverResponse{}
// 	t.Log("Invoking DSolver.Solve with\n\n", proto.MarshalTextString(request))
// 	err := d.Solve(request, response)
// 	FatalIfNonNil(err, "Solve:")
// 	t.Log("Response:\n\n", proto.MarshalTextString(response))
// 	if len(response.SatTimes) != 0 {
// 		t.Errorf("Expected 0 SAT time, observed %v", response.SatTimes)
// 	}
// 	if len(response.UnsatTimes) != 1 {
// 		t.Errorf("Expected 1 UNSAT time, observed %v", response.UnsatTimes)
// 	}
// 	if len(response.UnknownTimes) != 0 {
// 		t.Errorf("Expected 0 UNKNOWN time, observed %v", response.UnknownTimes)
// 	}
// }

// func TestCancel(t *testing.T) {
// 	d := newSolverOrDie(t)
// 	request := &DSolverRequest{
// 		Request: &solver.SolverRequest{
// 			Clauses: &solver.Dimacs{
// 				// h195-90.pb takes a long time (>10s) which is good enough for
// 				// cancellation.
// 				ClausesFile: proto.String("../../inputs/h195-90.cnf"),
// 			},
// 			SolverOptions: &solver.SolverOptions{
// 			//				       DlMergeWeight: solver.DLMergeWeight_UNIT_WEIGHT.Enum(),
// 			},
// 		},
// 		Id:      proto.Int64(1),
// 		SolveId: proto.Int32(1),
// 	}
// 	response := &DSolverResponse{}
// 	t.Log("Invoking DSolver.Solve with\n\n", proto.MarshalTextString(request))
// 	done := make(chan bool)
// 	go func() {
// 		_ = d.Solve(request, response)
// 		t.Log("Response:\n\n", proto.MarshalTextString(response))
// 		// Currently, when the sequential solver receives a cancel signal,
// 		// it replies with an UNKNOWN response.
// 		if len(response.SatTimes) != 0 {
// 			t.Errorf("Expected 0 SAT time, observed %v", response.SatTimes)
// 		}
// 		if len(response.UnsatTimes) != 0 {
// 			t.Errorf("Expected 0 UNSAT time, observed %v", response.UnsatTimes)
// 		}
// 		if len(response.UnknownTimes) != 1 {
// 			t.Errorf("Expected 1 UNKNOWN time, observed %v", response.UnknownTimes)
// 		}
// 		done <- true
// 	}()

// 	// Sleep for 1 second and then cancel the SOLVE request of h195-90
// 	time.Sleep(time.Second)
// 	creq := &CancelRequest{
// 		Id:      proto.Int64(1),
// 		SolveId: proto.Int32(1),
// 	}
// 	cresp := &CancelResponse{}
// 	err := d.Cancel(creq, cresp)
// 	FatalIfNonNil(err, "Cancel:")
// 	switch cresp.GetStatus() {
// 	case CancelResponse_CANCELLED:
// 		fmt.Println("CANCELLED woo hoo")
// 	default:
// 		t.Errorf("Expected CANCELLED, got %s", cresp)
// 	}
// 	// Make sure the SOLVE request actually finishes.
// 	_ = <-done
// 	fmt.Println("SOLVE request has finished")

// 	// Now send a CancelRequest with an invalid id.
// 	*creq.Id = 42
// 	*creq.SolveId = 42
// 	err = d.Cancel(creq, cresp)
// 	FatalIfNonNil(err, "Cancel:")
// 	switch cresp.GetStatus() {
// 	case CancelResponse_ABSENT:
// 		fmt.Println("ABSENT woo hoo")
// 	default:
// 		t.Errorf("Expected ABSENT, got %s", cresp)
// 	}
// }

// // TestPeerCancel tests that DSolver.CancelIthRequest cancels the "ith" request
// // generated by a SPLIT request.
// func TestPeerCancel(t *testing.T) {
// 	// Besides the goodness of 'const', it also avoids annoying when using K.
// 	const K = 1
// 	const N = 3
// 	// n==3 ==> 8 SOLVE requests sent out, or 2^N, or 1 << N

// 	request := &DSolverRequest{
// 		T: DSolverRequest_SPLIT.Enum(),
// 		Request: &solver.SolverRequest{
// 			Clauses: &solver.Dimacs{
// 				//N: proto.Int32(8),
// 				// h195-90.pb takes a long time (>10s) which is good enough for
// 				// cancellation.
// 				ClausesFile: proto.String("../../inputs/h195-90.cnf"),
// 			},
// 			SolverOptions: &solver.SolverOptions{
// 			//				       DlMergeWeight: solver.DLMergeWeight_UNIT_WEIGHT.Enum(),
// 			},
// 		},
// 		K:       proto.Int32(K),
// 		N:       proto.Int32(N),
// 		Id:      proto.Int64(1),
// 		SolveId: proto.Int32(1),
// 		Rounds:  proto.Int32(10),
// 	}
// 	t.Log("Invoking DSolver.Solve with\n\n", request)
// 	d := newSolverOrDie(t)
// 	time.Sleep(time.Second)
// 	done := make(chan bool)
// 	go func() {
// 		response := &DSolverResponse{}
// 		_ = d.Solve(request, response)
// 		t.Log("Response:\n\n", proto.MarshalTextString(response))
// 		// Currently, when the sequential solver receives a cancel signal,
// 		// it replies with an UNKNOWN response.
// 		if len(response.SatTimes) != 0 {
// 			t.Errorf("Expected 0 SAT time, observed %v", response.SatTimes)
// 		}
// 		if len(response.UnsatTimes) != 0 {
// 			t.Errorf("Expected 0 UNSAT time, observed %v", response.UnsatTimes)
// 		}
// 		if len(response.UnknownTimes) != 8 {
// 			t.Errorf("Expected 8 UNKNOWN time, observed %v", response.UnknownTimes)
// 		}
// 		done <- true
// 	}()

// 	// Sleep for 1 second and then cancel the SOLVE request of h195-90
// 	time.Sleep(time.Second)
// 	caRequest := &CancelAllRequest{
// 		Id: proto.Int64(1),
// 		N:  proto.Int32(N),
// 	}
// 	cResponse := &CancelResponse{}

// 	d.CancelAllRequests(caRequest, cResponse)

// 	// Make sure the SOLVE request actually finishes.
// 	_ = <-done
// }

// func TestEmitHistogram(t *testing.T) {
// 	kNum := 100
// 	latencies := make([]float64, kNum)
// 	for i := 0; i < kNum; i++ {
// 		latencies[i] = float64(i)
// 	}
// 	kBkts := 10
// 	EmitHistogram("TEST", latencies, kBkts)
// 	for i := 0; i < kNum; i++ {
// 		latencies[i] = 60.0
// 	}
// 	EmitHistogram("TEST OVERFLOW", latencies, kBkts)
// }

// func TestDSolverRequestDefaults(t *testing.T) {
// 	req := DSolverRequest{}
// 	if DSolverRequest_SOLVE != req.GetT() {
// 		t.Errorf("Expected default to be SOLVE, got %s", req.GetT())
// 	}
// }

// type int32Array []int32

// func (s int32Array) Len() int           { return len(s) }
// func (s int32Array) Swap(i, j int)      { s[i], s[j] = s[j], s[i] }
// func (s int32Array) Less(i, j int) bool { return s[i] < s[j] }

// // TestGetDLs
// func TestGetDLs(t *testing.T) {
// 	// func GetDLs(k int, m map[int32]int) []int32 {
// 	m := map[int32]int{
// 		int32(1): 1,
// 		int32(2): 2,
// 		int32(3): 3,
// 	}
// 	ans := GetDLs(3, m) // Test where 'k' is <= len(m)
// 	if len(ans) != 3 || ans[0] != 3 || ans[1] != 2 || ans[2] != 1 {
// 		t.Errorf("Wrong ans: %v", ans)
// 	}
// 	ans = GetDLs(8, m)         // Test where 'k' is > len(m)
// 	sort.Sort(int32Array(ans)) //This sort gets rid of the non-determinism in the test case.
// 	if len(ans) != 3 || ans[0] != 1 || ans[1] != 2 || ans[2] != 3 {
// 		t.Errorf("Wrong ans: %v", ans)
// 	}
// }

// func TestDLHistory(t *testing.T) {
// 	responses := []DSolverResponse{
// 		DSolverResponse{
// 			Reply: &solver.SolverReply{
// 				Answer:       solver.SolverAnswer_UNKNOWN.Enum(),
// 				DecisionLits: []int32{1, 2, 5, 10, 15, 20, 25, 30, 35, 40},
// 				Learnts: &solver.Dimacs{
// 					Clauses: []int32{10, 20, 0, 2, 0, 30, 35, 40, 0},
// 				},
// 			},
// 		},
// 		DSolverResponse{
// 			Reply: &solver.SolverReply{
// 				Answer:       solver.SolverAnswer_UNKNOWN.Enum(),
// 				DecisionLits: []int32{1, 2, 10, 20, 30, 40},
// 				Learnts:      nil,
// 			},
// 		},
// 		DSolverResponse{
// 			Reply: &solver.SolverReply{
// 				Answer:       solver.SolverAnswer_UNKNOWN.Enum(),
// 				DecisionLits: []int32{1, 2, 20, 40},
// 				Learnts:      nil,
// 			},
// 		},
// 	}
// 	h := DLHistory{}
// 	h.StartRound(solver.DLMergeWeight_UNIT_WEIGHT)
// 	for i, _ := range responses {
// 		h.RecordResponse(responses[i].Reply.DecisionLits, responses[i].Reply.Learnts)
// 	}
// 	h.StopRound()
// 	checker := func(expected []int, observed []int32) {
// 		observedAsInts := []int{}
// 		for _, dl := range observed {
// 			observedAsInts = append(observedAsInts, int(dl))
// 		}
// 		sort.IntSlice(observedAsInts).Sort()
// 		sort.IntSlice(expected).Sort()
// 		if len(expected) != len(observed) {
// 			t.Errorf("Observed and expected results have different length")
// 			return
// 		}
// 		for i, observed := range observedAsInts {
// 			if expected[i] != observed {
// 				t.Errorf("Expected %d, observed %d at position %d", expected[i], observed, i)
// 			}
// 		}
// 	}
// 	// Want 3 decision lits for next round. Expect 1, 20, 40
// 	checker([]int{1, 20, 40}, h.Get(3))
// 	// Now ask for 7000 decision lits, should get back
// 	// responses[0].Reply.DecisionLits
// 	checker([]int{1, 5, 10, 15, 20, 25, 30, 35, 40}, h.Get(7000))
// }

// func TestGenIndices(t *testing.T) {
// 	vars := []int32{1, 2, 3}
// 	index := 1
// 	is_pos := true
// 	res := GenIndices(vars, index, is_pos)
// 	fmt.Println("is_pos=", is_pos, ", indices=", res)
// 	if len(res) != (1 << uint(len(vars)-1)) {
// 		t.Errorf("Wrong: %v", res)
// 	}
// 	is_pos = false
// 	res = GenIndices(vars, index, is_pos)
// 	fmt.Println("is_pos=", is_pos, ", indices=", res)
// 	if len(res) != (1 << uint(len(vars)-1)) {
// 		t.Errorf("Wrong: %v", res)
// 	}
// }

// func TestGenAssignments(t *testing.T) {
// 	cases := []struct {
// 		fixed   int
// 		indices []int
// 		out     string
// 	}{
// 		// 1?? should be 100, 101, 110, 111 or {4, 5, 6, 7}
// 		{4, []int{1, 0}, "[4 5 6 7]"},
// 		// ?1? should be 010, 011, 110, 111 or {2, 3, 6, 7}
// 		{2, []int{2, 0}, "[2 3 6 7]"},
// 		// 10? should be 100, 101 or {4, 5}
// 		{4, []int{0}, "[4 5]"},
// 	}
// 	for _, c := range cases {
// 		as := GenAssignments(c.fixed, c.indices)
// 		sort.Ints(as)
// 		if c.out != fmt.Sprintf("%v", as) {
// 			t.Errorf("Expected %s, observed %v", c.out, as)
// 		}
// 	}
// }

// func TestComputeFixedAndIndices(t *testing.T) {
// 	dVars := []int32{1, -3, 8}
// 	cases := []struct {
// 		unsat_cores []int32
// 		fixed       int
// 		indices     []int
// 	}{
// 		{[]int32{1}, // NOTE: no trailing 0.
// 			1, // 0 0 1
// 			[]int{1, 2},
// 		},
// 		{[]int32{1, 3},
// 			1, // 0 0 1
// 			[]int{2},
// 		},
// 		{[]int32{3, -8},
// 			0, // 0 0 0
// 			[]int{0},
// 		},
// 	}
// 	for _, c := range cases {
// 		fixed, indices := ComputeFixedAndIndices(dVars, c.unsat_cores)
// 		if c.fixed != fixed {
// 			t.Errorf("Expected fixed %d, observed %d", c.fixed, fixed)
// 		}
// 		if fmt.Sprintf("%v", c.indices) != fmt.Sprintf("%v", indices) {
// 			t.Errorf("Expected indices %v, observed %v", c.indices, indices)
// 		}
// 	}
// }

// func TestGenCancellableAssignments(t *testing.T) {
// 	cases := []struct {
// 		dVars  []int32
// 		clause []int32
// 		out    string
// 	}{
// 		{[]int32{1, -3, 8}, []int32{-1}, "[1 3 5 7]"},
// 		{[]int32{1, -3, 8}, []int32{-1, -3}, "[1 5]"},
// 		{[]int32{1, -3, 8}, []int32{-3, 8}, "[0 1]"},
// 		{[]int32{1, -3, 8}, []int32{1, -3, 8}, "[0]"},
// 		{[]int32{-3}, []int32{-3}, "[0]"},
// 		{[]int32{-3, -10, 8}, []int32{-3}, "[0 2 4 6]"},
// 		{[]int32{-3, -10, 8}, []int32{-3, -10, 8}, "[0]"},
// 		{[]int32{-3, -10, 8}, []int32{3, 10, -8}, "[7]"},
// 	}
// 	for _, c := range cases {
// 		as := GenCancellableAssignments(c.dVars, c.clause)
// 		sort.Ints(as)
// 		if c.out != fmt.Sprintf("%v", as) {
// 			t.Errorf("Expected %s, observed %v", c.out, as)
// 		}
// 	}

// }
// func TestGenIthAssumption(t *testing.T) {
// 	cases := []struct {
// 		dVars []int32 // The sequence of dilemma variables
// 		i     int     // The assumption to generate
// 		out   []int32 // The expected output literals
// 	}{
// 		{[]int32{1, 2, 3}, 0, []int32{-1, -2, -3}},
// 		{[]int32{1, 2, 3}, 7, []int32{1, 2, 3}},
// 		{[]int32{1, 2, 3}, 8, []int32{-1, -2, -3}},
// 		{[]int32{1, 2, 3}, 15, []int32{1, 2, 3}},
// 		{[]int32{-3}, 0, []int32{3}},
// 		{[]int32{-3}, 1, []int32{-3}},
// 	}
// 	for _, c := range cases {
// 		as := GenIthAssumption(c.dVars, c.i)
// 		if fmt.Sprintf("%v", c.out) != fmt.Sprintf("%v", as) {
// 			t.Errorf("Expected %v, observed %v", c.out, as)
// 		}
// 	}
// }

func TestSingleSolve(t *testing.T) {
	d := newSolverOrDie(t)
	Id := getRequestId()

	//cnf := "../inputs/sat/f0010-01-s.cnf"
	cnf := "../9pipe_k.cnf"
	//cnf := "../inputs/sat/zebra_v155_c1135.cnf"
	expected := solver.SolverAnswer_UNSAT
	k := int32(2)
	n := int32(2)
	typ := DSolverRequest_SPLIT.Enum()

	request := &DSolverRequest{
		Request: &solver.SolverRequest{
			RequestId: &Id,
			Clauses: &solver.Dimacs{
				ClausesFile: proto.String(cnf),
			},
			SolverOptions: &solver.SolverOptions{
				//                       DlMergeWeight: solver.DLMergeWeight_UNIT_WEIGHT.Enum(),
				PropagationBudget:       proto.Uint64(20000000),
				ZerothPropagationBudget: proto.Uint64(2),
			},
		},
		T:         typ,
		K:         proto.Int32(k),
		N:         proto.Int32(n),
		RequestId: &DSolverRequestId{Id: proto.Int64(Id)},
	}
	response := &DSolverResponse{}
	t.Log("Invoking DSolver.Solve with\n\n", proto.MarshalTextString(request))
	err := d.Solve(request, response)
	FatalIfNonNil(err, "Solve:")
	//t.Log("Response:\n\n", proto.MarshalTextString(response))
	ans := response.Reply.GetAnswer()
	if ans != expected {
		t.Errorf("For %s, output %s, expected %s.", cnf, ans.String(), expected.String())
	}
}

func TestCancel(t *testing.T) {
	d := newSolverOrDie(t)
	Id := getRequestId()

	//cnf := "../inputs/sat/f0010-01-s.cnf"
	cnf := "../9pipe_k.cnf"
	//cnf := "../inputs/sat/zebra_v155_c1135.cnf"
	expected := solver.SolverAnswer_UNKNOWN
	k := int32(2)
	n := int32(2)
	typ := DSolverRequest_SPLIT.Enum()
	reqId := &DSolverRequestId{Id: proto.Int64(Id)}

	request := &DSolverRequest{
		Request: &solver.SolverRequest{
			RequestId: &Id,
			Clauses: &solver.Dimacs{
				ClausesFile: proto.String(cnf),
			},
			SolverOptions: &solver.SolverOptions{
				//                       DlMergeWeight: solver.DLMergeWeight_UNIT_WEIGHT.Enum(),
				PropagationBudget:       proto.Uint64(20000000),
				ZerothPropagationBudget: proto.Uint64(2),
			},
		},
		T:         typ,
		K:         proto.Int32(k),
		N:         proto.Int32(n),
		RequestId: reqId,
	}
	response := &DSolverResponse{}
	t.Log("Invoking DSolver.Solve with\n\n", proto.MarshalTextString(request))
	done := make(chan bool, 1)
	go func() {
		err := d.Solve(request, response)
		FatalIfNonNil(err, "Solve:")
		t.Log("Response:\n\n", proto.MarshalTextString(response))
		ans := response.Reply.GetAnswer()
		if ans != expected {
			t.Errorf("For %s, output %s, expected %s.", cnf, ans.String(), expected.String())
		}
		done <- true
	}()
	time.Sleep(2 * time.Second)
	d.CancelRequest(reqId)
	// Make sure the SOLVE request actually finishes.
	_ = <-done
}

// func TestSingleAssumptionSolve(t *testing.T) {
// 	d := newSolverOrDie(t)

// 	cnf := "../../inputs/sat/f0010-01-s.cnf"
// 	expected := solver.SolverAnswer_SAT
// 	k := int32(3)
// 	typ := DSolverRequest_SOLVE.Enum()

// 	dls := []int32{-3, -10, 8}
// 	as := GenIthAssumption(dls, 5)

// 	request := &DSolverRequest{
// 		Request: &solver.SolverRequest{
// 			Clauses: &solver.Dimacs{
// 				ClausesFile: proto.String(cnf),
// 			},
// 			SolverOptions: &solver.SolverOptions{
// 				DlMergeWeight:           solver.DLMergeWeight_UNIT_WEIGHT.Enum(),
// 				PropagationBudget:       proto.Uint64(300000),
// 				ZerothPropagationBudget: proto.Uint64(2),
// 			},
// 			Assumptions: as,
// 		},
// 		T:       typ,
// 		K:       proto.Int32(k),
// 		N:       proto.Int32(k),
// 		Id:      proto.Int64(1),
// 		SolveId: proto.Int32(1),
// 	}
// 	response := &DSolverResponse{}
// 	t.Log("Invoking DSolver.Solve with\n\n", proto.MarshalTextString(request))
// 	rand.Seed(1234)
// 	err := d.Solve(request, response)
// 	FatalIfNonNil(err, "Solve:")

// 	ans := response.Reply.GetAnswer()
// 	if ans != expected {
// 		t.Errorf("For %s, output %s, expected %s.", cnf, ans.String(), expected.String())
// 	}

// }

//func TestSingleDilemmaSolve(t *testing.T) {
//	d := newSolverOrDie(t)
//	rand.Seed(1234)
//	for i := 0; i < 1; i++ {
//		cnf := "../../inputs/sat/f0010-01-s.cnf"
//		expected := solver.SolverAnswer_SAT
//		k := int32(3)
//		typ := DSolverRequest_SPLIT.Enum()
//
//		dls := []int32{-3, -10, 8}
//
//		request := &DSolverRequest{
//			Request: &solver.SolverRequest{
//				Clauses: &solver.Dimacs{
//					ClausesFile: proto.String(cnf),
//				},
//				SolverOptions: &solver.SolverOptions{
//					DlMergeWeight:           solver.DLMergeWeight_UNIT_WEIGHT.Enum(),
//					PropagationBudget:       proto.Uint64(20),
//					ZerothPropagationBudget: proto.Uint64(2),
//					KeepSolverState:         proto.Bool(false),
//					ClearLearnts:            proto.Bool(true),
//				},
//				//Assumptions: as,
//			},
//			T:         typ,
//			K:         proto.Int32(k),
//			N:         proto.Int32(k),
//			RequestId: &DSolverRequestId{Id: 42},
//		}
//		response := &DSolverResponse{}
//		h := DLHistory{}
//		ClManager_small_limit := 2
//		ClManager_imp_limit := 100
//		ClManager_subsump_limit := 2
//		cm := solver.NewClauseManager(int(ClManager_small_limit), int(ClManager_imp_limit), float64(ClManager_subsump_limit))
//		t.Log("Invoking DSolver.Solve with\n\n", proto.MarshalTextString(request))
//
//		err := d.DilemmaSolve(request, response, dls, &h, cm)
//		FatalIfNonNil(err, "Solve:")
//		//t.Log("Response:\n\n", proto.MarshalTextString(response))
//		ans := response.Reply.GetAnswer()
//		if ans != expected {
//			t.Errorf("For %s, output %s, expected %s.", cnf, ans.String(), expected.String())
//		}
//	}
//
//}

// func TestKeepRunning(t *testing.T) {
// 	d := newSolverOrDie(t)

// 	cnf := "../../inputs/sat/f0010-01-s.cnf"
// 	expected := solver.SolverAnswer_SAT
// 	k := int32(3)
// 	typ := DSolverRequest_SOLVE.Enum()

// 	//dls := []int32{-3, -10, 8}
// 	//as := GenIthAssumption(dls, 5)
// 	as := []int32{-3, 10}

// 	request := &DSolverRequest{
// 		Request: &solver.SolverRequest{
// 			Clauses: &solver.Dimacs{
// 				ClausesFile: proto.String(cnf),
// 			},
// 			SolverOptions: &solver.SolverOptions{
// 				DlMergeWeight:           solver.DLMergeWeight_UNIT_WEIGHT.Enum(),
// 				PropagationBudget:       proto.Uint64(10),
// 				ZerothPropagationBudget: proto.Uint64(2),
// 			},
// 			Assumptions: as,
// 		},
// 		T:       typ,
// 		K:       proto.Int32(k),
// 		N:       proto.Int32(k),
// 		Id:      proto.Int64(1),
// 		SolveId: proto.Int32(1),
// 	}
// 	response := &DSolverResponse{}
// 	t.Log("Invoking DSolver.Solve with\n\n", proto.MarshalTextString(request))
// 	rand.Seed(1234)
// 	err := d.Solve(request, response)
// 	FatalIfNonNil(err, "Solve:")

// 	// let the solver run without assumptions for 1 second,
// 	// it should find SAT during this time
// 	time.Sleep(time.Second)

// 	// sending a second request, trivially UNSAT
// 	as = []int32{-3, 3}
// 	request = &DSolverRequest{
// 		Request: &solver.SolverRequest{
// 			Clauses: &solver.Dimacs{
// 				ClausesFile: proto.String(cnf),
// 			},
// 			SolverOptions: &solver.SolverOptions{
// 				DlMergeWeight:           solver.DLMergeWeight_UNIT_WEIGHT.Enum(),
// 				PropagationBudget:       proto.Uint64(200),
// 				ZerothPropagationBudget: proto.Uint64(2),
// 			},
// 			Assumptions: as,
// 		},
// 		T:       typ,
// 		K:       proto.Int32(k),
// 		N:       proto.Int32(k),
// 		Id:      proto.Int64(1),
// 		SolveId: proto.Int32(2),
// 	}
// 	response = &DSolverResponse{}
// 	err = d.Solve(request, response)
// 	FatalIfNonNil(err, "Solve:")

// 	ans := response.Reply.GetAnswer()
// 	// should have returned SAT, even though the last request is UNSAT
// 	if ans != expected {
// 		t.Errorf("For %s, output %s, expected %s.", cnf, ans.String(), expected.String())
// 	}
// }

// func TestCleanReturn(t *testing.T) {
// 	d := newSolverOrDie(t)
// 	d.SolverCommand.Process.Kill()
// }
