package dsolver

import (
	//"flag"
	"fmt"
	//"github.com/golang/protobuf/proto"
	//"solver"
	"testing"
	//"time"
)

var globalWM *WorkerManager

//func newWorkerOrDie(t *testing.T) *Worker {
//	if globalW == nil {
//		var err error
//		globalW, err = worker.NewWorker(*solverFlag, nil, worker_port)
//		solver.FatalIfNonNil(err, "Start Worker:")
//		time.Sleep(500 * time.Millisecond)
//	}
//	return globalW
//}

func newWorkerManagerOrDie(t *testing.T) *WorkerManager {
	if globalWM == nil {
		spawn := new(chan bool)
		globalWM, _ = NewWorkerManager(*spawn)
	}
	return globalWM
}

func TestConnectWorkers(t *testing.T) {
	wm := newWorkerManagerOrDie(t)
	fmt.Println(wm)
}
