package dsolver

import (
	"bufio"
	"log"
	"os"
	"solver"
	"strconv"
)

type VariableGraph struct {
	edges map[int32]map[int32]int
}

func NewVariableGraph() *VariableGraph {
	return &VariableGraph{
		edges: make(map[int32]map[int32]int),
	}
}

func (vg *VariableGraph) InsertClause(c []int32) {
	for i := 0; i < len(c); i++ {
		for j := i + 1; j < len(c); j++ {
			if _, ok := vg.edges[c[i]]; !ok {
				vg.edges[c[i]] = make(map[int32]int)
			}
			if _, ok := vg.edges[c[j]]; !ok {
				vg.edges[c[j]] = make(map[int32]int)
			}
			vg.edges[c[i]][c[j]] = vg.edges[c[i]][c[j]] + 1
			vg.edges[c[j]][c[i]] = vg.edges[c[j]][c[i]] + 1
		}
	}
}

func (vg *VariableGraph) NewRound() {
	//for v1, _ := range vg.edges {
	//	for v2, _ := range vg.edges[v1] {
	//		vg.edges[v1][v2] = vg.edges[v1][v2] / 10
	//	}
	//}
}

func (vg *VariableGraph) BuildFromDimacs(f *solver.Dimacs) {

	cl := make([]int32, 0)
	if f.ClausesFile != nil {
		log.Println("Building variable graph from file ", *f.ClausesFile)
		// TODO case where it's a file
		file, err := os.Open(*f.ClausesFile)
		if err != nil {
			log.Println("ERROR:", err)
			return
		}
		split := func(data []byte, atEOF bool) (advance int, token []byte, err error) {
			advance, token, err = bufio.ScanWords(data, atEOF)
			//if err == nil && token != nil {
			//	_, err = strconv.ParseInt(string(token), 10, 32)
			//}
			return
		}
		scanner := bufio.NewScanner(file)
		scanner.Split(split)
		n_var := 0
		n_clause := 0
		ready := 0
		for scanner.Scan() {
			line := scanner.Text()
			if ready == 0 && line == "cnf" {
				ready++
			}
			i, err := strconv.Atoi(line)
			if err == nil {
				if ready == 1 {
					n_var = i
					ready++
				} else if ready == 2 {
					n_clause = i
					ready++
				} else {
					if i == 0 {
						vg.InsertClause(cl)
						cl = make([]int32, 0)
						n_clause--
					} else {
						if i < 0 {
							i = -i
						}
						if i > n_var {
							log.Fatalf("Unexpected variable id")
						}
						cl = append(cl, int32(i))
					}
				}
			}
		}
		if n_clause != 0 {
			log.Fatalf("Did not read the expected amount of clauses")
		}
	}

	cl = make([]int32, 0)
	for _, lit := range f.Clauses {
		if lit == 0 {
			vg.InsertClause(cl)
			cl = make([]int32, 0)
		} else {
			if lit < 0 {
				lit = -lit
			}
			cl = append(cl, lit)
		}
	}
}

func (vg *VariableGraph) AreNeighbors(v1 int32, v2 int32) bool {
	if m, ok := vg.edges[v1]; ok {
		return m[v2] > 0
	}
	return false
}

func (vg *VariableGraph) NeigborsCoeff(v1 int32, v2 int32) int {
	if m, ok := vg.edges[v1]; ok {
		return m[v2]
	}
	return 0
}

func (vg *VariableGraph) BoostNeighborsOnDlh(v int32, Dlh *DLHistory) {
	vg.BoostNeighbors(v, &Dlh.m)
}

func (vg *VariableGraph) BoostNeighbors(v int32, m *map[int32]int) {
	if v < 0 {
		v = -v
	}
	for v2, n := range vg.edges[v] {
		//log.Println("Boosting neigbors", n)
		(*m)[v2] = (*m)[v2] + 2*n
	}
}
