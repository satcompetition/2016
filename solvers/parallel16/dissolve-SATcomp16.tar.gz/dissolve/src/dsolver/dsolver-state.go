package dsolver

import (
	"log"
	"math"
	"solver"
	"strconv"
	"sync"
)

// statistics related to finished rounds
type RoundStatistics struct {
	// TODO
	//
	// statistics gathered at the start of the round:
	//

	// list of selected DLs and corresponding scores
	DL_values []int32
	DL_scores []int32

	//
	// statistics gathered in the end of the round:
	//

	UnsatTimes   []float64
	SatTimes     []float64
	UnknownTimes []float64

	// number of learnt clauses
	nb_learnts []int32
}

func (rs *RoundStatistics) total_learnts() int32 {
	sum := int32(0)
	for _, value := range rs.nb_learnts {
		sum += value
	}
	return sum
}

func (rs *RoundStatistics) avg_learnts() float32 {
	return float32(rs.total_learnts()) / float32(len(rs.nb_learnts))
}

func (rs *RoundStatistics) var_learnts() float32 {
	avg := rs.avg_learnts()
	sum := float32(0.)
	for _, value := range rs.nb_learnts {
		sum += float32(math.Pow(float64(float32(value)-avg), 2))
	}
	return sum / float32(len(rs.nb_learnts))
}

func (rs *RoundStatistics) total_time() float64 {
	sum := 0.
	for _, value := range rs.UnsatTimes {
		sum += value
	}
	for _, value := range rs.SatTimes {
		sum += value
	}
	for _, value := range rs.UnknownTimes {
		sum += value
	}
	return sum
}

func (rs *RoundStatistics) avg_time() float64 {
	return rs.total_time() / float64(len(rs.UnsatTimes)+len(rs.SatTimes)+len(rs.UnknownTimes))
}

func (rs *RoundStatistics) var_time() float64 {
	avg := rs.avg_time()
	sum := 0.
	for _, value := range rs.UnsatTimes {
		sum += math.Pow(value-avg, 2)
	}
	for _, value := range rs.SatTimes {
		sum += math.Pow(value-avg, 2)
	}
	for _, value := range rs.UnknownTimes {
		sum += math.Pow(value-avg, 2)
	}
	return sum / float64(len(rs.UnsatTimes)+len(rs.SatTimes)+len(rs.UnknownTimes))
}

type DSolverStatistics struct {
	UnsatTimes   []float64
	SatTimes     []float64
	UnknownTimes []float64

	RoundStats []*RoundStatistics
}

func (s *DSolverStatistics) getStats() string {
	res := ""
	for round, stats := range s.RoundStats {
		res = res + "##########################\n"
		res = res + "Stats Round " + strconv.Itoa(round) + "\n"
		res = res + "##########################\n"
		res = res + "total_time = " + strconv.FormatFloat(stats.total_time(), 'f', 2, 32) + "\n"
		res = res + "avg_time = " + strconv.FormatFloat(stats.avg_time(), 'f', 2, 32) + "\n"
		res = res + "var_time = " + strconv.FormatFloat(stats.var_time(), 'f', 2, 32) + "\n"
		res = res + "total_learnts = " + strconv.Itoa(int(stats.total_learnts())) + "\n"
		res = res + "avg_learnts = " + strconv.FormatFloat(float64(stats.avg_learnts()), 'f', 2, 32) + "\n"
		res = res + "var_learnts = " + strconv.FormatFloat(float64(stats.var_learnts()), 'f', 2, 32) + "\n"

		DLs := ""
		for i, v := range stats.DL_values {
			DLs = DLs + " (" + strconv.Itoa(int(v)) + "," + strconv.Itoa(int(stats.DL_scores[i])) + ")"
		}
		res = res + "Round DLs:" + DLs + "\n"
	}
	return res
}

func (s *DSolverStatistics) printStats() {
	log.Println("RUN STATISTICS")
	log.Println(s.getStats())
}

type DSolverState struct {
	// TODO
	Request *solver.SolverRequest

	K int32
	N int32

	DLheuristic int32

	// If true, then the request associated with this dsolver state is active.
	// If false, the request has been cancelled.
	Inactive_signal chan bool

	recordLearnts bool
	CmMu          sync.Mutex
	Cm            *solver.ClauseManager

	Dlh   *DLHistory
	DlhMu sync.Mutex

	VG *VariableGraph

	Ans   solver.SolverAnswer
	AnsMu sync.Mutex

	ModelMu sync.Mutex
	Model   []int32

	PolaritiesMu sync.Mutex
	Polarities   map[int32]int32

	// Round-related variables
	initConflictBudget      uint64
	initPropagationBudget   uint64
	initLearntsBudget       uint64
	zerothPropagationBudget uint64

	inner_prop uint64
	outer_prop uint64
	inner_conf uint64
	outer_conf uint64

	init_seq_timeout  uint64
	inner_seq_timeout uint64
	outer_seq_timeout uint64

	round_timeout uint64

	// we use only one mutex to guard all the statistics-related fields
	StatsMu                 sync.RWMutex
	MinConflictClauseLength *int32
	stats                   DSolverStatistics
}

func NewDSolverState(
	Request *solver.SolverRequest,
	K int32,
	N int32,
	DLheuristic int32,
	seq_timeout int64,
	round_timeout int64,
	ClManager_small_limit int,
	ClManager_imp_limit int,
	ClManager_subsump_limit float64,
	ClManager_simp_level int32,
	ms solver.DLMergeWeight,
) *DSolverState {
	ss := &DSolverState{
		Request:           Request,
		K:                 K,
		N:                 N,
		DLheuristic:       DLheuristic,
		init_seq_timeout:  uint64(seq_timeout),
		inner_seq_timeout: uint64(seq_timeout),
		outer_seq_timeout: uint64(seq_timeout),
		round_timeout:     uint64(round_timeout),
		Inactive_signal:   make(chan bool, 100),
		Cm:                solver.NewClauseManager(ClManager_small_limit, ClManager_imp_limit, ClManager_subsump_limit, ClManager_simp_level),
		Dlh:               NewDLHistory(ms),
		VG:                NewVariableGraph(),
		Ans:               solver.SolverAnswer_UNKNOWN,
	}
	ss.Polarities = make(map[int32]int32)

	ss.recordLearnts = Request.SolverOptions.GetReturnLearnts()

	ss.initConflictBudget = Request.SolverOptions.GetConflictBudget()
	ss.initPropagationBudget = Request.SolverOptions.GetPropagationBudget()
	ss.initLearntsBudget = Request.SolverOptions.GetMaxLearntsOut()
	ss.zerothPropagationBudget = Request.SolverOptions.GetZerothPropagationBudget()

	// Implementing restart strategy from PicoSAT
	ss.inner_prop = uint64(ss.initPropagationBudget)
	ss.outer_prop = uint64(ss.initPropagationBudget)

	ss.inner_conf = uint64(ss.initConflictBudget)
	ss.outer_conf = uint64(ss.initConflictBudget)

	return ss
}

func (ss *DSolverState) createDSolverResponse(out *DSolverResponse) error {
	out.Reply.Answer = &ss.Ans
	out.Reply.Model = ss.Model
	out.UnsatTimes = ss.stats.UnsatTimes
	out.UnknownTimes = ss.stats.UnknownTimes
	out.SatTimes = ss.stats.SatTimes
	out.MinConflictClauseLength = ss.MinConflictClauseLength
	stats := ss.stats.getStats()
	out.Logtext = &stats
	return nil
}

func (ss *DSolverState) GetDLs(k int, round int) []int32 {
	ss.DlhMu.Lock()
	dVars, dScores := ss.Dlh.Get(k, ss.VG, ss.DLheuristic)
	ss.DlhMu.Unlock()
	ss.StatsMu.Lock()
	for len(ss.stats.RoundStats) <= round {
		s := &RoundStatistics{}
		ss.stats.RoundStats = append(ss.stats.RoundStats, s)
	}
	ss.stats.RoundStats[round].DL_values = dVars
	ss.stats.RoundStats[round].DL_scores = dScores
	ss.StatsMu.Unlock()
	return dVars
}

func (ss *DSolverState) RecordPolarity(k int32, p solver.Polarity) {
	if _, ok := ss.Polarities[k]; !ok {
		ss.Polarities[k] = 0
	}
	switch p {
	case solver.Polarity_UNCOMPUTED:
	case solver.Polarity_POS:
		ss.Polarities[k] += 1
	case solver.Polarity_NEG:
		ss.Polarities[k] -= 1
	}
}

func (ss *DSolverState) RecordPolarities(keys []int32, values []solver.Polarity) {
	ss.PolaritiesMu.Lock()
	for i, value := range values {
		key := keys[i]
		ss.RecordPolarity(key, value)
	}
	ss.PolaritiesMu.Unlock()
}

func (ss *DSolverState) GetPolaritiesMap() ([]int32, []solver.Polarity) {
	ss.PolaritiesMu.Lock()
	keys := make([]int32, len(ss.Polarities))
	values := make([]solver.Polarity, len(ss.Polarities))
	i := 0
	for key, p := range ss.Polarities {
		keys[i] = key
		if p > 0 {
			values[i] = solver.Polarity_POS
		} else if p < 0 {
			values[i] = solver.Polarity_NEG
		} else {
			values[i] = solver.Polarity_UNCOMPUTED
		}
		// reset the polarity
		// TODO: is that the best way to do?
		ss.Polarities[key] = 0
		i++
	}
	ss.PolaritiesMu.Unlock()
	return keys, values
}
