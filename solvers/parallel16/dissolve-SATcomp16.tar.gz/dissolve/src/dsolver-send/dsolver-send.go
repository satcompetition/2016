// dsolver-send is a simple utility to send a SolverRequest to a DSolver and
// output the SolverResponse.
package main

import (
	"encoding/json"
	"flag"
	"fmt"
	"io/ioutil"
	"math/rand"
	"net/rpc"
	"os"
	"os/signal"
	"path"
	"regexp"
	"syscall"
	"time"

	"github.com/golang/protobuf/proto"

	"dsolver"
	"solver"
)

var (
	printAllParametersFlag = flag.String("print_params", "", "Print all the parameters in a json format, in the file given as argument, then return")
	sequentialFlag         = flag.Bool("sequential", false, "Use this argument if you want to run the sequential solver")
	addrFlag               = flag.String("addr", "127.0.0.1:28000",
		"Network address of the DSolver to send the request to.")
	seqAddrFlag = flag.String("seq_addr", "127.0.0.1:27999",
		"Network address of the DSolver to send the request to.")

	timeLimitFlag = flag.Uint64("time_limit", 10, "Deadline in seconds.")
	randSeedFlag  = flag.Int64("rand_seed", 1,
		"Random seed to initialize go rand")
	kFlag                = flag.Int("k", 2, "Simulate dilemma split on 'k' variables")
	nFlag                = flag.Int("n", 0, "Each round will consist of 2^n branches. The value of 'n' actually used is max(k,n) specified.")
	dhFlag               = flag.Int("dh", 1, "Heuristic for the decision literal")
	learntsFlag          = flag.Uint64("learnts", 50000, "The initial number of learned clauses maintained per round")
	maxlengthClausesFlag = flag.Uint64("maxlength_clauses", 30, "The maximal length of the clauses")
	conflictsFlag        = flag.Uint64("conflicts", 0, "The initial conflict budget (the default value takes about 10 secs.), value 0 means +infinity")
	propagationsFlag     = flag.Uint64("propagations", 20000000, "The initial propagation budget (the default value takes about 10 secs.), value 0 means +infinity")
	learntsBudgetFlag    = flag.Uint64("learnts_budget", 0, "The initial learnt clauses budget, value 0 means +infinity")
	roundsFlag           = flag.Int("rounds", -1, "Maximum number of rounds before giving up, a negative value means +infinity")

	decLitsOutFlag = flag.Uint64("dec_lits_out", 10, "The number of decision literals the solver should try and return in the SolverRequest. ")
	//TODO(adi) Is there a better way of stating enums as flags?
	restartStrategyFlag    = flag.Int("restart_strategy", 0, "The strategy used to decide how long each round of dilemma split should run: picosat=0,luby=1, fixed=2. Look at solver.proto for more information.")
	zerothPropagationsFlag = flag.Uint64("zeroth_propagations", 20000, "The propagation budget in round zero.")

	dlMergeWeightFlag              = flag.Int("dl_merge_weight", 0, " When merging the sequence of decision literals returned by each of the solvers, what weight should be given to each literal. rank=0, unit=1, rand=2. Look at solver.proto for more information.")
	ClauseSmallLimitFlag           = flag.Int("cl_small_limit", 2, "Clauses of size less or equal to this parameter will be considered small")
	ClauseImpLimitFlag             = flag.Int("cl_imp_limit", 100, "Number of clauses that will be considered important")
	ClauseSubsumptionTimeLimitFlag = flag.Float64("clsubsumption_time_limit", 2.0, "Maximal time for which we simplify clauses using subsumption criteria")
	ClauseSimplificationLimitFlag  = flag.Int("ubtree_simp_level", 1, "level of simplification of the UBTrees")

	ClauseGoodLBDLimitFlag  = flag.Int("good_lbd_limit", 2, "maximal LBD of selected clauses")
	ClauseGoodSizeLimitFlag = flag.Int("good_size_limit", 2, "maximal size of selected clauses")

	ClearLearntsFlag         = flag.Bool("clear_learnts", true, "clear the set of learnt clauses in the sequential solvers before each round")
	KeepSolverStateFlag      = flag.Bool("keep_solver_state", true, "maintain the state of the sequential solvers between rounds")
	OnlineSimplificationFlag = flag.Bool("online_simplification", false, "run formula simplification before each round")
	ReturnPolaritiesFlag     = flag.Bool("use_polarities", true, "exchange polarities, not only clauses")
	ReturnLearntsFlag        = flag.Bool("use_learnts", true, "exchange learnt clauses")
	KeepRunningFlag          = flag.Bool("keep_running", true, "let the solver run without assumptions after returning results")
	TimeoutFlag              = flag.Int("timeout_request", 0, "If 0, no timeout. Otherwise, cancel each request after this number of seconds")
	RoundTimeoutFlag         = flag.Int("round_timeout_request", 0, "If 0, no timeout. Otherwise, cancel each round after this number of seconds, from the start of the round")

	// Glucose-specific parameters
	glucoseKFlag                      = flag.Float64("glucose_K", 0.8, "todo")
	glucoseRFlag                      = flag.Float64("glucose_R", 1.4, "todo")
	glucoseSizeLbdQueueFlag           = flag.Uint64("glucose_SizeLbdQueue", 50, "todo")
	glucoseSizeTrailQueueFlag         = flag.Uint("glucose_SizeTrailQueue", 5000, "todo")
	glucoseFirstReduceDbFlag          = flag.Uint("glucose_FirstReduceDb", 2000, "todo")
	glucoseIncReduceDbFlag            = flag.Uint("glucose_IncReduceDb", 300, "todo")
	glucoseSpecIncReduceDbFlag        = flag.Uint("glucose_SpecIncReduceDb", 1000, "todo")
	glucoseLbLbdFrozenClauseFlag      = flag.Uint("glucose_LbLbdFrozenClause", 30, "todo")
	glucoseLbSizeMinimizingClauseFlag = flag.Uint("glucose_LbSizeMinimizingClause", 30, "todo")
	glucoseLbLbdMinimizingClauseFlag  = flag.Uint("glucose_LbLbdMinimizingClause", 30, "todo")
	glucoseVarDecayFlag               = flag.Float64("glucose_VarDecay", 0.8, "todo")
	glucoseClauseDecayFlag            = flag.Float64("glucose_ClauseDecay", 0.999, "todo")
	glucoseRandomVarFreqFlag          = flag.Float64("glucose_RandomVarFreq", 0, "todo")
	glucoseCcminModeFlag              = flag.Uint("glucose_CcminMode", 2, "todo")
	glucosePhaseSavingFlag            = flag.Uint("glucose_PhaseSaving", 2, "todo")
	glucoseRndInitActFlag             = flag.Bool("glucose_RndInitAct", true, "todo")
	glucoseGarbageFracFlag            = flag.Float64("glucose_GarbageFrac", 0.2, "todo")
)

func GetSolverOptionsFromFlags() *solver.SolverOptions {

	// First, parse the Glucose-specific parameters
	glucose_so := &solver.GlucoseOptions{
		K: proto.Float64(*glucoseKFlag),
		R: proto.Float64(*glucoseRFlag),
		// in the following, we have to cast uint into uint32, because proto requires a Uint32, and
		// the flag package has no flag.Uint32 implemented... we used flag.Uint instead
		SizeLbdQueue:           proto.Uint32(uint32(*glucoseSizeLbdQueueFlag)),
		SizeTrailQueue:         proto.Uint32(uint32(*glucoseSizeTrailQueueFlag)),
		FirstReduceDb:          proto.Uint32(uint32(*glucoseFirstReduceDbFlag)),
		IncReduceDb:            proto.Uint32(uint32(*glucoseIncReduceDbFlag)),
		SpecIncReduceDb:        proto.Uint32(uint32(*glucoseSpecIncReduceDbFlag)),
		LbLbdFrozenClause:      proto.Uint32(uint32(*glucoseLbLbdFrozenClauseFlag)),
		LbSizeMinimizingClause: proto.Uint32(uint32(*glucoseLbSizeMinimizingClauseFlag)),
		LbLbdMinimizingClause:  proto.Uint32(uint32(*glucoseLbLbdMinimizingClauseFlag)),
		VarDecay:               proto.Float64(*glucoseVarDecayFlag),
		ClauseDecay:            proto.Float64(*glucoseClauseDecayFlag),
		RandomVarFreq:          proto.Float64(*glucoseRandomVarFreqFlag),
		CcminMode:              proto.Uint32(uint32(*glucoseCcminModeFlag)),
		PhaseSaving:            proto.Uint32(uint32(*glucosePhaseSavingFlag)),
		RndInitAct:             proto.Bool(*glucoseRndInitActFlag),
		GarbageFrac:            proto.Float64(*glucoseGarbageFracFlag),
	}

	so := &solver.SolverOptions{
		ConflictBudget:          proto.Uint64(*conflictsFlag),
		PropagationBudget:       proto.Uint64(*propagationsFlag),
		LearntClausesBudget:     proto.Uint64(*learntsBudgetFlag),
		MaxLearntsOut:           proto.Uint64(*learntsFlag),
		MaxLengthClauses:        proto.Uint64(*maxlengthClausesFlag),
		NumDecisionLits:         proto.Uint64(*decLitsOutFlag),
		RestartStrategy:         solver.RestartStrategy(*restartStrategyFlag).Enum(),
		ZerothPropagationBudget: proto.Uint64(*zerothPropagationsFlag),
		DlMergeWeight:           solver.DLMergeWeight(*dlMergeWeightFlag).Enum(),
		KeepSolverState:         proto.Bool(*KeepSolverStateFlag),
		ClearLearnts:            proto.Bool(*ClearLearntsFlag),
		OnlineSimplification:    proto.Bool(*OnlineSimplificationFlag),
		ReturnPolarities:        proto.Bool(*ReturnPolaritiesFlag),
		ReturnLearnts:           proto.Bool(*ReturnLearntsFlag),
		KeepRunning:             proto.Bool(*KeepRunningFlag),
		GoodSizeLimit:           proto.Uint32(uint32(*ClauseGoodSizeLimitFlag)),
		GoodLbdLimit:            proto.Uint32(uint32(*ClauseGoodLBDLimitFlag)),
		GlucoseOptions:          glucose_so,
	}

	fmt.Println("c Conflict budget: ", *so.ConflictBudget)
	fmt.Println("c Propagation buget: ", *so.PropagationBudget)
	fmt.Println("c Learnts buget: ", *so.LearntClausesBudget)
	fmt.Println("c Max learnts: ", *so.MaxLearntsOut)
	fmt.Println("c Max length clauses: ", *so.MaxLengthClauses)
	fmt.Println("c Num decision lits: ", *so.NumDecisionLits)
	fmt.Println("c Restart strategy: ", so.RestartStrategy.String())
	fmt.Println("c Zeroth propagation budget: ", *so.ZerothPropagationBudget)
	fmt.Println("c DL merge weight: ", so.DlMergeWeight.String())
	fmt.Println("c Max LBD of selected clauses: ", *so.GoodLbdLimit)
	fmt.Println("c Max size of selected clauses: ", *so.GoodSizeLimit)
	fmt.Println("c keep solver state: ", *so.KeepSolverState)
	fmt.Println("c clear learnts: ", *so.ClearLearnts)
	fmt.Println("c online simplification: ", *so.OnlineSimplification)
	fmt.Println("c keep running without assumptions: ", *so.KeepRunning)
	fmt.Println("c return learnts: ", *so.ReturnLearnts)
	fmt.Println("c return polarities: ", *so.ReturnPolarities)

	return so
}

func send_trivial_request(RequestId *dsolver.DSolverRequestId, client *rpc.Client) {
	request := &dsolver.DSolverRequest{
		Request: &solver.SolverRequest{
			RequestId: RequestId.Id,
			Clauses: &solver.Dimacs{
				N:       proto.Int32(1),
				M:       proto.Int32(0),
				Clauses: []int32{},
			},
			SolverOptions: GetSolverOptionsFromFlags(),
		},
		T:         dsolver.DSolverRequest_SPLIT.Enum(),
		K:         proto.Int32(int32(*kFlag)),
		N:         proto.Int32(int32(*nFlag)),
		Rounds:    proto.Int32(int32(10)),
		RequestId: RequestId,
	}
	response := &dsolver.DSolverResponse{}
	fmt.Println("c Calling a trivial request to make sure the dsolver returns in a good state")
	client.Call("DSolver.Solve", request, response)
}

func split_cancel(RequestId *dsolver.DSolverRequestId, client *rpc.Client) {
	response := &dsolver.CancelResponse{}
	fmt.Println("c Calling DSolver.CancelAllRequests")
	err := client.Call("DSolver.CancelAllRequests", RequestId, response)
	solver.FatalIfNonNil(err, "dsolver err when calling DSolver.CancelAllRequests:")
	//send_trivial_request(RequestId, client)
	return
}

func split_solve(RequestId *dsolver.DSolverRequestId, client *rpc.Client, input string, sopts *solver.SolverOptions, done chan int) {
	sReq := &solver.SolverRequest{
		RequestId: RequestId.Id,
		Clauses: &solver.Dimacs{
			ClausesFile: proto.String(input),
		},
	}

	// Update SolverRequest from flags
	sReq.TimeLimit = timeLimitFlag
	fmt.Println("c Time limit:", *timeLimitFlag)
	sReq.SolverOptions = sopts

	// TODO there should be a better way
	DHF := dsolver.DSolverRequest_STANDARD
	switch *dhFlag {
	case 1:
		DHF = dsolver.DSolverRequest_STANDARD
	case 2:
		DHF = dsolver.DSolverRequest_VARIABLEGRAPH
	}

	request := &dsolver.DSolverRequest{
		Request: sReq,
		//T:       dsolver.DSolverRequest_SOLVE.Enum(),
		T:                             dsolver.DSolverRequest_SPLIT.Enum(),
		K:                             proto.Int32(int32(*kFlag)),
		N:                             proto.Int32(int32(*nFlag)),
		Dh:                            DHF.Enum(),
		Timeout:                       proto.Int64(int64(*TimeoutFlag)),
		RoundTimeout:                  proto.Int64(int64(*RoundTimeoutFlag)),
		Rounds:                        proto.Int32(int32(*roundsFlag)),
		ClausemanagerSmallLimit:       proto.Int32(int32(*ClauseSmallLimitFlag)),
		ClausemanagerImpLimit:         proto.Int32(int32(*ClauseImpLimitFlag)),
		ClausemanagerSubsumptionLimit: proto.Float64(*ClauseSubsumptionTimeLimitFlag),
		UBTreeSimplificationLevel:     proto.Int32(int32(*ClauseSimplificationLimitFlag)),
		RequestId:                     RequestId,
	}

	if *printAllParametersFlag != "" {
		fmt.Println("c Parameters:")
		b, _ := json.Marshal(request)
		s := string(b)
		ioutil.WriteFile(*printAllParametersFlag, []byte(s), 0644)
		done <- 0
		return
	}

	//if *idFlag > 0 {
	//	fmt.Println("c Request Id:", *idFlag)
	//	request.Id = proto.Int64(*idFlag)
	//}
	response := &dsolver.DSolverResponse{}
	fmt.Println("c Calling DSolver.Solve")
	start := time.Now()
	err := client.Call("DSolver.Solve", request, response)
	elapsed := time.Since(start).Seconds()
	solver.FatalIfNonNil(err, "c dsolver err when calling DSolver.Solve in split_solve:")
	// Julien: we should not output a .pb every time while we don't need it
	// TODO: make it a parameter of dsolver-send?
	if false {
		f, err := os.Create(fmt.Sprintf("%s-response-k%d-rounds%d.pb", path.Base(input), *kFlag, *roundsFlag))
		solver.FatalIfNonNil(err, "Create file: ")
		solver.MarshalToFileOrDie(response, f)
		f.Close()
	}
	fmt.Println("c Total CPU time of seq. solvers:", response.GetTotal_CPUTime())
	fmt.Println("c Result:", response.Reply.GetAnswer(), "in", elapsed)
	// This is the standard format for outputting the answer
	fmt.Println("c Elapsed:", elapsed)
	re := regexp.MustCompile("\n")
	fmt.Println("c ", re.ReplaceAllString(response.GetLogtext(), "\nc "))
	switch response.Reply.GetAnswer() {
	case solver.SolverAnswer_SAT:
		fmt.Println("s SATISFIABLE")
		// print the model
		// TODO: make it optional
		fmt.Print("v ")
		for _, m := range response.Reply.Model {
			fmt.Print(m, " ")
		}
		fmt.Print("0\n")
		done <- 10
	case solver.SolverAnswer_UNSAT:
		fmt.Println("s UNSATISFIABLE")
		done <- 20
	default:
		fmt.Println("s UNKNOWN")
		done <- 0
	}
}

func sequential_solve(RequestId *dsolver.DSolverRequestId, client *rpc.Client, done chan int) {
	input := flag.Arg(0)
	sReq := &solver.SolverRequest{
		RequestId: RequestId.Id,
		Clauses: &solver.Dimacs{
			ClausesFile: proto.String(input),
		},
	}

	request := &dsolver.DSolverRequest{
		Request: sReq,
		T:       dsolver.DSolverRequest_SOLVE.Enum(),
	}
	response := &dsolver.DSolverResponse{}
	fmt.Println("c Calling DSolver.Solve")
	start := time.Now()
	err := client.Call("DSolver.Solve", request, response)
	elapsed := time.Since(start).Seconds()
	solver.FatalIfNonNil(err, "dsolver err when calling DSolver.Solve in sequential solve:")
	if false {
		f, err := os.Create("response_seq.pb")
		solver.FatalIfNonNil(err, "Create file: ")
		solver.MarshalToFileOrDie(response, f)
		f.Close()
	}
	fmt.Println("c Elapsed:", elapsed)
	if response.Reply.Answer != nil {
		fmt.Println("c Result:", response.Reply.GetAnswer(), "in", elapsed)
		if response.Reply.GetAnswer() == solver.SolverAnswer_SAT {
			fmt.Println("s SATISFIABLE")
			done <- 10
		} else {
			fmt.Println("s UNSATISFIABLE")
			done <- 20
		}
	} else {
		fmt.Println("c Result: UNKNOWN in", elapsed)
		fmt.Println("s UNKNOWN") // This is the standard format for outputting the answer
		done <- 0
	}

}

func main() {
	flag.Parse()

	// The value of n actually used is the max(k,n) provided.
	if *nFlag < *kFlag {
		*nFlag = *kFlag
	}

	rand.Seed(*randSeedFlag)
	sopts := GetSolverOptionsFromFlags()

	input := flag.Arg(0)

	// we want to catch Ctrl-C and kill signals so that we can cleanly cancel
	// the requests before quitting
	signalChan := make(chan os.Signal, 1)
	signal.Notify(signalChan, syscall.SIGINT, syscall.SIGTERM, syscall.SIGKILL)

	// We are creating separate channels for seq and split merely because
	// we want to know whether the sequential solve found the answer or
	// whether the split solve found the answer.
	done_seq := make(chan int, 1)
	done_split := make(chan int, 1)

	fmt.Println("c Connection to DSolver at", *addrFlag)
	client, err := rpc.DialHTTP("tcp", *addrFlag)
	solver.FatalIfNonNil(err, "dialing:")
	defer client.Close()

	// first, we have to ask for a RequestId
	RequestId := &dsolver.DSolverRequestId{}
	err = client.Call("DSolver.GetDSolverRequestId", RequestId, RequestId)

	// If the number of branches is 2^0 (=1) then just use sequential solve.
	if *sequentialFlag || *nFlag == 0 {
		go sequential_solve(RequestId, client, done_seq)
	}
	if *nFlag > 0 {
		go split_solve(RequestId, client, input, sopts, done_split)
	}
	select {
	case code := <-done_split:
		fmt.Println("c Split found the answer")
		os.Exit(code)
	case code := <-done_seq:
		fmt.Println("c Sequential found the answer")
		os.Exit(code)
	case <-time.After(time.Second * time.Duration(int64(*timeLimitFlag))):
		fmt.Printf("c Solver timed out (timeout %v seconds)\n", *timeLimitFlag)
		fmt.Println("s UNKNOWN") // This is the standard format for outputting the answer
		// Cancel all requests
		split_cancel(RequestId, client)
		os.Exit(0)
	case <-signalChan:
		fmt.Println("c \nReceived an interrupt, cancel all requests...\n")
		fmt.Println("s UNKNOWN") // This is the standard format for outputting the answer
		// Cancel all requests
		split_cancel(RequestId, client)
		os.Exit(0)
	}
}
