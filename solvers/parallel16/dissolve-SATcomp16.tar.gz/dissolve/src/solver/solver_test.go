package solver

import (
	"os/exec"
	"testing"
	"time"

	"github.com/golang/protobuf/proto"
)

func TestEqProto(t *testing.T) {
	if !EqProto(&SolverRequest{}, &SolverRequest{}) {
		t.Error("Proto equality failed")
	}
	req := &SolverRequest{
		Clauses: &Dimacs{
			N: proto.Int32(3),
			M: proto.Int32(3),
			Clauses: []int32{
				1, 0, 2, 0, 3, 0,
			},
		},
	}
	if !EqProto(req, req) {
		t.Error("Proto equality failed for", req)
	}
	r2 := &SolverRequest{}
	CopyProto(req, r2)
	if !EqProto(req, r2) {
		t.Error("Proto equality failed for copy", req)
	}
	r2.Assumptions = []int32{2}
	if EqProto(req, r2) {
		t.Error("Proto equality succeeded for different protos\n\t", req, "\n\t", r2)
	}
}

func TestCancellableRun(t *testing.T) {
	echo := exec.Command("echo", "foobar")
	quit := make(chan bool)
	// err should be nil b/c 'echo' runs to completion
	if err := CancellableRun(quit, echo); err != nil {
		t.Error("echo fail:", err)
	}
	status, err := echo.Process.Wait()
	t.Log("echo status:", status, ", err:", err)

	sleep := exec.Command("sleep", "10m")
	start := time.Now()
	// Should kill the process before the 10m sleep ends.
	go func() { quit <- true }()
	// err should NOT be nil b/c 'sleep' is killed.
	if err = CancellableRun(quit, sleep); err == nil {
		t.Error("sleep fail")
	}
	elapsed := time.Since(start)
	status, err = sleep.Process.Wait()
	t.Log("sleep status:", status, ", err:", err)
	t.Log("sleep cancelled in", elapsed.Seconds(), " s")
	if elapsed > 60*time.Second {
		t.Error("Cancellation failed")
	}
}
