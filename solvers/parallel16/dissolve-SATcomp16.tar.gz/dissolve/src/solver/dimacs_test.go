package solver

import "testing"

import "github.com/golang/protobuf/proto"

var dimacs_simplevel = int32(2)

var input = &Dimacs{
	N: proto.Int32(9),
	M: proto.Int32(9),
	Clauses: []int32{
		1, 0, 2, 0, 3, 0, 4, 0, 5, 0, 6, 0, 7, 0, 8, 0, 9, 0,
	},
}

func TestEq(t *testing.T) {
	if !input.Eq(input) {
		t.Error("Eq not reflexive")
	}
	if input.Eq(nil) || (*Dimacs)(nil).Eq(input) {
		t.Error("nil Eq fail")
	}
	input2 := &Dimacs{
		N: proto.Int32(9),
		M: proto.Int32(9),
		Clauses: []int32{
			1, 0, 2, 0, 3, 0, 4, 0, 5, 0, 6, 0, 7, 0, 8, 0, 9, 0,
		},
	}
	if !input.Eq(input2) {
		t.Error("input =/= input2")
	}
	canonicalUnsat := &Dimacs{N: proto.Int32(1), M: proto.Int32(1), Clauses: []int32{0}}
	if input.Eq(canonicalUnsat) || canonicalUnsat.Eq(input) {
		t.Error("input == canonical unsat")
	}
}

func TestGetClause(t *testing.T) {
	expected := [][]int32{
		{1, 0},
		{2, 0},
		{3, 0},
		{4, 0},
		{5, 0},
		{6, 0},
		{7, 0},
		{8, 0},
		{9, 0},
	}
	for i := 0; i < int(input.GetM()); i++ {
		c := input.GetClause(i)
		e := expected[i]
		// Observed clause length == expected clause length.
		if len(c) != len(e) {
			t.Errorf("Invalid length for clause %d.\n\tExpected: %v\n\tObserved: %v", i, e, c)
			break
		}
		// Clauses have the same values
		for j, _ := range e {
			if e[j] != c[j] {
				t.Errorf("Wrong literal in clause %d, index %d.\n\tExpected: %v\n\tObserved: %v", i, j, e, c)
			}
		}
	}
}

func TestEachClause(t *testing.T) {
	expected := [][]int32{
		{1, 0},
		{2, 0},
		{3, 0},
		{4, 0},
		{5, 0},
		{6, 0},
		{7, 0},
		{8, 0},
		{9, 0},
	}
	input.EachClause(func(clauseIndex int, c []int32) {
		e := expected[clauseIndex]
		// Observed clause length == expected clause length.
		if len(c) != len(e) {
			t.Errorf("Invalid length for clause %d.\n\tExpected: %v\n\tObserved: %v", clauseIndex, e, c)
			return
		}
		// Clauses have the same values
		for j, _ := range e {
			if e[j] != c[j] {
				t.Errorf("Wrong literal in clause %d, index %d.\n\tExpected: %v\n\tObserved: %v", clauseIndex, j, e, c)
			}
		}
	})
}

func TestRangePartition(t *testing.T) {
	d := &Dimacs{
		N: proto.Int32(5),
		M: proto.Int32(7),
		Clauses: []int32{
			1, 2, 3, 0,
			2, 3, 4, 0,
			3, 4, 5, 0,
			-1, -2, -3, 0,
			-2, -3, -4, 0,
			-3, -4, -5, 0,
			1, 3, 5, 0,
		},
	}
	t.Logf("Input: %s\n\n", proto.CompactTextString(d))
	parts := d.RangePartition(4)
	for i, p := range parts {
		t.Logf("Part %d = %s\n", i, proto.CompactTextString(p))
	}

}

func TestModPartition(t *testing.T) {
	k := 4
	parts := input.ModPartition(k)
	for _, part := range parts {
		if input.GetN() != part.GetN() {
			t.Errorf("Wrong number of variables: expected %d but observed %d", input.GetN(), part.GetN())
		}
	}
	for i, literal := range input.Clauses {
		// Ignore 0-based separator
		if (i % 2) == 1 {
			continue
		}
		// Ex. if i == 0 then want input indices 0, 8, 16
		// Ex. if i == 1 then want input indices 2, 10
		// Ex. if i == 2 then want input indices 4, 12
		// Ex. if i == 4 then want input indices 6, 14
		partIndex := (i / 2) % k
		clauseIndex := (i / 2) / k
		part := parts[partIndex]
		partLiteral := part.Clauses[clauseIndex*2]
		if literal != partLiteral {
			t.Errorf("i=%d, partIndex=%d, clauseIndex=%d\n", i, partIndex, clauseIndex)
			t.Errorf("Wrong literal: expected %d but observed %d at clause %d of part %d: %s",
				literal, partLiteral, clauseIndex, partIndex, proto.CompactTextString(part))
		}
	}
}

func TestDilemmaPartition(t *testing.T) {
	v := int32(1)
	fs := input.DilemmaPartition(v)
	if len(fs) != 2 {
		t.Errorf("Expected 2 generated formulas, observed %d", len(fs))
		return
	}
	fp, fn := fs[0], fs[1]
	if !(input.GetM()+1 == fp.GetM() && fp.GetM() == fn.GetM()) {
		t.Errorf("Unexpected M values where (input, fp, fn) = (%d, %d, %d)", input.GetM(), fp.GetM(), fn.GetM())
		return
	}
	if !(input.GetN() == fp.GetN() && fp.GetN() == fn.GetN()) {
		t.Errorf("Unexpected N values where (input, fp, fn) = (%d, %d, %d)", input.GetN(), fp.GetN(), fn.GetN())
		return
	}
	fpExpect := fp.Clauses[len(input.Clauses)]
	if fpExpect != v {
		t.Errorf("Expected %d, observed %d", v, fpExpect)
		return
	}
	fnExpect := fn.Clauses[len(input.Clauses)]
	if fnExpect != -v {
		t.Errorf("Expected %d, observed %d", -v, fnExpect)
		return
	}
}

func TestDilemmaPartitionMultiVar(t *testing.T) {
	t.Log(proto.MarshalTextString(input))
	v1, v2 := int32(1), int32(2)
	fs := input.DilemmaPartition(v1, v2)
	type K struct{ v1, v2 int32 }
	parts := map[K]bool{
		K{1, 2}:   true,
		K{1, -2}:  true,
		K{-1, 2}:  true,
		K{-1, -2}: true,
	}
	for i, f := range fs {
		if !(input.GetN() == f.GetN() && input.GetM() == f.GetM()-2) {
			t.Errorf("Wrong N or M values.\n==== input\n%s\n=== f\n%s",
				proto.MarshalTextString(input), proto.MarshalTextString(f))
		}
		// The last two clauses should be in parts.
		t.Log(i, ")", f)
		c1 := f.GetClause(int(f.GetM() - 2))
		c2 := f.GetClause(int(f.GetM() - 1))
		if len(c1) != 2 || len(c2) != 2 {
			t.Errorf("Final clauses have wrong length")
		}
		k := K{c1[0], c2[0]}
		if _, ok := parts[k]; !ok {
			t.Errorf("Unexpected clause")
		}
		delete(parts, k)
	}
}

func TestDilemmaImplicate(t *testing.T) {
	// Test the example given in dimacs.go
	impls := DilemmaImplicate(-1, 13, []int32{2, 3, 0, -5, 6, 0})
	expected := []int32{1, 13, 0, -13, 2, 3, 0, -13, -5, 6, 0}
	if len(expected) != len(impls) {
		t.Errorf("Wrong length:\nExpected: %v\nObserved: %v", expected, impls)
		return
	}
	for i, _ := range expected {
		if expected[i] != impls[i] {
			t.Errorf("Expected %s, observed %s", expected, impls)
			return
		}
	}
}

func TestAppend(t *testing.T) {
	f := &Dimacs{
		N:       proto.Int32(3),
		M:       proto.Int32(1),
		Clauses: []int32{1, 0},
	}
	g1 := &Dimacs{
		N:       proto.Int32(3),
		M:       proto.Int32(1),
		Clauses: []int32{2, 0},
	}
	g2 := &Dimacs{
		N:       proto.Int32(3),
		M:       proto.Int32(1),
		Clauses: []int32{3, 0},
	}
	f.Append(g1, g2)
	if f.GetM() != 3 {
		t.Error("Expected 3 clauses, observed", f.GetM())
	}
	for i, expected := range []int32{1, 0, 2, 0, 3, 0} {
		if f.Clauses[i] != expected {
			t.Errorf("Clauses[%d] not as expected: %d vs %d", i, expected, f.Clauses[i])
			break
		}
	}
}

func TestIsCanonicalUnsat(t *testing.T) {
	unsat := &Dimacs{
		M:       proto.Int32(1),
		Clauses: []int32{0},
	}
	if !unsat.IsCanonicalUnsat() {
		t.Error("Should be canonical unsat: ", proto.CompactTextString(unsat))
	}
	if input.IsCanonicalUnsat() {
		t.Error("Should not be canonical unsat: ", proto.CompactTextString(input))
	}
}

func TestIsSane(t *testing.T) {
	if err := input.IsSane(); err != nil {
		t.Error(err)
	}
	f := &Dimacs{
		N:       proto.Int32(3),
		M:       proto.Int32(1),
		Clauses: []int32{1, 0},
	}
	if err := f.IsSane(); err != nil {
		t.Error(err)
	}
	// Now make sure an invalid value of M is reported as an error
	*f.M = 13
	if err := f.IsSane(); err == nil {
		t.Error(err)
	}
}

func TestClone(t *testing.T) {
	g := input.Clone()
	if !g.Eq(input) {
		t.Error("g != input", "\n", proto.MarshalTextString(g), "\n", proto.MarshalTextString(input))
	}
}

func TestSimplify(t *testing.T) {
	f := &Dimacs{
		N:       proto.Int32(4),
		M:       proto.Int32(2),
		Clauses: []int32{1, 2, 3, 0, 1, 3, 2, 0},
	}

	expected := &Dimacs{
		N:       proto.Int32(4),
		M:       proto.Int32(1),
		Clauses: []int32{1, 2, 3, 0},
	}

	t.Log("Input ", proto.CompactTextString(f))
	simp := f.Simplify(dimacs_simplevel)
	t.Log("Simplified ", proto.CompactTextString(simp))
	if !expected.Eq(simp) {
		t.Error("Simplification incorrect")
	}

	f = &Dimacs{
		N:       proto.Int32(4),
		M:       proto.Int32(2),
		Clauses: []int32{1, 2, 3, 4, 0, 3, 2, 0},
	}

	expected = &Dimacs{
		N:       proto.Int32(4),
		M:       proto.Int32(1),
		Clauses: []int32{2, 3, 0},
	}

	t.Log("Input ", proto.CompactTextString(f))
	simp = f.Simplify(dimacs_simplevel)
	t.Log("Simplified ", proto.CompactTextString(simp))
	if !expected.Eq(simp) {
		t.Error("Simplification incorrect")
	}

	f = &Dimacs{
		N:       proto.Int32(4),
		M:       proto.Int32(4),
		Clauses: []int32{3, 2, 4, 1, 0, 3, 2, 0, -2, 0, -2, 3, 6, 0},
	}

	expected = &Dimacs{
		N:       proto.Int32(4),
		M:       proto.Int32(2),
		Clauses: []int32{2, 3, 0, -2, 0},
	}

	t.Log("Input ", proto.CompactTextString(f))
	simp = f.Simplify(dimacs_simplevel)
	t.Log("Simplified ", proto.CompactTextString(simp))
	if !expected.Eq(simp) {
		t.Errorf("Expected %s, observed %s", proto.CompactTextString(expected), proto.CompactTextString(simp))
	}

	f = &Dimacs{
		N:       proto.Int32(5),
		M:       proto.Int32(2),
		Clauses: []int32{1, 2, 0, 1, 3, 4, 5, 2, 0},
	}

	expected = &Dimacs{
		N:       proto.Int32(5),
		M:       proto.Int32(1),
		Clauses: []int32{1, 2, 0},
	}

	t.Log("Input ", proto.CompactTextString(f))
	simp = f.BoundedSimplify(1, dimacs_simplevel)
	t.Log("Simplified ", proto.CompactTextString(simp))
	if !expected.Eq(simp) {
		t.Error("Bounded Simplification incorrect")
	}

}
