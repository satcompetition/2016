package solver

// Defines helper methods for solver.Dimacs defined in solver.proto
import (
	"fmt"
	"log"
	"time"

	"github.com/golang/protobuf/proto"
)

// Eq returns true of 'f' and 'g' have equal contents.
func (f *Dimacs) Eq(g *Dimacs) bool {
	if f == g {
		return true
	}
	if f == nil || g == nil {
		return false
	}
	if f.GetN() != g.GetN() || f.GetM() != g.GetM() || len(f.Clauses) != len(g.Clauses) {
		return false
	}
	for i := 0; i < len(f.Clauses); i++ {
		c := f.GetClause(i)
		if !g.ContainsClause(c) {
			return false
		}
	}
	return true
}

// compares two clauses and return true if they are equal
// ex: 1 2 -3 0 and 2 -3 1 0 are considered equal
//     1 2 -3 0 and 1 2 0 are considered disequal
func Clauses_equal(clause1 []int32, clause2 []int32) bool {
	if len(clause1) != len(clause2) {
		return false
	}
	for _, Lit := range clause1 {
		found := false
		for _, Lit2 := range clause2 {
			if Lit2 == Lit {
				found = true
				break
			}
		}
		if !found {
			return false
		}
	}
	return true
}

// returns true if the clause is included in f
func (f *Dimacs) ContainsClause(clause []int32) bool {
	i := 0
	for ; i < len(f.Clauses); i++ {
		c := f.GetClause(i)
		if Clauses_equal(c, clause) {
			return true
		}
	}
	return false
}

func (f *Dimacs) GetClause(index int) []int32 {
	if index < 0 {
		panic(fmt.Errorf("Negative index (%d) to Dimacs.GetClause", index))
	}
	if f.GetM() <= int32(index) {
		return nil
	}
	// Clause at index 'index' begins after the index'th clause separator (which is 0).
	i, zeros := 0, 0
	for ; i < len(f.Clauses) && zeros < index; i++ {
		if f.Clauses[i] == 0 {
			zeros++
		}
	}
	if zeros != index {
		log.Printf("Clause %d does not exist, f has just %d clauses", index, f.GetM())
		return nil
	}
	res := []int32{}
	for ; i < len(f.Clauses) && f.Clauses[i] != 0; i++ {
		res = append(res, f.Clauses[i])
	}
	return append(res, 0)
}

func (f *Dimacs) EachClause(fn func(clauseIndex int, clause []int32)) {
	clauseStart := 0
	clauseIndex := 0
	for i, l := range f.Clauses {
		if l == 0 {
			fn(clauseIndex, f.Clauses[clauseStart:i+1])
			clauseStart = i + 1
			clauseIndex++
		}
	}
}

func (f *Dimacs) Simplify(simplification_level int32) *Dimacs {
	start := time.Now()
	n := NewNode()

	// Insert smaller clauses first.
	clauseStart := 0
	for i, l := range f.Clauses {

		// TODO(adi): Ideally we would like to insert in ascending order of length.
		if l == 0 {
			if len(f.Clauses[clauseStart:i]) <= 3 {
				// Don't include the trailing zero.
				InsertAndTruncate(f.Clauses[clauseStart:i], n, simplification_level)
			}
			clauseStart = i + 1
		}
	}

	// Insert the rest
	clauseStart = 0
	subset_bound := 3
	for i, l := range f.Clauses {
		// Insert smaller clauses first.
		// TODO(adi): Ideally we would like to insert in ascending order of length.
		if l == 0 {
			if len(f.Clauses[clauseStart:i]) > 3 {
				// If we run out of time then just insert
				if time.Since(start).Seconds() < 2.0 {
					// Don't include the trailing zero.
					n.InsertIfNotBoundedSubsumed(f.Clauses[clauseStart:i], subset_bound, simplification_level)
				} else {
					// Don't include the trailing zero.
					InsertAndTruncate(f.Clauses[clauseStart:i], n, simplification_level)
				}
			}
			clauseStart = i + 1
		}
	}
	const truncate = true
	simp := n.ToDimacs(truncate)
	// Set N
	simp.N = proto.Int32(f.GetN())

	log.Println("Simplified ", f.GetM(), " clauses to ", simp.GetM(), " in ", time.Since(start).Seconds(), " seconds")
	return simp
}

func (f *Dimacs) BoundedSimplify(max_clauses uint64, simplification_level int32) *Dimacs {
	start := time.Now()
	n := NewNode()

	// Insert smaller clauses first.
	clauseStart := 0
	for i, l := range f.Clauses {

		// TODO(adi): Ideally we would like to insert in ascending order of length.
		if l == 0 {
			if len(f.Clauses[clauseStart:i]) <= 3 {
				// Don't include the trailing zero.
				//n.InsertIfNotSubsumed(f.Clauses[clauseStart:i])
				InsertAndTruncate(f.Clauses[clauseStart:i], n, simplification_level)
			}
			clauseStart = i + 1
		}
	}

	// Insert the rest
	clauseStart = 0
	subset_bound := 3
	for i, l := range f.Clauses {
		// Insert smaller clauses first.
		// TODO(adi): Ideally we would like to insert in ascending order of length.
		if l == 0 {
			if len(f.Clauses[clauseStart:i]) > 3 {
				// If we run out of time then just insert
				if time.Since(start).Seconds() < 2.0 {
					// Don't include the trailing zero.
					n.InsertIfNotBoundedSubsumed(f.Clauses[clauseStart:i], subset_bound, simplification_level)
				} else {
					// Don't include the trailing zero.
					InsertAndTruncate(f.Clauses[clauseStart:i], n, simplification_level)
				}
			}
			clauseStart = i + 1
		}
	}

	const truncate = true
	simp := n.ToBoundedDimacs(truncate, max_clauses)
	// Set N
	simp.N = proto.Int32(f.GetN())

	log.Println("(Bounded) Simplified ", f.GetM(), " clauses to ", simp.GetM(), " in ", time.Since(start).Seconds(), " seconds")
	return simp
}

// RangePartition partitions 'f' into 'k' formulas where each partition contains
// 1/k clauses of 'f'.
func (f *Dimacs) RangePartition(k int32) []*Dimacs {
	if f.GetM() < k {
		log.Fatalf("RangePartition size too large: %d clauses but asked for %d parts.", f.GetM(), k)
	}
	r := make([]*Dimacs, int(k))
	clausesPerPart := make([]int32, k)
	// fmt.Println(f.GetM(), "/", k, "=", f.GetM() / k)
	// Each part gets at least M/k clauses.
	for i := int32(0); i < k; i++ {
		clausesPerPart[i] = f.GetM() / k
	}
	// Add the remainder one at a time to the first mod-k parts.
	for i := int32(0); i < f.GetM()%k; i++ {
		clausesPerPart[i]++
	}
	startIndex := 0
	for part := int32(0); part < k; part++ {
		stopIndex := startIndex
		// Stop once observed clausesPerPart[i] zeroes in f.Clauses
		// Ex: clausesPerPart[0] == 2
		//     f.Clauses         == 1 2 3 0 1 2 3 0 1 2 3 0
		//     startIndex        == 0
		//     stopIndex         == 0
		// ... execute for loops ...
		//     stopIndex         == 8
		//
		for numZeros := int32(0); numZeros < clausesPerPart[part]; numZeros++ {
			for f.Clauses[stopIndex] != 0 {
				stopIndex++
			}
			stopIndex++
		}
		r[part] = &Dimacs{
			N:       f.N,
			M:       proto.Int32(clausesPerPart[part]),
			Clauses: f.Clauses[startIndex:stopIndex],
		}
		startIndex = stopIndex
	}
	return r
}

// ModPartition partitions 'f' into 'k' parts where each part gets the mod-k
// clauses for its index. E.g., part 0 gets clauses 0, k, 2k, etc. In general,
// each part 'i' gets clauses i, k + i, 2k + i, etc.
func (f *Dimacs) ModPartition(k int) []*Dimacs {
	if f == nil || f.GetM() < int32(k) {
		log.Fatalf("Invalid ModPartition with k=%d and f=%s", k, proto.CompactTextString(f))
	}
	parts := make([]*Dimacs, k)
	for i, _ := range parts {
		parts[i] = &Dimacs{
			N:       proto.Int32(f.GetN()),
			M:       proto.Int32(0),
			Clauses: []int32{},
		}
	}
	partIndex := 0
	for _, literal := range f.Clauses {
		part := parts[partIndex]
		part.Clauses = append(part.Clauses, literal)
		if literal == 0 {
			*part.M++
			partIndex = (partIndex + 1) % k
		}
	}
	return parts
}

// DilemmaPartition partitions 'f' into 2^v formulas, one for each valuation of
// variables in 'vs. For example let 'vs=[1,2]'. The result would be:
//   f & 1 & 2
//   f & 1 & -2
//   f & -1 & 2
//   f & -1 & -2
// If no variables are specified returns the nil slice.
func (f *Dimacs) DilemmaPartition(vs ...int32) []*Dimacs {
	switch len(vs) {
	case 0:
		return nil
	case 1:
		// validate v
		v := vs[0]
		if v < 1 || v > f.GetN() {
			panic(fmt.Errorf("Invalid variable id=%d for Dimacs formula with N=%d", v, f.GetN()))
		}
		// Make sure f.Clauses ends with 0
		if f.Clauses[len(f.Clauses)-1] != 0 {
			f.Clauses = append(f.Clauses, 0)
		}
		fp, fn := f.Clone(), f.Clone()
		// Append '& v+'
		fp.Clauses = append(fp.Clauses, v, 0)
		*fp.M++
		// Append '& v-'
		fn.Clauses = append(fn.Clauses, -v, 0)
		*fn.M++
		return []*Dimacs{fp, fn}
	default:
		res := []*Dimacs{f}
		for _, v := range vs {
			var acc []*Dimacs
			for _, g := range res {
				acc = append(acc, g.DilemmaPartition(v)...)
			}
			res = acc
		}
		return res
	}
}

// Given a variable in positive or negative form (e.g., +3 or -3 for variable
// with identifier 3), and a "dilemma variable", transform "learnedClauses" to
// be implied by 'v'. An example will make this more clear:
//   v=-1   // Variable with id 1 in the "negative form" split
//   dv=13  // New "dilemma var" with id 13
//   lC={{2,3},{-5,6}}
// Returns:
//     {1, 13}, {-13, 2, 3}, {-13, -5, 6}
func DilemmaImplicate(v, dv int32, learnedClauses []int32) []int32 {
	// Start with 'v ==> dv'
	implications := []int32{-v, dv, 0}
	// Then append 'dv ==> c' for each c \in learnedClauses
	clauseStart := 0
	for clauseEnd, lit := range learnedClauses {
		if lit == 0 {
			// +1 b/c append is non-inclusive at the stop point
			implications = append(implications, -dv)
			implications = append(implications, learnedClauses[clauseStart:clauseEnd+1]...)
			// Next start is +1 to begin after the terminating 0
			clauseStart = clauseEnd + 1
		}
	}
	return implications
}

// Append appends the clauses in each 'g' of 'gs' to 'f', updating 'f.M' accordingly..
func (f *Dimacs) Append(gs ...*Dimacs) {
	for i, g := range gs {
		if f.GetN() != g.GetN() {
			fmt.Printf("WARNING: f and g (index %d) do not agree on N: %d vs %d\n", i, f.GetN(), g.GetN())
		}
		*f.M += g.GetM()
		f.Clauses = append(f.Clauses, g.Clauses...)
	}
}

// IsCanonicalUnsat returns whether or not 'f' is the canonical unsat formula
// which contains a single empty clause.
func (f *Dimacs) IsCanonicalUnsat() bool {
	return f != nil && f.GetM() == 1 && len(f.Clauses) == 1 && f.Clauses[0] == 0
}

// IsSane returns nil if f.GetM() actually matches f.Clauses and each literal
// in f.Clauses is in the range [-N, N] inclusive.
func (f *Dimacs) IsSane() error {
	if f == nil {
		return nil // TODO(nkidd) allow nil formulas?
	}
	// ClausesFile takes precedence
	if f.ClausesFile != nil {
		return nil
	}
	if f.N == nil || f.M == nil {
		return fmt.Errorf("N, M, or Clauses is nil.")
	}
	if f.GetN() < int32(0) || f.GetM() < int32(0) {
		return fmt.Errorf("N or M is 0")
	}
	if f.ClausesFile == nil {
		clauseCount := int32(0)
		for i, lit := range f.Clauses {
			if lit == 0 {
				clauseCount++
			} else if lit < -1*f.GetN() {
				return fmt.Errorf("Index %d has invalid literal %d", i, lit)
			} else if lit > f.GetN() {
				return fmt.Errorf("Index %d has invalid literal %d", i, lit)
			}
		}
		if f.GetM() != clauseCount {
			return fmt.Errorf("M = %d but observed %d clauses", f.GetM(), clauseCount)
		}
	}
	return nil
}

func (f *Dimacs) Clone() *Dimacs {
	if f == nil {
		return nil
	}
	g := &Dimacs{
		N:       proto.Int32(f.GetN()),
		M:       proto.Int32(f.GetM()),
		Clauses: make([]int32, len(f.Clauses)),
	}
	// NB: copy args are dst then src
	copy(g.Clauses, f.Clauses)
	return g
}

func (f *Dimacs) Stats(round int) {
	log.Println("stat: #variables:", f.GetN())
	log.Println("stat: #clauses:", f.GetM())

	// count the length of the clauses
	if f.GetM() > 0 {
		current_length := 0
		distribution := make(map[int]int)
		for _, lit := range f.GetClauses() {
			if lit == 0 {
				if _, ok := distribution[current_length]; ok {
					distribution[current_length]++
				} else {
					distribution[current_length] = 1
				}
				current_length = 0
			} else {
				current_length++
			}
		}

		// now, print the distribution map
		num_keys := len(distribution)
		found := 0
		for length := 0; found < num_keys; length++ {
			if number, ok := distribution[length]; ok {
				log.Printf("stat: #length (%d;%d;%d)", length, number, round)
				found++
			}
		}

	}
}
