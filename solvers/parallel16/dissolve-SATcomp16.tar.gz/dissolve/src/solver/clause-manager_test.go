package solver

import (
	"github.com/golang/protobuf/proto"

	"testing"
)

var simplevel = int32(2)

func TestClauseManagerInsertClause(t *testing.T) {
	use_subsumption := true
	cm := NewClauseManager(2, 100, 2.0, simplevel)
	if !cm.InsertClause(use_subsumption, []int32{2, 1, 3}, false) {
		t.Errorf("Clause not inserted")
	}

	if cm.InsertClause(use_subsumption, []int32{2, 3, 1, 5}, false) {
		t.Errorf("Subsumed clause inserted")
	}

	if !cm.InsertClause(use_subsumption, []int32{6, 7}, true) {
		t.Errorf("Clause not inserted")
	}

	if !cm.InsertClause(use_subsumption, []int32{6, 3, 2, 5, 34, 32}, true) {
		t.Errorf("Clause marked important not inserted")
	}
	if !cm.InsertClause(use_subsumption, []int32{6, 675, 2, -5, -34, 45, 123}, false) {
		t.Errorf("Long non-important clause not inserted")
	}

	if cm.InsertClause(use_subsumption, []int32{6, 2, -5, -34, 45, 123, 675, 676}, false) {
		t.Errorf("Long non-important clause inserted")
	}
	f := cm.ToDimacs()
	//t.Log("\nDimacs: ", proto.CompactTextString(f))
	if f.GetM() != 4 {
		t.Errorf("Expected 4 clauses")
	}

}

func TestClauseManagerInsertDimacs(t *testing.T) {
	cases := []struct {
		input    *Dimacs
		expected *Dimacs
	}{
		{
			&Dimacs{
				N:       proto.Int32(4),
				M:       proto.Int32(2),
				Clauses: []int32{1, 2, 3, 0, 1, 3, 2, 0},
			},
			&Dimacs{
				N:       proto.Int32(4),
				M:       proto.Int32(1),
				Clauses: []int32{1, 2, 3, 0},
			}},
		{
			&Dimacs{
				N:       proto.Int32(4),
				M:       proto.Int32(4),
				Clauses: []int32{3, 2, 4, 1, 0, 3, 2, 0, -2, 0, -2, 3, 6, 0},
			},
			&Dimacs{
				N:       proto.Int32(4),
				M:       proto.Int32(2),
				Clauses: []int32{2, 3, 0, -2, 0},
			}},
		{
			&Dimacs{
				N:       proto.Int32(4),
				M:       proto.Int32(4),
				Clauses: []int32{3, 2, 0, -2, 0, -2, 3, 6, 0, 3, 2, 4, 1, 0},
			},
			&Dimacs{
				N:       proto.Int32(4),
				M:       proto.Int32(2),
				Clauses: []int32{2, 3, 0, -2, 0},
			}},
	}
	time_limit := float64(10.0)
	for _, c := range cases {
		cm := NewClauseManager(2, 100, time_limit, simplevel)
		cm.Insert(c.input)
		ans := cm.ToDimacs()
		if !ans.Eq(c.expected) {
			t.Errorf("Expected %s, observed %s", proto.CompactTextString(c.expected), proto.CompactTextString(ans))
		}
	}

}

func TestClauseManagerInsertBoundedDimacs(t *testing.T) {
	cases := []struct {
		input    *Dimacs
		expected *Dimacs
	}{
		{
			&Dimacs{
				N:       proto.Int32(4),
				M:       proto.Int32(2),
				Clauses: []int32{1, 2, 3, 0, 1, 3, 2, 0},
			},
			&Dimacs{
				N:       proto.Int32(4),
				M:       proto.Int32(1),
				Clauses: []int32{1, 2, 3, 0},
			}},
		{
			&Dimacs{
				N:       proto.Int32(6),
				M:       proto.Int32(4),
				Clauses: []int32{3, 2, 4, 1, 0, 3, 2, 0, -2, 0, -2, 3, 6, 0},
			},
			&Dimacs{
				N:       proto.Int32(6),
				M:       proto.Int32(1),
				Clauses: []int32{-2, 0},
			}},
		{
			&Dimacs{
				N:       proto.Int32(6),
				M:       proto.Int32(1),
				Clauses: []int32{3, 2, 0, -2, 0, -2, 3, 6, 0, 3, 2, 4, 1, 0},
			},
			&Dimacs{
				N:       proto.Int32(6),
				M:       proto.Int32(1),
				Clauses: []int32{-2, 0},
			}},
	}
	time_limit := float64(10.0)
	for _, c := range cases {
		cm := NewClauseManager(2, 100, time_limit, simplevel)
		cm.small_limit = 1
		cm.Insert(c.input)
		ans := cm.ToBoundedDimacs(1)
		if !ans.Eq(c.expected) {
			t.Errorf("Expected %s, observed %s", proto.CompactTextString(c.expected), proto.CompactTextString(ans))
		}
	}

}
