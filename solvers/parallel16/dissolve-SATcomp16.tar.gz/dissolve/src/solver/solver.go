package solver

import (
	"bytes"
	"io"
	"io/ioutil"
	"log"
	"os"
	"os/exec"
	"path"
	"syscall"
	"time"

	"github.com/golang/protobuf/proto"
)

func FatalIfNonNil(err error, msg string) {
	if err != nil {
		log.Fatal(msg, err)
	}
}

func MarshalToFileOrDie(pb proto.Message, f *os.File) {
	buf := proto.NewBuffer(nil)
	if err := buf.Marshal(pb); err != nil {
		log.Fatal("Marshal error: ", err)
	}
	if _, err := io.Copy(f, bytes.NewBuffer(buf.Bytes())); err != nil {
		log.Fatal("Cannot write to TIN: ", err)
	}
}

func UnmarshalFromFile(name string, pb proto.Message) error {
	f, err := os.Open(name)
	if err != nil {
		return err
	}
	defer f.Close()
	b, err := ioutil.ReadAll(f)
	if err != nil {
		return err
	}
	return proto.Unmarshal(b, pb)
}

func UnmarshalFromFileOrDie(name string, pb proto.Message) {
	FatalIfNonNil(UnmarshalFromFile(name, pb), "UnmarshalFromFile")
}

// CopyProto copies proto 'in' to proto 'out' via Marshal/Unmarshal.
func CopyProto(in, out proto.Message) {
	data, err := proto.Marshal(in)
	FatalIfNonNil(err, "Marshal failed")
	err = proto.Unmarshal(data, out)
	FatalIfNonNil(err, "Unmarshal failed")
}

// Rely on deterministic of proto serialization for equality testing.
func EqProto(a, b proto.Message) bool {
	b1, err1 := proto.Marshal(a)
	FatalIfNonNil(err1, "proto.Marshal failed")
	b2, err2 := proto.Marshal(b)
	FatalIfNonNil(err2, "proto.Marshal failed")
	return bytes.Equal(b1, b2)
}

func (d *SolverRequest) GobEncode() ([]byte, error) {
	return proto.Marshal(d)
}

func (d *SolverRequest) GobDecode(data []byte) error {
	return proto.Unmarshal(data, d)
}

func (d *SolverReply) GobEncode() ([]byte, error) {
	return proto.Marshal(d)
}

func (d *SolverReply) GobDecode(data []byte) error {
	return proto.Unmarshal(data, d)
}

// CancellableRun Run()s 'cmd' which Start()s it and Wait()s for it to complete.
// If an input is received on 'quit' then 'cmd' will be Kill()d.
// RETURNS: The output of cmd.Run().
// REQUIRES: 'cmd' must not have been already started.
func CancellableRun(quit chan bool, cmd *exec.Cmd) (err error) {
	done := make(chan error)
	cmd.Start()
	go func() { done <- cmd.Wait() }()
	select {
	case err = <-done:
	case sigint := <-quit:
		if sigint {
			// We have to add some delay here (20ms seems to be sufficient) for the following reason:
			// It might happen that a solving instance is tagged as cancellable even before it actually started (quit channel already contains true when calling this function). Then, when it starts, the 'quit' channel already contains true and the SIGINT is triggered instantaneously. This is a problem because the sequential solver does not have enough time to initialize. Then, we need to wait for some time before sending the SIGINT, so that we make sure the sequential solver had enough time to be "ready" to be interrupted.
			time.Sleep(20 * time.Millisecond)
			cmd.Process.Signal(syscall.SIGINT)
			log.Println("CancellableRun has been interrupted")
		} else {
			cmd.Process.Kill()
			log.Println("CancellableRun has been killed")
		}
		err = <-done
	}
	log.Println("CancellableRun returns with error:", err)
	return err
}

type SolverCmd struct {
	// Exe is the name of the executable
	Exe string
	// Args to pass to the executable
	Args []string
	// The input and output protos.
	In, Out proto.Message
	// Tin and Tout are the names of the files that Input and Output are
	// serialized into and out from, respectively.
	tinName, toutName string
}

// Represents
//   exe --pb_in=<tin> --pb_out=<tout> args
func NewSolverCmd(exe string, args []string, in, out proto.Message) *SolverCmd {
	c := &SolverCmd{
		Exe:  exe,
		Args: args,
		In:   in,
		Out:  out,
	}
	// 1. Serialize in to a temporary file TIN.
	tin, err := ioutil.TempFile("", "tin")
	if err != nil {
		log.Fatal("Cannot create temp file TIN: ", err)
	}
	c.tinName = tin.Name()
	MarshalToFileOrDie(in, tin)
	tin.Close()
	// 2. Create an output temporary file TOUT.
	tout, err := ioutil.TempFile("", "tout")
	if err != nil {
		log.Fatal("Cannot create temp file TOUT: ", err)
	}
	c.toutName = tout.Name()
	tout.Close()
	return c
}

// Run runs 'c' to completion. While waiting for 'c' to terminate
// Run will also listen for input on channel 'quit'. If input
// is received on 'quit' first, a true, resp. false, value sends
// a SIGINT, resp. SIGKILL, signal to the subprocess.
func (c *SolverCmd) Run(quit chan bool) error {
	defer os.Remove(c.tinName)
	defer os.Remove(c.toutName)
	start := time.Now()
	// 3. Invoke exe --pb_in=TIN --pb_out=TOUT
	inOut := []string{
		"--pb_in=" + c.tinName,
		"--pb_out=" + c.toutName,
	}
	cmd := exec.Command(c.Exe, append(inOut, c.Args...)...)
	var b bytes.Buffer
	cmd.Stdout = &b
	cmd.Stderr = &b
	err := CancellableRun(quit, cmd)
	if err == nil {
		// 4. Read TOUT, deserialize, store in out, return.
		err = UnmarshalFromFile(c.toutName, c.Out)
	}
	stop := time.Now()
	log.Printf("Elapsed %fs to run %s, output:\n%s",
		stop.Sub(start).Seconds(), path.Base(c.Exe), b.String())

	return err

}
