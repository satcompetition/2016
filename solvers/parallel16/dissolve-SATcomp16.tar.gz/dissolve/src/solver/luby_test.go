package solver

import "testing"

func TestLuby(t *testing.T) {
	expected := [12]uint64{0, 1, 1, 2, 1, 1, 2, 4, 1, 1, 2, 1}
	observed := [12]uint64{}
	for i, _ := range observed {
		observed[i] = GetLuby(i)
	}
	if observed != expected {
		t.Errorf("Expected %v, observed %v", expected, observed)
	}
}
