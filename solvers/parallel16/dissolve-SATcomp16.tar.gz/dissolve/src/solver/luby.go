package solver

import "math"

func GetLuby(i int) uint64 {
	if i == 1 {
		return uint64(1)
	}
	k := math.Log2(float64(i + 1))

	if k == math.Floor(k+0.5) {
		return uint64(math.Pow(2, k-1))
	} else {
		k = math.Floor(k)
		return GetLuby(i - int(math.Pow(2, k)) + 1)
	}
}
