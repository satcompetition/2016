package solver

import (
	"github.com/golang/protobuf/proto"

	"fmt"
	"log"
	"sort"
	"time"
)

// Implementing data-structure from
// "A new method to index and query sets"
// Hoffmann, Koehler

type Node struct {
	d        int32
	EoP      bool
	children map[int32]*Node
}

func NewNode() *Node {
	return &Node{
		d:        0,
		EoP:      false,
		children: make(map[int32]*Node),
	}
}

func (n *Node) LookupChild(v int32) *Node {
	if n.children == nil {
		return nil
	}
	return n.children[v]
}

func (n *Node) InsertChild(v int32) *Node {
	if n.children == nil {
		n.children = make(map[int32]*Node)
	}
	c := &Node{
		d:   v,
		EoP: false,
	}
	n.children[v] = c
	return c
}

func Truncate(lits []int32, n *Node) bool {
	if len(lits) == 0 {
		n.children = nil
		return true
	}
	var k int32
	v := lits[0]
	keys := []int32{}
	for k, _ = range n.children {
		keys = append(keys, k)
	}
	sort.Sort(int32Array(keys))
	// iterate over the childs in order
	res := len(keys) > 0
	for _, k = range keys {
		if k == v {
			if Truncate(lits[1:], n.children[k]) {
				delete(n.children, k)
			} else {
				res = false
			}
		} else if k < v {
			if Truncate(lits, n.children[k]) {
				delete(n.children, k)
			} else {
				res = false
			}
		} else {
			// k > v means there is no more possible subsumption
			res = false
			break
		}
	}
	return res
}

func InsertAndTruncateSorted(lits []int32, n *Node, simplification_level int32) bool {
	if simplification_level < 2 {
		return InsertAndTruncateSortedOld(lits, n)
	}
	if len(lits) == 0 {
		n.EoP = true
		n.children = nil // truncate the childrens as they are subsumed
		return true
	}
	if n.EoP {
		return true // inserted clause is already subsumed, no need to insert
	}

	var k int32
	v := lits[0]
	keys := []int32{}
	for k, _ = range n.children {
		keys = append(keys, k)
	}
	sort.Sort(int32Array(keys))
	// iterate over the childs in order
	for _, k = range keys {
		if k < v {
			// truncate the childs
			if Truncate(lits, n.children[k]) {
				delete(n.children, k)
			}
		} else {
			break
		}
	}
	// should insert child if needed and call recursively
	var c *Node
	if k == v {
		c = n.children[k]
	} else {
		// k > v, i.e. v does not exist in n.children
		c = n.InsertChild(v)
	}
	return InsertAndTruncateSorted(lits[1:], c, simplification_level)
}

// Insert the sorted set "lits".
// Truncate the tree so that no strict
func InsertAndTruncateSortedOld(lits []int32, n *Node) bool {

	for _, v := range lits {
		// Found a proper subset, return
		if n.EoP {
			return false
		}
		c := n.LookupChild(v)
		if c == nil {
			c = n.InsertChild(v)
		}
		// Found a proper subset; break
		//if n.EoP { break }
		n = c
	}
	// Truncate the rest of trie
	n.EoP = true
	n.children = nil
	return true
}

func InsertAndTruncate(lits []int32, n *Node, simplification_level int32) {
	sort.Sort(int32Array(lits))
	InsertAndTruncateSorted(lits, n, simplification_level)
}

// Insert the sorted set "lits".
func Insert(lits []int32, n *Node) {

	for _, v := range lits {
		c := n.LookupChild(v)
		if c == nil {
			c = n.InsertChild(v)
		}
		n = c
	}
	n.EoP = true
	return
}

// Lookup subset of size at most bound
// p has to be sorted
func (n *Node) LookupBoundedSubset(p []int32, bound int) bool {

	if bound == 0 {
		return false
	}
	for i, v := range p {
		c := n.LookupChild(v)
		if c != nil {
			if c.EoP {
				return true
			}
			if c.LookupBoundedSubset(p[i+1:], bound-1) {
				return true
			}
		}
	}
	return false
}

// p has to be sorted
func (n *Node) LookupSubset(p []int32) bool {
	return n.LookupBoundedSubset(p, len(p))
}

// p has to be sorted
func (n *Node) LookupExact(p []int32) bool {

	if len(p) == 0 {
		return n.EoP
	}
	c := n.LookupChild(p[0])
	if c != nil {
		return c.LookupExact(p[1:])
	} else {
		return false
	}
}

type int32Array []int32

func (s int32Array) Len() int           { return len(s) }
func (s int32Array) Swap(i, j int)      { s[i], s[j] = s[j], s[i] }
func (s int32Array) Less(i, j int) bool { return s[i] < s[j] }

func (n *Node) InsertIfNotSubsumed(p []int32, simplification_level int32) {

	sort.Sort(int32Array(p))
	if n.LookupSubset(p) {
		return
	}
	InsertAndTruncateSorted(p, n, simplification_level)
}

func (n *Node) InsertIfNotBoundedSubsumed(p []int32, bound int, simplification_level int32) {

	sort.Sort(int32Array(p))
	if n.LookupBoundedSubset(p, bound) {
		return
	}
	InsertAndTruncateSorted(p, n, simplification_level)
}

func (n *Node) print(p []int32) {
	if n.EoP {
		fmt.Println(p)
	}
	for k, v := range n.children {
		v.print(append(p, k))
	}
	return
}

func (n *Node) Print() {
	fmt.Println("###")
	n.print(make([]int32, 0))
}

// If truncate is true, then the traversal down the UBTree is stopped
// once a clause is found.
// Thus, if [ 1 2 3 ] and [1 2 3 4 5] are in the UBTree and truncate=true,
// then only [ 1 2 3 ] will be stored in the Dimacs object.
// This is another method of getting some sort of subsumption for free.
func (n *Node) to_dimacs(truncate bool, p []int32, f *Dimacs) {
	if n.EoP {
		f.Clauses = append(f.Clauses, p...)
		f.Clauses = append(f.Clauses, 0)
		*f.M++
		if truncate {
			return
		}
	}
	for k, v := range n.children {
		v.to_dimacs(truncate, append(p, k), f)
	}
	return
}

// ToDimacs converts the clauses stored in the UBTree into Dimacs format.
// If truncate is true, then the traversal down the UBTree is stopped
// once a clause is found.
// Thus, if [ 1 2 3 ] and [1 2 3 4 5] are in the UBTree and truncate=true,
// then only [ 1 2 3 ] will be stored in the Dimacs object.
// This is another method of getting some sort of subsumption for free.
func (n *Node) ToDimacs(truncate bool) *Dimacs {
	f := &Dimacs{
		N:       proto.Int32(0),
		M:       proto.Int32(0),
		Clauses: make([]int32, 0),
	}
	n.to_dimacs(truncate, make([]int32, 0), f)
	return f

}

// InsertDimacs inserts all clauses in the Dimacs object into the UBTree.
func (n *Node) InsertDimacs(f *Dimacs) {

	clauseStart := 0
	for i, l := range f.Clauses {
		if l == 0 {
			p := f.Clauses[clauseStart:i]
			sort.Sort(int32Array(p))
			// Don't include the trailing zero.
			Insert(p, n)
			clauseStart = i + 1
		}
	}
}

// If truncate is true, then the traversal down the UBTree is stopped
// once a clause is found.
// Thus, if [ 1 2 3 ] and [1 2 3 4 5] are in the UBTree and truncate=true,
// then only [ 1 2 3 ] will be stored in the Dimacs object.
// This is another method of getting some sort of subsumption for free.
func (n *Node) to_bounded_dimacs(truncate bool, max_clauses uint64, p []int32, f *Dimacs) {
	if uint64(f.GetM()) >= max_clauses {
		return
	}
	if len(f.Clauses) >= 8000000 {
		log.Println("Size of DIMACS too big: limiting to", f.GetM(), "clauses")
		return
	}
	if n.EoP {
		f.Clauses = append(f.Clauses, p...)
		f.Clauses = append(f.Clauses, 0)
		*f.M++
		if truncate {
			return
		}
	}
	for k, v := range n.children {
		p1 := append(p, k)
		v.to_bounded_dimacs(truncate, max_clauses, p1, f)
	}
	return
}

// If truncate is true, then the traversal down the UBTree is stopped
// once a clause is found.
// Thus, if [ 1 2 3 ] and [1 2 3 4 5] are in the UBTree and truncate=true,
// then only [ 1 2 3 ] will be stored in the Dimacs object.
// This is another method of getting some sort of subsumption for free.
func (n *Node) ToBoundedDimacs(truncate bool, max_clauses uint64) *Dimacs {
	f := &Dimacs{
		N:       proto.Int32(0),
		M:       proto.Int32(0),
		Clauses: make([]int32, 0),
	}
	n.to_bounded_dimacs(truncate, max_clauses, make([]int32, 0), f)
	return f

}

func (n *Node) to_bounded_dimacs_not_subsumed(time_limit_secs float64, max_clauses uint64, start time.Time, p []int32, cm *ClauseManager, f *Dimacs) {
	if uint64(f.GetM()) >= max_clauses {
		return
	}
	if len(f.Clauses) >= 8000000 {
		log.Println("Size of DIMACS too big: limiting to", f.GetM(), "clauses")
		return
	}
	if n.EoP && (time.Since(start).Seconds() >= time_limit_secs || !cm.IsSubsumed(p)) {
		f.Clauses = append(f.Clauses, p...)
		f.Clauses = append(f.Clauses, 0)
		*f.M++
		return
	}
	for k, v := range n.children {
		p1 := append(p, k)
		v.to_bounded_dimacs_not_subsumed(time_limit_secs, max_clauses, start, p1, cm, f)
	}
	return
}
