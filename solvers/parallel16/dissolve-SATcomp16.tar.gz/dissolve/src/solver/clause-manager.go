package solver

import (
	"github.com/golang/protobuf/proto"

	"fmt"
	"log"
	"sort"
	"time"
)

type ClauseManager struct {
	small map[int]*Node // small or short clauses
	imp   map[int]*Node // important clauses
	other map[int]*Node // the rest of the clauses

	small_cnf map[int]*Dimacs // small or short clauses
	imp_cnf   map[int]*Dimacs // important clauses
	other_cnf map[int]*Dimacs // the rest of the clauses

	current_round int

	peers_round map[int]int

	small_limit                int     // clauses of length <= small_limit are considered small
	imp_limit                  int     // the first imp_limit clauses will be considered as important
	size                       int     // an over-approximation of the number of clauses present
	N                          int32   // number of variables; only used in ToDimacs methods
	use_subsumption_time_limit float64 // Maximal time for which we check for clauses subsumption
	simplification_level       int32
}

func NewClauseManager(small_limit int, imp_limit int, subsumption_time_limit float64, simplification_level int32) *ClauseManager {
	return &ClauseManager{
		small:         make(map[int]*Node),
		imp:           make(map[int]*Node),
		other:         make(map[int]*Node),
		small_cnf:     make(map[int]*Dimacs),
		imp_cnf:       make(map[int]*Dimacs),
		other_cnf:     make(map[int]*Dimacs),
		current_round: 0,
		peers_round:   make(map[int]int),
		small_limit:   small_limit,
		imp_limit:     imp_limit,
		N:             0,
		use_subsumption_time_limit: subsumption_time_limit,
		simplification_level:       simplification_level,
	}
}

func (cm *ClauseManager) Print() {
	fmt.Printf("Small clauses (%d) \n", cm.small_limit)
	cm.small[cm.current_round].Print()
	fmt.Println("Important clauses")
	cm.imp[cm.current_round].Print()
	fmt.Println("Other clauses")
	cm.other[cm.current_round].Print()
}

// Move important clauses to other.
// Clear important clauses
//func (cm *ClauseManager) Shift() *Node {
//	backup_clauses := cm.other
//	cm.other = cm.imp
//	cm.imp = NewNode()
//	//cm.imp = cm.small
//	//cm.small = NewNode()
//	return backup_clauses
//}

func (cm *ClauseManager) StartRound(round int) {
	log.Println("Starting round ", round)
	cm.small[round] = NewNode()
	cm.imp[round] = NewNode()
	cm.other[round] = NewNode()
	cm.current_round = round
	// TODO: delete Nodes that are too old

	if round > 0 {
		cm.small_cnf[round-1] = &Dimacs{
			N:       proto.Int32(cm.N),
			M:       proto.Int32(0),
			Clauses: make([]int32, 0),
		}
		cm.imp_cnf[round-1] = &Dimacs{
			N:       proto.Int32(cm.N),
			M:       proto.Int32(0),
			Clauses: make([]int32, 0),
		}
		cm.other_cnf[round-1] = &Dimacs{
			N:       proto.Int32(cm.N),
			M:       proto.Int32(0),
			Clauses: make([]int32, 0),
		}
		truncate := true
		if val, ok := cm.small[round-1]; ok {
			log.Println("val is NULL?? ", val == nil)
		} else {
			log.Println("ERROR : round ", round-1, " not present it cm.small")
		}
		cm.small[round-1].to_dimacs(truncate, make([]int32, 0), cm.small_cnf[round-1])
		cm.imp[round-1].to_dimacs(truncate, make([]int32, 0), cm.imp_cnf[round-1])
		cm.other[round-1].to_dimacs(truncate, make([]int32, 0), cm.other_cnf[round-1])

		log.Println("#small round ", round-1, " is ", *cm.small_cnf[round-1].M)
		log.Println("#imp round ", round-1, " is ", *cm.imp_cnf[round-1].M)
		log.Println("#other round ", round-1, " is ", *cm.other_cnf[round-1].M)
		//cm.small_cnf[round-1].Stats(round - 1)
		//cm.imp_cnf[round-1].Stats(round - 1)
		//cm.other_cnf[round-1].Stats(round - 1)
		delete(cm.small, round-1)
		delete(cm.imp, round-1)
		delete(cm.other, round-1)
	}
}

func (cm *ClauseManager) InsertClause(use_subsumption bool, lits []int32, is_imp bool) bool {
	// Sort
	sort.Sort(int32Array(lits))

	// If subsumed by small clauses, return
	if use_subsumption && cm.small[cm.current_round].LookupSubset(lits) {
		return false
	}
	// If small clause, then insert in small clauses
	if len(lits) <= cm.small_limit {
		return InsertAndTruncateSorted(lits, cm.small[cm.current_round], cm.simplification_level)
	}
	// Check if bounded subsumed by important clauses
	if use_subsumption && cm.imp[cm.current_round].LookupBoundedSubset(lits, cm.small_limit+2) {
		return false
	}
	// If important, then insert in imp clauses
	if is_imp {
		return InsertAndTruncateSorted(lits, cm.imp[cm.current_round], cm.simplification_level)
	}

	// Check if bounded subsumed by other clauses
	if use_subsumption && cm.other[cm.current_round].LookupBoundedSubset(lits, cm.small_limit+2) {
		return false
	}
	return InsertAndTruncateSorted(lits, cm.other[cm.current_round], cm.simplification_level)
}

func (cm *ClauseManager) IsSubsumed(lits []int32) bool {
	// Sort
	sort.Sort(int32Array(lits))
	return cm.small[cm.current_round].LookupSubset(lits) || cm.imp[cm.current_round].LookupBoundedSubset(lits, cm.small_limit+2) || cm.other[cm.current_round].LookupBoundedSubset(lits, cm.small_limit+2)
}

func (cm *ClauseManager) Insert(f *Dimacs) {
	if f == nil {
		return
	}
	start := time.Now()

	if cm.N < f.GetN() {
		cm.N = f.GetN()
	}
	// TODO(adi): Ideally we would like to insert in ascending order of length.

	// Insert small clauses.
	clauseStart := 0
	for i, l := range f.Clauses {
		if l == 0 {
			if len(f.Clauses[clauseStart:i]) <= cm.small_limit {
				// Don't include the trailing zero.
				cm.InsertClause(time.Since(start).Seconds() <= cm.use_subsumption_time_limit, f.Clauses[clauseStart:i], false)
			}
			clauseStart = i + 1
		}
	}

	// Insert the rest of the clauses; the first imp_limit clauses are considered important
	clauseStart = 0
	count := 0
	for i, l := range f.Clauses {
		if l == 0 {
			if len(f.Clauses[clauseStart:i]) > cm.small_limit {
				cm.InsertClause(time.Since(start).Seconds() <= cm.use_subsumption_time_limit, f.Clauses[clauseStart:i], count <= cm.imp_limit)
			}
			count++
			clauseStart = i + 1
		}
	}
}

func (cm *ClauseManager) ToDimacs() *Dimacs {
	f := &Dimacs{
		N:       proto.Int32(0),
		M:       proto.Int32(0),
		Clauses: make([]int32, 0),
	}
	const truncate = true
	cm.small[cm.current_round].to_dimacs(truncate, make([]int32, 0), f)
	cm.imp[cm.current_round].to_dimacs(truncate, make([]int32, 0), f)
	cm.other[cm.current_round].to_dimacs(truncate, make([]int32, 0), f)
	// Set N
	f.N = proto.Int32(cm.N)

	return f
}

func (cm *ClauseManager) ToBoundedDimacs(max_clauses uint64) *Dimacs {
	f := &Dimacs{
		N:       proto.Int32(0),
		M:       proto.Int32(0),
		Clauses: make([]int32, 0),
	}
	const truncate = true
	cm.small[cm.current_round].to_bounded_dimacs(truncate, max_clauses, make([]int32, 0), f)
	cm.imp[cm.current_round].to_bounded_dimacs(truncate, max_clauses, make([]int32, 0), f)
	cm.other[cm.current_round].to_bounded_dimacs(truncate, max_clauses, make([]int32, 0), f)
	// Set N
	f.N = proto.Int32(cm.N)

	return f
}

func (cm *ClauseManager) ToBoundedDimacsWithBackup(max_clauses uint64, backup_clauses *Node) *Dimacs {
	f := &Dimacs{
		N:       proto.Int32(0),
		M:       proto.Int32(0),
		Clauses: make([]int32, 0),
	}
	const truncate = true
	cm.small[cm.current_round].to_bounded_dimacs(truncate, max_clauses, make([]int32, 0), f)
	cm.imp[cm.current_round].to_bounded_dimacs(truncate, max_clauses, make([]int32, 0), f)
	cm.other[cm.current_round].to_bounded_dimacs(truncate, max_clauses, make([]int32, 0), f)

	start := time.Now()
	backup_clauses.to_bounded_dimacs_not_subsumed(cm.use_subsumption_time_limit, max_clauses, start, make([]int32, 0), cm, f)
	// Set N
	f.N = proto.Int32(cm.N)

	return f
}

func (cm *ClauseManager) GetBestClausesSince(previous_round int, current_round int, max_clauses uint64, nbpeers int) *Dimacs {
	log.Println("there are", nbpeers, "peers")

	f := &Dimacs{
		N:       proto.Int32(cm.N),
		M:       proto.Int32(0),
		Clauses: make([]int32, 0),
	}
	log.Println("Get best clause between rounds ", previous_round, "->", current_round)
	const truncate = true
	for round := previous_round; round < current_round; round++ {
		if val, ok := cm.peers_round[round]; ok {
			cm.peers_round[round] = val + 1
		} else {
			cm.peers_round[round] = 1
		}
	}
	for round := current_round - 1; round >= previous_round && f.GetM() < int32(max_clauses); round-- {
		f.Append(cm.small_cnf[round])
	}
	for round := current_round - 1; round >= previous_round && f.GetM() < int32(max_clauses); round-- {
		f.Append(cm.other_cnf[round])
		//cm.imp[round].to_bounded_dimacs(truncate, max_clauses, make([]int32, 0), f)
	}
	for round := current_round - 1; round >= previous_round && f.GetM()+*cm.other_cnf[round].M < int32(max_clauses); round-- {
		f.Append(cm.other_cnf[round])
	}
	log.Println("About to send ", *f.M, " clauses to the solver")

	for round := previous_round; round < current_round; round++ {
		if cm.peers_round[round] >= nbpeers {
			log.Println("cleaning UBTrees for round ", round)
			cm.peers_round[round] = 0
			// TODO
			//cm.small_cnf[round] = nil
			//cm.imp_cnf[round] = nil
			//cm.other_cnf[round] = nil
		}
	}

	return f
}
