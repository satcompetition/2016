package solver

import (
	"testing"
)

var ubtree_simplevel = int32(2)

func TestUBTreeNewNode(t *testing.T) {
	n := NewNode()
	if n.EoP == true {
		t.Errorf("Default value of node.EoP should be false, not true.")
	}
}

func TestLookupChild(t *testing.T) {
	n := NewNode()

	if n.LookupChild(10) != nil {
		t.Errorf("Expected nil after initial lookup.")
	}

	if n.LookupExact([]int32{1, 2, 3}) {
		t.Errorf("Expected LookupExact to return false.")
	}

	n.InsertChild(2)
	if n.LookupChild(2) == nil {
		t.Errorf("Expected LookupChild to return non-nil value after InsertChild.")
	}

	if n.LookupExact([]int32{1, 2, 3}) {
		t.Errorf("Expected LookupExact to return false.")
	}

}

func TestUBTreeInsertAndTruncate(t *testing.T) {
	n := NewNode()

	if n.LookupExact([]int32{1, 2, 3}) {
		t.Errorf("Expected LookupExact to return false")
	}

	l1 := []int32{1, 2, 3}
	InsertAndTruncate(l1, n, ubtree_simplevel)

	if !n.LookupExact([]int32{1, 2, 3}) {
		t.Errorf("Expected LookupExact to return true")
	}

	if !n.LookupSubset([]int32{1, 2, 3}) {
		t.Errorf("Expected LookupSubset to return true")
	}

	if !n.LookupSubset([]int32{1, 2, 3, 4}) {
		t.Errorf("Expected LookupSubset to return true")
	}
	if n.LookupSubset([]int32{2, 3, 4}) {
		t.Errorf("Expected LookupSubset to return false")
	}

	l2 := []int32{2, 3, 4}
	InsertAndTruncate(l2, n, ubtree_simplevel)

	if !n.LookupExact([]int32{2, 3, 4}) {
		t.Errorf("Expected LookupExact to return true")
	}

	l3 := []int32{1, 2, 3, 4}
	InsertAndTruncate(l3, n, ubtree_simplevel)

	if n.LookupExact([]int32{1, 2, 3, 4}) {
		t.Errorf("Expected LookupExact to return false")
	}

	l4 := []int32{1, 2}
	InsertAndTruncate(l4, n, ubtree_simplevel)

	if n.LookupExact([]int32{1}) {
		t.Errorf("Expected LookupExact to return false")
	}
	if !n.LookupExact([]int32{1, 2}) {
		t.Errorf("Expected LookupExact to return true")
	}

	if n.LookupExact([]int32{1, 2, 3}) {
		t.Errorf("Expected LookupExact to return false")
	}

	if n.LookupExact([]int32{1, 2, 3, 4}) {
		t.Errorf("Expected LookupExact to return false")
	}

	l5 := []int32{2}
	InsertAndTruncate(l5, n, ubtree_simplevel)

	if n.LookupExact([]int32{1, 2, 3}) {
		t.Errorf("Expected LookupExact to return false")
	}

	if n.LookupExact([]int32{2, 3, 4}) {
		t.Errorf("Expected LookupExact to return false")
	}

	if n.LookupExact([]int32{1, 2}) {
		t.Errorf("Expected LookupExact to return false")
	}

	if n.LookupExact([]int32{1}) {
		t.Errorf("Expected LookupExact to return false")
	}

	if !n.LookupExact([]int32{2}) {
		t.Errorf("Expected LookupExact to return true")
	}

	InsertAndTruncate([]int32{12, 13, 15, 18}, n, ubtree_simplevel)
	InsertAndTruncate([]int32{12, 13, 15, 17, 18}, n, ubtree_simplevel)
	InsertAndTruncate([]int32{12, 17, 18, 19}, n, ubtree_simplevel)
	InsertAndTruncate([]int32{12, 13, 17, 18}, n, ubtree_simplevel)
	//InsertAndTruncate([]int32{14, 15, 17, 18, 22}, n, ubtree_simplevel)
	//InsertAndTruncate([]int32{17, 18, 22}, n, ubtree_simplevel)
	//InsertAndTruncate([]int32{17, 18}, n, ubtree_simplevel)
	n.Print()

}

func TestUBTreeInsert(t *testing.T) {
	n := NewNode()
	items := [][]int32{
		{1, 2, 4, 6},
		{1, 2, 6},
		{1, 6},
		{6, 7, 10},
		{6, 7, 10, 100, 120, 4000},
		{2, 6, 4000},
	}

	for i := 0; i < len(items); i++ {
		Insert(items[i], n)
		for j := 0; j <= i; j++ {
			if !n.LookupExact(items[j]) {
				t.Errorf("Expected LookupExact to return true after Insert.")
			}
		}
		for j := i + 1; j < len(items); j++ {
			if n.LookupExact(items[j]) {
				t.Errorf("Expected LookupExact to return false when looking for %v", items[j])
			}

		}

	}

}

func TestUBTreeLookupSubset(t *testing.T) {

	items := [][]int32{
		{1, 2, 4, 6},
		{1, 2, 6},
		{1, 6},
		{6, 7, 10},
		{6, 7, 10, 100, 120, 4000},
		{2, 6, 4000},
	}

	for i := 0; i < len(items); i++ {
		n := NewNode()
		Insert(items[i], n)

		if !n.LookupSubset(items[i]) {
			t.Errorf("Expected LookupSubset of %v to return true after Insert of %v.", items[i], items[i])
		}

		suff := append(items[i], []int32{1000, 2000, 3000}...)
		if !n.LookupSubset(suff) {
			t.Errorf("Expected LookupSubset of %v to return true after Insert of %v.", suff, items[i])
		}

		pref := append([]int32{-3000, -2000, -1000}, items[i]...)
		if !n.LookupSubset(pref) {
			t.Errorf("Expected LookupSubset %v to return true after Insert of %v.", pref, items[i])
		}

		both := append(append([]int32{-3000, -2000, -1000}, items[i]...), []int32{1000, 2000, 3000}...)
		if !n.LookupSubset(both) {
			t.Errorf("Expected LookupSubset %v to return true after Insert of %v.", both, items[i])
		}
	}

}

func TestUBTreeLookupBoundedSubset(t *testing.T) {

	items := [][]int32{
		{1, 2, 4, 6},
		{1, 2, 6},
		{1, 6},
		{6, 7, 10},
		{6, 7, 10, 100, 120, 4000},
		{2, 6, 4000},
	}

	for i := 0; i < len(items); i++ {
		n := NewNode()
		Insert(items[i], n)

		l := len(items[i])

		// Using l as the bound, LookupBoundedSubset should return true.

		if !n.LookupBoundedSubset(items[i], l) {
			t.Errorf("Expected LookupBoundedSubset of %v to return true after Insert of %v.", items[i], items[i])
		}

		suff := append(items[i], []int32{1000, 2000, 3000}...)
		if !n.LookupBoundedSubset(suff, l) {
			t.Errorf("Expected LookupBoundedSubset of %v to return true after Insert of %v.", suff, items[i])
		}

		pref := append([]int32{-3000, -2000, -1000}, items[i]...)
		if !n.LookupBoundedSubset(pref, l) {
			t.Errorf("Expected LookupBoundedSubset %v to return true after Insert of %v.", pref, items[i])
		}

		both := append(append([]int32{-3000, -2000, -1000}, items[i]...), []int32{1000, 2000, 3000}...)
		if !n.LookupBoundedSubset(both, l) {
			t.Errorf("Expected LookupBoundedSubset %v to return true after Insert of %v.", both, items[i])
		}

		// Using l-1 as the bound, LookupBoundedSubset should return true.

		if n.LookupBoundedSubset(items[i], l-1) {
			t.Errorf("Expected LookupBoundedSubset of %v to return false after Insert of %v.", items[i], items[i])
		}

		suff = append(items[i], []int32{1000, 2000, 3000}...)
		if n.LookupBoundedSubset(suff, l-1) {
			t.Errorf("Expected LookupBoundedSubset of %v to return false after Insert of %v.", suff, items[i])
		}

		pref = append([]int32{-3000, -2000, -1000}, items[i]...)
		if n.LookupBoundedSubset(pref, l-1) {
			t.Errorf("Expected LookupBoundedSubset %v to return false after Insert of %v.", pref, items[i])
		}

		both = append(append([]int32{-3000, -2000, -1000}, items[i]...), []int32{1000, 2000, 3000}...)
		if n.LookupBoundedSubset(both, l-1) {
			t.Errorf("Expected LookupBoundedSubset %v to return false after Insert of %v.", both, items[i])
		}

	}

}

func TestUBTreeInsertIfNotSubsumed(t *testing.T) {
	n := NewNode()
	// These need not be sorted
	items := [][]int32{
		{6, 1},
		{7, 10, 6},
		{2, 6, 4000},
	}

	subsumed_items := [][]int32{
		{2, 4, 6, 1},
		{2, 6, 1},
		{7, 10, 6, 100, 120, 4000},
	}

	// Insert, if not subsumed, all items
	all := append(items, subsumed_items...)
	for i := 0; i < len(all); i++ {
		n.InsertIfNotSubsumed(all[i], ubtree_simplevel)
	}

	// All items in 'items' should be present.
	for i := 0; i < len(items); i++ {
		if !n.LookupExact(items[i]) {
			t.Errorf("Expected LookupExact to return true after InsertIfNotSubsumed.")
		}
	}

	// None of the subsumed items should be present.
	for i := 0; i < len(subsumed_items); i++ {
		if n.LookupExact(subsumed_items[i]) {
			t.Errorf("Expected LookupExact to return true after InsertIfNotSubsumed.")
		}
	}
}

func TestUBTreeInsertIfNotTwoBoundedSubsumed(t *testing.T) {
	n := NewNode()
	// These need not be sorted
	items := [][]int32{
		{6, 1},
		{7, 10, 120},
		{2, 6, 4000},
		{7, 10, 6, 100, 120, 4000},
	}

	two_bounded_subsumed_items := [][]int32{
		{2, 4, 6, 1},
		{2, 6, 1},
	}

	// Insert, if not subsumed, all items
	all := append(items, two_bounded_subsumed_items...)
	for i := 0; i < len(all); i++ {
		n.InsertIfNotBoundedSubsumed(all[i], 2, ubtree_simplevel)
	}

	// All items in 'items' should be present.
	for i := 0; i < len(items); i++ {
		if !n.LookupExact(items[i]) {
			t.Errorf("Did not find %v after InsertIfNotBoundedSubsumed", items[i])
		}
	}

	// None of the subsumed items should be present.
	for i := 0; i < len(two_bounded_subsumed_items); i++ {
		if n.LookupExact(two_bounded_subsumed_items[i]) {
			t.Errorf("Found %v after InsertIfNotBoundedSubsumed", two_bounded_subsumed_items[i])
		}
	}
}

func TestUBTreeInsertIfNotThreeBoundedSubsumed(t *testing.T) {
	n := NewNode()
	// These need not be sorted
	items := [][]int32{
		{6, 1},
		{7, 10, 120},
		{2, 6, 4000},
		{20, 30, 50, 60, 80},
		{10, 20, 30, 40, 50, 60, 70, 80},
	}

	three_bounded_subsumed_items := [][]int32{
		{2, 4, 6, 1},
		{2, 6, 1},
		{7, 10, 6, 100, 120, 4000},
	}

	// Insert, if not subsumed, all items
	all := append(items, three_bounded_subsumed_items...)
	for i := 0; i < len(all); i++ {
		n.InsertIfNotBoundedSubsumed(all[i], 3, ubtree_simplevel)
	}

	// All items in 'items' should be present.
	for i := 0; i < len(items); i++ {
		if !n.LookupExact(items[i]) {
			t.Errorf("Did not find %v after InsertIfNotBoundedSubsumed", items[i])
		}
	}

	// None of the subsumed items should be present.
	for i := 0; i < len(three_bounded_subsumed_items); i++ {
		if n.LookupExact(three_bounded_subsumed_items[i]) {
			t.Errorf("Found %v after InsertIfNotBoundedSubsumed", three_bounded_subsumed_items[i])
		}
	}
}

func TestUBTreeInsertToDimacs(t *testing.T) {
	n := NewNode()
	items := [][]int32{
		{1, 2, 4, 6},
		{1, 2, 6},
		{1, 6},
		{6, 7, 10},
		{6, 7, 10, 100, 120, 4000},
		{2, 6, 4000},
		{7, 10, 100},
	}

	// Insert all items
	for i := 0; i < len(items); i++ {
		Insert(items[i], n)
	}

	// Convert to Dimacs
	const truncate = false
	f := n.ToDimacs(truncate)

	// Check whether the number of clauses is correct
	if int(f.GetM()) != len(items) {
		t.Errorf("Clauses in Dimacs: expected %d, actual %d", len(items), f.GetM())
	}

	// Convert back to UBTree
	n = NewNode()
	n.InsertDimacs(f)

	// Check that all the items are present
	for i := 0; i < len(items); i++ {
		if !n.LookupExact(items[i]) {
			t.Errorf("LookupExact failed for %v", items[i])
		}
	}

}

func TestUBTreeInsertToDimacsTruncate(t *testing.T) {
	n := NewNode()
	items := [][]int32{
		{1, 2, 4, 6},
		{1, 2, 6},
		{1, 6},
		{6, 7, 10},
		{6, 7, 10, 100, 120, 4000},
		{2, 6, 4000},
		{7, 10, 100},
		{1, 2, 4, 6, 10, 14},
	}

	truncated_items := [][]int32{
		{1, 2, 4, 6},
		{1, 2, 6},
		{1, 6},
		{6, 7, 10},
		//{6, 7, 10, 100, 120, 4000}, // Do not uncomment.
		{2, 6, 4000},
		{7, 10, 100},
		//{1, 2, 4, 6, 10, 14}, // Do not uncomment.
	}

	// Insert all items
	for i := 0; i < len(items); i++ {
		Insert(items[i], n)
	}

	// Convert to Dimacs
	const truncate = true
	f := n.ToDimacs(truncate)

	// Check whether the number of clauses is correct
	if int(f.GetM()) != len(truncated_items) {
		t.Errorf("Clauses in Dimacs: expected %d, actual %d", len(items), f.GetM())
	}

	// Convert back to UBTree
	n = NewNode()
	n.InsertDimacs(f)

	// Check that all the items are present
	for i := 0; i < len(truncated_items); i++ {
		if !n.LookupExact(truncated_items[i]) {
			t.Errorf("LookupExact failed for %v", items[i])
		}
	}

}

func TestUBTreeInsertToBoundedDimacsTrivial(t *testing.T) {
	n := NewNode()
	items := [][]int32{
		{1, 2, 4, 6},
		{1, 2, 6},
		{1, 6},
		{6, 7, 10},
		{6, 7, 10, 100, 120, 4000},
		{2, 6, 4000},
		{7, 10, 100},
	}

	// Insert all items
	for i := 0; i < len(items); i++ {
		Insert(items[i], n)
	}

	// Convert to Dimacs
	const truncate = false
	f := n.ToBoundedDimacs(truncate, uint64(len(items)+1))

	// Check whether the number of clauses is correct
	if int(f.GetM()) != len(items) {
		t.Errorf("Clauses in Dimacs: expected %d, actual %d", len(items), f.GetM())
	}

	// Convert back to UBTree
	n = NewNode()
	n.InsertDimacs(f)

	// Check that all the items are present
	for i := 0; i < len(items); i++ {
		if !n.LookupExact(items[i]) {
			t.Errorf("LookupExact failed for %v", items[i])
		}
	}

}

func TestUBTreeInsertToBoundedDimacsTruncateTrivial(t *testing.T) {
	n := NewNode()
	items := [][]int32{
		{1, 2, 4, 6},
		{1, 2, 6},
		{1, 6},
		{6, 7, 10},
		{6, 7, 10, 100, 120, 4000},
		{2, 6, 4000},
		{7, 10, 100},
		{1, 2, 4, 6, 10, 14},
	}

	truncated_items := [][]int32{
		{1, 2, 4, 6},
		{1, 2, 6},
		{1, 6},
		{6, 7, 10},
		//{6, 7, 10, 100, 120, 4000}, // Do not uncomment.
		{2, 6, 4000},
		{7, 10, 100},
		//{1, 2, 4, 6, 10, 14}, // Do not uncomment.
	}

	// Insert all items
	for i := 0; i < len(items); i++ {
		Insert(items[i], n)
	}

	// Convert to Dimacs
	const truncate = true
	f := n.ToBoundedDimacs(truncate, uint64(len(truncated_items)+1))

	// Check whether the number of clauses is correct
	if int(f.GetM()) != len(truncated_items) {
		t.Errorf("Clauses in Dimacs: expected %d, actual %d", len(items), f.GetM())
	}

	// Convert back to UBTree
	n = NewNode()
	n.InsertDimacs(f)

	// Check that all the items are present
	for i := 0; i < len(truncated_items); i++ {
		if !n.LookupExact(truncated_items[i]) {
			t.Errorf("LookupExact failed for %v", items[i])
		}
	}

}

func TestUBTreeInsertToBoundedDimacs(t *testing.T) {
	n := NewNode()
	items := [][]int32{
		{1, 2, 4, 6},
		{1, 2, 6},
		{1, 6},
		{6, 7, 10},
		{6, 7, 10, 100, 120, 4000},
		{2, 6, 4000},
		{7, 10, 100},
	}

	// Insert all items
	for i := 0; i < len(items); i++ {
		Insert(items[i], n)
	}

	// Convert to Dimacs
	const truncate = false
	bound := uint64(len(items) - 2)
	f := n.ToBoundedDimacs(truncate, bound)

	// Check whether the number of clauses is correct
	if uint64(f.GetM()) != bound {
		t.Errorf("Clauses in Dimacs: expected %d, actual %d", len(items), f.GetM())
	}

	// Convert back to UBTree
	n = NewNode()
	n.InsertDimacs(f)

	// Check that bound number of items are present in n now.
	count := 0
	for i := 0; i < len(items); i++ {
		if n.LookupExact(items[i]) {
			count++
		}
	}
	if uint64(count) != bound {
		t.Errorf("ToBoundedDimacs: expected %d items, actual %d", bound, count)
	}

}

func TestUBTreeInsertToBoundedDimacsTruncate(t *testing.T) {
	n := NewNode()
	items := [][]int32{
		{1, 2, 4, 6},
		{1, 2, 6},
		{1, 6},
		{6, 7, 10},
		{6, 7, 10, 100, 120, 4000},
		{2, 6, 4000},
		{7, 10, 100},
		{1, 2, 4, 6, 10, 14},
		{400, 500, 600},
	}

	truncated_items := [][]int32{
		{1, 2, 4, 6},
		{1, 2, 6},
		{1, 6},
		{6, 7, 10},
		//{6, 7, 10, 100, 120, 4000}, // Do not uncomment.
		{2, 6, 4000},
		{7, 10, 100},
		//{1, 2, 4, 6, 10, 14}, // Do not uncomment.
		{400, 500, 600},
	}

	// Insert all items
	for i := 0; i < len(items); i++ {
		Insert(items[i], n)
	}

	// Convert to Dimacs
	const truncate = true
	bound := uint64(len(items) - 3)
	f := n.ToBoundedDimacs(truncate, bound)

	// Check whether the number of clauses is correct
	if uint64(f.GetM()) != bound {
		t.Errorf("Clauses in Dimacs: expected %d, actual %d", len(items), f.GetM())
	}

	// Convert back to UBTree
	n = NewNode()
	n.InsertDimacs(f)

	// Check that bound number of items are present in n now.
	count := 0
	for i := 0; i < len(truncated_items); i++ {
		if n.LookupExact(truncated_items[i]) {
			count++
		}
	}
	if uint64(count) != bound {
		t.Errorf("ToBoundedDimacs: expected %d items, actual %d", bound, count)
	}

}
