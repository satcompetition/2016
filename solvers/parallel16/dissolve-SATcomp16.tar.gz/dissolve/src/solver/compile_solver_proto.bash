#!/bin/bash

# requires: protoc and protoc-gen-go are in your $PATH

# this script is a utility for compiling solver.proto.
# It updates the following files:
# $GO_PATH/solver.pb.go
# $CPP_PATH/solver.pb.{cc,h}

GO_OUTPUT_PATH="./"
CPP_OUTPUT_PATH="../../ssolver/glucose-3.0/core/"
protoc --go_out=$GO_OUTPUT_PATH solver.proto
protoc --cpp_out=$CPP_OUTPUT_PATH solver.proto
