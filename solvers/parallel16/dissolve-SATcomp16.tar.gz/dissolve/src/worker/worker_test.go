package worker

import (
	"dsolver"
	"flag"
	"fmt"
	"github.com/golang/protobuf/proto"
	"solver"
	"testing"
	"time"
)

//var FatalIfNonNil = solver.FatalIfNonNil
var globalW map[int32]*Worker

var solverFlag = flag.String("solver", "../../ssolver/glucose-3.0/bin/solver", "Path to seq. solver for test")
var glucose = "../../ssolver/glucose-3.0/bin/solver"
var cvc4 = "../../ssolver/cvc4-2015-09-19/builds/bin/cvc4"
var seqsolver = cvc4

const worker_addr int32 = 12345

func newWorkerOrDie(t *testing.T, addr int32) *Worker {
	if globalW == nil {
		globalW = make(map[int32]*Worker)
	}
	if w, ok := globalW[addr]; !ok {
		var err error
		w, err = NewWorker(seqsolver, nil, addr)
		solver.FatalIfNonNil(err, "Start Worker:")
		globalW[addr] = w
		time.Sleep(500 * time.Millisecond)
	}
	return globalW[addr]
}

func DeleteWorker(t *testing.T, addr int32) {
	if _, ok := globalW[addr]; !ok {
		delete(globalW, addr)
	}
}

func TestGetWorker(t *testing.T) {
	w := newWorkerOrDie(t, worker_addr)
	t.Log(w.Solver)
}

func TestWorkerSolve(t *testing.T) {
	w := newWorkerOrDie(t, worker_addr)
	//cnf := "../../inputs/sat/f0010-01-s.cnf"
	//expected := solver.SolverAnswer_SAT
	cnf := "../../ssolver/cvc4-2015-09-19/test/regress/regress1/arith/lpsat-goal-9.smt2"
	expected := solver.SolverAnswer_UNSAT
	typ := dsolver.DSolverRequest_SOLVE.Enum()
	k := int32(1)
	n := int32(1)
	request := &dsolver.DSolverRequest{
		Request: &solver.SolverRequest{
			Clauses: &solver.Dimacs{
				ClausesFile: proto.String(cnf),
			},
			SolverOptions: &solver.SolverOptions{
				PropagationBudget:       proto.Uint64(100000),
				ZerothPropagationBudget: proto.Uint64(100000),
			},
		},
		T: typ,
		K: proto.Int32(k),
		N: proto.Int32(n),
		RequestId: &dsolver.DSolverRequestId{
			Id: proto.Int64(1),
		},
		SolveId: proto.Int64(1),
	}
	response := &dsolver.DSolverResponse{
		Reply: &solver.SolverReply{},
	}
	w.Solve(request, response)
	ans := response.Reply.GetAnswer()
	if ans != expected {
		t.Errorf("For %s, output %s, expected %s.", cnf, ans.String(), expected.String())
	}
}

func TestWorkerCancel(t *testing.T) {
	w := newWorkerOrDie(t, worker_addr)
	//cnf := "../../inputs/h195-90.cnf"
	cnf := "../../ssolver/cvc4-2015-09-19/test_unsat2.smt2"
	expected := solver.SolverAnswer_UNKNOWN
	request := &dsolver.DSolverRequest{
		Request: &solver.SolverRequest{
			Clauses: &solver.Dimacs{
				// h195-90.pb takes a long time (>10s) which is good enough for
				// cancellation.
				ClausesFile: proto.String(cnf),
			},
			SolverOptions: &solver.SolverOptions{},
		},
		RequestId: &dsolver.DSolverRequestId{
			Id: proto.Int64(1),
		},
		SolveId: proto.Int64(1),
	}

	response := &dsolver.DSolverResponse{
		Reply: &solver.SolverReply{},
	}
	done := make(chan bool)
	go func() {
		w.Solve(request, response)
		done <- true
	}()

	time.Sleep(time.Second * 5)
	creq := &dsolver.CancelRequest{
		SolveId: proto.Int64(1),
	}
	cresp := &dsolver.CancelResponse{}
	err := w.Cancel(creq, cresp)

	solver.FatalIfNonNil(err, "Cancel:")
	switch cresp.GetStatus() {
	case dsolver.CancelResponse_CANCELLED:
		fmt.Println("CANCELLED woo hoo")
	default:
		t.Errorf("Expected CANCELLED, got %s", cresp)
	}

	// Make sure the SOLVE request actually finishes.
	_ = <-done
	fmt.Println("SOLVE request has finished")

	ans := response.Reply.GetAnswer()
	if ans != expected {
		t.Errorf("For %s, output %s, expected %s.", cnf, ans.String(), expected.String())
	}
}

func TestWorkerBudgetLimit(t *testing.T) {
	w := newWorkerOrDie(t, worker_addr)
	//cnf := "../../inputs/h195-90.cnf"
	cnf := "../../ssolver/cvc4-2015-09-19/test_unsat2.smt2"
	expected := solver.SolverAnswer_UNKNOWN
	request := &dsolver.DSolverRequest{
		Request: &solver.SolverRequest{
			Clauses: &solver.Dimacs{
				// h195-90.pb takes a long time (>10s) which is good enough for
				// cancellation.
				ClausesFile: proto.String(cnf),
			},
			SolverOptions: &solver.SolverOptions{
				PropagationBudget: proto.Uint64(30000),
			},
		},
		RequestId: &dsolver.DSolverRequestId{
			Id: proto.Int64(1),
		},
		SolveId: proto.Int64(1),
	}

	response := &dsolver.DSolverResponse{
		Reply: &solver.SolverReply{},
	}
	w.Solve(request, response)
	fmt.Println("SOLVE request has finished")
	ans := response.Reply.GetAnswer()
	if ans != expected {
		t.Errorf("For %s, output %s, expected %s.", cnf, ans.String(), expected.String())
	}

	// send the same request again
	//request.Request.RequestId = proto.Int64(1)
	request.SolveId = proto.Int64(2)
	request.Request.SolverOptions.PropagationBudget = proto.Uint64(30000)
	w.Solve(request, response)
	fmt.Println("SOLVE request has finished")
	ans = response.Reply.GetAnswer()
	if ans != expected {
		t.Errorf("For %s, output %s, expected %s.", cnf, ans.String(), expected.String())
	}
}

/////
// Tests for the interactions between the worker and the workerManager
// These tests could not be written in workermanager_test.go because of cyclic dependencies
/////
var globalWM *dsolver.WorkerManager

func newWorkerManagerOrDie(t *testing.T) *dsolver.WorkerManager {
	if globalWM == nil {
		spawn := make(chan bool)
		globalWM, _ = dsolver.NewWorkerManager(spawn)
	}
	return globalWM
}

func TestWorkerManagerConnect(t *testing.T) {
	wm := newWorkerManagerOrDie(t)
	w := newWorkerOrDie(t, worker_addr)
	go wm.AddPeer(fmt.Sprintf("127.0.0.1:%d", worker_addr))
	fmt.Println(w)
	peer := <-wm.AvailablePeers
	wm.PeerStatus()
	t.Log("peer connected: ", peer)
}

// TODO: this test does not behave as expected, even though it passes
func TestWorkerManagerPeerDisconnect(t *testing.T) {
	// start a workermanager and a worker
	wm := newWorkerManagerOrDie(t)
	newWorkerOrDie(t, worker_addr)
	go wm.AddPeer(fmt.Sprintf("127.0.0.1:%d", worker_addr))
	time.Sleep(time.Second)
	// delete the worker
	// TODO : how to do that ?
	DeleteWorker(t, worker_addr)
	time.Sleep(time.Second)
	done := make(chan bool)
	// workermanager has a disconnected worker
	var peer *dsolver.Peer
	go func() {
		peer = <-wm.AvailablePeers
		if !wm.IsLive(peer) {
			t.Log("Worker is not connected")
			peer = <-wm.AvailablePeers
			t.Log("Worker has reconnected")
		} else {
			t.Log("Worker is still connected")
		}
		done <- true
	}()
	time.Sleep(2 * time.Second)
	newWorkerOrDie(t, worker_addr)
	<-done
}

func TestWorkerManagerSolve(t *testing.T) {
	wm := newWorkerManagerOrDie(t)
	w := newWorkerOrDie(t, worker_addr)
	go wm.AddPeer(fmt.Sprintf("127.0.0.1:%d", worker_addr))
	fmt.Println(w)

	cnf := "../../inputs/sat/f0010-01-s.cnf"
	expected := solver.SolverAnswer_SAT
	typ := dsolver.DSolverRequest_SOLVE.Enum()
	k := int32(1)
	n := int32(1)
	request := &dsolver.DSolverRequest{
		Request: &solver.SolverRequest{
			Clauses: &solver.Dimacs{
				ClausesFile: proto.String(cnf),
			},
			SolverOptions: &solver.SolverOptions{
				PropagationBudget:       proto.Uint64(100000),
				ZerothPropagationBudget: proto.Uint64(100000),
			},
		},
		T: typ,
		K: proto.Int32(k),
		N: proto.Int32(n),
	}
	out := make(chan dsolver.Instance)
	wm.IssueSolve(request, out)
	response := <-out
	ans := response.Response.Reply.GetAnswer()
	if ans != expected {
		t.Errorf("For %s, output %s, expected %s.", cnf, ans.String(), expected.String())
	}
}

// Testing the case where a cancelling is triggered while the request is active
func TestWorkerManagerCancel(t *testing.T) {
	wm := newWorkerManagerOrDie(t)
	w := newWorkerOrDie(t, worker_addr)
	go wm.AddPeer(fmt.Sprintf("127.0.0.1:%d", worker_addr))
	fmt.Println(w)

	cnf := "../../inputs/h195-90.cnf"
	expected := solver.SolverAnswer_UNKNOWN
	request := &dsolver.DSolverRequest{
		Request: &solver.SolverRequest{
			Clauses: &solver.Dimacs{
				// h195-90.pb takes a long time (>10s) which is good enough for
				// cancellation.
				ClausesFile: proto.String(cnf),
			},
			SolverOptions: &solver.SolverOptions{},
		},
	}

	out := make(chan dsolver.Instance)
	reqId := wm.IssueSolve(request, out)

	time.Sleep(time.Second)

	wm.CancelSolve(reqId)
	response := <-out
	ans := response.Response.Reply.GetAnswer()
	if ans != expected {
		t.Errorf("For %s, output %s, expected %s.", cnf, ans.String(), expected.String())
	}
}

// Testing the case where a cancelling is triggered on a waiting request
func TestWorkerManagerEarlyCancel(t *testing.T) {
	wm := newWorkerManagerOrDie(t)
	w := newWorkerOrDie(t, worker_addr)
	fmt.Println(w)

	cnf := "../../inputs/h195-90.cnf"
	expected := solver.SolverAnswer_UNKNOWN
	request := &dsolver.DSolverRequest{
		Request: &solver.SolverRequest{
			Clauses: &solver.Dimacs{
				// h195-90.pb takes a long time (>10s) which is good enough for
				// cancellation.
				ClausesFile: proto.String(cnf),
			},
			SolverOptions: &solver.SolverOptions{},
		},
	}

	out := make(chan dsolver.Instance)
	reqId := wm.IssueSolve(request, out)

	time.Sleep(time.Second)
	wm.CancelSolve(reqId)
	time.Sleep(time.Second)
	go wm.AddPeer(fmt.Sprintf("127.0.0.1:%d", worker_addr))

	response := <-out
	ans := response.Response.Reply.GetAnswer()
	if ans != expected {
		t.Errorf("For %s, output %s, expected %s.", cnf, ans.String(), expected.String())
	}
}

func TestCleanReturn(t *testing.T) {
	w := newWorkerOrDie(t, worker_addr)
	w.SolverCommand.Process.Kill()
}
