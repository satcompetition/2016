package worker

import (
	"dsolver"
	"encoding/binary"
	"fmt"
	"github.com/golang/protobuf/proto"
	"io"
	"log"
	"net"
	"net/http"
	"net/rpc"
	"os"
	"os/exec"
	"solver"
	"strconv"
	"syscall"
	"time"
)

// Worker are the go objects that 'encapsulate' the sequential solvers
// and can solve DSolverRequest_SOLVE requests
// they should be used by RPC calls to Solve and Cancel
type Worker struct {
	// the instance of the running solver, and its input/output pipes
	SolverCommand exec.Cmd
	SolverInput   io.WriteCloser
	SolverOutput  io.ReadCloser

	// The address this DSolver listens on.
	Addr net.Addr
	Port int32

	// Written to and read from before and after calling solver.Solve.
	// TODO: do we still need this ?
	solveThrottle chan int

	// id of the request being currently processed
	currentId int64 // TODO should not be a int64, but a SolveId

	// cancelling requests go there
	quit chan bool

	// Name of the sequential solver executable
	Solver string
	// Additional args to pass to 'Solver'. Can be empty.
	SolverArgs []string
}

func NewWorker(Solver string, SolverArgs []string, Port int32) (*Worker, error) {
	w := &Worker{
		solveThrottle: make(chan int, 1),
		quit:          make(chan bool),
		Solver:        Solver,
		SolverArgs:    SolverArgs,
		currentId:     0,
		Port:          Port,
	}

	rpc.Register(w)
	rpc.HandleHTTP()
	l, e := net.Listen("tcp", fmt.Sprintf(":%d", Port))
	if e != nil {
		return nil, e
	}
	w.Addr = l.Addr()
	http.HandleFunc("/status", w.StatusHandler)
	go http.Serve(l, nil)

	// start the sequential solver and establish a pipe interface
	w.SolverCommand = *exec.Command(w.Solver, w.SolverArgs...)
	w.SolverInput, _ = w.SolverCommand.StdinPipe()
	w.SolverOutput, _ = w.SolverCommand.StdoutPipe()
	w.SolverCommand.Stderr = os.Stderr

	err := w.SolverCommand.Start()
	if err != nil {
		log.Fatal("Solver could not be started: ", err)
	}
	return w, nil
}

// StatusHandler reports status information on the DSolver via an HTTP request
// to host:port/status of the DSolver.
func (w *Worker) StatusHandler(f http.ResponseWriter, r *http.Request) {
	req := &dsolver.StatusRequest{}
	resp := &dsolver.StatusResponse{}
	err := w.Status(req, resp)
	if err != nil {
		log.Fatalf("Worker cannot report status: %s", err)
	}
	fmt.Fprintf(f, "Status: %s\n", proto.CompactTextString(resp))
}

func (w *Worker) Status(in *dsolver.StatusRequest, out *dsolver.StatusResponse) error {
	out.Solver = proto.String(w.Solver)
	out.Port = proto.Int32(w.Port)
	return nil
}

func (w *Worker) Solve(req *dsolver.DSolverRequest, resp *dsolver.DSolverResponse) error {
	err := w.doSolve(req, resp)
	return err
}

func (w *Worker) Cancel(req *dsolver.CancelRequest, resp *dsolver.CancelResponse) error {
	log.Printf("received a CancelRequest for request ", req.GetSolveId())
	if req.GetSolveId() != w.currentId {
		// we receive a cancel request for another request
		// this is unexpected by design
		//log.Fatal("received a CancelRequest for request ", req.GetSolveId(), " while the worker computes request ", w.currentId)
		log.Println("received a CancelRequest for request ", req.GetSolveId(), " while the worker computes request ", w.currentId)
		return nil
	}
	w.quit <- true
	resp.Status = dsolver.CancelResponse_CANCELLED.Enum()
	log.Printf("CancelRequest for request ", req.GetSolveId(), " has been processed")
	return nil
}

// doSolve handles Solve RPCs where DSolverRequest.GetT() is SOLVE. The actual
// solving is performed by the sequential solver.
func (w *Worker) doSolve(in *dsolver.DSolverRequest, out *dsolver.DSolverResponse) error {
	var err error

	// this channel should have a buffer of 1 to deal with the case where
	// 1 - a cancelling is about to come
	// 2 - the computation of the worker terminates
	// 3 - the cancelling adds true inside the channel, but will never be read by the Run method since it's aleady finished
	w.quit = make(chan bool, 1)

	// set this to false to use the 'old' interface between go/c++ (communication via files on disk)
	// if true, use the new interface via pipes
	const usePipeInterface = true

	// Limit the number of concurrent SOLVE requests
	log.Println("Waiting for doSolve, request", in.GetSolveId())
	w.solveThrottle <- 1
	w.currentId = in.GetSolveId()
	log.Println("Starting doSolve for request", in.GetSolveId())

	start := time.Now()
	if usePipeInterface {
		err = w.Run(w.quit, in, out)
	} else {
		c := solver.NewSolverCmd(w.Solver, w.SolverArgs, in.Request, out.Reply)
		err = c.Run(w.quit)
	}
	//}
	elapsed := time.Since(start).Seconds()
	log.Println("Finished doSolve for request", in.GetSolveId())
	<-w.solveThrottle
	times := []float64{elapsed}
	// Record the local computation time in the DSolverResponse.
	switch out.Reply.GetAnswer() {
	case solver.SolverAnswer_UNSAT:
		out.UnsatTimes = times
		log.Println("doSolve found UNSAT for request", in.GetSolveId(), ", finished with error:", err)
	case solver.SolverAnswer_SAT:
		out.SatTimes = times
		log.Println("doSolve found SAT for request", in.GetSolveId(), ", finished with error:", err)
	case solver.SolverAnswer_UNKNOWN:
		out.UnknownTimes = times
		log.Println("doSolve found UNKNOWN for request", in.GetSolveId(), ", finished with error:", err)
	}
	if err != nil {
		log.Println("ERROR:", w.Solver, "finished with error:", err)
	}
	return err
}

func (w *Worker) Run(quit chan bool, in *dsolver.DSolverRequest, out *dsolver.DSolverResponse) error {
	var err error

	// these two lines are for debugging purpose:
	// the solver request is stored in /tmp/protobuf.pb
	//tin, err := os.Create("/tmp/protobuf.pb")
	//solver.MarshalToFileOrDie(in.Request, tin)
	//PbToFile(0, 10, "/tmp/protobufv2", in.Request)

	buf := proto.NewBuffer(nil)
	if err = buf.Marshal(in.Request); err != nil {
		log.Fatal("Marshal error: ", err)
	}
	log.Println("Write writes ", len(buf.Bytes()), " bytes")

	// TODO: make it work on machine using Big Endian encoding
	// we send an interrupt to signal the sequential solver we are ready to send a request
	w.SolverCommand.Process.Signal(syscall.SIGXCPU)

	b := make([]byte, 4)
	binary.LittleEndian.PutUint32(b, uint32(len(buf.Bytes())))
	_, err = w.SolverInput.Write(b)
	_, err = w.SolverInput.Write(buf.Bytes())
	log.Println("wrote to pipe err:", err)

	done := make(chan error)

	var size uint32
	var SolverResBuf []byte

	go func() {
		b_input := make([]byte, 4)
		log.Println("Waiting for message size, instance", in.GetSolveId())
		n, e := io.ReadFull(w.SolverOutput, b_input)
		if e != nil || n != 4 {
			log.Fatalf("Error:", e)
		}
		size = binary.LittleEndian.Uint32(b_input)
		SolverResBuf = make([]byte, size)
		log.Println("Waiting for message of size", size, "instance", in.GetSolveId())
		n, e = io.ReadAtLeast(w.SolverOutput, SolverResBuf, int(size))
		if e != nil || n != int(size) {
			log.Fatalf("Error:", e)
		}
		log.Println("has received ", size, " bytes of data,  error:", e)
		out.Reply = &solver.SolverReply{}
		proto.Unmarshal(SolverResBuf, out.Reply)
		//PbToFile(0, 10, "/tmp/protobufv2-res", out.Reply)
		done <- e
	}()

	select {
	case err = <-done:
	case sigint := <-quit:
		if sigint {
			w.SolverCommand.Process.Signal(syscall.SIGINT)
			log.Println("SIGINT has been sent to instance", in.GetSolveId())
		} else {
			w.SolverCommand.Process.Kill()
		}
		err = <-done
	}

	log.Println("Read has read ", size, " bytes")
	return err

}

func PbToFile(attempt int, max_attempt int, filename string, pb proto.Message) {
	if attempt > max_attempt {
		return
	}
	if _, exist := os.Stat(filename + strconv.Itoa(attempt) + ".pb"); exist == nil {
		PbToFile(attempt+1, max_attempt, filename, pb)
	} else {
		tin, _ := os.Create(filename + strconv.Itoa(attempt) + ".pb")
		solver.MarshalToFileOrDie(pb, tin)
	}
}
