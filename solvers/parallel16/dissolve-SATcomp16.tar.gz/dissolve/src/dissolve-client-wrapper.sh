#!/bin/bash

SCRIPT_DIR=$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )


# we use the date as the ID, (shoud be unique...)
date=$(date +%Y%m%d%H%M%S)

echo "Launching dissolve-client"
$SCRIPT_DIR/dissolve-client -id=$date $@

