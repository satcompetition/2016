#!/bin/bash

SCRIPT_DIR=$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )
CVC4="../ssolver/cvc4-2015-09-19/builds/bin/cvc4"
GLUCOSE="../ssolver/solver"

SOLVER=$GLUCOSE

pkill -9 ${SOLVER}
pkill -9 dissolve-server
pkill -9 dissolve-server-bin
pkill -9 worker-bin
pkill -9 worker-bin-bin
#rm -f /tmp/dsolver.output /tmp/worker*.output
sleep 3

N=${1:-4}
shift

echo "Starting $N instances of dissolve-server"
PORTBASE=28000
PEERS=""
for((i=1;i<=$N;i++)); do
	PT=$((${PORTBASE}+$i))
	echo "New peer on port ${PT}"
	if [ -z "$PEERS" ] ; then
		PEERS=":${PT}"
	else
		PEERS="${PEERS},:${PT}"
	fi
done
echo "Peer definition ${PEERS}"
for((i=1;i<=$N;i++)); do
	echo ${SCRIPT_DIR}/worker-bin $@ -port $((28000+${i})) -solver ${SCRIPT_DIR}/../${SOLVER}
	${SCRIPT_DIR}/worker-bin $@ -port $((28000+${i})) -solver ${SCRIPT_DIR}/${SOLVER} >> /tmp/worker${2}${i}.output 2>&1 &
done

sleep 1

# starting server
echo ${SCRIPT_DIR}/dissolve-server $@ -port ${PORTBASE} -peers ${PEERS} 
${SCRIPT_DIR}/dissolve-server $@ -port ${PORTBASE} -peers ${PEERS} -cpuprofile=/tmp/dissolve_cpuprofile >> /tmp/dsolver${2}.output 2>&1 &

# for sequential solver
#echo "Starting 1 instance of dissolve-server for sequential solving"
#${SCRIPT_DIR}/dissolve-server $@ -port 27999 -peers :27999 -solver ${SCRIPT_DIR}/../ssolver/solver -simplifier ${SCRIPT_DIR}/../ssolver/simplifier > /tmp/dsolver_seq.output 2>&1 &
