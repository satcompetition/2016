package main

import (
	"flag"
	"fmt"

	"dsolver"
	"solver"

	"github.com/golang/protobuf/proto"
)

var dimacsFlag = flag.String("dimacs", "", "Path to a serialized solver.Dimacs proto")
var requestFlag = flag.String("solver_request", "", "Path to a serialized solver.SolverRequest proto")
var replyFlag = flag.String("solver_reply", "", "Path to a serialized solver.SolverReply proto")
var drequestFlag = flag.String("dsolver_request", "", "Path to a serialized dsolver.DSolverRequest proto")
var dreplyFlag = flag.String("dsolver_reply", "", "Path to a serialized dsolver.DSolverResponse proto")

func main() {
	flag.Parse()
	DumpProto(*dimacsFlag, "Dimacs", &solver.Dimacs{})
	DumpProto(*requestFlag, "SolverRequest", &solver.SolverRequest{})
	DumpProto(*replyFlag, "SolverReply", &solver.SolverReply{})
	DumpProto(*drequestFlag, "DSolverRequest", &dsolver.DSolverRequest{})
	DumpProto(*dreplyFlag, "DSolverResponse", &dsolver.DSolverResponse{})
}

func DumpProto(path, pName string, pb proto.Message) {
	if len(path) > 0 {
		solver.UnmarshalFromFileOrDie(path, pb)
		fmt.Printf("%s file: %s\n", pName, path)
		fmt.Println(proto.MarshalTextString(pb))
	}
}
