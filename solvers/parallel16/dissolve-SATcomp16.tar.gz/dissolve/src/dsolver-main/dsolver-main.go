package main

import (
	"flag"
	"io"
	"io/ioutil"
	"log"
	"os"
	"os/exec"
	"runtime"
	"runtime/pprof"
	"strings"
	"time"

	"github.com/golang/protobuf/proto"

	"dsolver"
)

var (
	portFlag  = flag.Int("port", 6282, "Port the DSolver listens on")
	peersFlag = flag.String("peers", "",
		`Comma separated list of DSolver peers to connect to. `+
			`E.g., a.b.c.d:1234,e.f.g.h:1234,i.j.k.l:1234.`)
	cpuprofile     = flag.String("cpuprofile", "", "write cpu profile to file")
	disableLogFlag = flag.Bool("disablelog", false, "disable all logging")
	maxCPUsFlag    = flag.Int("maxcpu", runtime.NumCPU(), "number of CPUs allowed")
)

func main() {
	flag.Parse()
	if *cpuprofile != "" {
		f, err := os.Create(*cpuprofile)
		if err != nil {
			log.Fatal(err)
		}
		pprof.StartCPUProfile(f)
	}
	runtime.GOMAXPROCS(*maxCPUsFlag)

	if *disableLogFlag {
		log.SetOutput(ioutil.Discard)
	}

	d, ch, err := dsolver.NewDSolver(GetPeers(), GetOpts())
	if err != nil {
		log.Fatalf("Failed to create DSolver: %s", err)
	}
	for {
		select {
		case <-ch:
			if *cpuprofile != "" {
				pprof.StopCPUProfile()
			}
		case <-time.After(time.Minute):
			PrintStatus(os.Stdout, d)
		}
	}
}

func PrintStatus(w io.Writer, d *dsolver.DSolver) {
	req := &dsolver.StatusRequest{}
	resp := &dsolver.StatusResponse{}
	err := d.Status(req, resp)
	if err != nil {
		log.Fatalf("DSolver cannot report status: %s", err)
	}
	log.Println(w, "Status: ", proto.CompactTextString(resp))
}

func GetPeers() []string {
	if len(*peersFlag) == 0 {
		log.Fatal("No peers specified")
	}
	addrs := strings.Split(*peersFlag, ",")
	for i, addr := range addrs {
		addrs[i] = strings.TrimSpace(addr)
		log.Print("New peer: ", addrs[i])
	}
	return addrs
}

func GetOpts() dsolver.DSolverOpts {
	return dsolver.DSolverOpts{
		Port: GetPort(),
	}
}

func GetPort() int32 {
	p := *portFlag
	if p < 0 || p >= 65536 {
		log.Fatalf("Invalid port: %d", p)
	}
	return int32(*portFlag)
}

func GetExe(path string) string {
	p, err := exec.LookPath(path)
	if err != nil {
		log.Fatalf("Executable '%s' not found: %s", path, err)
	}
	return p
}
