#!/bin/bash

MACHINES="velveeta.cs.wisc.edu point.cs.wisc.edu"
SRC="./dsolver-main"
TGTBIN="dsolver-main-${USER}"
TGT="/scratch/${USER}/${TGTBIN}"

# copy the binary to machines
for M in ${MACHINES}; do
  echo "+++ rsync dsolver-main to ${M}:${TGT}"
  rsync -e ssh ./dsolver-main "${USER}@${M}:${TGT}"
  rsync -e ssh ../../ssolver/simplifier "${USER}@${M}:/scratch/${USER}/"
  rsync -e ssh ../../ssolver/solver "${USER}@${M}:/scratch/${USER}/"
done
echo ""

# Kill existing jobs
for M in ${MACHINES}; do
  echo "+++ KILLing ${TGTBIN} on ${M}"
  ssh $USER@${M} killall -9 ${TGTBIN}
done
echo ""

# Create peer definition
N=${1:-4}
PORTBASE=${2:-28000}
PEERS=""
for M in ${MACHINES}; do
  for((i=0;i<$N;i++)); do
    PT=$((${PORTBASE}+$i))
    # echo "New peer ${M}:${PT}"
    PEERS="${PEERS},${M}:${PT}"
  done
done
# Remove initial ','
PEERS=$(echo ${PEERS} | sed 's/^,//')
echo "PEER=${PEERS}"
echo ""

#-peers="": Comma separated list of DSolver peers to connect to. E.g., a.b.c.d:1234,e.f.g.h:1234,i.j.k.l:1234.
#-port=6282: Port the DSolver listens on
#-simplifier="../../ssolver/simplifier": Path to simplivier executable
#-solve_concurrenty=2: Maximum number of concurrent solver invocations.
#-solver="../../ssolver/solver": Path to solver executable

for M in ${MACHINES}; do
  echo "Launching $N instances of dsolver-main on ${M} starting at port ${PORTBASE}"
  for((i=0;i<$N;i++)); do
    PT=$((${PORTBASE}+$i))
    CMD="${TGT} --peers=${PEERS} --port=${PT} --simplifier=/scratch/${USER}/simplifier --solver=/scratch/${USER}/solver"
    # echo "+++ On ${M} launch ${CMD}"
    ssh ${USER}@${M} "screen -d -m ${CMD}"
  done
done

# Jobs are launched, send queries
echo ""
for M in ${MACHINES}; do
  echo "+++ SEND queries to ${M}:${PORTBASE} through port $((${PORTBASE}+${N}-1))"
  echo "+++ KILL dsolvers on ${M} with ssh ${USER}@${M} killall -9 ${TGTBIN}"
  echo ""
done
