package main

import (
	"flag"
	"fmt"
	"log"
	"math/rand"
	"os"
	"path"
	"time"

	"dsolver"
	"github.com/golang/protobuf/proto"
	"solver"
)

var (
	portFlag       = flag.Int("port", 6282, "Port the DSolver listens on")
	solverFlag     = flag.String("solver", "../../ssolver/solver", "Path to executable solver")
	simplifierFlag = flag.String("simplifier", "../../ssolver/simplifier", "Path to simplifier executable")
	kFlag          = flag.Int("k", 2, "Simulate dilemma split on 'k' variables")
	roundsFlag     = flag.Int("rounds", 10, "Maximum number of rounds before giving up")
	learntsFlag    = flag.Uint64("learnts", 50000, "The initial number of learned clauses maintained per round")
	conflictsFlag  = flag.Uint64("conflicts", 200000, "The initial conflict budget (the default value takes about 10 secs.)")
)

// State holds state for simulation
type State struct {
	k       int
	h       dsolver.DLHistory
	d       *dsolver.DSolver
	request *dsolver.DSolverRequest
	// responses holds the DSolverResponses generated from each round, in order.
	responses []*dsolver.DSolverResponse
}

func main() {
	flag.Parse()
	start := time.Now()
	defer func() {
		log.Println("Total execution time:", time.Since(start))
	}()
	if len(flag.Args()) == 0 {
		log.Fatal("Missing input.pb")
	}
	st := InitState()
	reply := &solver.SolverReply{}

	for round := 0; round < *roundsFlag; round++ {
		cBudg := dsolver.GetConflictBudget(round)
		st.request.Request.ConflictBudget = proto.Uint64(cBudg)
		lBudg := dsolver.GetLearntsBudget(round) >> uint64(st.k)
		st.request.Request.MaxLearntsOut = proto.Uint64(lBudg)
		reply = Run(st, reply)
		if IsSolved(st, reply) {
			return
		}
	}
	fmt.Println()
	log.Printf("Failed to solve the input in %d rounds\n", *roundsFlag)
	log.Printf("s INDETERMINATE") // This is the standard format for outputting the answer
}

type Instance struct {
	// i for the i^th instance
	i          int
	req        *solver.SolverRequest
	response   *dsolver.DSolverResponse
	elapsedSec float64
}

func Run(st *State, reply *solver.SolverReply) *solver.SolverReply {
	fmt.Println("\n=================================================")
	round := len(st.responses)
	fmt.Printf("===== ROUND %d, conflict budget %d, DL %+v\n",
		round, st.request.Request.GetConflictBudget(), reply.DecisionLits)
	fmt.Println("=================================================\n")
	// 3) O/w, SolverReply contains
	//     DL) an ordered set of decision_lits
	//     LC) a set of learnt clauses
	// 4) Pick the first 'k' of those and ...
	k := st.k
	if len(reply.DecisionLits) < k {
		k = len(reply.DecisionLits)
	}
	DL := reply.DecisionLits[:k]
	aCh := make(chan []int32)
	iCh := make(chan Instance)
	// ... generate 2^k assumptions
	go GenAssumes(DL, aCh)
	// 5) Run 2^k instances of DSolver.Solve, each with the given conflict budget
	go EachAssume(st, reply, aCh, iCh)
	response := Reduce(st, iCh)
	st.responses = append(st.responses, response)
	return response.Reply
}

// GenAssumes generates 2^k slices of assumptions to 'ch', where k=len(decLits).
// Example
//    Input:    decLits = [3, 4]
//    Outputs:  [3, 4], [3, -4], [-3, 4], [-3, -4]
func GenAssumes(decLits []int32, ch chan<- []int32) {
	// 2^k
	max := 1 << uint(len(decLits))
	for code := 0; code < max; code++ {
		assumption := make([]int32, len(decLits))
		// code's binary form encodes one of the 2^k assumptions.
		for pos, lit := range decLits {
			if code&(1<<uint(pos)) > 0 {
				assumption[pos] = lit
			} else {
				assumption[pos] = -lit
			}
		}
		ch <- assumption
	}
	// Close the channel when done so the reader exits.
	close(ch)
}

// EachAssume generates a SolverRequest req for each assumption A.
// 'req' gets assumption from A; learnts from reply.Learnts.
// 'reply' is the SolverReply from the previous iteration.
func EachAssume(st *State, reply *solver.SolverReply, aCh <-chan []int32, iCh chan<- Instance) {
	i := 0
	for A := range aCh {
		log.Printf("Instance %5d with A:%+v\n", i, A)
		req_i := &solver.SolverRequest{}
		solver.CopyProto(st.request.Request, req_i)
		req_i.Assumptions = A
		// No need to copy here, reply.Learnts won't be modified via req_i
		if reply.Learnts != nil {
			req_i.Learnts = reply.Learnts
		}
		if reply.Polarities != nil {
			req_i.Polarities = reply.Polarities
		}
		// Initiailize random seed
		req_i.RandSeed = proto.Float64(rand.Float64())
		inst := Instance{
			i:   i,
			req: req_i,
		}
		start := time.Now()
		inst.response = RunSolver(st, req_i)
		inst.elapsedSec = time.Since(start).Seconds()
		iCh <- inst
		i++
	}
	// Close the channel when done so the reader exits.
	close(iCh)
}

func Reduce(st *State, iCh <-chan Instance) *dsolver.DSolverResponse {
	round := len(st.responses)
	// Holds Instance.elapsedSec for each instance. Used to report a timing
	// histogram at the end of Reduce.
	var unsatElapsed, unknownElapsed []float64
	// reply is the output for this round. That is, reply is the
	// reduction of all the instances streamed over 'iCh'.
	response := &dsolver.DSolverResponse{
		Reply: &solver.SolverReply{
			Learnts: &solver.Dimacs{
				N:       st.request.Request.Clauses.N,
				M:       proto.Int32(0),
				Clauses: []int32{},
			},
			DecisionLits: []int32{},
		},
	}
	reply := response.Reply
	st.h.StartRound()
	for inst := range iCh {
		// Convert Instance to dsolver.Instance for passing to dsolver.Reduce
		dinst := dsolver.Instance{
			Index:    inst.i,
			Response: inst.response,
			Elapsed:  inst.elapsedSec,
		}
		st.d.Reduce(st.request, response, &st.h, dinst)
	}
	st.h.StopRound()
	if (round == 0 && len(response.UnsatTimes) == 1) ||
		(len(response.UnsatTimes) == 1<<uint(st.k)) {
		reply.Answer = solver.SolverAnswer_UNSAT.Enum()
		return response
	}
	// reply.DecisionLits is filled with the keys in dlCounts sorted by their values (i.e., counts)
	// log.Printf("dlCounts: %+v\n", dlCounts)
	reply.DecisionLits = st.h.Get(st.k)
	log.Printf("Round %5d %d UNSAT, %d UNKNOWN, learned %d clauses, generated DL:%+v\n",
		round, len(unsatElapsed), len(unknownElapsed), reply.Learnts.GetM(), reply.DecisionLits)
	err := st.d.Simplify(reply.Learnts, reply.Learnts)
	solver.FatalIfNonNil(err, "Simplify error: ")
	dsolver.EmitHistogram("UNSAT", unsatElapsed, 10 /* numBkts */)
	dsolver.EmitHistogram("UKNOWN", unknownElapsed, 10 /* numBkts */)
	return response
}

func IsSolved(st *State, reply *solver.SolverReply) bool {
	if reply != nil && reply.Answer != nil {
		log.Printf("%s says '%s' is %s\n",
			path.Base(*solverFlag), InputFile(), reply.GetAnswer())
		if reply.GetAnswer() == solver.SolverAnswer_SAT {
			log.Printf("Model: %+v", reply.Model)
		}
		// This is the standard way of outputting the answer
		if reply.GetAnswer() == solver.SolverAnswer_SAT {
			log.Printf("s SATISFIABLE")
		} else {
			log.Printf("s UNSATISFIABLE")
		}
		// Solved!
		return true
	}
	return false
}

// RunInstance runs DSolver.Solve on 'req'. It is a fatal error if DSolver
// encounters an error.
func RunSolver(st *State, req *solver.SolverRequest) *dsolver.DSolverResponse {
	request := &dsolver.DSolverRequest{
		Request: req,
		// T: Avoid allocation by not setting T b/c default is SOLVE.
	}
	response := &dsolver.DSolverResponse{}
	// log.Printf("...running solver with {N:%d M:%d A:%+v}\n", req.Clauses.GetN(), req.Clauses.GetM(), req.Assumptions)
	err := st.d.Solve(request, response)
	solver.FatalIfNonNil(err, "Solve error:")
	return response
}

func InputFile() string {
	return flag.Arg(0)
}

func InitState() *State {
	inputFile := InputFile()
	_, err := os.Stat(inputFile)
	if err != nil {
		log.Fatal(fmt.Errorf("invalid input file: %s", flag.Arg(0)))
	}
	d, err := dsolver.NewDSolver([]string{}, GetOpts())
	if err != nil {
		log.Fatal(fmt.Errorf("failed to create DSolver: %s", err))
	}
	st := &State{
		k: *kFlag,
		d: d,
		request: &dsolver.DSolverRequest{
			Request: &solver.SolverRequest{},
		},
	}
	solver.UnmarshalFromFileOrDie(inputFile, st.request.Request)
	inputStr := proto.CompactTextString(st.request)
	if len(inputStr) > 80 {
		log.Printf("Input: %.80s...\n", inputStr)
	} else {
		log.Printf("Input: %sn", inputStr)
	}
	return st
}

func GetOpts() dsolver.DSolverOpts {
	return dsolver.DSolverOpts{
		Port:           GetPort(),
		Solver:         *solverFlag,
		SolverArgs:     []string{},
		Simplifier:     *simplifierFlag,
		SimplifierArgs: []string{},
	}
}

func GetPort() int32 {
	p := *portFlag
	if p < 0 || p >= 65536 {
		log.Fatalf("Invalid port: %d", p)
	}
	return int32(p)
}
