#!/bin/bash

SCRIPT_DIR=$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )
CVC4="../ssolver/cvc4-2015-09-19/builds/bin/cvc4"
GLUCOSE="../ssolver/solver"

SOLVER=$GLUCOSE

# make sure previous program instances are not running
pkill -9 ${SOLVER}
pkill -9 dissolve-server
pkill -9 dissolve-server-bin
pkill -9 worker-bin
pkill -9 worker-bin-bin
#rm -f /tmp/dsolver.output /tmp/worker*.output
sleep 0.3s

N=${1:-4}
shift

echo "c Starting $N instances of dissolve-server"
PORTBASE=28000
PEERS=""
for((i=1;i<=$N;i++)); do
	PT=$((${PORTBASE}+$i))
	echo "c New peer on port ${PT}"
	if [ -z "$PEERS" ] ; then
		PEERS=":${PT}"
	else
		PEERS="${PEERS},:${PT}"
	fi
done
echo "c Peer definition ${PEERS}"
for((i=1;i<=$N;i++)); do
	echo c ${SCRIPT_DIR}/worker-bin $@ -port $((28000+${i})) -solver ${SCRIPT_DIR}/../${SOLVER}
	${SCRIPT_DIR}/worker-bin $@ -port $((28000+${i})) -solver ${SCRIPT_DIR}/${SOLVER} >> /tmp/worker${2}${i}.output 2>&1 &
done

sleep 0.2s

# starting server
echo c ${SCRIPT_DIR}/dissolve-server $@ -disablelog=true -port ${PORTBASE} -peers ${PEERS} 
${SCRIPT_DIR}/dissolve-server $@ -disablelog=true -port ${PORTBASE} -peers ${PEERS} >> /tmp/dsolver${2}.output 2>&1 &
#${SCRIPT_DIR}/dissolve-server $@ -disablelog=false -port ${PORTBASE} -peers ${PEERS} >> /tmp/dsolver${2}.output 2>&1 &

sleep 1s
