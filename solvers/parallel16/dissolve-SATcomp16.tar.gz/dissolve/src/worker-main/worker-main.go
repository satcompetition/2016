package main

import (
	"flag"
	"fmt"
	"io"
	"log"
	"os"
	"os/exec"
	"runtime/pprof"
	//"strings"
	"dsolver"
	"github.com/golang/protobuf/proto"
	"time"
	"worker"
)

var (
	portFlag   = flag.Int("port", 6282, "Port the DSolver listens on")
	solverFlag = flag.String("solver", "../ssolver/glucose-3.0/bin/solver", "Path to solver executable")
	cpuprofile = flag.String("cpuprofile", "", "write cpu profile to file")
)

func main() {
	flag.Parse()
	if *cpuprofile != "" {
		f, err := os.Create(*cpuprofile)
		if err != nil {
			log.Fatal(err)
		}
		pprof.StartCPUProfile(f)
		defer pprof.StopCPUProfile()
	}
	w, err := worker.NewWorker(GetExe(*solverFlag), nil, GetPort())
	if err != nil {
		log.Fatalf("Failed to create Worker: %d", err)
	}
	for {
		PrintStatus(os.Stdout, w)
		time.Sleep(time.Minute)
	}
}

func PrintStatus(wr io.Writer, w *worker.Worker) {
	req := &dsolver.StatusRequest{}
	resp := &dsolver.StatusResponse{}
	err := w.Status(req, resp)
	if err != nil {
		log.Fatalf("Worker cannot report status: %s", err)
	}
	fmt.Fprintf(wr, "Status: %s\n", proto.CompactTextString(resp))
}

func GetPort() int32 {
	p := *portFlag
	if p < 0 || p >= 65536 {
		log.Fatalf("Invalid port: %d", p)
	}
	return int32(*portFlag)
}

func GetExe(path string) string {
	p, err := exec.LookPath(path)
	if err != nil {
		log.Fatalf("Executable '%s' not found: %s", path, err)
	}
	return p
}
