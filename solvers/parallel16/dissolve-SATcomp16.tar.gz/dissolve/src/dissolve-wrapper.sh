#!/bin/bash

SCRIPT_DIR=$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )

NBCORES=$1
shift

echo "Launching servers"
sh $SCRIPT_DIR/run-server.sh $NBCORES

echo "Sleeping 1s"
sleep 2

echo "Launching dissolve-client"
$SCRIPT_DIR/dissolve-client $@

