dissolve
========

A distributed SAT solver


INSTALL
-------
Method 1:
- run make in the dissolve directory

Method 2:
- install golang 1.3.3 http://golang.org/dl/
- install goprotobuf https://code.google.com/p/goprotobuf/
- export GOPATH=$GOPATH:/path/to/dissolve
- install gflags 1.7 into dissolve/ssolver/glucose-3.0/third-party/glog
- install glog 0.3.3 into dissolve/ssolver/glucose-3.0/third-party/glog
- install protobuf 2.5.0 into dissolve/ssolver/glucose-3.0/third-party/protobuf
- To compile ssolver: run scons in dissolve/ssolver/glucose-3.0. Copy solver and simplifier binaries from glucose-3.0/bin into dissolve/ssolver. 

RUNNING DISSOLVE
----------------

Execute the dissolve-satcomp16.sh script with the CNF file as argument
example use: ./dissolve-satcomp16.sh formula.cnf

IMPORTANT NOTES
---------------
* Note that ONLY ONE instance of dissolve can be run at a time on a given machine (otherwise, there is an collision in the ports the different solver will be listening to)
* the dissolve-satcomp16.sh script and all other files in this directory should not be copied to another directory, otherwise the scripts might not work anymore.
