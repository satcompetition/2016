#!/bin/bash

SCRIPT_DIR=$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )

NBCORES=48

echo "c Launching servers"
$SCRIPT_DIR/src/run-server.sh $NBCORES

echo "c Launching dissolve-client"
K=5
prop=20000000
$SCRIPT_DIR/src/dissolve-client -time_limit=100000  -k=${K} -timeout_request=5 -propagations=${prop} -ubtree_simp_level=1 -dec_lits_out=100 -use_polarities=false $@

