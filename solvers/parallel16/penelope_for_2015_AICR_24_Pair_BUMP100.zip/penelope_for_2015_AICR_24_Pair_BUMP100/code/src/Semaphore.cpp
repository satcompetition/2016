#include "penelope/utils/Semaphore.h"

using namespace penelope;

Semaphore::Semaphore(bool multiProcessShared, int initialValue){
    sem_init(&sema,multiProcessShared? 0 : 1, initialValue);
}

Semaphore::~Semaphore(){
    sem_destroy(&sema);
}

void Semaphore::signal(){
    sem_post(&sema);
}

void Semaphore::wait(){
    sem_wait(&sema);
}

bool Semaphore::tryWait(){
    return sem_trywait(&sema) == 0;
}

