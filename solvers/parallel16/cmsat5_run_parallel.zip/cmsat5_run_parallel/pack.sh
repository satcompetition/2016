#!/bin/bash

set -e
set -x

(
cd m4ri-20140914
make clean
rm -rf .libs
rm -rf myinstall
)

rm -rf build
rm -f bin/crypto*
rm -f ./*.zip

(
cd bin
cp "${1}" starexec_run_default
)

zip -r "cmsat5_${1}.zip" ./*
