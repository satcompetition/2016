#include <penelope/utils/Asserts.h>
unsigned long int __nb_Asserts = 0;
