/*
 * This file was created automatically. Do not change it.
 * If you want to distribute the source code without
 * git, make sure you include this file in your bundle.
 */
#include "coprocessor/version.h"

const char* Coprocessor::gitSHA1            = "v6.0";
const char* Coprocessor::gitDate            = "Sat Apr 16 21:38:29 2016";
const char* Coprocessor::coprocessorVersion = "6.0.0";
const char* Coprocessor::signature          = "coprocessor 6.0.0 build v6.0";
