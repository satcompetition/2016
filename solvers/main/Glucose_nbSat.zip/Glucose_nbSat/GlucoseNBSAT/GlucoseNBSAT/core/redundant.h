#define NONE -1
#define FALSE 0
#define TRUE 1

template<class Vec, class Idx>
class vec2 {
  vec<Vec> occs;
 public:
    // Don't allow copying (error prone):
  vec2<Vec, Idx>&  operator = (vec2<Vec, Idx>& other) { assert(0); return *this; }
  vec2<Vec, Idx>        (vec2<Vec, Idx>& other) { assert(0); }

    vec2() {}
    void  init      (const Idx& idx){ occs.growTo(toInt(idx)+1); }
    Vec&  operator[](const Idx& idx){ return occs[toInt(idx)]; }
    void  clear(){
      int i;
      for(i=0; i<occs.size(); i++)
	occs[i].shrink_(occs[i].size());
      occs.shrink_(occs.size());
    }
};

class ClauseLS {
  int nbTrueLit;

 public:
  CRef cr;
  
 ClauseLS(CRef cr_) : nbTrueLit(0)  {};
  int nbTrue()  const   {return nbTrueLit;}
  void setNbTrue(int i) {nbTrueLit=i;}
};

typedef int CRefLS;
