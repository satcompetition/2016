#include "GlucoseNBSAT/mtl/Sort.h"
#include "GlucoseNBSAT/core/Solver.h"
#include "GlucoseNBSAT/core/Constants.h"
#include "GlucoseNBSAT/utils/System.h"

using namespace Glucose;

// sattime functions

#define noRedundant -7
#define redundant -77
#define newRedundant -777
#define oldRedundant -7777
#define perfectRslvtn -77777
#define nonPerfectRslvtn 0
#define noRslvtn         -3

struct sortClause_lt {    
    ClauseAllocator& ca;
    sortClause_lt(ClauseAllocator& ca_) : ca(ca_) {}
    bool operator () (CRef x, CRef y) {
        return ca[x].size() > ca[y].size();
    }
};

struct sortLiterals_lt {
    vec2<vec<CRefLS>, Lit>& inClauses;
    sortLiterals_lt(vec2<vec<CRefLS>, Lit>& inClauses_) : inClauses(inClauses_) {}
    bool operator () (Lit lit1, Lit  lit2) {
        return inClauses[lit1].size() < inClauses[lit2].size();
    }
};

void Solver::clear_inovled_clauses(vec<int>& involved) {
    int i;
    for(i=0; i<involved.size(); i++)
        if (clausesLS[involved[i]].nbTrue() > 0)
            clausesLS[involved[i]].setNbTrue(0);
    involved.shrink_(involved.size());
}

bool Solver::contain(CRef cr, Lit lit) {
    Clause& c=ca[cr];
    for(int i=0; i<c.size(); i++)
        if (lit==c[i])
            return true;
    return false;
}

int Solver::containVar(CRef cr, Lit lit) {
    Clause& c=ca[cr];
    for(int i=0; i<c.size(); i++) {
        if (lit==c[i])
            return 1;
        else if (var(lit) == var(c[i]))
            return -1;
    }
    return 0;
}

bool Solver::removed(CRef cr) {
    return ca[cr].mark() == 1;
}

void Solver::reorganizeClausesLS() {
    int i, j;
    clearInClausesLists();   clausesLS_fillPointer=0;

    for(i=j=0; i<clauses.size(); i++) {
        CRef cr=clauses[i];
        if (!removed(cr)) {
            ClauseLS& cls=clausesLS[clausesLS_fillPointer];
            cls.cr=cr; cls.setNbTrue(0);
            Clause& c = ca[cr];
            for(int j=0; j<c.size(); j++)
                inClauses[c[j]].push(clausesLS_fillPointer);
            clausesLS_fillPointer++;
            clauses[j++]=cr;
        }
    }
    clauses.shrink_(i-j);
    printf("c reornanize inClauses...with %d subsumed clauses and %d removed clauses\n", nbSubsumed, i-j);
}

void Solver::addIntoInClauses(CRef newCr) {
    Clause& newC=ca[newCr];
    if (clausesLS_fillPointer>=clausesLS_size) {
        printf("c realloc clausesLS in learning....\n");
        clausesLS_size=(int) (1.2*clausesLS_size);
        clausesLS=(ClauseLS*) realloc(clausesLS, clausesLS_size*sizeof(ClauseLS));
    }
    ClauseLS& cls=clausesLS[clausesLS_fillPointer];
    cls.cr=newCr; cls.setNbTrue(0);
    for(int j=0; j<newC.size(); j++)
        inClauses[newC[j]].push(clausesLS_fillPointer);
    clausesLS_fillPointer++;
}

//clause oldCr contains literals lits[0], ..., lits[pivotIndex-1]
// and ~lits[pivotIndex]. Check if oldCr contains other literals of lits
// if yes, remove oldCr and add oldCr after excluding ~lits[pivotIndex].
// the added clause is original if oldCr is original
// If the resolvent subsumes both oldCr and lits (like 2 3 subsumes 1 2 3  
// and -1 2 3), then the function returns perfectRslvtn
int Solver::resolve(CRef oldCr, int pivotIndex, vec<Lit>& lits) {
    int i;
    for(i=pivotIndex+1; i<lits.size(); i++)
        if (!contain(oldCr, lits[i]))
            return noRslvtn;
    Clause& c=ca[oldCr]; Lit p=~lits[pivotIndex];
    resolvent.clear();
    for(i=0; i<c.size(); i++) {
        if (value(c[i])==l_True)
            return noRslvtn;
        else if (value(c[i]) != l_False && (c[i]!=p))
            resolvent.push(c[i]);
        //   else printf("c ****falsified lit\n");
    }
    nbResolved++;

    if (certifiedUNSAT) {
        if (vbyte) {
            write_char('a');
            for (int i = 0; i < resolvent.size(); i++)
                write_lit(2*(var(resolvent[i])+1) + sign(resolvent[i]));
            write_lit(0);
        }
        else {
            for (int i = 0; i < resolvent.size(); i++)
                fprintf(certifiedOutput, "%i " , (var(resolvent[i]) + 1) *
                        (-2 * sign(resolvent[i]) + 1) );
            fprintf(certifiedOutput, "0\n");
        }
    }

    if (resolvent.size()==1) {
        if (value(resolvent[0]) == l_Undef) {
            printf("c one unit clause is obtained by resolution\n");
            uncheckedEnqueue(resolvent[0]);nbUn++;
        }
        else if (value(resolvent[0]) != l_True)
            printf("c ****contradiction by resolution****\n");
    }
    else {
        CRef cr=ca.alloc(resolvent, false);
        clauses.push(cr);
        attachClause(cr);
        //  addIntoInClauses(cr);
    }
    if (ca[oldCr].size()==lits.size())
        return perfectRslvtn;
    else return nonPerfectRslvtn;
}

// redundant clauses due to newCr are placed in the redundantClauses stack.
// newCr can be resolved with an old clause so that the resolvent subsumes
// both, in this case, the function returns perfectRslvtn.
int Solver::getRedundantClauses_for_preproc(CRef newCr) {
    int i, j, k, result=noRslvtn;

    Clause& newC = ca[newCr];
    lits.clear(); redundantClauses.clear();
    uint32_t newAbstraction = 0;
    for(i=0; i<newC.size(); i++) {
        if (value(newC[i])==l_True) {
            return result;
            printf("c bizzar lit true in preproc...\n");
        }
        else if (value(newC[i])!=l_False) {
            lits.push(newC[i]);
            newAbstraction |= 1 << (var(lits[i]) & 31);
        }
    }
    sort(lits, sortLiterals_lt(inClauses));
    vec<CRefLS>& ks=inClauses[lits[0]];
    for(k=0; k<ks.size(); k++) {
        CRef cr=clausesLS[ks[k]].cr;
        if (clausesLS[ks[k]].nbTrue()>=0 && ca[cr].size()>=lits.size() && !removed(cr) &&
                ((newAbstraction & ~ca[cr].abstraction()) == 0))
            redundantClauses.push(ks[k]);
    }
    for(i=1; i<lits.size(); i++) {
        for(j=k=0; j<redundantClauses.size(); j++) {
            ClauseLS& cls=clausesLS[redundantClauses[j]];
            int res=containVar(cls.cr, lits[i]);
            if (res==1) //clausesLS[redundantClauses[j]].cr contains lits[i]
                redundantClauses[k++]=redundantClauses[j];
            else if (res==-1) {
                //clausesLS[redundantClauses[j]].cr contains ~lits[i]
                int res=resolve(cls.cr, i, lits);
                if (res==perfectRslvtn)
                    result=perfectRslvtn;
                if (res != noRslvtn) {
                    removeClause(cls.cr);
                    cls.setNbTrue(redundant);
                }
            }
        }
        redundantClauses.shrink_(j-k);
        if (k==0) return result;
    }
    return result;
}

// redundant clauses due to newCr are placed in the redundantClauses stack.
// newCr can be resolved with an old clause so that the resolvent subsumes
// both, in this case, the function returns perfectRslvtn.
int Solver::getRedundantClauses(CRef newCr) {
    int i, j, k, result=noRslvtn;

    Clause& newC = ca[newCr];
    lits.clear(); redundantClauses.clear();
    uint32_t newAbstraction = 0;
    for(i=0; i<newC.size(); i++) {
        if (value(newC[i])==l_True)
            return result;
        else if (value(newC[i])!=l_False) {
            lits.push(newC[i]);
            newAbstraction |= 1 << (var(lits[i]) & 31);
        }
    }
    sort(lits, sortLiterals_lt(inClauses));
    vec<CRefLS>& ks=inClauses[lits[0]];
    for(k=0; k<ks.size(); k++) {
        CRef cr=clausesLS[ks[k]].cr;
        if (clausesLS[ks[k]].nbTrue()>=0 && ca[cr].size()>=lits.size() && !removed(cr) &&
                ((newAbstraction & ~ca[cr].abstraction()) == 0))
            redundantClauses.push(ks[k]);
    }
    for(i=1; i<lits.size(); i++) {
        for(j=k=0; j<redundantClauses.size(); j++) {
            ClauseLS& cls=clausesLS[redundantClauses[j]];
            int res=containVar(cls.cr, lits[i]);
            if (res==1) //clausesLS[redundantClauses[j]].cr contains lits[i]
                redundantClauses[k++]=redundantClauses[j];
            else if (res==-1) {
                //clausesLS[redundantClauses[j]].cr contains ~lits[i]
                int res=resolve(cls.cr, i, lits);
                // if (res==perfectRslvtn)
                //   result=perfectRslvtn;
                if (res != noRslvtn) {
                    removeClause(cls.cr);
                    cls.setNbTrue(redundant);
                }
            }
        }
        redundantClauses.shrink_(j-k);
        if (k==0) return result;
    }
    return result;
}

bool Solver::replaceRedundantOriClause(CRef newCr) {
    int i, result;
    if (ca[newCr].size()>20 || ca[newCr].size()>maxOriClauseLength)
        return false;
    bool keepNew=true;
    int saved=clauses.size();
    result=getRedundantClauses(newCr);
    // if (result == perfectRslvtn)
    //   return false;
    if (redundantClauses.size()>0) {
        for(i=0; i<redundantClauses.size(); i++) {
            if (keepNew && ca[clausesLS[redundantClauses[i]].cr].size()==lits.size()) {
                keepNew=false;
            }
            else {
                clausesLS[redundantClauses[i]].setNbTrue(redundant);
                removeClause(clausesLS[redundantClauses[i]].cr);
                nbSubsumed++;
            }
        }
        if (keepNew) {
            Clause& newC=ca[newCr];
            newC.setLearnt(false);
            newC.calcAbstraction();
            clauses.push(newCr);
        }
    }
    else return false;
    for(i=saved; i<clauses.size(); i++)
        addIntoInClauses(clauses[i]);
    return keepNew;
}

// use the nbTrue slot for redundant clause detecting
int Solver::markRedundantClause(int cIndex) {
    int i, result;
    bool keepNew=true;

    ClauseLS& cls=clausesLS[cIndex]; CRef newCr=cls.cr;
    result=getRedundantClauses_for_preproc(newCr);
    if (result == perfectRslvtn) {
        keepNew=false;
        removeClause(newCr);  cls.setNbTrue(redundant);
    }
    if (redundantClauses.size()>0) {
        for(i=0; i<redundantClauses.size(); i++) {
            if (keepNew && ca[clausesLS[redundantClauses[i]].cr].size()==lits.size()) {
                keepNew=false;
                removeClause(newCr); cls.setNbTrue(redundant);
            }
            else {
                clausesLS[redundantClauses[i]].setNbTrue(redundant);
                removeClause(clausesLS[redundantClauses[i]].cr);
                nbSubsumed++;
            }
        }
    }
    if (!keepNew)
        return newRedundant;
    else if (redundantClauses.size()>0 || result != noRslvtn)
        return oldRedundant;
    else return noRedundant;
}

void Solver::clearInClausesLists() {
    int i;
    for(i=0; i<nVars(); i++) {
        Lit p=mkLit(i, false);
        inClauses[p].shrink_(inClauses[p].size());
        inClauses[~p].shrink_(inClauses[~p].size());
    }
}

bool Solver::markRedundantClauses(vec<CRef>& cs) {
    int i, res, cIndex;
    bool isRedundant=false;

    for(i=0; i<cs.size(); i++) {
        if (clausesLS_fillPointer >= clausesLS_size) {
            printf("c realloc clausesLS in preprocessing....\n");
            clausesLS_size=(int) (1.2*clausesLS_size);
            clausesLS=(ClauseLS*) realloc(clausesLS, clausesLS_size*sizeof(ClauseLS));
        }
        cIndex=clausesLS_fillPointer;
        ClauseLS& cls=clausesLS[cIndex];
        cls.cr=cs[i]; cls.setNbTrue(0);
        clausesLS_fillPointer++;
        res=markRedundantClause(cIndex);
        if (res == newRedundant)
            isRedundant=true;
        else {
            Clause& c = ca[cls.cr];
            for(int j=0; j<c.size(); j++)
                inClauses[c[j]].push(cIndex);
            if (res == oldRedundant)
                isRedundant=true;
        }
    }
    return isRedundant;
}

void Solver::removeRedundantsClauses(){
    int i, originalClausesSize, LearntsSize;
    bool originalRemove, learntRemove;
    static int oldSubsumed=0;

    double begin=cpuTime();
    sort(clauses, sortClause_lt(ca));
    clearInClausesLists();
    clausesLS_fillPointer=0;
    originalClausesSize=clauses.size();
    originalRemove=markRedundantClauses(clauses);
    // sort(learnts, sortClause_lt(ca));
    learntRemove=false; //markRedundantClauses(learnts, involved);
    if (originalRemove || learntRemove) {
        clauses.shrink_(clauses.size());
        assert(clauses.size()==0);
        LearntsSize=learnts.size();
        //  learnts.shrink_(LearntsSize);
        for(i=0; i<clausesLS_fillPointer; i++) {
            ClauseLS& cls=clausesLS[i];
            if (cls.nbTrue()>=0) {
                if (ca[cls.cr].learnt())
                    learnts.push(cls.cr);
                else clauses.push(cls.cr);
            }
            //    else removeClause(cls.cr);
        }
        printf("c total number of literals: %llu\n", clauses_literals + learnts_literals);
        printf("c %d original clauses are subsumed and %d are redundant and removed over %d clauses\n",
               nbSubsumed-oldSubsumed, originalClausesSize-clauses.size(), originalClausesSize);
        printf("c %d original clauses are resolved and shortened\n", nbResolved);
        oldSubsumed=nbSubsumed;
        printf("c %d learnt clauses are redundant and removed over %d clauses\n",
               LearntsSize-learnts.size(), LearntsSize);
    }
    printf("c redundancies removed in %12.2f secs\n", cpuTime()-begin);
}

