

#include "riss/utils/Statistics-mt.h"

// global accessable statistics object

Statistics statistics;