For compiling:

../starexec_build

---------------

For running:

../bin/starexec_run_default <OPTION>

